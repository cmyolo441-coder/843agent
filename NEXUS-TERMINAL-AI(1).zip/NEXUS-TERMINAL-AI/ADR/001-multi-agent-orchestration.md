# ADR 001 — Multi-Agent Orchestration

## Status
Accepted — 2025-09-14

## Context
A single LLM call cannot reliably plan, execute, critique and refine in one shot.
We need orchestrated specialization.

## Decision
Adopt a coordinator + role-specialized worker pattern (planner / executor / critic /
researcher / synthesizer), all async, communicating through a typed message bus.

## Consequences
- Higher latency per task, but improved quality and traceability
- Explicit roles map naturally onto auditing and metering
- Requires a robust async scheduler (see ADR 004)
