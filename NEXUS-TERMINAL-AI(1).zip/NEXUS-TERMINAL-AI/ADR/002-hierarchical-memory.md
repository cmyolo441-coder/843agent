# ADR 002 — Hierarchical Memory

## Status
Accepted — 2025-09-21

## Context
Flat conversation buffers exhaust context windows and lose long-term knowledge.

## Decision
Implement four-tier memory: **working** (ring buffer), **episodic** (timeline DB),
**semantic** (vector store), **procedural** (skill index). Each tier owns its own
retention and retrieval policy.

## Consequences
- Cross-tier consolidation runs on idle ticks
- Storage cost grows linearly with episodes; pruner runs nightly
