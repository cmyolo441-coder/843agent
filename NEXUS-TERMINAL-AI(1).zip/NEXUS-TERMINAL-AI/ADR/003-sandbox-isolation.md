# ADR 003 — Sandbox Isolation

## Status
Accepted — 2025-10-02

## Context
LLM-emitted code may be unsafe. Direct host execution is unacceptable.

## Decision
Provide pluggable sandbox backends: `firejail`, `docker`, `nsjail`, `wasm`.
Default to `firejail` on Linux dev hosts and `docker` in production.

## Consequences
- All filesystem and network access goes through capability bundles
- Compatible with rootless containers
- ~50–200ms overhead per invocation
