# ADR 004 — Async Scheduler

## Status
Accepted — 2025-10-09

## Context
Concurrent agents need fair scheduling, prioritization, and back-pressure.

## Decision
Asyncio-based scheduler with a priority queue, bounded worker pool, and bulkhead
isolation per agent role. Use a heartbeat for liveness, a watchdog for deadlines.

## Consequences
- Long-running tools must be cooperative (no blocking calls)
- We need a thread-pool escape hatch for sync libraries (e.g. sqlite)
