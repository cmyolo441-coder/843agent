# ADR 005 — Plugin System

## Status
Accepted — 2025-10-16

## Context
Third parties want to add tools, agents, and memory backends without forking.

## Decision
A `Plugin` manifest in TOML with Ed25519 signature, declared capability bundle,
and a Python entry point. Plugins load via `importlib.metadata` and are sandboxed
at the same level as the host process by default.

## Consequences
- Manifest verification cost on cold start (~ms per plugin)
- A signing CLI is required (`nexus plugin sign`)
