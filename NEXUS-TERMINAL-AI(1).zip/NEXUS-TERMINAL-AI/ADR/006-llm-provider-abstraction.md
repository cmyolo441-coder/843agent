# ADR 006 — LLM Provider Abstraction

## Status
Accepted — 2025-10-24

## Context
We must support Anthropic, OpenAI, local vLLM, and cloud endpoints without leaking
provider quirks into the core.

## Decision
Define `LLMLike` Protocol with `complete`, `stream`, `tool_use`. Adapters implement
provider-specific transport + a `Capabilities` advert. Router picks adapters by
`(ModelTier, Capabilities, cost_budget)`.

## Consequences
- Common failures (rate limit, 5xx) are uniform across providers
- Caching keyed by canonical request hash
