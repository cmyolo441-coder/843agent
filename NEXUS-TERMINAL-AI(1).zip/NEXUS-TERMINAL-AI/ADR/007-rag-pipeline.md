# ADR 007 — RAG Pipeline

## Status
Accepted — 2025-11-02

## Context
Long-tail knowledge must be retrievable without burning context tokens.

## Decision
A retrieval pipeline: query → expand → embed → vector-search → hybrid-rerank →
context-pack → LLM. ChromaDB is the default vector backend; BM25 fallback for
sparse signal. Rerankers are optional and pluggable.

## Consequences
- Memory cost: ~1.5 GB per million chunks
- Latency budget: 200–500 ms p50 over a warm index
