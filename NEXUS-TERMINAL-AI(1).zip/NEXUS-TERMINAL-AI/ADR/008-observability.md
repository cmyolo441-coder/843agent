# ADR 008 — Observability

## Status
Accepted — 2025-11-12

## Context
Multi-agent traces are hard to debug without structured signals.

## Decision
OpenTelemetry traces for every pipeline stage, Prometheus counters/histograms for
LLM usage, structured JSON logs with a `trace_id` propagated through ContextVar.

## Consequences
- ~5 % CPU overhead on hot path
- Operators get end-to-end agent traces in Jaeger / Tempo
