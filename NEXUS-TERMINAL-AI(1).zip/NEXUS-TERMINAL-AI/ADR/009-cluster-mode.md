# ADR 009 — Cluster Mode

## Status
Accepted — 2025-11-23

## Context
Single-node deployments saturate at a few dozen concurrent agents.

## Decision
Use Ray as the default distributed back-end. Agents are stateless workers; state
lives in Redis + Postgres + the vector store. A head node hosts the orchestrator.

## Consequences
- Plain `pip install -e .[cluster]` to enable
- Operators must run an external Redis + Postgres
