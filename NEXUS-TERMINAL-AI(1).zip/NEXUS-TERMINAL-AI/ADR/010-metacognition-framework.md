# ADR 010 — Metacognition Framework

## Status
Accepted — 2025-12-04

## Context
Agents must evaluate their own outputs, retry, and route around dead ends.

## Decision
Each task carries a `MetacognitionState`: confidence, uncertainty, evidence-set,
and a self-evaluator that runs after every pipeline cycle. If confidence < τ
the executor reroutes to a critic / researcher loop with a fresh plan.

## Consequences
- ~1.3× LLM cost for high-stakes tasks
- Measurable quality lift on multi-hop reasoning benchmarks
