# Changelog

All notable changes to NEXUS Terminal AI follow [Keep a Changelog](https://keepachangelog.com).

## [10.0.0] - 2026-06-01
### Added
- Multi-agent orchestration with role-based specialization
- Hierarchical memory (working / episodic / semantic / procedural)
- Metacognition framework with self-evaluation loops
- Sandbox isolation for code execution
- Plugin system with signed manifests

### Changed
- Switched core LLM client to anthropic 0.39.0
- Migrated vector store to ChromaDB 0.5

## [9.5.0] - 2026-03-12
### Added
- Streaming tool-use
- Cluster mode via Ray

## [9.0.0] - 2025-12-01
- Initial public release of the v9 line
