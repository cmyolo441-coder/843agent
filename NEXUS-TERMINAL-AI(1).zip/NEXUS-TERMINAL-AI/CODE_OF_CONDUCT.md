# Contributor Covenant Code of Conduct

We pledge to make participation in NEXUS Terminal AI a harassment-free experience for everyone.

## Standards

- Be respectful and inclusive
- Welcome constructive criticism
- Focus on what is best for the community
- Show empathy toward other community members

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to
conduct@nexus.ai. Maintainers will review and investigate all complaints.

Adapted from the Contributor Covenant v2.1.
