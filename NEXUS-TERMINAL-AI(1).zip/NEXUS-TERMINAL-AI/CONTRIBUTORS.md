# Contributors

NEXUS Terminal AI is built by a community of researchers and engineers.

## Core Team
- NEXUS Architecture Group
- Multi-Agent Systems Lab
- Reasoning & Memory Research

## How to Contribute
1. Fork the repo and create a topic branch
2. Run `make install` and `make test`
3. Open a PR with a clear description and tests

See `CONTRIBUTING.md` for the full workflow.
