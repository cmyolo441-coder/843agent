# Migration Guide

## 9.x → 10.x

### Breaking
- `nexus.Agent` constructor now requires `role: AgentRole`
- Memory back-ends consolidated under `nexus.memory`
- Config keys renamed: `llm.model` → `llm.default_model`

### Steps
1. Update imports: `from nexus.agents import BaseAgent`
2. Migrate config with `nexus migrate config --from 9 --to 10`
3. Re-index vector stores: `nexus migrate vectors`
4. Re-sign plugins (Ed25519 required)

### Removed
- Legacy `SyncAgent` (replaced by async-only `BaseAgent`)
- `nexus.llm.openai_legacy` (use `nexus.llm.openai_v2`)
