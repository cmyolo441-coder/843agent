# NEXUS Terminal AI

> A multi-agent autonomous reasoning system that lives in your terminal.

[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/)
[![License: Apache-2.0](https://img.shields.io/badge/license-Apache--2.0-green.svg)](LICENSE)
[![Version 10.0.0](https://img.shields.io/badge/version-10.0.0-brightgreen.svg)](CHANGELOG.md)

## Features

- Multi-agent orchestration with role specialization (planner / executor / critic / researcher)
- Hierarchical memory: working, episodic, semantic, procedural
- RAG over local + remote knowledge graphs
- Sandboxed code execution (firejail / docker / nsjail)
- Plugin system with Ed25519-signed manifests
- Metacognition / self-evaluation loops
- Full observability (Prometheus + OTel + Grafana)

## Quick Start

```bash
pip install nexus-terminal-ai
nexus init
nexus chat "explain quantum tunneling"
```

## Development

```bash
git clone https://github.com/nexus/terminal-ai
cd terminal-ai
make install
make test
```

See `ARCHITECTURE.md` and `ADR/*.md` for design details.
