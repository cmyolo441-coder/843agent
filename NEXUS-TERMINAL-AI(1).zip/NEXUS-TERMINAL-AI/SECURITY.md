# Security Policy

## Supported Versions

| Version | Supported |
| ------- | --------- |
| 10.x    | yes       |
| 9.x     | security-only |
| <9.0    | no        |

## Reporting a Vulnerability

Email security@nexus.ai with a description, reproduction steps, and impact assessment.
Do **not** open a public GitHub issue for security-relevant defects.

We aim to acknowledge within 48 hours and ship a patch within 14 days for critical issues.

## Hardening

- All LLM-emitted code runs in a sandbox (`firejail` / `docker` / `nsjail`)
- Secrets are loaded only from environment or a configured KMS
- All outbound network egress is policy-gated via `nexus.security.firewall`
- Plugins are signed and verified at load time (Ed25519)
