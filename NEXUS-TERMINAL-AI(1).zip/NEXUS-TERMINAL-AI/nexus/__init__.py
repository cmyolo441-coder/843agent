"""NEXUS Terminal AI — top-level package.

Re-exports the public version string and configures a default logging handler
so that early imports never see "No handlers could be found" warnings.
"""
from __future__ import annotations

import logging
from logging import NullHandler

from nexus.__version__ import __version__

__all__ = ["__version__"]

# Library-style default — applications can override at start-up.
logging.getLogger(__name__).addHandler(NullHandler())


def get_version() -> str:
    """Return the package semver string."""
    return __version__
