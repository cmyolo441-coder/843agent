"""nexus.agents — Autonomous agent framework for NEXUS.

Provides the BaseAgent ABC, an agent registry, message protocol, and
specialized agents for planning, coding, review, research, security,
and more.
"""
from __future__ import annotations

from .base_agent import BaseAgent, AgentState, AgentContext
from .agent_registry import AgentRegistry, agent_registry
from .agent_factory import AgentFactory
from .agent_protocol import AgentMessage, MessageKind
from .agent_comm import AgentBus

__all__ = [
    "BaseAgent",
    "AgentState",
    "AgentContext",
    "AgentRegistry",
    "agent_registry",
    "AgentFactory",
    "AgentMessage",
    "MessageKind",
    "AgentBus",
]
