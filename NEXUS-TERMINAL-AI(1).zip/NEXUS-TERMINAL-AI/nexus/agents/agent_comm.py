"""Async pub/sub bus for inter-agent messaging."""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Awaitable, Callable

from .agent_protocol import AgentMessage, MessageKind

logger = logging.getLogger(__name__)

Handler = Callable[[AgentMessage], Awaitable[None]]


class AgentBus:
    """In-process async message bus for agents.

    Subscribers register by topic or by specific receiver-id. The
    broadcast receiver "*" delivers to every subscribed agent.
    """

    def __init__(self) -> None:
        self._subs: dict[str, list[Handler]] = defaultdict(list)
        self._topic_subs: dict[str, list[Handler]] = defaultdict(list)
        self._history: list[AgentMessage] = []
        self._history_cap = 1000
        self._lock = asyncio.Lock()

    def subscribe(self, receiver_id: str, handler: Handler) -> None:
        self._subs[receiver_id].append(handler)
        logger.debug("Subscribed %s to direct messages", receiver_id)

    def subscribe_topic(self, topic: str, handler: Handler) -> None:
        self._topic_subs[topic].append(handler)
        logger.debug("Subscribed handler to topic %s", topic)

    def unsubscribe(self, receiver_id: str, handler: Handler) -> None:
        if handler in self._subs.get(receiver_id, []):
            self._subs[receiver_id].remove(handler)

    async def publish(self, msg: AgentMessage, topic: str | None = None) -> int:
        """Deliver msg; return count of handlers invoked."""
        async with self._lock:
            self._history.append(msg)
            if len(self._history) > self._history_cap:
                self._history = self._history[-self._history_cap:]
        delivered = 0
        targets: list[Handler] = []
        if msg.receiver == "*" or msg.kind is MessageKind.BROADCAST:
            for hs in self._subs.values():
                targets.extend(hs)
        else:
            targets.extend(self._subs.get(msg.receiver, []))
        if topic:
            targets.extend(self._topic_subs.get(topic, []))
        for h in targets:
            try:
                await h(msg)
                delivered += 1
            except Exception:  # noqa: BLE001
                logger.exception("Bus handler raised")
        return delivered

    async def request(self, msg: AgentMessage, timeout: float = 5.0) -> AgentMessage | None:
        """Send a REQUEST and wait for a matching RESPONSE."""
        fut: asyncio.Future[AgentMessage] = asyncio.get_event_loop().create_future()

        async def on_msg(m: AgentMessage) -> None:
            if not fut.done() and m.in_reply_to == msg.msg_id:
                fut.set_result(m)

        self.subscribe(msg.sender, on_msg)
        try:
            await self.publish(msg)
            return await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            return None
        finally:
            self.unsubscribe(msg.sender, on_msg)

    def history(self, limit: int = 50) -> list[AgentMessage]:
        return list(self._history[-limit:])
