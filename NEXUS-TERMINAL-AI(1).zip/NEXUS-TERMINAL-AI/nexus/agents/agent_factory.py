"""Factory for instantiating agents by role with shared dependencies."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from .agent_registry import AgentRegistry, agent_registry
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


@dataclass
class AgentFactory:
    """Creates agent instances and wires in shared dependencies (LLM, memory)."""
    registry: AgentRegistry = field(default_factory=lambda: agent_registry)
    default_llm: Any = None
    default_memory: Any = None
    defaults: dict[str, dict[str, Any]] = field(default_factory=dict)

    def create(self, role: str, **overrides: Any) -> BaseAgent:
        cls = self.registry.get(role)
        kwargs: dict[str, Any] = {"llm": self.default_llm, "memory": self.default_memory}
        kwargs.update(self.defaults.get(role.lower(), {}))
        kwargs.update(overrides)
        agent = cls(**kwargs)
        self.registry.add_instance(agent)
        logger.info("Created agent role=%s id=%s", role, agent.id)
        return agent

    def create_many(self, roles: list[str]) -> list[BaseAgent]:
        return [self.create(r) for r in roles]

    def configure_defaults(self, role: str, **kwargs: Any) -> None:
        self.defaults.setdefault(role.lower(), {}).update(kwargs)

    def destroy(self, agent: BaseAgent) -> None:
        self.registry.remove_instance(agent.id)
