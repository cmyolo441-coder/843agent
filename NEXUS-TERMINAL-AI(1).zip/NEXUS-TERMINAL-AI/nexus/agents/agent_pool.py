"""Pool of pre-created agents for high-throughput task dispatch."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

from .agent_factory import AgentFactory
from .base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@dataclass
class AgentPool:
    """Bounded pool of agents of a single role; checkout/checkin for tasks."""
    factory: AgentFactory
    role: str
    size: int = 4
    _queue: asyncio.Queue[BaseAgent] = field(init=False)
    _all: list[BaseAgent] = field(default_factory=list, init=False)

    def __post_init__(self) -> None:
        self._queue = asyncio.Queue(maxsize=self.size)
        for _ in range(self.size):
            agent = self.factory.create(self.role)
            self._all.append(agent)
            self._queue.put_nowait(agent)
        logger.info("AgentPool[%s] size=%d ready", self.role, self.size)

    async def checkout(self) -> BaseAgent:
        return await self._queue.get()

    async def checkin(self, agent: BaseAgent) -> None:
        await self._queue.put(agent)

    async def run(self, goal: str, **inputs) -> AgentContext:
        agent = await self.checkout()
        try:
            return await agent.run(goal, **inputs)
        finally:
            await self.checkin(agent)

    async def map(self, goals: list[str]) -> list[AgentContext]:
        return await asyncio.gather(*[self.run(g) for g in goals])

    def stats(self) -> dict[str, int]:
        return {"size": self.size, "available": self._queue.qsize(), "in_use": self.size - self._queue.qsize()}

    async def shutdown(self) -> None:
        for a in self._all:
            self.factory.destroy(a)
        self._all.clear()
