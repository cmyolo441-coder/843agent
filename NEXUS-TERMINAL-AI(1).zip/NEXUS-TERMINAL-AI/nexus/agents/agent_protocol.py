"""Wire protocol for inter-agent messaging."""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class MessageKind(str, Enum):
    REQUEST = "request"
    RESPONSE = "response"
    NOTIFY = "notify"
    BROADCAST = "broadcast"
    COMMAND = "command"
    EVENT = "event"
    ERROR = "error"
    HEARTBEAT = "heartbeat"


@dataclass
class AgentMessage:
    """Self-contained message between agents."""
    sender: str
    receiver: str  # specific agent id or "*" for broadcast
    kind: MessageKind = MessageKind.NOTIFY
    payload: dict[str, Any] = field(default_factory=dict)
    msg_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    in_reply_to: str | None = None
    correlation_id: str | None = None
    ttl_seconds: float | None = None
    timestamp: float = field(default_factory=time.time)

    def to_json(self) -> str:
        d = asdict(self)
        d["kind"] = self.kind.value
        return json.dumps(d, default=str)

    @classmethod
    def from_json(cls, raw: str) -> "AgentMessage":
        obj = json.loads(raw)
        obj["kind"] = MessageKind(obj.get("kind", "notify"))
        return cls(**obj)

    def reply(self, sender: str, payload: dict[str, Any], kind: MessageKind = MessageKind.RESPONSE) -> "AgentMessage":
        return AgentMessage(sender=sender, receiver=self.sender, kind=kind, payload=payload,
                             in_reply_to=self.msg_id, correlation_id=self.correlation_id or self.msg_id)

    def is_expired(self, now: float | None = None) -> bool:
        if self.ttl_seconds is None:
            return False
        ts = now if now is not None else time.time()
        return (ts - self.timestamp) > self.ttl_seconds
