"""Registry of agent classes by role name."""
from __future__ import annotations

import logging
import threading
from typing import Callable, Type

from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class AgentRegistry:
    """Thread-safe registry mapping role names to agent classes."""

    def __init__(self) -> None:
        self._registry: dict[str, Type[BaseAgent]] = {}
        self._instances: dict[str, BaseAgent] = {}
        self._lock = threading.Lock()

    def register(self, role: str | None = None) -> Callable[[Type[BaseAgent]], Type[BaseAgent]]:
        """Decorator. Use as @registry.register("planner") on an agent class."""
        def deco(cls: Type[BaseAgent]) -> Type[BaseAgent]:
            key = (role or cls.role).lower()
            with self._lock:
                if key in self._registry:
                    logger.warning("Overwriting agent class for role %s", key)
                self._registry[key] = cls
                cls.role = key
            return cls
        return deco

    def register_class(self, cls: Type[BaseAgent], role: str | None = None) -> None:
        key = (role or cls.role).lower()
        with self._lock:
            self._registry[key] = cls
            cls.role = key

    def get(self, role: str) -> Type[BaseAgent]:
        key = role.lower()
        if key not in self._registry:
            raise KeyError(f"No agent registered with role {role!r}. Known: {sorted(self._registry)}")
        return self._registry[key]

    def roles(self) -> list[str]:
        return sorted(self._registry)

    def add_instance(self, agent: BaseAgent) -> None:
        with self._lock:
            self._instances[agent.id] = agent

    def remove_instance(self, agent_id: str) -> None:
        with self._lock:
            self._instances.pop(agent_id, None)

    def instances(self) -> list[BaseAgent]:
        with self._lock:
            return list(self._instances.values())


agent_registry = AgentRegistry()
