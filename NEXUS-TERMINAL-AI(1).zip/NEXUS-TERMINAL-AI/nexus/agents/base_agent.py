"""Abstract base agent — perceive / decide / act loop with memory reference."""
from __future__ import annotations

import abc
import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class AgentState(str, Enum):
    IDLE = "idle"
    PERCEIVING = "perceiving"
    DECIDING = "deciding"
    ACTING = "acting"
    DONE = "done"
    ERROR = "error"


@dataclass
class AgentContext:
    """Per-run context passed through the perceive/decide/act loop."""
    goal: str
    inputs: dict[str, Any] = field(default_factory=dict)
    observations: list[Any] = field(default_factory=list)
    intermediate: dict[str, Any] = field(default_factory=dict)
    artifacts: list[Any] = field(default_factory=list)
    iteration: int = 0
    started_at: float = field(default_factory=time.time)


class BaseAgent(abc.ABC):
    """Abstract base for all NEXUS agents."""

    role: str = "agent"
    system_prompt: str = "You are a helpful AI agent."

    def __init__(self, name: str | None = None, memory: Any = None,
                 llm: Any = None, max_iterations: int = 8, **kw: Any) -> None:
        self.id = f"{self.role}-{uuid.uuid4().hex[:8]}"
        self.name = name or self.id
        self.memory = memory
        self.llm = llm
        self.max_iterations = max_iterations
        self.state: AgentState = AgentState.IDLE
        self.options = kw
        self._log = logging.getLogger(f"{__name__}.{self.role}")

    async def run(self, goal: str, **inputs: Any) -> AgentContext:
        """Standard perceive -> decide -> act loop until done or max iterations."""
        ctx = AgentContext(goal=goal, inputs=dict(inputs))
        self._log.info("Agent %s starting goal=%r", self.name, goal[:80])
        for i in range(self.max_iterations):
            ctx.iteration = i
            try:
                self.state = AgentState.PERCEIVING
                obs = await self.perceive(ctx)
                if obs is not None:
                    ctx.observations.append(obs)
                self.state = AgentState.DECIDING
                decision = await self.decide(ctx)
                if decision is None:
                    self.state = AgentState.DONE
                    break
                self.state = AgentState.ACTING
                result = await self.act(decision, ctx)
                ctx.artifacts.append(result)
                if await self.is_done(ctx):
                    self.state = AgentState.DONE
                    break
            except Exception as exc:  # noqa: BLE001
                self.state = AgentState.ERROR
                self._log.exception("Agent %s iteration %d failed", self.name, i)
                ctx.intermediate.setdefault("errors", []).append(str(exc))
                break
        else:
            self._log.warning("Agent %s exhausted iterations", self.name)
        return ctx

    @abc.abstractmethod
    async def perceive(self, ctx: AgentContext) -> Any:
        """Gather information about the current environment / context."""

    @abc.abstractmethod
    async def decide(self, ctx: AgentContext) -> Any:
        """Choose the next action based on observations."""

    @abc.abstractmethod
    async def act(self, decision: Any, ctx: AgentContext) -> Any:
        """Execute the chosen action and return its result."""

    async def is_done(self, ctx: AgentContext) -> bool:
        """Override to define a custom termination check; default: stop after one action."""
        return len(ctx.artifacts) >= 1

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} id={self.id} state={self.state.value}>"
