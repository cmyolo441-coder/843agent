"""Multi-agent coordination primitives."""
from __future__ import annotations

from .leader_election import LeaderElection
from .task_decomposition import TaskDecomposer, SubTask
from .task_allocation import TaskAllocator, Task, Assignment
from .conflict_resolution import ConflictResolver, Conflict
from .negotiation import Negotiator, Offer
from .collaboration import CollaborationSession
from .synchronization import Barrier, Latch

__all__ = ["LeaderElection", "TaskDecomposer", "SubTask", "TaskAllocator",
           "Task", "Assignment", "ConflictResolver", "Conflict",
           "Negotiator", "Offer", "CollaborationSession", "Barrier", "Latch"]
