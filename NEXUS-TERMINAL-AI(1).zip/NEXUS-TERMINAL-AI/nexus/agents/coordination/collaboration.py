"""Collaboration session — agents pool contributions toward a shared artifact."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class Contribution:
    agent_id: str
    content: Any
    timestamp: float = field(default_factory=time.time)
    weight: float = 1.0


@dataclass
class CollaborationSession:
    """A shared workspace where agents add contributions to a growing artifact."""
    artifact: list[Any] = field(default_factory=list)
    contributions: list[Contribution] = field(default_factory=list)
    participants: set[str] = field(default_factory=set)
    started_at: float = field(default_factory=time.time)

    def contribute(self, agent_id: str, content: Any, weight: float = 1.0) -> Contribution:
        c = Contribution(agent_id=agent_id, content=content, weight=weight)
        self.contributions.append(c)
        self.participants.add(agent_id)
        self.artifact.append(content)
        return c

    def vote(self, agent_id: str, idx: int, delta: float = 1.0) -> None:
        if 0 <= idx < len(self.contributions):
            self.contributions[idx].weight += delta

    def consensus_artifact(self, top_k: int | None = None) -> list[Any]:
        """Return contributions sorted by weight (most valued first)."""
        sorted_c = sorted(self.contributions, key=lambda c: -c.weight)
        if top_k is not None:
            sorted_c = sorted_c[:top_k]
        return [c.content for c in sorted_c]

    def participation(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for c in self.contributions:
            counts[c.agent_id] = counts.get(c.agent_id, 0) + 1
        return counts

    def duration(self) -> float:
        return time.time() - self.started_at
