"""Conflict resolution between agents proposing competing actions."""
from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class ConflictType(str, Enum):
    RESOURCE = "resource"
    GOAL = "goal"
    BELIEF = "belief"
    ORDER = "order"


@dataclass
class Conflict:
    """Two or more proposals contend for the same outcome."""
    kind: ConflictType
    parties: list[str]
    proposals: dict[str, Any]
    context: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConflictResolver:
    """Resolves conflicts via voting, priority, or escalation."""
    priorities: dict[str, float] = field(default_factory=dict)

    def resolve(self, conflict: Conflict) -> dict[str, Any]:
        if conflict.kind is ConflictType.RESOURCE:
            return self._by_priority(conflict)
        if conflict.kind is ConflictType.BELIEF:
            return self._by_majority(conflict)
        if conflict.kind is ConflictType.GOAL:
            return self._compromise(conflict)
        return self._by_order(conflict)

    def _by_priority(self, c: Conflict) -> dict[str, Any]:
        winner = max(c.parties, key=lambda p: self.priorities.get(p, 0.0))
        return {"winner": winner, "method": "priority", "value": c.proposals.get(winner)}

    def _by_majority(self, c: Conflict) -> dict[str, Any]:
        counter: Counter = Counter()
        for party, prop in c.proposals.items():
            counter[str(prop)] += 1
        winning_value, _ = counter.most_common(1)[0]
        winners = [p for p, v in c.proposals.items() if str(v) == winning_value]
        return {"winner": winners, "method": "majority", "value": winning_value}

    def _compromise(self, c: Conflict) -> dict[str, Any]:
        # If proposals are numeric, average; else fall back to majority
        try:
            vals = [float(v) for v in c.proposals.values()]
            avg = sum(vals) / len(vals)
            return {"winner": "all", "method": "compromise", "value": avg}
        except (TypeError, ValueError):
            return self._by_majority(c)

    def _by_order(self, c: Conflict) -> dict[str, Any]:
        first = c.parties[0] if c.parties else None
        return {"winner": first, "method": "first_in", "value": c.proposals.get(first)}
