"""Leader election among a set of peer agents."""
from __future__ import annotations

import logging
import random
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class Method(str, Enum):
    BULLY = "bully"
    RING = "ring"
    RANDOM = "random"
    LOWEST_ID = "lowest_id"


@dataclass
class LeaderElection:
    """Choose a leader among peer agents."""
    method: Method = Method.LOWEST_ID
    leader: str | None = None
    term: int = 0
    last_elected_at: float = 0.0

    def elect(self, peers: list[str], scores: dict[str, float] | None = None) -> str:
        if not peers:
            raise ValueError("No peers to elect from")
        if self.method is Method.LOWEST_ID:
            chosen = min(peers)
        elif self.method is Method.BULLY:
            if scores is None:
                chosen = max(peers)
            else:
                chosen = max(peers, key=lambda p: scores.get(p, 0.0))
        elif self.method is Method.RING:
            # Stable choice: highest in the sorted ring
            ring = sorted(peers)
            chosen = ring[self.term % len(ring)]
        else:  # RANDOM
            chosen = random.choice(peers)
        self.leader = chosen
        self.term += 1
        self.last_elected_at = time.time()
        logger.info("Elected leader %s (method=%s, term=%d)", chosen, self.method.value, self.term)
        return chosen

    def step_down(self) -> None:
        logger.info("Leader %s stepping down (term=%d)", self.leader, self.term)
        self.leader = None

    def is_leader(self, agent_id: str) -> bool:
        return self.leader == agent_id
