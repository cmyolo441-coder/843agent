"""Negotiation protocol between two agents — concession-based bargaining."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class Offer:
    """A proposal on the table."""
    from_agent: str
    value: float
    notes: str = ""


@dataclass
class Negotiator:
    """Monotonic concession negotiation: meet halfway each round, up to max_rounds."""
    max_rounds: int = 8
    concession_rate: float = 0.5
    floor: float = 0.0
    ceiling: float = 100.0

    def negotiate(self, opening_a: Offer, opening_b: Offer) -> dict[str, Any]:
        a, b = opening_a, opening_b
        log: list[dict[str, Any]] = [{"a": a.value, "b": b.value, "gap": abs(a.value - b.value)}]
        for r in range(self.max_rounds):
            if abs(a.value - b.value) <= 1e-3:
                return {"agreed": True, "value": (a.value + b.value) / 2, "rounds": r + 1, "log": log}
            a = Offer(from_agent=a.from_agent,
                      value=self._concede(a.value, b.value))
            b = Offer(from_agent=b.from_agent,
                      value=self._concede(b.value, a.value))
            log.append({"a": a.value, "b": b.value, "gap": abs(a.value - b.value)})
        if abs(a.value - b.value) <= (self.ceiling - self.floor) * 0.05:
            return {"agreed": True, "value": (a.value + b.value) / 2,
                     "rounds": self.max_rounds, "log": log}
        return {"agreed": False, "value": None, "rounds": self.max_rounds, "log": log}

    def _concede(self, mine: float, theirs: float) -> float:
        return mine + (theirs - mine) * self.concession_rate
