"""Synchronization primitives for coordinating agents — barriers and latches."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class Barrier:
    """An async barrier: N agents must arrive before all proceed."""
    parties: int
    _arrived: int = 0
    _event: asyncio.Event = field(default_factory=asyncio.Event)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _generation: int = 0

    async def wait(self) -> int:
        async with self._lock:
            gen = self._generation
            self._arrived += 1
            arrived_now = self._arrived
            if arrived_now >= self.parties:
                self._event.set()
                self._arrived = 0
                self._generation += 1
                # Open and immediately reset for next generation
                evt = self._event
                self._event = asyncio.Event()
                evt.set()
                return arrived_now
            evt = self._event
        await evt.wait()
        return gen

    def reset(self) -> None:
        self._arrived = 0
        self._event = asyncio.Event()
        self._generation += 1


@dataclass
class Latch:
    """Count-down latch: one or more agents wait until count reaches zero."""
    count: int
    _event: asyncio.Event = field(default_factory=asyncio.Event)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def count_down(self, n: int = 1) -> None:
        async with self._lock:
            self.count = max(0, self.count - n)
            if self.count == 0:
                self._event.set()

    async def wait(self, timeout: float | None = None) -> bool:
        try:
            if timeout is None:
                await self._event.wait()
                return True
            await asyncio.wait_for(self._event.wait(), timeout=timeout)
            return True
        except asyncio.TimeoutError:
            return False

    @property
    def is_open(self) -> bool:
        return self._event.is_set()
