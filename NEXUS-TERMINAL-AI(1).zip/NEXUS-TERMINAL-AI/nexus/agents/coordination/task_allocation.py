"""Allocate tasks to agents — Hungarian-style greedy assignment."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable

logger = logging.getLogger(__name__)


@dataclass
class Task:
    task_id: str
    description: str
    required_skill: str = ""
    priority: float = 1.0


@dataclass
class Assignment:
    task_id: str
    agent_id: str
    cost: float


@dataclass
class TaskAllocator:
    """Greedy minimum-cost bipartite assignment."""
    cost_fn: Callable[[Task, str], float] | None = None

    def allocate(self, tasks: list[Task], agents: list[str]) -> list[Assignment]:
        if not tasks or not agents:
            return []
        cost_fn = self.cost_fn or self._default_cost
        # Cost matrix
        matrix: list[list[float]] = []
        for t in tasks:
            row = [cost_fn(t, a) for a in agents]
            matrix.append(row)
        # Greedy allocation: pick min cost cell repeatedly
        remaining_tasks = list(range(len(tasks)))
        remaining_agents = list(range(len(agents)))
        out: list[Assignment] = []
        while remaining_tasks and remaining_agents:
            best = None
            for i in remaining_tasks:
                for j in remaining_agents:
                    c = matrix[i][j]
                    if best is None or c < best[2]:
                        best = (i, j, c)
            if best is None:
                break
            i, j, c = best
            out.append(Assignment(task_id=tasks[i].task_id, agent_id=agents[j], cost=c))
            remaining_tasks.remove(i)
            remaining_agents.remove(j)
        logger.info("Allocated %d/%d tasks", len(out), len(tasks))
        return out

    @staticmethod
    def _default_cost(task: Task, agent_id: str) -> float:
        # Heuristic: weight by priority (inverse) and required-skill match in agent_id
        match = 0.0 if task.required_skill and task.required_skill in agent_id else 1.0
        return match + 1.0 / max(0.1, task.priority)
