"""Task decomposition — split a high-level goal into a DAG of sub-tasks."""
from __future__ import annotations

import logging
import re
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SubTask:
    description: str
    depends_on: list[str] = field(default_factory=list)
    estimated_effort: float = 1.0
    task_id: str = field(default_factory=lambda: f"st-{uuid.uuid4().hex[:6]}")


@dataclass
class TaskDecomposer:
    """Heuristic decomposition based on conjunctions; supports manual DAG."""

    def decompose(self, goal: str) -> list[SubTask]:
        parts = self._split(goal)
        tasks = [SubTask(description=p.strip()) for p in parts if p.strip()]
        # Sequential default: each depends on the previous
        for i in range(1, len(tasks)):
            tasks[i].depends_on.append(tasks[i - 1].task_id)
        return tasks

    def _split(self, goal: str) -> list[str]:
        return [p for p in re.split(r"\bthen\b|;|\band\b", goal, flags=re.IGNORECASE) if p.strip()]

    def topological_order(self, tasks: list[SubTask]) -> list[SubTask]:
        by_id = {t.task_id: t for t in tasks}
        in_deg: dict[str, int] = {t.task_id: len(t.depends_on) for t in tasks}
        edges: dict[str, list[str]] = defaultdict(list)
        for t in tasks:
            for dep in t.depends_on:
                edges[dep].append(t.task_id)
        q = deque([tid for tid, n in in_deg.items() if n == 0])
        out: list[SubTask] = []
        while q:
            cur = q.popleft()
            out.append(by_id[cur])
            for nxt in edges.get(cur, []):
                in_deg[nxt] -= 1
                if in_deg[nxt] == 0:
                    q.append(nxt)
        if len(out) != len(tasks):
            raise RuntimeError("Cycle detected in task DAG")
        return out

    def critical_path(self, tasks: list[SubTask]) -> list[SubTask]:
        ordered = self.topological_order(tasks)
        by_id = {t.task_id: t for t in tasks}
        ef: dict[str, float] = {}
        pred: dict[str, str | None] = {}
        for t in ordered:
            best_prev = 0.0
            best_pred: str | None = None
            for d in t.depends_on:
                if ef.get(d, 0.0) > best_prev:
                    best_prev = ef[d]
                    best_pred = d
            ef[t.task_id] = best_prev + t.estimated_effort
            pred[t.task_id] = best_pred
        end = max(ef, key=ef.get) if ef else None
        path: list[SubTask] = []
        cur: str | None = end
        while cur is not None:
            path.append(by_id[cur])
            cur = pred.get(cur)
        return list(reversed(path))
