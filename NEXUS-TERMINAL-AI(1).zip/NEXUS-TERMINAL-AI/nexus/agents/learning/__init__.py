"""Agent learning subsystems: RL, imitation, transfer, curriculum, meta, few-shot, continual, adaptive."""
from __future__ import annotations

from .reinforcement import ReinforcementLearner, QTable
from .imitation import ImitationLearner, Demo
from .transfer import TransferLearner
from .curriculum import CurriculumLearner, CurriculumItem
from .meta_learn import MetaLearner
from .few_shot import FewShotLearner
from .continual import ContinualLearner
from .adaptive import AdaptiveLearner

__all__ = ["ReinforcementLearner", "QTable", "ImitationLearner", "Demo",
           "TransferLearner", "CurriculumLearner", "CurriculumItem",
           "MetaLearner", "FewShotLearner", "ContinualLearner", "AdaptiveLearner"]
