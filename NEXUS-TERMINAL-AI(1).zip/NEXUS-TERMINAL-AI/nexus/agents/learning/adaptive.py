"""Adaptive learner — tunes its own hyperparameters via online bandits."""
from __future__ import annotations

import logging
import math
import random
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Hashable

logger = logging.getLogger(__name__)


@dataclass
class _Arm:
    pulls: int = 0
    total_reward: float = 0.0

    @property
    def mean(self) -> float:
        return self.total_reward / self.pulls if self.pulls else 0.0


@dataclass
class AdaptiveLearner:
    """UCB1 bandit over a discrete set of hyperparameter choices."""
    arms: dict[Hashable, _Arm] = field(default_factory=lambda: defaultdict(_Arm))
    total_pulls: int = 0
    exploration: float = math.sqrt(2)

    def register(self, choices: list[Hashable]) -> None:
        for c in choices:
            self.arms.setdefault(c, _Arm())

    def pick(self) -> Hashable:
        if not self.arms:
            raise RuntimeError("No arms registered")
        # First, pull each arm at least once
        for k, a in self.arms.items():
            if a.pulls == 0:
                return k
        # Otherwise UCB1
        def ucb(arm: _Arm) -> float:
            if arm.pulls == 0:
                return float("inf")
            return arm.mean + self.exploration * math.sqrt(math.log(self.total_pulls) / arm.pulls)
        return max(self.arms.items(), key=lambda kv: ucb(kv[1]))[0]

    def record(self, choice: Hashable, reward: float) -> None:
        arm = self.arms[choice]
        arm.pulls += 1
        arm.total_reward += reward
        self.total_pulls += 1

    def summary(self) -> dict[Hashable, dict[str, float]]:
        return {k: {"pulls": float(a.pulls), "mean_reward": a.mean} for k, a in self.arms.items()}

    def best(self) -> Hashable | None:
        if not self.arms:
            return None
        return max(self.arms.items(), key=lambda kv: kv[1].mean)[0]
