"""Continual learning — learn over a stream without catastrophic forgetting."""
from __future__ import annotations

import logging
import random
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Trainer = Callable[[list[Any]], Awaitable[float]]


@dataclass
class ReplayBuffer:
    """Reservoir-sampled replay buffer for old experience."""
    capacity: int = 1024
    _items: list[Any] = field(default_factory=list)
    _seen: int = 0

    def add(self, item: Any) -> None:
        self._seen += 1
        if len(self._items) < self.capacity:
            self._items.append(item)
        else:
            j = random.randint(0, self._seen - 1)
            if j < self.capacity:
                self._items[j] = item

    def sample(self, n: int) -> list[Any]:
        return random.sample(self._items, min(n, len(self._items)))

    def __len__(self) -> int:
        return len(self._items)


@dataclass
class ContinualLearner:
    """Trains on incoming batches while rehearsing from a replay buffer."""
    trainer: Trainer
    buffer: ReplayBuffer = field(default_factory=ReplayBuffer)
    rehearsal_ratio: float = 0.5
    losses: deque[float] = field(default_factory=lambda: deque(maxlen=100))

    async def update(self, batch: list[Any]) -> float:
        for item in batch:
            self.buffer.add(item)
        rehearse = self.buffer.sample(int(len(batch) * self.rehearsal_ratio))
        loss = await self.trainer(list(batch) + rehearse)
        self.losses.append(loss)
        logger.debug("Continual: loss=%.4f buffer=%d", loss, len(self.buffer))
        return loss

    def forgetting_metric(self) -> float:
        if len(self.losses) < 10:
            return 0.0
        recent = sum(list(self.losses)[-10:]) / 10
        early = sum(list(self.losses)[:10]) / 10
        return max(0.0, recent - early)
