"""Curriculum learning — present tasks in increasing difficulty."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Iterable

logger = logging.getLogger(__name__)


@dataclass
class CurriculumItem:
    task: Any
    difficulty: float = 1.0
    tag: str = ""


@dataclass
class CurriculumLearner:
    """Maintain an ordered curriculum and adapt based on performance."""
    items: list[CurriculumItem] = field(default_factory=list)
    threshold: float = 0.7  # advance to harder when above
    floor: float = 0.3       # retreat to easier when below
    _index: int = 0

    def add(self, item: CurriculumItem) -> None:
        self.items.append(item)
        self.items.sort(key=lambda x: x.difficulty)

    def add_many(self, items: Iterable[CurriculumItem]) -> None:
        for it in items:
            self.add(it)

    def current(self) -> CurriculumItem | None:
        if not self.items or self._index >= len(self.items):
            return None
        return self.items[self._index]

    def record(self, score: float) -> str:
        """Move forward, hold, or backward based on score."""
        if score >= self.threshold:
            self._index = min(self._index + 1, len(self.items) - 1)
            return "advanced"
        if score < self.floor and self._index > 0:
            self._index -= 1
            return "retreated"
        return "held"

    def progress(self) -> dict[str, Any]:
        return {"index": self._index, "total": len(self.items),
                "fraction": self._index / max(1, len(self.items) - 1),
                "current_difficulty": self.current().difficulty if self.current() else None}
