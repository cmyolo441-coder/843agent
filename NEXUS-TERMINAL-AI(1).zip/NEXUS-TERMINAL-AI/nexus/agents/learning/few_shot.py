"""Few-shot learning — make predictions from a handful of examples."""
from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Callable, Hashable

logger = logging.getLogger(__name__)


@dataclass
class FewShotLearner:
    """Nearest-neighbor classifier over a small in-memory set of examples."""
    examples: list[tuple[Any, Hashable]] = field(default_factory=list)
    k: int = 3
    distance: Callable[[Any, Any], float] | None = None

    def add(self, item: Any, label: Hashable) -> None:
        self.examples.append((item, label))

    def add_many(self, pairs: list[tuple[Any, Hashable]]) -> None:
        self.examples.extend(pairs)

    def predict(self, query: Any) -> Hashable | None:
        if not self.examples:
            return None
        d = self.distance or self._default_distance
        ranked = sorted(self.examples, key=lambda ex: d(query, ex[0]))[: self.k]
        votes = Counter(label for _, label in ranked)
        return votes.most_common(1)[0][0]

    def confidence(self, query: Any) -> float:
        if not self.examples:
            return 0.0
        d = self.distance or self._default_distance
        ranked = sorted(self.examples, key=lambda ex: d(query, ex[0]))[: self.k]
        votes = Counter(label for _, label in ranked)
        top = votes.most_common(1)[0][1]
        return top / max(1, sum(votes.values()))

    @staticmethod
    def _default_distance(a: Any, b: Any) -> float:
        sa, sb = str(a), str(b)
        # Cheap symmetric difference of token sets
        ta, tb = set(sa.lower().split()), set(sb.lower().split())
        if not ta and not tb:
            return 0.0
        return 1.0 - len(ta & tb) / max(1, len(ta | tb))
