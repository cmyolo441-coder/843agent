"""Imitation learning — learn from expert demonstrations."""
from __future__ import annotations

import logging
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Hashable

logger = logging.getLogger(__name__)


@dataclass
class Demo:
    """A single expert demonstration: (state, action) trajectory."""
    states: list[Hashable]
    actions: list[Hashable]

    def __len__(self) -> int:
        return min(len(self.states), len(self.actions))


@dataclass
class ImitationLearner:
    """Behavior-cloning style: pick the most frequent expert action per state."""
    counts: dict[Hashable, Counter] = field(default_factory=lambda: defaultdict(Counter))
    n_demos: int = 0

    def add_demo(self, demo: Demo) -> None:
        for s, a in zip(demo.states, demo.actions):
            self.counts[s][a] += 1
        self.n_demos += 1

    def policy(self, state: Hashable) -> Hashable | None:
        c = self.counts.get(state)
        if not c:
            return None
        return c.most_common(1)[0][0]

    def confidence(self, state: Hashable) -> float:
        c = self.counts.get(state)
        if not c:
            return 0.0
        total = sum(c.values())
        top = c.most_common(1)[0][1]
        return top / total

    def coverage(self, states: list[Hashable]) -> float:
        seen = sum(1 for s in states if s in self.counts)
        return seen / max(1, len(states))
