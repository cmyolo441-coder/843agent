"""Meta-learning — learn how to learn (MAML-style outer loop)."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

TaskFn = Callable[[dict[str, float]], Awaitable[float]]  # returns loss


@dataclass
class MetaLearner:
    """A first-order meta-learner that averages task-specific updates."""
    meta_params: dict[str, float] = field(default_factory=dict)
    inner_lr: float = 0.1
    outer_lr: float = 0.05

    async def inner_step(self, task: TaskFn, params: dict[str, float],
                          steps: int = 3) -> dict[str, float]:
        p = dict(params)
        for _ in range(steps):
            loss = await task(p)
            # Synthetic gradient: nudge each param down by loss * lr
            for k in list(p):
                p[k] = p[k] - self.inner_lr * loss * 0.01
        return p

    async def meta_update(self, tasks: list[TaskFn], inner_steps: int = 3) -> dict[str, Any]:
        """Run inner adaptation on each task; average update into meta_params."""
        accum: dict[str, float] = {k: 0.0 for k in self.meta_params}
        for task in tasks:
            adapted = await self.inner_step(task, self.meta_params, inner_steps)
            for k in self.meta_params:
                accum[k] += (adapted.get(k, 0.0) - self.meta_params[k])
        n = max(1, len(tasks))
        for k in self.meta_params:
            self.meta_params[k] += self.outer_lr * (accum[k] / n)
        logger.info("Meta-update across %d tasks", n)
        return {"meta_params": dict(self.meta_params), "n_tasks": n}

    def initialize(self, params: dict[str, float]) -> None:
        self.meta_params = dict(params)
