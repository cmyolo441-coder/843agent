"""Tabular Q-learning for small discrete state/action spaces."""
from __future__ import annotations

import logging
import random
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Hashable

logger = logging.getLogger(__name__)


@dataclass
class QTable:
    """Q(s,a) table with default-zero initialization."""
    table: dict[tuple[Any, Any], float] = field(default_factory=lambda: defaultdict(float))

    def get(self, state: Hashable, action: Hashable) -> float:
        return self.table[(state, action)]

    def set(self, state: Hashable, action: Hashable, value: float) -> None:
        self.table[(state, action)] = value

    def best(self, state: Hashable, actions: list[Hashable]) -> tuple[Hashable, float]:
        if not actions:
            raise ValueError("no actions")
        scored = [(a, self.get(state, a)) for a in actions]
        return max(scored, key=lambda x: x[1])


@dataclass
class ReinforcementLearner:
    """Q-learning with epsilon-greedy exploration."""
    q: QTable = field(default_factory=QTable)
    alpha: float = 0.1
    gamma: float = 0.95
    epsilon: float = 0.2

    def choose(self, state: Hashable, actions: list[Hashable]) -> Hashable:
        if random.random() < self.epsilon:
            return random.choice(actions)
        return self.q.best(state, actions)[0]

    def update(self, state: Hashable, action: Hashable, reward: float,
               next_state: Hashable, next_actions: list[Hashable]) -> float:
        max_next = self.q.best(next_state, next_actions)[1] if next_actions else 0.0
        old = self.q.get(state, action)
        new = old + self.alpha * (reward + self.gamma * max_next - old)
        self.q.set(state, action, new)
        return new

    def decay_epsilon(self, factor: float = 0.99, floor: float = 0.01) -> None:
        self.epsilon = max(floor, self.epsilon * factor)

    def policy(self, state: Hashable, actions: list[Hashable]) -> dict[Hashable, float]:
        """Return softmax probabilities for actions in state."""
        import math
        vals = [self.q.get(state, a) for a in actions]
        m = max(vals) if vals else 0.0
        exps = [math.exp(v - m) for v in vals]
        z = sum(exps) or 1.0
        return {a: e / z for a, e in zip(actions, exps)}
