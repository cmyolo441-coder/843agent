"""Transfer learning — adapt knowledge from a source domain to a target."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class TransferLearner:
    """Map a source-domain policy/parameter set into a target domain."""
    source_params: dict[str, float] = field(default_factory=dict)
    target_params: dict[str, float] = field(default_factory=dict)
    alpha: float = 0.5  # blending coefficient between source and target

    def initialize_target(self, blend_with: dict[str, float] | None = None) -> None:
        """Initialize target params from source, optionally blending with seed."""
        if blend_with is None:
            self.target_params = dict(self.source_params)
        else:
            for k in set(self.source_params) | set(blend_with):
                src = self.source_params.get(k, 0.0)
                seed = blend_with.get(k, 0.0)
                self.target_params[k] = (1 - self.alpha) * src + self.alpha * seed

    def update(self, gradients: dict[str, float], lr: float = 0.01) -> None:
        for k, g in gradients.items():
            self.target_params[k] = self.target_params.get(k, 0.0) - lr * g

    def transfer_score(self, evaluator: Callable[[dict[str, float]], float]) -> dict[str, float]:
        """Compare source vs target performance via the supplied evaluator."""
        src = evaluator(self.source_params)
        tgt = evaluator(self.target_params)
        gain = tgt - src
        logger.info("Transfer gain: %.4f (src=%.4f tgt=%.4f)", gain, src, tgt)
        return {"source": src, "target": tgt, "gain": gain}

    def freeze(self, keys: list[str]) -> None:
        """Freeze a subset of target params at their current value (no-op storage)."""
        self.target_params.setdefault("_frozen", 0.0)
        self.target_params["_frozen_keys"] = ",".join(keys)  # type: ignore[assignment]
