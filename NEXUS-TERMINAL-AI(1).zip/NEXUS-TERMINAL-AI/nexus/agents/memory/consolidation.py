"""Memory consolidation: move episodic items into semantic/procedural stores."""
from __future__ import annotations

import logging
import re
from collections import Counter
from dataclasses import dataclass
from typing import Any

from .episodic import EpisodicMemory, Episode
from .procedural import ProceduralMemory
from .semantic import SemanticMemory

logger = logging.getLogger(__name__)

_FACT_RE = re.compile(r"\b([A-Z][\w\- ]{1,40})\s+(is|are|has|have|equals)\s+(.+?)(?:\.|$)")
_WORD_RE = re.compile(r"[A-Za-z][A-Za-z'-]+")


@dataclass
class MemoryConsolidator:
    """Periodically distill episodic memory into semantic/procedural form."""
    min_repetition: int = 2

    def consolidate(self, episodic: EpisodicMemory, semantic: SemanticMemory,
                    procedural: ProceduralMemory | None = None) -> dict[str, int]:
        added_concepts = self._extract_facts(episodic.recent(500), semantic)
        reinforced = self._reinforce_repeated(episodic.recent(500), semantic)
        logger.info("Consolidation: %d new concepts, %d reinforced", added_concepts, reinforced)
        return {"new_concepts": added_concepts, "reinforced": reinforced}

    def _extract_facts(self, episodes: list[Episode], semantic: SemanticMemory) -> int:
        added = 0
        for ep in episodes:
            for m in _FACT_RE.finditer(ep.content):
                subj, rel, obj = m.group(1).strip(), m.group(2), m.group(3).strip()
                if rel in ("is", "are"):
                    semantic.is_a(subj, obj.split()[0])
                elif rel in ("has", "have"):
                    semantic.has_a(subj, obj.split()[0])
                added += 1
        return added

    def _reinforce_repeated(self, episodes: list[Episode], semantic: SemanticMemory) -> int:
        counts: Counter[str] = Counter()
        for ep in episodes:
            for word in _WORD_RE.findall(ep.content):
                if word.istitle():
                    counts[word] += 1
        reinforced = 0
        for term, n in counts.items():
            if n >= self.min_repetition:
                semantic.define(term, frequency=n)
                reinforced += 1
        return reinforced
