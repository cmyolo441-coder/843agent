"""Episodic memory — timestamped events with tags and retrieval."""
from __future__ import annotations

import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable

logger = logging.getLogger(__name__)


@dataclass
class Episode:
    """A single remembered event."""
    content: str
    timestamp: float = field(default_factory=time.time)
    tags: list[str] = field(default_factory=list)
    salience: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)
    episode_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])


@dataclass
class EpisodicMemory:
    """Append-only journal of episodes with tag and time indexing."""
    capacity: int = 128000
    _journal: list[Episode] = field(default_factory=list)
    _tag_index: dict[str, list[int]] = field(default_factory=lambda: defaultdict(list))

    def add(self, content: str, tags: Iterable[str] | None = None,
            salience: float = 1.0, **meta: Any) -> Episode:
        ep = Episode(content=content, tags=list(tags or []),
                      salience=salience, metadata=dict(meta))
        idx = len(self._journal)
        self._journal.append(ep)
        for t in ep.tags:
            self._tag_index[t].append(idx)
        if len(self._journal) > self.capacity:
            self._compact()
        return ep

    def recent(self, n: int = 10) -> list[Episode]:
        return self._journal[-n:]

    def by_tag(self, tag: str, limit: int = 50) -> list[Episode]:
        idxs = self._tag_index.get(tag, [])[-limit:]
        return [self._journal[i] for i in idxs if i < len(self._journal)]

    def search(self, query: str, limit: int = 20) -> list[Episode]:
        q = query.lower()
        out = [e for e in self._journal if q in e.content.lower()]
        return out[-limit:]

    def between(self, start: float, end: float) -> list[Episode]:
        return [e for e in self._journal if start <= e.timestamp <= end]

    def forget(self, threshold: float = 0.1) -> int:
        """Drop low-salience episodes (returns count removed)."""
        before = len(self._journal)
        self._journal = [e for e in self._journal if e.salience >= threshold]
        self._rebuild_index()
        return before - len(self._journal)

    def _compact(self) -> None:
        # Keep the most salient + most recent
        keep = sorted(self._journal, key=lambda e: (e.salience, e.timestamp), reverse=True)
        self._journal = sorted(keep[: self.capacity], key=lambda e: e.timestamp)
        self._rebuild_index()

    def _rebuild_index(self) -> None:
        self._tag_index.clear()
        for i, ep in enumerate(self._journal):
            for t in ep.tags:
                self._tag_index[t].append(i)

    def __len__(self) -> int:
        return len(self._journal)
