"""Meta-memory — what the agent knows about its own memory and skills."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SkillRating:
    skill: str
    confidence: float  # 0..1
    last_assessed: float
    notes: str = ""


@dataclass
class MetaMemory:
    """Self-knowledge: confidence in skills, blind spots, calibration."""
    confidences: dict[str, SkillRating] = field(default_factory=dict)
    blind_spots: set[str] = field(default_factory=set)
    calibration_log: list[dict[str, Any]] = field(default_factory=list)

    def rate(self, skill: str, confidence: float, notes: str = "") -> None:
        import time
        self.confidences[skill] = SkillRating(skill=skill,
                                                confidence=max(0.0, min(1.0, confidence)),
                                                last_assessed=time.time(), notes=notes)

    def confidence(self, skill: str) -> float:
        rating = self.confidences.get(skill)
        return rating.confidence if rating else 0.5

    def mark_blind_spot(self, topic: str) -> None:
        self.blind_spots.add(topic)
        logger.info("Meta: registered blind spot %s", topic)

    def is_blind_spot(self, topic: str) -> bool:
        topic_l = topic.lower()
        return any(b.lower() in topic_l for b in self.blind_spots)

    def record_calibration(self, skill: str, predicted: float, actual: float) -> None:
        """Log how confident we were vs how it actually went (0..1)."""
        self.calibration_log.append({"skill": skill, "predicted": predicted, "actual": actual,
                                       "error": predicted - actual})
        # Nudge confidence toward observed performance
        rating = self.confidences.get(skill)
        if rating is not None:
            new_conf = 0.7 * rating.confidence + 0.3 * actual
            self.rate(skill, new_conf, rating.notes)

    def best_skills(self, k: int = 5) -> list[SkillRating]:
        return sorted(self.confidences.values(), key=lambda r: -r.confidence)[:k]

    def needs_practice(self, threshold: float = 0.4) -> list[str]:
        return [r.skill for r in self.confidences.values() if r.confidence < threshold]
