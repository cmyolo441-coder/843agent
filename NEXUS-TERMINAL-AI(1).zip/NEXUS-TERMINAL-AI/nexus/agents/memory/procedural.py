"""Procedural memory — skills/routines that can be executed."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

ProcedureFn = Callable[..., Awaitable[Any]]


@dataclass
class Procedure:
    """A named, parameterized skill the agent can invoke."""
    name: str
    fn: ProcedureFn
    description: str = ""
    parameter_schema: dict[str, Any] = field(default_factory=dict)
    success_count: int = 0
    failure_count: int = 0
    last_used: float = 0.0

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        return self.success_count / total if total else 0.0


@dataclass
class ProceduralMemory:
    """Registry of procedures with execution tracking."""
    procedures: dict[str, Procedure] = field(default_factory=dict)

    def register(self, name: str, fn: ProcedureFn, description: str = "",
                 schema: dict[str, Any] | None = None) -> Procedure:
        p = Procedure(name=name, fn=fn, description=description,
                       parameter_schema=schema or {})
        self.procedures[name] = p
        return p

    def get(self, name: str) -> Procedure | None:
        return self.procedures.get(name)

    async def execute(self, name: str, /, *args: Any, **kwargs: Any) -> Any:
        p = self.procedures.get(name)
        if p is None:
            raise KeyError(f"Unknown procedure: {name}")
        try:
            result = await p.fn(*args, **kwargs)
            p.success_count += 1
            p.last_used = time.time()
            return result
        except Exception:
            p.failure_count += 1
            p.last_used = time.time()
            logger.exception("Procedure %s failed", name)
            raise

    def best(self) -> list[Procedure]:
        return sorted(self.procedures.values(), key=lambda p: -p.success_rate)

    def by_keyword(self, keyword: str) -> list[Procedure]:
        kw = keyword.lower()
        return [p for p in self.procedures.values()
                if kw in p.name.lower() or kw in p.description.lower()]
