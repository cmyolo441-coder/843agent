"""Semantic memory — concepts and their relations."""
from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable

logger = logging.getLogger(__name__)


@dataclass
class Concept:
    """A semantic concept with attributes and links to other concepts."""
    name: str
    attributes: dict[str, Any] = field(default_factory=dict)
    is_a: set[str] = field(default_factory=set)
    has_a: set[str] = field(default_factory=set)
    related: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))


@dataclass
class SemanticMemory:
    """Concept graph supporting is-a/has-a/relation queries."""
    concepts: dict[str, Concept] = field(default_factory=dict)

    def get_or_create(self, name: str) -> Concept:
        c = self.concepts.get(name)
        if c is None:
            c = Concept(name=name)
            self.concepts[name] = c
        return c

    def define(self, name: str, **attributes: Any) -> Concept:
        c = self.get_or_create(name)
        c.attributes.update(attributes)
        return c

    def is_a(self, child: str, parent: str) -> None:
        self.get_or_create(child).is_a.add(parent)
        self.get_or_create(parent)

    def has_a(self, owner: str, part: str) -> None:
        self.get_or_create(owner).has_a.add(part)
        self.get_or_create(part)

    def relate(self, a: str, relation: str, b: str) -> None:
        self.get_or_create(a).related[relation].add(b)
        self.get_or_create(b)

    def is_instance_of(self, name: str, target: str, max_depth: int = 8) -> bool:
        """Walk is-a chain transitively."""
        seen: set[str] = set()
        stack = [name]
        depth = 0
        while stack and depth < max_depth:
            cur = stack.pop()
            if cur == target:
                return True
            if cur in seen:
                continue
            seen.add(cur)
            c = self.concepts.get(cur)
            if c:
                stack.extend(c.is_a)
            depth += 1
        return False

    def descendants(self, root: str) -> set[str]:
        """All concepts where is_a* contains root."""
        out: set[str] = set()
        for name in self.concepts:
            if name != root and self.is_instance_of(name, root):
                out.add(name)
        return out

    def neighbors(self, name: str, relation: str | None = None) -> set[str]:
        c = self.concepts.get(name)
        if c is None:
            return set()
        if relation is None:
            out: set[str] = set(c.is_a) | set(c.has_a)
            for vs in c.related.values():
                out |= vs
            return out
        return c.related.get(relation, set())

    def __len__(self) -> int:
        return len(self.concepts)
