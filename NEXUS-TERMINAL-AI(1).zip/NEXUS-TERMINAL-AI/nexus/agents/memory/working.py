"""Working memory — short-term scratch space, LRU-evicted."""
from __future__ import annotations

import logging
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class WorkingMemory:
    """LRU dict with time-based decay for short-lived agent state."""
    capacity: int = 64
    ttl_seconds: float = 600.0
    _store: "OrderedDict[str, tuple[Any, float]]" = field(default_factory=OrderedDict)

    def set(self, key: str, value: Any) -> None:
        self._evict_expired()
        if key in self._store:
            self._store.move_to_end(key)
        self._store[key] = (value, time.time())
        while len(self._store) > self.capacity:
            k, _ = self._store.popitem(last=False)
            logger.debug("WorkingMemory evict %s", k)

    def get(self, key: str, default: Any = None) -> Any:
        self._evict_expired()
        if key not in self._store:
            return default
        value, ts = self._store[key]
        if self._expired(ts):
            self._store.pop(key, None)
            return default
        self._store.move_to_end(key)
        return value

    def has(self, key: str) -> bool:
        return self.get(key, _SENTINEL) is not _SENTINEL

    def delete(self, key: str) -> None:
        self._store.pop(key, None)

    def keys(self) -> list[str]:
        self._evict_expired()
        return list(self._store.keys())

    def clear(self) -> None:
        self._store.clear()

    def _expired(self, ts: float) -> bool:
        return self.ttl_seconds > 0 and (time.time() - ts) > self.ttl_seconds

    def _evict_expired(self) -> None:
        if self.ttl_seconds <= 0:
            return
        now = time.time()
        expired = [k for k, (_, ts) in self._store.items() if (now - ts) > self.ttl_seconds]
        for k in expired:
            self._store.pop(k, None)


_SENTINEL = object()
