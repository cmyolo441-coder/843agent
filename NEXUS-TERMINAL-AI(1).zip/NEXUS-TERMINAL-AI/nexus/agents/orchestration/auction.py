"""Auction strategy: agents bid on the task; lowest bidder wins."""
from __future__ import annotations

import asyncio
import logging
import random
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class AuctionStrategy(OrchestrationStrategy):
    name = "auction"

    def __init__(self, second_price: bool = False) -> None:
        self.second_price = second_price  # Vickrey-style if True

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        bids = await asyncio.gather(*[self._collect_bid(a, goal, inputs) for a in agents])
        valid = [b for b in bids if b["bid"] is not None]
        if not valid:
            return {"strategy": self.name, "winner": None, "bids": bids}
        valid.sort(key=lambda b: b["bid"])
        winner = valid[0]
        clearing_price = valid[1]["bid"] if self.second_price and len(valid) > 1 else winner["bid"]
        logger.info("Auction winner: %s @ %.2f (clearing=%.2f)",
                     winner["agent"], winner["bid"], clearing_price)
        # Winner executes the task
        agent_lookup = {a.name: a for a in agents}
        ctx = await agent_lookup[winner["agent"]].run(goal, **inputs)
        return {"strategy": self.name, "bids": bids, "winner": winner["agent"],
                 "clearing_price": clearing_price,
                 "result": ctx.artifacts[-1] if ctx.artifacts else None}

    async def _collect_bid(self, agent: BaseAgent, goal: str, inputs: dict[str, Any]) -> dict[str, Any]:
        # In a real system the agent would estimate cost; here we model with random/options
        try:
            bid_opt = float(agent.options.get("bid_estimate", random.uniform(1.0, 10.0)))
            return {"agent": agent.name, "bid": bid_opt}
        except Exception as exc:  # noqa: BLE001
            logger.warning("Bid collect failed for %s: %s", agent.name, exc)
            return {"agent": agent.name, "bid": None}
