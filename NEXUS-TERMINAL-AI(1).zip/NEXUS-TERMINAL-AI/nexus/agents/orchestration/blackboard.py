"""Blackboard architecture: agents read/write a shared workspace."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


@dataclass
class Blackboard:
    """Shared workspace of (key -> value) entries."""
    _entries: dict[str, Any] = field(default_factory=dict)
    _versions: dict[str, int] = field(default_factory=dict)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def write(self, key: str, value: Any) -> int:
        async with self._lock:
            self._entries[key] = value
            self._versions[key] = self._versions.get(key, 0) + 1
            return self._versions[key]

    def read(self, key: str, default: Any = None) -> Any:
        return self._entries.get(key, default)

    def snapshot(self) -> dict[str, Any]:
        return dict(self._entries)


class BlackboardStrategy(OrchestrationStrategy):
    name = "blackboard"

    def __init__(self, max_rounds: int = 5) -> None:
        self.max_rounds = max_rounds

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        bb = Blackboard()
        await bb.write("goal", goal)
        for k, v in inputs.items():
            await bb.write(k, v)
        history: list[dict[str, Any]] = []
        for r in range(self.max_rounds):
            round_results = await asyncio.gather(*[
                a.run(goal, blackboard=bb.snapshot(), round=r) for a in agents
            ], return_exceptions=True)
            for agent, ctx in zip(agents, round_results):
                if isinstance(ctx, BaseException):
                    continue
                if ctx.artifacts:
                    await bb.write(f"{agent.name}_r{r}", ctx.artifacts[-1])
                history.append({"round": r, "agent": agent.name,
                                 "artifact": ctx.artifacts[-1] if ctx.artifacts else None})
            if bb.read("done"):
                logger.info("Blackboard: done flag set at round %d", r)
                break
        return {"strategy": self.name, "blackboard": bb.snapshot(), "history": history}
