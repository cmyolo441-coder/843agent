"""Consensus strategy: agents propose answers until a quorum agrees."""
from __future__ import annotations

import asyncio
import hashlib
import logging
from collections import Counter
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class ConsensusStrategy(OrchestrationStrategy):
    name = "consensus"

    def __init__(self, quorum: float = 0.6, max_rounds: int = 3) -> None:
        self.quorum = quorum
        self.max_rounds = max_rounds

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        history: list[dict[str, Any]] = []
        for r in range(self.max_rounds):
            results = await asyncio.gather(*[a.run(goal, round=r, **inputs) for a in agents],
                                            return_exceptions=True)
            artifacts: list[str] = []
            for a, ctx in zip(agents, results):
                if isinstance(ctx, BaseException) or not ctx.artifacts:
                    continue
                artifacts.append(self._canonical(ctx.artifacts[-1]))
            counts = Counter(artifacts)
            if not counts:
                continue
            top, n = counts.most_common(1)[0]
            ratio = n / max(1, len(agents))
            history.append({"round": r, "top_hash": top[:12], "support": n, "ratio": ratio})
            logger.info("Consensus round %d: top=%s support=%.2f", r, top[:8], ratio)
            if ratio >= self.quorum:
                return {"strategy": self.name, "reached": True, "support": ratio,
                         "answer_hash": top, "history": history}
        return {"strategy": self.name, "reached": False, "history": history}

    @staticmethod
    def _canonical(value: Any) -> str:
        s = str(value).strip().lower()
        return hashlib.sha256(s.encode("utf-8")).hexdigest()
