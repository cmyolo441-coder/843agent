"""Contract Net Protocol: announce task, collect bids, award contract."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


@dataclass
class Bid:
    agent: str
    capability_score: float = 0.0
    cost: float = 0.0
    estimate_seconds: float = 0.0
    notes: str = ""

    def utility(self) -> float:
        # higher cap, lower cost, lower estimate -> higher utility
        return self.capability_score / (1.0 + self.cost) / (1.0 + self.estimate_seconds / 10.0)


class ContractNetStrategy(OrchestrationStrategy):
    name = "contract_net"

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        announcement = {"goal": goal, **inputs}
        logger.info("CNP announce to %d agents: %s", len(agents), goal[:60])
        bids = await asyncio.gather(*[self._bid(a, announcement) for a in agents])
        valid = [b for b in bids if b is not None]
        if not valid:
            return {"strategy": self.name, "awarded": None, "result": None}
        winner_bid = max(valid, key=lambda b: b.utility())
        lookup = {a.name: a for a in agents}
        winner = lookup[winner_bid.agent]
        logger.info("CNP awarded contract to %s (utility=%.3f)", winner.name, winner_bid.utility())
        ctx = await winner.run(goal, **inputs)
        return {"strategy": self.name, "bids": [b.__dict__ for b in valid],
                 "awarded": winner.name,
                 "result": ctx.artifacts[-1] if ctx.artifacts else None}

    async def _bid(self, agent: BaseAgent, ann: dict[str, Any]) -> Bid | None:
        try:
            cap = float(agent.options.get("capability", 0.7))
            cost = float(agent.options.get("cost", 1.0))
            est = float(agent.options.get("estimate", 5.0))
            return Bid(agent=agent.name, capability_score=cap, cost=cost,
                        estimate_seconds=est, notes=str(ann.get("goal", ""))[:80])
        except Exception:  # noqa: BLE001
            logger.exception("CNP bid failed for %s", agent.name)
            return None
