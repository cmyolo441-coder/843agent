"""Debate strategy: agents argue across rounds; a judge picks the winner."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class DebateStrategy(OrchestrationStrategy):
    name = "debate"

    def __init__(self, rounds: int = 3, judge: BaseAgent | None = None) -> None:
        self.rounds = rounds
        self.judge = judge

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        if len(agents) < 2:
            raise RuntimeError("Debate requires at least 2 debaters")
        transcript: list[dict[str, Any]] = []
        prior_arguments: list[str] = []
        for r in range(self.rounds):
            round_results = await asyncio.gather(*[
                a.run(goal, round=r, prior=prior_arguments, position=("for" if i % 2 == 0 else "against"))
                for i, a in enumerate(agents)
            ], return_exceptions=True)
            for a, ctx in zip(agents, round_results):
                if isinstance(ctx, BaseException):
                    continue
                arg = ctx.artifacts[-1] if ctx.artifacts else ""
                transcript.append({"round": r, "agent": a.name, "argument": str(arg)})
                prior_arguments.append(str(arg))
            logger.info("Debate round %d complete (%d args total)", r + 1, len(prior_arguments))
        verdict = None
        if self.judge is not None:
            judge_ctx = await self.judge.run(f"Judge debate on: {goal}", transcript=transcript)
            verdict = judge_ctx.artifacts[-1] if judge_ctx.artifacts else None
        return {"strategy": self.name, "transcript": transcript, "verdict": verdict}
