"""Evolutionary strategy: generations of agent outputs, mutate & select best."""
from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass, field
from typing import Any, Callable

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


@dataclass
class Individual:
    genome: str  # the candidate solution
    fitness: float = 0.0
    parent: str | None = None


class EvolutionaryStrategy(OrchestrationStrategy):
    name = "evolutionary"

    def __init__(self, generations: int = 4, mutation_rate: float = 0.3,
                 fitness_fn: Callable[[str], float] | None = None) -> None:
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.fitness_fn = fitness_fn or (lambda g: float(len(g)) / 100.0)

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        # Seed: each agent contributes an initial candidate
        population = await self._seed(agents, goal, inputs)
        history: list[dict[str, Any]] = []
        for gen in range(self.generations):
            for ind in population:
                ind.fitness = self.fitness_fn(ind.genome)
            population.sort(key=lambda i: -i.fitness)
            history.append({"gen": gen, "best_fit": population[0].fitness,
                             "median": population[len(population) // 2].fitness})
            logger.info("EvoGen %d best=%.3f", gen, population[0].fitness)
            # Keep top half, regenerate bottom half via agents
            survivors = population[: max(1, len(population) // 2)]
            children = await self._mutate_via_agents(survivors, agents, goal)
            population = survivors + children
        best = max(population, key=lambda i: self.fitness_fn(i.genome))
        return {"strategy": self.name, "history": history,
                 "best_genome": best.genome, "best_fitness": best.fitness}

    async def _seed(self, agents: list[BaseAgent], goal: str, inputs: dict) -> list[Individual]:
        results = await asyncio.gather(*[a.run(goal, **inputs) for a in agents],
                                        return_exceptions=True)
        pop: list[Individual] = []
        for a, r in zip(agents, results):
            if isinstance(r, BaseException):
                continue
            g = str(r.artifacts[-1]) if r.artifacts else ""
            pop.append(Individual(genome=g, parent=a.name))
        return pop or [Individual(genome=goal)]

    async def _mutate_via_agents(self, survivors: list[Individual],
                                  agents: list[BaseAgent], goal: str) -> list[Individual]:
        out: list[Individual] = []
        for s in survivors:
            agent = random.choice(agents)
            mutate_prompt = f"Improve this candidate solution to '{goal}':\n{s.genome}"
            ctx = await agent.run(mutate_prompt, mutation_rate=self.mutation_rate)
            g = str(ctx.artifacts[-1]) if ctx.artifacts else s.genome
            out.append(Individual(genome=g, parent=s.genome[:40]))
        return out
