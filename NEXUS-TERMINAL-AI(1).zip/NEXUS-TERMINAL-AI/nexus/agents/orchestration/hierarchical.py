"""Hierarchical strategy: leader plans, workers execute, leader summarizes."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class HierarchicalStrategy(OrchestrationStrategy):
    name = "hierarchical"

    def __init__(self, leader: BaseAgent | None = None) -> None:
        self.leader = leader

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        if not agents:
            raise RuntimeError("hierarchical needs at least one agent")
        leader = self.leader or agents[0]
        workers = [a for a in agents if a is not leader]
        logger.info("Hierarchical: leader=%s workers=%d", leader.name, len(workers))

        # 1. Leader plans
        plan_ctx = await leader.run(f"PLAN: {goal}", **inputs)
        plan = plan_ctx.artifacts[-1] if plan_ctx.artifacts else goal

        # 2. Workers execute sub-tasks
        if isinstance(plan, list):
            subtasks = [str(s) for s in plan]
        else:
            subtasks = [f"{goal} (part {i+1})" for i in range(len(workers))]
        worker_tasks = [w.run(subtasks[i % len(subtasks)] if subtasks else goal)
                        for i, w in enumerate(workers)]
        worker_results = await asyncio.gather(*worker_tasks, return_exceptions=True)

        # 3. Leader synthesizes
        summary_inputs = {"worker_outputs": [
            r.artifacts[-1] if not isinstance(r, BaseException) and r.artifacts else str(r)
            for r in worker_results]}
        final_ctx = await leader.run(f"SUMMARIZE results for: {goal}", **summary_inputs)
        final = final_ctx.artifacts[-1] if final_ctx.artifacts else None
        return {"strategy": self.name, "plan": plan,
                 "worker_results": summary_inputs["worker_outputs"], "final": final}
