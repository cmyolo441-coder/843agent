"""Market-based coordination: agents trade tasks based on price signals."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


@dataclass
class MarketOrder:
    agent: str
    side: str  # "buy" or "sell"
    task: str
    price: float


@dataclass
class OrderBook:
    bids: list[MarketOrder] = field(default_factory=list)
    asks: list[MarketOrder] = field(default_factory=list)

    def match(self) -> list[tuple[MarketOrder, MarketOrder, float]]:
        """Match buy and sell orders; return (bid, ask, clearing_price) triples."""
        self.bids.sort(key=lambda o: -o.price)
        self.asks.sort(key=lambda o: o.price)
        matches: list[tuple[MarketOrder, MarketOrder, float]] = []
        while self.bids and self.asks and self.bids[0].price >= self.asks[0].price:
            b, a = self.bids.pop(0), self.asks.pop(0)
            matches.append((b, a, (b.price + a.price) / 2))
        return matches


class MarketStrategy(OrchestrationStrategy):
    name = "market"

    def __init__(self, base_price: float = 1.0) -> None:
        self.base_price = base_price

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        book = OrderBook()
        for i, a in enumerate(agents):
            side = "sell" if i % 2 == 0 else "buy"
            offered_price = self.base_price * float(a.options.get("price_factor", 1.0))
            book.bids.append(MarketOrder(a.name, "buy", goal, offered_price)) if side == "buy" \
                else book.asks.append(MarketOrder(a.name, "sell", goal, offered_price))
        matches = book.match()
        logger.info("Market matched %d pairs", len(matches))
        # Sellers execute the task
        lookup = {a.name: a for a in agents}
        executions = []
        for bid, ask, price in matches:
            seller = lookup.get(ask.agent)
            if seller is None:
                continue
            ctx = await seller.run(goal, **inputs)
            executions.append({"buyer": bid.agent, "seller": ask.agent, "price": price,
                                "result": ctx.artifacts[-1] if ctx.artifacts else None})
        return {"strategy": self.name, "matches": len(matches), "trades": executions}
