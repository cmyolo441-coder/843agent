"""Monte Carlo Tree Search orchestration over agent actions."""
from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field
from typing import Any, Callable

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


@dataclass
class MCTSNode:
    state: Any
    parent: "MCTSNode | None" = None
    children: list["MCTSNode"] = field(default_factory=list)
    visits: int = 0
    value: float = 0.0
    action: Any = None

    def ucb1(self, c: float = math.sqrt(2)) -> float:
        if self.visits == 0:
            return float("inf")
        parent_visits = self.parent.visits if self.parent else 1
        return (self.value / self.visits) + c * math.sqrt(math.log(parent_visits + 1) / self.visits)


class MCTSStrategy(OrchestrationStrategy):
    name = "mcts"

    def __init__(self, simulations: int = 32, max_depth: int = 4,
                 reward_fn: Callable[[Any], float] | None = None) -> None:
        self.simulations = simulations
        self.max_depth = max_depth
        self.reward_fn = reward_fn or (lambda s: random.random())

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        root = MCTSNode(state={"goal": goal, **inputs})
        for _ in range(self.simulations):
            leaf = self._select(root)
            await self._expand(leaf, agents)
            reward = self.reward_fn(leaf.state)
            self._backpropagate(leaf, reward)
        best = max(root.children, key=lambda c: c.visits) if root.children else root
        logger.info("MCTS done; best action visits=%d value=%.3f", best.visits, best.value)
        return {"strategy": self.name, "root_visits": root.visits,
                 "best_action": best.action, "best_value": best.value / max(1, best.visits)}

    def _select(self, node: MCTSNode) -> MCTSNode:
        depth = 0
        while node.children and depth < self.max_depth:
            node = max(node.children, key=lambda c: c.ucb1())
            depth += 1
        return node

    async def _expand(self, node: MCTSNode, agents: list[BaseAgent]) -> None:
        for a in agents:
            child = MCTSNode(state={**node.state, "via": a.name},
                              parent=node, action=a.name)
            node.children.append(child)

    @staticmethod
    def _backpropagate(node: MCTSNode, reward: float) -> None:
        cur: MCTSNode | None = node
        while cur is not None:
            cur.visits += 1
            cur.value += reward
            cur = cur.parent
