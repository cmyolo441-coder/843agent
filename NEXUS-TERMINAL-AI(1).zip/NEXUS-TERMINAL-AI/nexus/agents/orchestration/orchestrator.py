"""Top-level orchestrator that selects and runs a strategy."""
from __future__ import annotations

import abc
import logging
from dataclasses import dataclass, field
from typing import Any

from ..base_agent import BaseAgent

logger = logging.getLogger(__name__)


class OrchestrationStrategy(abc.ABC):
    """Base class for all orchestration strategies."""

    name: str = "abstract"

    @abc.abstractmethod
    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        """Run agents under this strategy and return aggregated results."""


@dataclass
class Orchestrator:
    """Selects and executes an orchestration strategy across agents."""
    strategy: OrchestrationStrategy
    agents: list[BaseAgent] = field(default_factory=list)

    def add(self, agent: BaseAgent) -> "Orchestrator":
        self.agents.append(agent)
        return self

    def set_strategy(self, strategy: OrchestrationStrategy) -> None:
        logger.info("Orchestrator switching strategy %s -> %s",
                     self.strategy.name if self.strategy else "none", strategy.name)
        self.strategy = strategy

    async def run(self, goal: str, **inputs: Any) -> dict[str, Any]:
        if not self.agents:
            raise RuntimeError("Orchestrator has no agents")
        logger.info("Orchestrator(%s) running with %d agents", self.strategy.name, len(self.agents))
        return await self.strategy.run(self.agents, goal, **inputs)
