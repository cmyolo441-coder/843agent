"""Parallel strategy: all agents run concurrently on the same goal."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class ParallelStrategy(OrchestrationStrategy):
    name = "parallel"

    def __init__(self, return_when: str = "ALL") -> None:
        self.return_when = return_when  # ALL | FIRST_COMPLETED

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        logger.info("Parallel running %d agents", len(agents))
        tasks = {asyncio.create_task(a.run(goal, **inputs)): a for a in agents}
        if self.return_when == "FIRST_COMPLETED":
            done, pending = await asyncio.wait(tasks.keys(),
                                                 return_when=asyncio.FIRST_COMPLETED)
            for p in pending:
                p.cancel()
        else:
            done = set()
            for t in asyncio.as_completed(list(tasks.keys())):
                done.add(await asyncio.shield(t))
        results = []
        for task, agent in tasks.items():
            if task.done() and not task.cancelled():
                try:
                    ctx = task.result()
                    last = ctx.artifacts[-1] if ctx.artifacts else None
                    results.append({"agent": agent.name, "artifact": last, "ok": True})
                except Exception as exc:  # noqa: BLE001
                    results.append({"agent": agent.name, "error": str(exc), "ok": False})
            else:
                results.append({"agent": agent.name, "ok": False, "cancelled": True})
        return {"strategy": self.name, "results": results}
