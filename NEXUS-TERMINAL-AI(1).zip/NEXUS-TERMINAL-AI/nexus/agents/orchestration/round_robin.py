"""Round-robin strategy: agents take turns until goal is met or max turns."""
from __future__ import annotations

import logging
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class RoundRobinStrategy(OrchestrationStrategy):
    name = "round_robin"

    def __init__(self, max_turns: int = 12) -> None:
        self.max_turns = max_turns

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        if not agents:
            return {"strategy": self.name, "turns": [], "final": None}
        turns: list[dict[str, Any]] = []
        shared_state: dict[str, Any] = dict(inputs)
        n = len(agents)
        for t in range(self.max_turns):
            agent = agents[t % n]
            ctx = await agent.run(goal, turn=t, shared=shared_state)
            last = ctx.artifacts[-1] if ctx.artifacts else None
            turns.append({"turn": t, "agent": agent.name, "artifact": last})
            shared_state["last_artifact"] = last
            if isinstance(last, dict) and last.get("done"):
                logger.info("Round-robin: agent %s declared done at turn %d", agent.name, t)
                break
        return {"strategy": self.name, "turns": turns, "final": turns[-1]["artifact"] if turns else None}
