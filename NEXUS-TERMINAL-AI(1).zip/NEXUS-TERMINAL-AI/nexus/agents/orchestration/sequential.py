"""Sequential strategy: agents run one after the other, passing outputs forward."""
from __future__ import annotations

import logging
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class SequentialStrategy(OrchestrationStrategy):
    name = "sequential"

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        results: list[dict[str, Any]] = []
        current_input = dict(inputs)
        current_goal = goal
        for i, agent in enumerate(agents):
            logger.info("Sequential step %d/%d: %s", i + 1, len(agents), agent.name)
            ctx = await agent.run(current_goal, **current_input)
            last_artifact = ctx.artifacts[-1] if ctx.artifacts else None
            results.append({"agent": agent.name, "state": agent.state.value,
                             "artifact": last_artifact, "iterations": ctx.iteration + 1})
            # Pass last output forward as next input
            current_input["previous"] = last_artifact
            if last_artifact:
                current_goal = f"{goal}\n\nContext from previous step: {str(last_artifact)[:300]}"
        return {"strategy": self.name, "steps": results,
                "final": results[-1]["artifact"] if results else None}
