"""Swarm strategy: many agents explore variants and a coordinator picks the best."""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class SwarmStrategy(OrchestrationStrategy):
    name = "swarm"

    def __init__(self, scorer: Callable[[Any], float] | None = None) -> None:
        self.scorer = scorer or (lambda art: len(str(art)) if art else 0)

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        logger.info("Swarm: %d agents exploring", len(agents))
        # Each agent runs with a different "seed" so outputs diverge.
        tasks = [a.run(goal, seed=i, **inputs) for i, a in enumerate(agents)]
        contexts = await asyncio.gather(*tasks, return_exceptions=True)

        candidates: list[dict[str, Any]] = []
        for agent, ctx in zip(agents, contexts):
            if isinstance(ctx, BaseException):
                continue
            last = ctx.artifacts[-1] if ctx.artifacts else None
            candidates.append({"agent": agent.name, "artifact": last,
                                "score": self.scorer(last)})
        if not candidates:
            return {"strategy": self.name, "best": None, "candidates": []}
        best = max(candidates, key=lambda c: c["score"])
        return {"strategy": self.name, "candidates": candidates, "best": best}
