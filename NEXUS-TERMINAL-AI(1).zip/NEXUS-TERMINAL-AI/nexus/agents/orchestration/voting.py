"""Voting strategy: agents vote on a set of options; aggregate via plurality/Borda."""
from __future__ import annotations

import asyncio
import logging
from collections import Counter, defaultdict
from enum import Enum
from typing import Any

from ..base_agent import BaseAgent
from .orchestrator import OrchestrationStrategy

logger = logging.getLogger(__name__)


class VotingMethod(str, Enum):
    PLURALITY = "plurality"
    BORDA = "borda"
    APPROVAL = "approval"


class VotingStrategy(OrchestrationStrategy):
    name = "voting"

    def __init__(self, options: list[str], method: VotingMethod = VotingMethod.PLURALITY) -> None:
        self.options = options
        self.method = method

    async def run(self, agents: list[BaseAgent], goal: str, **inputs: Any) -> dict[str, Any]:
        ballots = await asyncio.gather(*[a.run(goal, options=self.options, **inputs)
                                          for a in agents], return_exceptions=True)
        if self.method is VotingMethod.PLURALITY:
            winner, tally = self._plurality(ballots)
        elif self.method is VotingMethod.BORDA:
            winner, tally = self._borda(ballots)
        else:
            winner, tally = self._approval(ballots)
        logger.info("Voting(%s) winner=%s tally=%s", self.method.value, winner, tally)
        return {"strategy": self.name, "method": self.method.value, "winner": winner, "tally": tally}

    def _extract(self, ballot: Any) -> list[str]:
        if hasattr(ballot, "artifacts") and ballot.artifacts:
            last = ballot.artifacts[-1]
            if isinstance(last, list):
                return [str(x) for x in last]
            if isinstance(last, str):
                return [last]
        return []

    def _plurality(self, ballots: list[Any]) -> tuple[str | None, dict[str, int]]:
        counts: Counter[str] = Counter()
        for b in ballots:
            ranked = self._extract(b)
            if ranked:
                counts[ranked[0]] += 1
        if not counts:
            return None, {}
        winner = counts.most_common(1)[0][0]
        return winner, dict(counts)

    def _borda(self, ballots: list[Any]) -> tuple[str | None, dict[str, int]]:
        scores: dict[str, int] = defaultdict(int)
        n = len(self.options)
        for b in ballots:
            ranked = self._extract(b)
            for i, opt in enumerate(ranked[:n]):
                scores[opt] += (n - i)
        if not scores:
            return None, {}
        winner = max(scores.items(), key=lambda kv: kv[1])[0]
        return winner, dict(scores)

    def _approval(self, ballots: list[Any]) -> tuple[str | None, dict[str, int]]:
        counts: Counter[str] = Counter()
        for b in ballots:
            for opt in set(self._extract(b)):
                counts[opt] += 1
        if not counts:
            return None, {}
        return counts.most_common(1)[0][0], dict(counts)
