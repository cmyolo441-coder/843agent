"""Ablation reasoning: remove components systematically to find what matters."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Evaluator = Callable[[list[str]], Awaitable[float]]


@dataclass
class AblationResult:
    component: str
    score: float
    delta_from_baseline: float


@dataclass
class Ablation:
    """Sequentially drop each component and measure impact on a metric."""
    evaluator: Evaluator

    async def run(self, components: list[str]) -> dict[str, Any]:
        if not components:
            return {"baseline": 0.0, "results": []}
        baseline = await self.evaluator(components)
        results: list[AblationResult] = []
        for c in components:
            remaining = [x for x in components if x != c]
            score = await self.evaluator(remaining)
            results.append(AblationResult(component=c, score=score,
                                            delta_from_baseline=score - baseline))
            logger.debug("Ablating %s -> score=%.3f (Δ=%.3f)", c, score, score - baseline)
        results.sort(key=lambda r: r.delta_from_baseline)
        most_important = results[0].component if results else None
        return {"baseline": baseline,
                 "results": [r.__dict__ for r in results],
                 "most_important": most_important}
