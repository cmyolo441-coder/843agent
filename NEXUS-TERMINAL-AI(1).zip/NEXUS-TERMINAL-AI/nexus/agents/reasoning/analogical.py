"""Analogical reasoning: map structure from a known case to a new problem."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class Analogy:
    """A structural mapping between source and target domains."""
    source_domain: str
    target_domain: str
    mappings: dict[str, str] = field(default_factory=dict)

    def apply(self, source_term: str) -> str | None:
        return self.mappings.get(source_term)

    def invert(self) -> "Analogy":
        return Analogy(source_domain=self.target_domain, target_domain=self.source_domain,
                        mappings={v: k for k, v in self.mappings.items()})


@dataclass
class AnalogicalReasoner:
    """Find and apply analogies from a small library."""
    library: list[Analogy] = field(default_factory=list)

    def add(self, analogy: Analogy) -> None:
        self.library.append(analogy)

    def find(self, target_domain: str) -> list[Analogy]:
        t = target_domain.lower()
        return [a for a in self.library if a.target_domain.lower() == t]

    def transfer(self, target_domain: str, source_term: str) -> list[str]:
        """Find candidate transferred concepts."""
        out: list[str] = []
        for a in self.find(target_domain):
            mapped = a.apply(source_term)
            if mapped:
                out.append(mapped)
        return out

    def map_problem(self, target_domain: str, source_problem: dict[str, str]) -> dict[str, str]:
        """Apply best matching analogy to all keys/values in a problem dict."""
        analogies = self.find(target_domain)
        if not analogies:
            return source_problem
        # Choose the analogy with most overlapping terms
        best = max(analogies, key=lambda a: sum(1 for v in source_problem.values() if v in a.mappings))
        return {k: best.apply(v) or v for k, v in source_problem.items()}
