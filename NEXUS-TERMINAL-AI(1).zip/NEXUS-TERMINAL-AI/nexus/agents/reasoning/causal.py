"""Causal reasoning over a small directed graph of variables."""
from __future__ import annotations

import logging
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class CausalReasoner:
    """Directed-graph reasoning: ancestors, descendants, do-intervention."""
    edges: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))

    def add_edge(self, cause: str, effect: str) -> None:
        self.edges[cause].add(effect)
        self.edges.setdefault(effect, set())

    def descendants(self, node: str) -> set[str]:
        out: set[str] = set()
        q: deque[str] = deque([node])
        while q:
            cur = q.popleft()
            for child in self.edges.get(cur, set()):
                if child not in out:
                    out.add(child)
                    q.append(child)
        return out

    def ancestors(self, node: str) -> set[str]:
        out: set[str] = set()
        for parent, children in self.edges.items():
            if node in children:
                out.add(parent)
                out |= self.ancestors(parent)
        return out

    def is_cause(self, cause: str, effect: str) -> bool:
        return effect in self.descendants(cause)

    def intervene(self, node: str) -> "CausalReasoner":
        """do-operator: return a graph with all incoming edges to `node` removed."""
        new = CausalReasoner()
        for parent, children in self.edges.items():
            for child in children:
                if child == node:
                    continue
                new.add_edge(parent, child)
        return new

    def explain(self, cause: str, effect: str) -> list[str]:
        """Return a (probable) path from cause to effect, BFS."""
        if cause == effect:
            return [cause]
        parents: dict[str, str] = {}
        seen = {cause}
        q: deque[str] = deque([cause])
        while q:
            cur = q.popleft()
            for child in self.edges.get(cur, set()):
                if child in seen:
                    continue
                parents[child] = cur
                if child == effect:
                    path = [child]
                    while path[-1] != cause:
                        path.append(parents[path[-1]])
                    return list(reversed(path))
                seen.add(child)
                q.append(child)
        return []
