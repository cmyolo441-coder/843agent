"""Chain-of-thought reasoning: encourage step-by-step thinking."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ChainOfThought:
    """Wraps a problem with a CoT prompt and extracts steps + answer."""
    nudge: str = "Let's think step by step."
    answer_marker: str = "ANSWER:"

    def prompt(self, problem: str) -> str:
        return f"{problem}\n\n{self.nudge}"

    def parse(self, output: str) -> dict[str, Any]:
        steps = self._extract_steps(output)
        answer = self._extract_answer(output)
        return {"steps": steps, "answer": answer, "n_steps": len(steps)}

    def _extract_steps(self, text: str) -> list[str]:
        out: list[str] = []
        for line in text.splitlines():
            m = re.match(r"\s*(?:step\s*\d+[:.)]?|\d+[.):])\s*(.+)$", line, re.IGNORECASE)
            if m:
                out.append(m.group(1).strip())
        return out

    def _extract_answer(self, text: str) -> str:
        m = re.search(rf"{re.escape(self.answer_marker)}\s*(.*)", text)
        if m:
            return m.group(1).strip()
        # Fallback: last non-empty line
        lines = [l for l in text.splitlines() if l.strip()]
        return lines[-1] if lines else ""

    def confidence(self, parsed: dict[str, Any]) -> float:
        steps = parsed.get("steps", [])
        if not steps:
            return 0.3
        # More steps with longer reasoning -> higher confidence (saturating)
        avg_len = sum(len(s) for s in steps) / len(steps)
        return min(1.0, 0.4 + 0.05 * len(steps) + 0.001 * avg_len)
