"""Deductive reasoning: apply rules to facts via forward chaining."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class Rule:
    """If all premises are in the fact set, conclude the consequent."""
    name: str
    premises: list[str]
    conclusion: str

    def fires(self, facts: set[str]) -> bool:
        return all(p in facts for p in self.premises)


@dataclass
class DeductiveReasoner:
    """Forward-chaining engine over a fact base and rule set."""
    facts: set[str] = field(default_factory=set)
    rules: list[Rule] = field(default_factory=list)
    max_iters: int = 64

    def add_fact(self, fact: str) -> None:
        self.facts.add(fact)

    def add_rule(self, rule: Rule) -> None:
        self.rules.append(rule)

    def infer(self) -> dict[str, Any]:
        """Iterate until no new facts emerge."""
        derived: list[dict[str, Any]] = []
        for it in range(self.max_iters):
            new_facts: set[str] = set()
            fired: list[str] = []
            for rule in self.rules:
                if rule.fires(self.facts) and rule.conclusion not in self.facts:
                    new_facts.add(rule.conclusion)
                    fired.append(rule.name)
            if not new_facts:
                logger.debug("Deduction stable at iter %d", it)
                break
            self.facts |= new_facts
            derived.append({"iter": it, "new": sorted(new_facts), "fired": fired})
        return {"facts": sorted(self.facts), "trace": derived}

    def entails(self, claim: str) -> bool:
        self.infer()
        return claim in self.facts
