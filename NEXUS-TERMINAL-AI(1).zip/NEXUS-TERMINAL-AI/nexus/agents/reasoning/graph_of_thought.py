"""Graph-of-thought reasoning — DAG of intermediate thoughts."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class GoTNode:
    id: str
    content: str
    score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class GraphOfThought:
    """Maintain a DAG of thoughts with parent/child edges and aggregation."""
    nodes: dict[str, GoTNode] = field(default_factory=dict)
    edges: dict[str, set[str]] = field(default_factory=dict)
    reverse_edges: dict[str, set[str]] = field(default_factory=dict)

    def add(self, node: GoTNode, parents: list[str] | None = None) -> None:
        self.nodes[node.id] = node
        self.edges.setdefault(node.id, set())
        for p in parents or []:
            self.edges.setdefault(p, set()).add(node.id)
            self.reverse_edges.setdefault(node.id, set()).add(p)

    def neighbors(self, node_id: str) -> list[GoTNode]:
        return [self.nodes[c] for c in self.edges.get(node_id, set()) if c in self.nodes]

    def parents(self, node_id: str) -> list[GoTNode]:
        return [self.nodes[p] for p in self.reverse_edges.get(node_id, set()) if p in self.nodes]

    def merge(self, ids: list[str], new_id: str, content: str) -> GoTNode:
        """Merge multiple thoughts into a new aggregate node."""
        merged = GoTNode(id=new_id, content=content,
                          score=max((self.nodes[i].score for i in ids if i in self.nodes), default=0.0))
        self.add(merged, parents=ids)
        return merged

    def best_path(self, target_id: str) -> list[GoTNode]:
        """Walk backwards from target via best-scoring parents."""
        path: list[GoTNode] = []
        cur_id: str | None = target_id
        seen: set[str] = set()
        while cur_id and cur_id in self.nodes and cur_id not in seen:
            seen.add(cur_id)
            path.append(self.nodes[cur_id])
            parents = self.parents(cur_id)
            if not parents:
                break
            cur_id = max(parents, key=lambda n: n.score).id
        return list(reversed(path))

    def stats(self) -> dict[str, int]:
        return {"nodes": len(self.nodes),
                 "edges": sum(len(s) for s in self.edges.values())}
