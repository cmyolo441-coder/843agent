"""Inductive reasoning: generalize a rule from examples."""
from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class Hypothesis:
    description: str
    predicate: Callable[[Any], bool]
    support: int = 0
    coverage: float = 0.0
    accuracy: float = 0.0


@dataclass
class InductiveReasoner:
    """Build candidate hypotheses from labeled examples and score them."""
    candidates: list[Hypothesis] = field(default_factory=list)

    def add_hypothesis(self, h: Hypothesis) -> None:
        self.candidates.append(h)

    def fit(self, examples: list[tuple[Any, bool]]) -> Hypothesis | None:
        """Evaluate each candidate and return the best by accuracy * coverage."""
        if not examples or not self.candidates:
            return None
        n = len(examples)
        for h in self.candidates:
            preds = [h.predicate(x) for x, _ in examples]
            tp = sum(1 for p, (_, y) in zip(preds, examples) if p and y)
            tn = sum(1 for p, (_, y) in zip(preds, examples) if not p and not y)
            covered = sum(preds)
            h.support = tp
            h.coverage = covered / n
            h.accuracy = (tp + tn) / n
        ranked = sorted(self.candidates, key=lambda h: -(h.accuracy * (0.5 + h.coverage)))
        best = ranked[0]
        logger.info("Best hypothesis: %s acc=%.2f cov=%.2f", best.description, best.accuracy, best.coverage)
        return best

    @staticmethod
    def majority_label(examples: list[tuple[Any, bool]]) -> bool:
        counts = Counter(label for _, label in examples)
        return counts[True] >= counts[False]
