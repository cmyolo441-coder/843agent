"""Least-to-most prompting: solve easiest subproblems first."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Decomposer = Callable[[str], Awaitable[list[str]]]
Solver = Callable[[str, list[dict[str, str]]], Awaitable[str]]
Difficulty = Callable[[str], float]


@dataclass
class LeastToMost:
    """Decompose, sort by difficulty (asc), solve in order using prior answers."""
    decomposer: Decomposer
    solver: Solver
    difficulty: Difficulty | None = None

    async def run(self, problem: str) -> dict[str, Any]:
        subs = await self.decomposer(problem)
        if self.difficulty is not None:
            subs = sorted(subs, key=self.difficulty)
        else:
            subs = sorted(subs, key=lambda s: len(s))
        logger.info("LeastToMost solving %d subproblems in order", len(subs))
        prior: list[dict[str, str]] = []
        for s in subs:
            answer = await self.solver(s, prior)
            prior.append({"q": s, "a": answer})
        final = await self.solver(problem, prior)
        return {"subs": prior, "final": final}
