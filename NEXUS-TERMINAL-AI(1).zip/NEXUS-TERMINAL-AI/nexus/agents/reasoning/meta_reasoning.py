"""Meta-reasoning: decide which reasoning strategy to use for a problem."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class Strategy(str, Enum):
    COT = "chain_of_thought"
    TOT = "tree_of_thought"
    REACT = "react"
    PLAN_SOLVE = "plan_solve"
    SELF_ASK = "self_ask"
    REFLEXION = "reflexion"
    DEDUCTIVE = "deductive"
    INDUCTIVE = "inductive"


@dataclass
class MetaReasoner:
    """Picks a reasoning strategy based on heuristics about the problem."""
    cost_budget: float = 1.0  # 0..1, where 1 means "any cost allowed"

    def classify(self, problem: str) -> dict[str, Any]:
        p = problem.lower()
        features = {
            "is_math": bool(re.search(r"[\d+\-*/=]\s*[\d]|\bcompute|\bsolve\b", p)),
            "has_tools_hint": bool(re.search(r"\bsearch|\bfetch|\blookup|\btool|\bapi\b", p)),
            "is_compound": bool(re.search(r"\band\b|\bthen\b|;|\,", p)) and len(p.split()) > 20,
            "needs_facts": bool(re.search(r"\bwho|\bwhen|\bwhere|\bcite\b", p)),
            "is_open_ended": bool(re.search(r"\bdesign|\bpropose|\bbrainstorm\b", p)),
            "length": len(p),
        }
        return features

    def decide(self, problem: str) -> Strategy:
        f = self.classify(problem)
        if f["has_tools_hint"]:
            return Strategy.REACT
        if f["is_open_ended"] and self.cost_budget > 0.6:
            return Strategy.TOT
        if f["is_compound"]:
            return Strategy.PLAN_SOLVE
        if f["needs_facts"]:
            return Strategy.SELF_ASK
        if f["is_math"]:
            return Strategy.COT
        if f["length"] > 500:
            return Strategy.REFLEXION
        return Strategy.COT

    def justify(self, problem: str) -> dict[str, Any]:
        feats = self.classify(problem)
        choice = self.decide(problem)
        return {"strategy": choice.value, "features": feats}
