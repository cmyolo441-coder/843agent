"""Plan-and-Solve: first plan, then execute each step, then verify."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Planner = Callable[[str], Awaitable[list[str]]]
StepRunner = Callable[[str, dict[str, Any]], Awaitable[str]]
Verifier = Callable[[str, str], Awaitable[bool]]


@dataclass
class PlanSolve:
    """Implements the Plan-and-Solve prompting strategy."""
    planner: Planner
    runner: StepRunner
    verifier: Verifier | None = None

    async def run(self, problem: str) -> dict[str, Any]:
        plan = await self.planner(problem)
        logger.info("PlanSolve plan with %d steps", len(plan))
        state: dict[str, Any] = {"problem": problem, "results": []}
        for i, step in enumerate(plan, 1):
            result = await self.runner(step, state)
            state["results"].append({"step": i, "action": step, "result": result})
            state["last"] = result
        final = state.get("last", "")
        verified = True
        if self.verifier is not None:
            verified = await self.verifier(problem, final)
        return {"plan": plan, "trace": state["results"], "final": final, "verified": verified}
