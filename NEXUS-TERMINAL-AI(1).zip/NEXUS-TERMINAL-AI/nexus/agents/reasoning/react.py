"""ReAct (Reason + Act) reasoner."""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

ToolFn = Callable[[str, dict[str, Any]], Awaitable[str]]

_THOUGHT = re.compile(r"Thought:\s*(.+)", re.IGNORECASE)
_ACTION = re.compile(r"Action:\s*([A-Za-z0-9_.\-]+)", re.IGNORECASE)
_ACTION_INPUT = re.compile(r"Action Input:\s*(.+)", re.IGNORECASE | re.DOTALL)
_FINAL = re.compile(r"Final Answer:\s*(.+)", re.IGNORECASE | re.DOTALL)


@dataclass
class ReActStep:
    thought: str = ""
    action: str | None = None
    action_input: dict[str, Any] | None = None
    observation: str | None = None
    final_answer: str | None = None


@dataclass
class ReActReasoner:
    """Parse ReAct-formatted output and drive a tool loop."""
    tools: dict[str, ToolFn] = field(default_factory=dict)
    max_steps: int = 8

    def register_tool(self, name: str, fn: ToolFn) -> None:
        self.tools[name] = fn

    def parse_step(self, text: str) -> ReActStep:
        step = ReActStep()
        if m := _THOUGHT.search(text):
            step.thought = m.group(1).strip().splitlines()[0]
        if m := _ACTION.search(text):
            step.action = m.group(1).strip()
        if m := _ACTION_INPUT.search(text):
            raw = m.group(1).strip()
            try:
                step.action_input = json.loads(raw)
            except json.JSONDecodeError:
                step.action_input = {"_raw": raw}
        if m := _FINAL.search(text):
            step.final_answer = m.group(1).strip()
        return step

    async def execute(self, step: ReActStep) -> str:
        if not step.action:
            return ""
        tool = self.tools.get(step.action)
        if tool is None:
            return f"<error: unknown tool {step.action}>"
        try:
            return await tool(step.action, step.action_input or {})
        except Exception as exc:  # noqa: BLE001
            logger.exception("Tool %s failed", step.action)
            return f"<error: {exc}>"

    async def run(self, generate_step: Callable[[str], Awaitable[str]],
                  initial_prompt: str) -> dict[str, Any]:
        scratchpad = initial_prompt
        history: list[ReActStep] = []
        for _ in range(self.max_steps):
            chunk = await generate_step(scratchpad)
            step = self.parse_step(chunk)
            history.append(step)
            if step.final_answer:
                return {"answer": step.final_answer, "trace": history}
            obs = await self.execute(step)
            step.observation = obs
            scratchpad += f"\n{chunk}\nObservation: {obs}\n"
        return {"answer": None, "trace": history}
