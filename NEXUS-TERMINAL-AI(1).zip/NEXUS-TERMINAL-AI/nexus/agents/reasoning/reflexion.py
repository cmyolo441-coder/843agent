"""Reflexion: self-critique after failures, accumulate lessons across retries."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Solver = Callable[[str, list[str]], Awaitable[str]]
Verifier = Callable[[str], Awaitable[bool]]
Critic = Callable[[str, str], Awaitable[str]]


@dataclass
class ReflexionMemory:
    lessons: list[str] = field(default_factory=list)

    def add(self, lesson: str) -> None:
        if lesson and lesson not in self.lessons:
            self.lessons.append(lesson)

    def render(self) -> str:
        return "\n".join(f"- {l}" for l in self.lessons)


@dataclass
class Reflexion:
    """Run solve -> verify -> critique loop until success or max retries."""
    solver: Solver
    verifier: Verifier
    critic: Critic
    max_retries: int = 3
    memory: ReflexionMemory = field(default_factory=ReflexionMemory)

    async def run(self, task: str) -> dict[str, Any]:
        attempts: list[dict[str, Any]] = []
        for attempt in range(self.max_retries + 1):
            candidate = await self.solver(task, self.memory.lessons)
            ok = await self.verifier(candidate)
            attempts.append({"attempt": attempt, "candidate": candidate[:500], "ok": ok})
            if ok:
                logger.info("Reflexion succeeded after %d attempt(s)", attempt + 1)
                return {"success": True, "answer": candidate,
                         "attempts": attempts, "lessons": list(self.memory.lessons)}
            lesson = await self.critic(task, candidate)
            self.memory.add(lesson)
            logger.info("Reflexion attempt %d failed; lesson=%s", attempt + 1, lesson[:80])
        return {"success": False, "answer": attempts[-1]["candidate"] if attempts else None,
                 "attempts": attempts, "lessons": list(self.memory.lessons)}
