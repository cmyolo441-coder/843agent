"""Scratchpad — append-only working memory for intermediate thoughts."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Iterable

logger = logging.getLogger(__name__)


@dataclass
class ScratchEntry:
    timestamp: float
    kind: str
    content: str
    tags: list[str] = field(default_factory=list)


@dataclass
class Scratchpad:
    """In-memory scratchpad with simple search and rendering."""
    entries: list[ScratchEntry] = field(default_factory=list)
    max_size: int = 1024

    def write(self, kind: str, content: str, tags: Iterable[str] | None = None) -> ScratchEntry:
        e = ScratchEntry(timestamp=time.time(), kind=kind, content=content,
                          tags=list(tags or []))
        self.entries.append(e)
        if len(self.entries) > self.max_size:
            self.entries = self.entries[-self.max_size:]
        return e

    def thought(self, text: str) -> ScratchEntry:
        return self.write("thought", text)

    def observation(self, text: str) -> ScratchEntry:
        return self.write("observation", text)

    def action(self, text: str) -> ScratchEntry:
        return self.write("action", text)

    def search(self, query: str, limit: int = 10) -> list[ScratchEntry]:
        q = query.lower()
        hits = [e for e in self.entries if q in e.content.lower()]
        return hits[-limit:]

    def filter(self, kind: str) -> list[ScratchEntry]:
        return [e for e in self.entries if e.kind == kind]

    def render(self, limit: int | None = None) -> str:
        items = self.entries[-limit:] if limit else self.entries
        return "\n".join(f"[{e.kind}] {e.content}" for e in items)

    def clear(self) -> None:
        self.entries.clear()
