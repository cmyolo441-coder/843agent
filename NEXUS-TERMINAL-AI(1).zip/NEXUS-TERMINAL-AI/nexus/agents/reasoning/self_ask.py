"""Self-Ask: decompose into sub-questions and answer each."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

SubAnswerer = Callable[[str], Awaitable[str]]
Decomposer = Callable[[str], Awaitable[list[str]]]


@dataclass
class SelfAsk:
    """Decompose a compound question into atomic sub-questions and combine answers."""
    decomposer: Decomposer
    sub_answerer: SubAnswerer
    max_subs: int = 6

    async def run(self, question: str) -> dict[str, Any]:
        subs = await self.decomposer(question)
        subs = subs[: self.max_subs] if subs else self._naive_split(question)
        qa: list[dict[str, str]] = []
        for sub in subs:
            ans = await self.sub_answerer(sub)
            qa.append({"q": sub, "a": ans})
            logger.debug("SelfAsk sub=%s -> %s", sub[:60], ans[:60])
        final = self._combine(question, qa)
        return {"question": question, "subs": qa, "final": final}

    def _naive_split(self, q: str) -> list[str]:
        parts = re.split(r"\?|\band\b|\bor\b|;", q)
        return [p.strip() + "?" for p in parts if p.strip()]

    def _combine(self, q: str, qa: list[dict[str, str]]) -> str:
        joined = " ".join(item["a"] for item in qa)
        return f"For '{q}': {joined}".strip()
