"""Self-refine: iteratively improve an answer via self-feedback."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Generator = Callable[[str], Awaitable[str]]
Refiner = Callable[[str, str], Awaitable[str]]
Feedbacker = Callable[[str], Awaitable[str]]


@dataclass
class SelfRefine:
    """Generate, critique, refine until a stop criterion."""
    generator: Generator
    feedbacker: Feedbacker
    refiner: Refiner
    max_iters: int = 3
    stop_phrase: str = "LGTM"

    async def run(self, prompt: str) -> dict[str, Any]:
        current = await self.generator(prompt)
        history: list[dict[str, str]] = [{"iter": "0", "draft": current}]
        for i in range(self.max_iters):
            feedback = await self.feedbacker(current)
            history.append({"iter": f"{i}fb", "feedback": feedback})
            if self.stop_phrase.lower() in feedback.lower():
                logger.info("Self-refine: stop phrase reached at iter %d", i)
                break
            current = await self.refiner(current, feedback)
            history.append({"iter": str(i + 1), "draft": current})
        return {"final": current, "iterations": len(history) // 2, "history": history}
