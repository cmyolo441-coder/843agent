"""Tree-of-thought search reasoning."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Expander = Callable[[str, int], Awaitable[list[str]]]
Evaluator = Callable[[str], Awaitable[float]]


@dataclass
class ToTNode:
    state: str
    score: float = 0.0
    parent: "ToTNode | None" = None
    children: list["ToTNode"] = field(default_factory=list)
    depth: int = 0


@dataclass
class TreeOfThought:
    branching: int = 3
    max_depth: int = 3
    beam_width: int = 3
    expander: Expander | None = None
    evaluator: Evaluator | None = None

    async def search(self, root_state: str) -> ToTNode:
        root = ToTNode(state=root_state, depth=0)
        frontier: list[ToTNode] = [root]
        for d in range(self.max_depth):
            expanded: list[ToTNode] = []
            for node in frontier:
                children = await self._expand(node)
                node.children.extend(children)
                expanded.extend(children)
            if not expanded:
                break
            # score and keep top-k
            await asyncio.gather(*[self._score(n) for n in expanded])
            expanded.sort(key=lambda n: -n.score)
            frontier = expanded[: self.beam_width]
            logger.debug("ToT depth=%d frontier=%d best=%.3f", d + 1,
                          len(frontier), frontier[0].score if frontier else 0.0)
        return max(self._all_nodes(root), key=lambda n: n.score) if root.children else root

    async def _expand(self, node: ToTNode) -> list[ToTNode]:
        if self.expander is None:
            return [ToTNode(state=f"{node.state} | option {i}",
                             parent=node, depth=node.depth + 1)
                    for i in range(self.branching)]
        kids = await self.expander(node.state, self.branching)
        return [ToTNode(state=k, parent=node, depth=node.depth + 1) for k in kids[: self.branching]]

    async def _score(self, node: ToTNode) -> None:
        if self.evaluator is None:
            node.score = len(node.state) / 1000.0
            return
        node.score = await self.evaluator(node.state)

    def _all_nodes(self, root: ToTNode) -> list[ToTNode]:
        out: list[ToTNode] = []
        stack = [root]
        while stack:
            n = stack.pop()
            out.append(n)
            stack.extend(n.children)
        return out
