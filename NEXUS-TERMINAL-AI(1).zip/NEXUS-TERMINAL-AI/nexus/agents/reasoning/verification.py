"""Verifier — check candidate answers against constraints and evidence."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Check = Callable[[str, dict[str, Any]], Awaitable[tuple[bool, str]]]


@dataclass
class Verifier:
    """Runs a chain of async checks; reports pass/fail + reasons."""
    checks: list[Check] = field(default_factory=list)
    stop_on_first_fail: bool = False

    def add(self, check: Check) -> "Verifier":
        self.checks.append(check)
        return self

    async def verify(self, candidate: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        ctx = context or {}
        results: list[dict[str, Any]] = []
        all_ok = True
        for i, c in enumerate(self.checks):
            try:
                ok, reason = await c(candidate, ctx)
            except Exception as exc:  # noqa: BLE001
                ok, reason = False, f"check#{i} raised: {exc}"
            results.append({"index": i, "ok": ok, "reason": reason})
            all_ok = all_ok and ok
            if not ok and self.stop_on_first_fail:
                break
        return {"ok": all_ok, "checks": results}

    @staticmethod
    async def regex_check(pattern: str, must_match: bool = True):
        async def _check(candidate: str, ctx: dict[str, Any]) -> tuple[bool, str]:
            hit = bool(re.search(pattern, candidate))
            ok = hit if must_match else not hit
            return ok, f"regex {pattern!r} {'matched' if hit else 'no match'}"
        return _check

    @staticmethod
    async def length_check(min_chars: int = 0, max_chars: int = 10**6):
        async def _check(candidate: str, ctx: dict[str, Any]) -> tuple[bool, str]:
            n = len(candidate)
            return (min_chars <= n <= max_chars,
                    f"length {n} not in [{min_chars}, {max_chars}]" if not (min_chars <= n <= max_chars) else "ok")
        return _check
