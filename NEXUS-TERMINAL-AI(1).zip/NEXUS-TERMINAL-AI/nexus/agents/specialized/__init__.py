"""Specialized agents — concrete role implementations on top of BaseAgent."""
from __future__ import annotations

from .planner_agent import PlannerAgent
from .coder_agent import CoderAgent
from .reviewer_agent import ReviewerAgent
from .debugger_agent import DebuggerAgent
from .researcher_agent import ResearcherAgent
from .analyst_agent import AnalystAgent
from .writer_agent import WriterAgent
from .critic_agent import CriticAgent
from .validator_agent import ValidatorAgent
from .summarizer_agent import SummarizerAgent
from .translator_agent import TranslatorAgent
from .security_agent import SecurityAgent
from .tester_agent import TesterAgent
from .architect_agent import ArchitectAgent
from .devops_agent import DevOpsAgent
from .doc_agent import DocAgent
from .math_agent import MathAgent
from .legal_agent import LegalAgent
from .finance_agent import FinanceAgent
from .medical_agent import MedicalAgent
from .creative_agent import CreativeAgent
from .tutor_agent import TutorAgent
from .sentinel_agent import SentinelAgent

__all__ = [
    "PlannerAgent", "CoderAgent", "ReviewerAgent", "DebuggerAgent", "ResearcherAgent",
    "AnalystAgent", "WriterAgent", "CriticAgent", "ValidatorAgent", "SummarizerAgent",
    "TranslatorAgent", "SecurityAgent", "TesterAgent", "ArchitectAgent", "DevOpsAgent",
    "DocAgent", "MathAgent", "LegalAgent", "FinanceAgent", "MedicalAgent",
    "CreativeAgent", "TutorAgent", "SentinelAgent",
]
