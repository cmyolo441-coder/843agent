"""AnalystAgent — quantitative analysis over structured data."""
from __future__ import annotations

import logging
import statistics
from typing import Any, Sequence

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("analyst")
class AnalystAgent(BaseAgent):
    role = "analyst"
    system_prompt = "You are a data analyst. Produce numerical summaries and insights."

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        data = ctx.inputs.get("data", [])
        return {"data": data, "n": len(data) if hasattr(data, "__len__") else 0}

    async def decide(self, ctx: AgentContext) -> str | None:
        if ctx.iteration > 0:
            return None
        return "describe"

    async def act(self, decision: str, ctx: AgentContext) -> dict[str, Any]:
        data = ctx.inputs.get("data", [])
        if not data:
            return {"summary": "no data"}
        rows = self._extract_numeric(data)
        results: dict[str, Any] = {}
        for col, vals in rows.items():
            if vals:
                results[col] = self._describe(vals)
        results["n_rows"] = max((len(v) for v in rows.values()), default=0)
        if self.llm is not None:
            results["narrative"] = await self._narrate(results)
        return results

    def _extract_numeric(self, data: Any) -> dict[str, list[float]]:
        out: dict[str, list[float]] = {}
        if isinstance(data, list) and data and isinstance(data[0], dict):
            for row in data:
                for k, v in row.items():
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        out.setdefault(k, []).append(float(v))
        elif isinstance(data, list) and all(isinstance(x, (int, float)) for x in data):
            out["value"] = [float(x) for x in data]
        return out

    def _describe(self, xs: Sequence[float]) -> dict[str, float]:
        sx = sorted(xs)
        return {
            "n": len(xs),
            "min": sx[0],
            "max": sx[-1],
            "mean": statistics.fmean(xs),
            "median": statistics.median(xs),
            "stdev": statistics.pstdev(xs) if len(xs) > 1 else 0.0,
            "p25": sx[len(sx) // 4],
            "p75": sx[(len(sx) * 3) // 4],
        }

    async def _narrate(self, results: dict[str, Any]) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        body = ", ".join(f"{k}={v}" for k, v in results.items() if isinstance(v, dict))
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=f"Summarize: {body}")],
                          temperature=0.2)
        resp = await self.llm.agenerate(req)
        return resp.content
