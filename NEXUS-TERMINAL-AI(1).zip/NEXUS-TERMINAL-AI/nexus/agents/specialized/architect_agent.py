"""ArchitectAgent — designs system architecture for a problem statement."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("architect")
class ArchitectAgent(BaseAgent):
    role = "architect"
    system_prompt = (
        "You are a software architect. Given a problem, propose a system architecture "
        "with components, interfaces, data flow, and tradeoffs. Use Mermaid diagrams "
        "where helpful. List non-functional requirements explicitly."
    )

    DEFAULT_COMPONENTS = ("api_gateway", "service", "database", "cache", "queue", "worker")

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"constraints": ctx.inputs.get("constraints", []),
                 "scale": ctx.inputs.get("scale", "medium"),
                 "platform": ctx.inputs.get("platform", "cloud")}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        if self.llm is None:
            return {"components": list(self.DEFAULT_COMPONENTS),
                     "diagram": self._stub_mermaid(),
                     "tradeoffs": ["simplicity vs scale", "consistency vs availability"]}
        return await self._llm_design(ctx.goal, decision)

    async def _llm_design(self, goal: str, params: dict[str, Any]) -> dict[str, Any]:
        from ...llm.base import LLMMessage, LLMRequest, Role
        body = (f"Design system for: {goal}\nConstraints: {params.get('constraints')}\n"
                f"Scale: {params.get('scale')}\nPlatform: {params.get('platform')}")
        req = LLMRequest(model=self.options.get("model", "claude-opus-4-8"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=body)],
                          temperature=0.4)
        resp = await self.llm.agenerate(req)
        return {"design": resp.content,
                 "components": [c for c in self.DEFAULT_COMPONENTS if c in resp.content.lower()] or
                                list(self.DEFAULT_COMPONENTS)}

    @staticmethod
    def _stub_mermaid() -> str:
        return ("```mermaid\nflowchart LR\n"
                "  client --> api[API Gateway] --> svc[Service]\n"
                "  svc --> cache[(Cache)]\n  svc --> db[(Database)]\n"
                "  svc --> q[Queue] --> worker[Worker]\n```")
