"""CoderAgent — writes code for a given specification."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("coder")
class CoderAgent(BaseAgent):
    role = "coder"
    system_prompt = (
        "You are an expert software engineer. Given a spec, produce clean, idiomatic, "
        "well-tested code. Prefer standard library. Output a single code block. "
        "Add type hints and docstrings. Explain non-obvious choices briefly above the code."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"language": ctx.inputs.get("language", "python"),
                 "constraints": ctx.inputs.get("constraints", []),
                 "previous": ctx.inputs.get("previous")}

    async def decide(self, ctx: AgentContext) -> str | None:
        if ctx.iteration > 0:
            return None
        return f"Write {ctx.inputs.get('language', 'python')} code for: {ctx.goal}"

    async def act(self, decision: str, ctx: AgentContext) -> dict[str, Any]:
        if self.llm is None:
            code = f"# TODO: implement\ndef solution(*args, **kwargs):\n    \"\"\"Stub for: {ctx.goal[:80]}\"\"\"\n    raise NotImplementedError"
        else:
            code = await self._generate_code(decision)
        from ...llm.adapters.code_adapter import CodeAdapter
        ad = CodeAdapter()
        first = ad.first(code, language="python") or ad.first(code)
        return {"language": first.language if first else "text",
                 "code": first.code if first else code,
                 "valid": ad.validate(first)[0] if first else True}

    async def _generate_code(self, prompt: str) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        req = LLMRequest(
            model=self.options.get("model", "claude-opus-4-8"),
            messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                       LLMMessage(role=Role.USER, content=prompt)],
            temperature=0.2,
        )
        resp = await self.llm.agenerate(req)
        return resp.content
