"""CreativeAgent — generates creative content (stories, poetry, ideas)."""
from __future__ import annotations

import logging
import random
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("creative")
class CreativeAgent(BaseAgent):
    role = "creative"
    system_prompt = (
        "You are a creative writer. Generate vivid, original content matching the "
        "requested form (story, poem, idea list, headline). Surprise the reader."
    )

    FORMS = ("story", "poem", "ideas", "headline", "metaphor", "dialogue")

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"form": ctx.inputs.get("form", "story"),
                 "style": ctx.inputs.get("style", "modern"),
                 "length": ctx.inputs.get("length", "short"),
                 "seed": ctx.inputs.get("seed", random.randint(0, 10**9))}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        form = decision.get("form", "story")
        if self.llm is None:
            content = self._stub(form, ctx.goal)
        else:
            content = await self._generate(form, ctx.goal, decision)
        return {"form": form, "content": content, "seed": decision.get("seed")}

    def _stub(self, form: str, prompt: str) -> str:
        if form == "poem":
            return f"In silent code, the {prompt} stirs,\nA quiet hum, a soft demur,\nThe day departs, the night confers."
        if form == "ideas":
            return "\n".join(f"- idea {i}: {prompt} with twist {i}" for i in range(1, 6))
        return f"Once upon a time, {prompt} began to take shape in unexpected ways."

    async def _generate(self, form: str, prompt: str, params: dict[str, Any]) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        user = f"Form: {form}\nStyle: {params.get('style')}\nLength: {params.get('length')}\nTopic: {prompt}"
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=user)],
                          temperature=0.95, top_p=0.95)
        resp = await self.llm.agenerate(req)
        return resp.content
