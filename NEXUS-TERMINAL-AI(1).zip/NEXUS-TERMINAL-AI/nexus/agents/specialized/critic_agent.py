"""CriticAgent — adversarially critiques a candidate answer."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("critic")
class CriticAgent(BaseAgent):
    role = "critic"
    system_prompt = (
        "You are a rigorous critic. For each candidate answer, identify: "
        "(1) factual errors, (2) logical gaps, (3) unsupported claims. "
        "Be specific and concise. Score the answer 0..10."
    )

    DIMS = ("factuality", "logic", "support", "completeness", "clarity")

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"candidate": ctx.inputs.get("candidate", ""),
                 "reference": ctx.inputs.get("reference", "")}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        candidate = decision.get("candidate", "")
        score = self._heuristic_score(candidate)
        critique = "Generic critique: ensure each claim is sourced."
        if self.llm is not None:
            critique, score = await self._llm_critique(candidate, decision.get("reference", ""))
        return {"critique": critique, "scores": score,
                 "overall": sum(score.values()) / max(1, len(score))}

    def _heuristic_score(self, text: str) -> dict[str, float]:
        n = max(1, len(text.split()))
        clarity = min(10.0, 10000.0 / n) if n < 1000 else 6.0
        return {d: round(clarity, 1) for d in self.DIMS}

    async def _llm_critique(self, candidate: str, reference: str) -> tuple[str, dict[str, float]]:
        from ...llm.base import LLMMessage, LLMRequest, Role
        msg = f"Candidate:\n{candidate[:4000]}\n\nReference:\n{reference[:2000]}"
        req = LLMRequest(model=self.options.get("model", "claude-opus-4-8"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=msg)],
                          temperature=0.0)
        resp = await self.llm.agenerate(req)
        return resp.content, {d: 7.0 for d in self.DIMS}
