"""DebuggerAgent — analyzes a failing program and proposes fixes."""
from __future__ import annotations

import logging
import re
import traceback
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("debugger")
class DebuggerAgent(BaseAgent):
    role = "debugger"
    system_prompt = (
        "You are a debugging assistant. Given a stack trace and source snippet, "
        "identify the root cause and propose a minimal patch. Return JSON: "
        '{"root_cause": "...", "fix": "...", "confidence": 0..1}.'
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        tb = ctx.inputs.get("traceback", "")
        return {"frames": self._parse_traceback(tb),
                 "exception": self._extract_exception(tb),
                 "snippet": ctx.inputs.get("source", "")}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        latest = ctx.observations[-1] if ctx.observations else {}
        return {"frames": latest.get("frames", []),
                 "exception": latest.get("exception"),
                 "snippet": latest.get("snippet")}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        exc = decision.get("exception") or ""
        frames = decision.get("frames", [])
        hint = self._heuristic_hint(exc)
        if self.llm is None:
            return {"root_cause": exc, "fix": hint, "confidence": 0.4,
                     "top_frame": frames[-1] if frames else None}
        return await self._llm_diagnose(decision)

    async def _llm_diagnose(self, decision: dict[str, Any]) -> dict[str, Any]:
        from ...llm.base import LLMMessage, LLMRequest, Role
        from ...llm.adapters.json_adapter import JSONAdapter
        payload = f"Exception: {decision.get('exception')}\nFrames:\n" + \
                   "\n".join(f"{f['file']}:{f['line']} in {f['func']}"
                              for f in decision.get("frames", [])) + \
                   f"\n\nSource snippet:\n{decision.get('snippet', '')}"
        req = LLMRequest(model=self.options.get("model", "claude-opus-4-8"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=payload)],
                          temperature=0.0)
        try:
            resp = await self.llm.agenerate(req)
        except Exception as exc:  # noqa: BLE001
            logger.warning("LLM diagnose failed: %s", exc)
            return {"root_cause": str(decision.get("exception")), "fix": "(llm unavailable)",
                     "confidence": 0.2}
        return JSONAdapter().parse(resp.content) or {"root_cause": "?", "fix": resp.content[:500]}

    @staticmethod
    def _parse_traceback(tb: str) -> list[dict[str, Any]]:
        frames: list[dict[str, Any]] = []
        for m in re.finditer(r'File "([^"]+)", line (\d+), in (\S+)', tb or ""):
            frames.append({"file": m.group(1), "line": int(m.group(2)), "func": m.group(3)})
        return frames

    @staticmethod
    def _extract_exception(tb: str) -> str:
        if not tb:
            return ""
        line = tb.strip().splitlines()[-1] if tb.strip() else ""
        return line.strip()

    @staticmethod
    def _heuristic_hint(exc: str) -> str:
        if "ModuleNotFoundError" in exc:
            return "Install the missing module via pip"
        if "AttributeError" in exc:
            return "Object has no such attribute — check spelling or initialization"
        if "KeyError" in exc:
            return "Missing dict key — check key existence with .get() or 'in' first"
        if "ZeroDivisionError" in exc:
            return "Guard against zero denominator"
        return "Inspect the variable types at the failing line"
