"""DevOpsAgent — generates deployment configs, CI/CD pipelines, IaC."""
from __future__ import annotations

import logging
import textwrap
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("devops")
class DevOpsAgent(BaseAgent):
    role = "devops"
    system_prompt = (
        "You are a DevOps engineer. Generate Dockerfiles, Kubernetes manifests, "
        "Terraform, and CI/CD pipeline YAML. Follow best practices: minimal images, "
        "non-root users, resource limits, health checks."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"artifact": ctx.inputs.get("artifact", "dockerfile"),
                 "language": ctx.inputs.get("language", "python"),
                 "app_name": ctx.inputs.get("app_name", "app")}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        artifact = decision.get("artifact", "dockerfile")
        if self.llm is None:
            content = self._stub(artifact, decision)
        else:
            content = await self._generate(artifact, decision, ctx.goal)
        return {"artifact": artifact, "content": content, "length": len(content)}

    def _stub(self, kind: str, decision: dict[str, Any]) -> str:
        lang = decision.get("language", "python")
        app = decision.get("app_name", "app")
        if kind == "dockerfile":
            return textwrap.dedent(f"""\
                FROM python:3.12-slim AS base
                WORKDIR /app
                RUN useradd -m -u 1000 {app}
                COPY --chown={app}:{app} requirements.txt .
                RUN pip install --no-cache-dir -r requirements.txt
                COPY --chown={app}:{app} . .
                USER {app}
                HEALTHCHECK --interval=30s CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')"
                EXPOSE 8000
                CMD ["python", "-m", "{app}"]
            """)
        if kind == "k8s":
            return textwrap.dedent(f"""\
                apiVersion: apps/v1
                kind: Deployment
                metadata:
                  name: {app}
                spec:
                  replicas: 2
                  selector:
                    matchLabels: {{app: {app}}}
                  template:
                    metadata:
                      labels: {{app: {app}}}
                    spec:
                      containers:
                      - name: {app}
                        image: {app}:latest
                        ports: [{{containerPort: 8000}}]
                        resources:
                          limits: {{cpu: 500m, memory: 512Mi}}
                          requests: {{cpu: 100m, memory: 128Mi}}
            """)
        if kind == "ci":
            return textwrap.dedent("""\
                name: ci
                on: [push, pull_request]
                jobs:
                  test:
                    runs-on: ubuntu-latest
                    steps:
                      - uses: actions/checkout@v4
                      - uses: actions/setup-python@v5
                        with: {python-version: '3.12'}
                      - run: pip install -r requirements.txt
                      - run: pytest -q
            """)
        return f"# stub {kind}"

    async def _generate(self, kind: str, decision: dict[str, Any], goal: str) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        prompt = f"Produce a {kind} for app '{decision.get('app_name')}' in {decision.get('language')}. Goal: {goal}"
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=prompt)],
                          temperature=0.1)
        resp = await self.llm.agenerate(req)
        return resp.content
