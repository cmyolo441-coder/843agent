"""DocAgent — generates documentation for code/APIs."""
from __future__ import annotations

import ast
import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("doc")
class DocAgent(BaseAgent):
    role = "doc"
    system_prompt = (
        "You are a documentation writer. Produce clear, concise reference docs "
        "with usage examples, parameter descriptions, and return value semantics."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"source": ctx.inputs.get("source", ""),
                 "format": ctx.inputs.get("format", "markdown")}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        src = decision.get("source", "")
        symbols = self._parse_symbols(src)
        if self.llm is None:
            doc = self._stub_doc(symbols)
        else:
            doc = await self._llm_doc(src, symbols, decision.get("format", "markdown"))
        return {"symbols": symbols, "doc": doc, "format": decision.get("format", "markdown")}

    def _parse_symbols(self, source: str) -> list[dict[str, Any]]:
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return []
        out: list[dict[str, Any]] = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                out.append({"kind": "function", "name": node.name,
                             "args": [a.arg for a in node.args.args],
                             "docstring": ast.get_docstring(node) or ""})
            elif isinstance(node, ast.ClassDef):
                methods = [n.name for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
                out.append({"kind": "class", "name": node.name, "methods": methods,
                             "docstring": ast.get_docstring(node) or ""})
        return out

    def _stub_doc(self, symbols: list[dict[str, Any]]) -> str:
        lines = ["# API Reference\n"]
        for s in symbols:
            if s["kind"] == "function":
                args = ", ".join(s["args"])
                lines.append(f"## `{s['name']}({args})`\n\n{s['docstring'] or 'No description.'}\n")
            elif s["kind"] == "class":
                lines.append(f"## `class {s['name']}`\n\n{s['docstring'] or 'No description.'}\n"
                              f"\nMethods: {', '.join(s['methods'])}\n")
        return "\n".join(lines)

    async def _llm_doc(self, source: str, symbols: list[dict[str, Any]], fmt: str) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER,
                                                 content=f"Format: {fmt}\nDocument:\n{source[:5000]}")],
                          temperature=0.2)
        resp = await self.llm.agenerate(req)
        return resp.content
