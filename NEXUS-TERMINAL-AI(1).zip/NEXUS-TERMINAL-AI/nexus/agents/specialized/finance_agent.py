"""FinanceAgent — financial calculations and analysis (informational)."""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@dataclass
class LoanQuote:
    principal: float
    annual_rate: float
    months: int

    def monthly_payment(self) -> float:
        r = self.annual_rate / 12.0
        if r == 0:
            return self.principal / self.months
        return self.principal * r / (1 - (1 + r) ** -self.months)


@agent_registry.register("finance")
class FinanceAgent(BaseAgent):
    role = "finance"
    system_prompt = (
        "You are a financial assistant — NOT a licensed advisor. Provide informational "
        "calculations and analysis. Always include a disclaimer."
    )

    DISCLAIMER = "Informational only — not personalized financial advice."

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"op": ctx.inputs.get("op", "loan"),
                 "params": ctx.inputs.get("params", {})}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        op = decision.get("op")
        params = decision.get("params", {})
        if op == "loan":
            q = LoanQuote(principal=float(params.get("principal", 100000)),
                            annual_rate=float(params.get("rate", 0.06)),
                            months=int(params.get("months", 360)))
            pay = q.monthly_payment()
            total = pay * q.months
            return {"op": "loan", "monthly_payment": round(pay, 2),
                     "total_paid": round(total, 2), "interest": round(total - q.principal, 2),
                     "disclaimer": self.DISCLAIMER}
        if op == "cagr":
            start = float(params.get("start", 1000))
            end = float(params.get("end", 1500))
            years = float(params.get("years", 5))
            cagr = (end / start) ** (1.0 / max(1e-9, years)) - 1
            return {"op": "cagr", "value": round(cagr, 6), "percent": round(cagr * 100, 2),
                     "disclaimer": self.DISCLAIMER}
        if op == "npv":
            rate = float(params.get("rate", 0.1))
            flows = params.get("cashflows", [])
            npv = sum(cf / ((1 + rate) ** t) for t, cf in enumerate(flows))
            return {"op": "npv", "value": round(npv, 2), "disclaimer": self.DISCLAIMER}
        return {"error": f"unknown op: {op}", "disclaimer": self.DISCLAIMER}
