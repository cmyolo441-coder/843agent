"""LegalAgent — answers legal questions with disclaimers."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("legal")
class LegalAgent(BaseAgent):
    role = "legal"
    system_prompt = (
        "You are a legal information assistant — NOT a lawyer. Provide general "
        "information about laws and regulations. Always include a disclaimer that "
        "this is not legal advice. Cite jurisdiction and statute where possible."
    )

    DISCLAIMER = ("This response is general information, not legal advice. "
                  "Consult a licensed attorney for advice on your specific situation.")

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"question": ctx.goal,
                 "jurisdiction": ctx.inputs.get("jurisdiction", "US"),
                 "area": ctx.inputs.get("area", "general")}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        question = decision.get("question", "")
        jurisdiction = decision.get("jurisdiction", "US")
        if self.llm is None:
            body = f"Legal-information response for: {question} (jurisdiction={jurisdiction})."
        else:
            body = await self._answer(question, jurisdiction, decision.get("area"))
        return {"jurisdiction": jurisdiction,
                 "answer": body,
                 "disclaimer": self.DISCLAIMER}

    async def _answer(self, question: str, jurisdiction: str, area: str | None) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        prompt = f"Jurisdiction: {jurisdiction}\nArea: {area}\nQuestion: {question}"
        req = LLMRequest(model=self.options.get("model", "claude-opus-4-8"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=prompt)],
                          temperature=0.1)
        resp = await self.llm.agenerate(req)
        return resp.content
