"""MathAgent — solves math problems symbolically or numerically."""
from __future__ import annotations

import ast
import logging
import math
import operator
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


_SAFE_BINOPS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.Mod: operator.mod, ast.Pow: operator.pow,
    ast.FloorDiv: operator.floordiv,
}
_SAFE_UNARY = {ast.USub: operator.neg, ast.UAdd: operator.pos}
_SAFE_FUNCS = {"sqrt": math.sqrt, "log": math.log, "log10": math.log10, "exp": math.exp,
                "sin": math.sin, "cos": math.cos, "tan": math.tan,
                "abs": abs, "round": round, "pi": math.pi, "e": math.e}


@agent_registry.register("math")
class MathAgent(BaseAgent):
    role = "math"
    system_prompt = (
        "You are a math agent. Solve problems step by step, then give a clean final answer. "
        "Use exact values where possible."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"problem": ctx.goal, "vars": ctx.inputs.get("vars", {})}

    async def decide(self, ctx: AgentContext) -> str | None:
        if ctx.iteration > 0:
            return None
        return ctx.goal

    async def act(self, decision: str, ctx: AgentContext) -> dict[str, Any]:
        numeric = self._try_eval(decision)
        result: dict[str, Any] = {"input": decision, "numeric": numeric}
        if self.llm is not None:
            result["explanation"] = await self._llm_solve(decision)
        return result

    def _try_eval(self, expr: str) -> Any:
        # Strip non-math text leniently
        try:
            tree = ast.parse(expr, mode="eval")
        except SyntaxError:
            return None
        try:
            return self._eval(tree.body)
        except Exception:  # noqa: BLE001
            return None

    def _eval(self, node: ast.AST) -> Any:
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _SAFE_BINOPS:
            return _SAFE_BINOPS[type(node.op)](self._eval(node.left), self._eval(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _SAFE_UNARY:
            return _SAFE_UNARY[type(node.op)](self._eval(node.operand))
        if isinstance(node, ast.Name) and node.id in _SAFE_FUNCS:
            return _SAFE_FUNCS[node.id]
        if isinstance(node, ast.Call):
            fn = self._eval(node.func)
            args = [self._eval(a) for a in node.args]
            if callable(fn):
                return fn(*args)
        raise ValueError(f"Unsafe expression: {ast.dump(node)}")

    async def _llm_solve(self, problem: str) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        req = LLMRequest(model=self.options.get("model", "claude-opus-4-8"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=problem)],
                          temperature=0.0)
        resp = await self.llm.agenerate(req)
        return resp.content
