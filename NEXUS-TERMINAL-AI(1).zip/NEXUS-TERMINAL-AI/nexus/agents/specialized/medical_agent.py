"""MedicalAgent — general medical information with strong disclaimers."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("medical")
class MedicalAgent(BaseAgent):
    role = "medical"
    system_prompt = (
        "You are a medical-information assistant — NOT a physician. Provide general "
        "information about conditions, terms, and procedures. NEVER diagnose. "
        "Always recommend consulting a qualified healthcare professional."
    )

    DISCLAIMER = ("This is general medical information, not a diagnosis or treatment "
                  "recommendation. For symptoms requiring evaluation, contact a licensed "
                  "healthcare provider. In an emergency, call your local emergency number.")

    EMERGENCY_KEYWORDS = (
        "chest pain", "shortness of breath", "stroke", "suicide", "overdose",
        "bleeding heavily", "unconscious", "anaphylaxis",
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        q = ctx.goal.lower()
        return {"question": ctx.goal,
                 "emergency_flag": any(k in q for k in self.EMERGENCY_KEYWORDS)}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        if decision.get("emergency_flag"):
            return {"answer": "This sounds like a possible medical emergency. "
                               "Call your local emergency number immediately.",
                     "emergency": True, "disclaimer": self.DISCLAIMER}
        question = decision.get("question", "")
        body = await self._answer(question) if self.llm is not None else \
                f"General information about: {question}"
        return {"answer": body, "emergency": False, "disclaimer": self.DISCLAIMER}

    async def _answer(self, question: str) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        req = LLMRequest(model=self.options.get("model", "claude-opus-4-8"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=question)],
                          temperature=0.0)
        resp = await self.llm.agenerate(req)
        return resp.content
