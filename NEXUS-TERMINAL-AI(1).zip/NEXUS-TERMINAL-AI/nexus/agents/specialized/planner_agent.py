"""PlannerAgent — breaks a goal into an ordered plan of steps."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("planner")
class PlannerAgent(BaseAgent):
    role = "planner"
    system_prompt = (
        "You are a planning agent. Given a user goal, produce a numbered, ordered "
        "list of concrete steps. Each step must be small, observable, and actionable. "
        "Identify parallelizable steps with a [P] tag."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"goal": ctx.goal, "have_llm": self.llm is not None,
                 "constraints": ctx.inputs.get("constraints", [])}

    async def decide(self, ctx: AgentContext) -> str:
        if ctx.iteration > 0:
            return ""  # one-shot
        return f"PLAN:{ctx.goal}"

    async def act(self, decision: str, ctx: AgentContext) -> list[dict[str, Any]]:
        text = await self._call_llm(decision, ctx) if self.llm else self._heuristic_plan(ctx.goal)
        steps = self._parse_steps(text)
        logger.info("Planner produced %d steps", len(steps))
        return steps

    async def _call_llm(self, prompt: str, ctx: AgentContext) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        req = LLMRequest(
            model=self.options.get("model", "claude-sonnet-4-5"),
            messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                       LLMMessage(role=Role.USER, content=prompt)],
            temperature=0.3,
        )
        resp = await self.llm.agenerate(req)
        return resp.content

    def _heuristic_plan(self, goal: str) -> str:
        words = [w for w in re.findall(r"\w+", goal) if len(w) > 3]
        return "\n".join(f"{i + 1}. {w}" for i, w in enumerate(words[:5])) or "1. analyze\n2. execute\n3. verify"

    @staticmethod
    def _parse_steps(text: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for line in text.splitlines():
            m = re.match(r"\s*(?:\d+\.|[-*])\s*(\[P\])?\s*(.+)$", line)
            if m:
                out.append({"step": m.group(2).strip(), "parallel": bool(m.group(1))})
        return out

    async def is_done(self, ctx: AgentContext) -> bool:
        return bool(ctx.artifacts)
