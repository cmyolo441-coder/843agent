"""ResearcherAgent — gathers and cites information about a topic."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("researcher")
class ResearcherAgent(BaseAgent):
    role = "researcher"
    system_prompt = (
        "You are a research assistant. Gather facts from credible sources, cite them, "
        "and flag claims that lack support. Output JSON with 'findings' and 'sources'."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"topic": ctx.goal,
                 "depth": ctx.inputs.get("depth", "shallow"),
                 "max_sources": ctx.inputs.get("max_sources", 5)}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration >= 1:
            return None
        return {"query": ctx.goal}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        sources = await self._search(decision["query"])
        digest = await self._summarize(decision["query"], sources)
        return {"topic": decision["query"], "sources": sources, "digest": digest}

    async def _search(self, query: str) -> list[dict[str, Any]]:
        # Pluggable search hook — real impl would call MCP/search tool
        return [{"title": f"Stub source for: {query[:40]}",
                 "url": f"https://example.org/?q={query[:32].replace(' ', '+')}",
                 "snippet": "Auto-generated stub. Replace with real search adapter."}]

    async def _summarize(self, query: str, sources: list[dict[str, Any]]) -> str:
        if self.llm is None:
            return f"Researched {len(sources)} sources for '{query[:60]}'."
        from ...llm.base import LLMMessage, LLMRequest, Role
        joined = "\n\n".join(f"[{i+1}] {s['title']}\n{s['snippet']}" for i, s in enumerate(sources))
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER,
                                                 content=f"Topic: {query}\nSources:\n{joined}\n\nWrite a 5-sentence digest with [n] citations.")],
                          temperature=0.2)
        resp = await self.llm.agenerate(req)
        return resp.content
