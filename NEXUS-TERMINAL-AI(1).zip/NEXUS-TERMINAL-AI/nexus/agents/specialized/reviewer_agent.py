"""ReviewerAgent — reviews code for correctness, style, and security."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("reviewer")
class ReviewerAgent(BaseAgent):
    role = "reviewer"
    system_prompt = (
        "You are a senior code reviewer. Identify correctness bugs, security flaws, "
        "and maintainability issues. Quote line numbers and propose concrete fixes. "
        "Severity scale: critical, high, medium, low, nit."
    )

    SMELLS = {
        r"\beval\s*\(": ("critical", "Avoid eval()"),
        r"\bexec\s*\(": ("critical", "Avoid exec()"),
        r"shell\s*=\s*True": ("high", "subprocess shell=True allows injection"),
        r"pickle\.loads?\b": ("high", "Pickle deserialization can execute code"),
        r"\bprint\(": ("nit", "Prefer logging over print"),
        r"TODO|FIXME|XXX": ("low", "Unresolved TODO marker"),
    }

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"code": ctx.inputs.get("code", "")}

    async def decide(self, ctx: AgentContext) -> str | None:
        if ctx.iteration > 0:
            return None
        return ctx.inputs.get("code", "")

    async def act(self, decision: str, ctx: AgentContext) -> dict[str, Any]:
        findings = self._static_scan(decision)
        if self.llm is not None:
            findings.extend(await self._llm_review(decision))
        return {"findings": findings, "total": len(findings),
                 "by_severity": self._by_severity(findings)}

    def _static_scan(self, code: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for i, line in enumerate(code.splitlines(), 1):
            for pat, (sev, msg) in self.SMELLS.items():
                if re.search(pat, line):
                    out.append({"line": i, "severity": sev, "message": msg,
                                 "snippet": line.strip()[:120]})
        return out

    async def _llm_review(self, code: str) -> list[dict[str, Any]]:
        from ...llm.base import LLMMessage, LLMRequest, Role
        req = LLMRequest(
            model=self.options.get("model", "claude-opus-4-8"),
            messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                       LLMMessage(role=Role.USER,
                                   content=f"Review this code:\n```\n{code[:6000]}\n```")],
            temperature=0.1,
        )
        try:
            resp = await self.llm.agenerate(req)
            return [{"source": "llm", "severity": "info", "message": resp.content[:1000]}]
        except Exception as exc:  # noqa: BLE001
            logger.warning("LLM review failed: %s", exc)
            return []

    @staticmethod
    def _by_severity(findings: list[dict[str, Any]]) -> dict[str, int]:
        counts: dict[str, int] = {}
        for f in findings:
            counts[f.get("severity", "info")] = counts.get(f.get("severity", "info"), 0) + 1
        return counts
