"""SecurityAgent — security audits, secret detection, vulnerability triage."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("security")
class SecurityAgent(BaseAgent):
    role = "security"
    system_prompt = (
        "You are a security engineer. Audit input for vulnerabilities: injection, "
        "secret exposure, unsafe deserialization, missing authn/authz, supply chain, "
        "and crypto misuse. Output severity-tagged findings."
    )

    SECRET_PATTERNS = {
        "aws_access_key": r"AKIA[0-9A-Z]{16}",
        "aws_secret": r"(?i)aws(.{0,20})?(secret|sk).{0,3}['\"][0-9a-zA-Z/+]{40}['\"]",
        "github_pat": r"ghp_[A-Za-z0-9]{36,}",
        "openai_key": r"sk-[A-Za-z0-9]{20,}",
        "private_key": r"-----BEGIN (?:RSA |EC |OPENSSH |)PRIVATE KEY-----",
        "slack_token": r"xox[abps]-[A-Za-z0-9-]{10,}",
    }

    VULN_PATTERNS = {
        "sql_injection": (r"f\"SELECT.*\{[^}]*\}|\.execute\(['\"].*%s|\bformat\(.*SELECT", "high"),
        "shell_injection": (r"subprocess\.[a-z_]+\([^)]*shell\s*=\s*True", "high"),
        "yaml_load": (r"yaml\.load\(", "medium"),
        "pickle_loads": (r"pickle\.loads?\(", "high"),
        "weak_random": (r"\brandom\.(?:random|choice|randint)\b.*(?:token|password|secret)", "medium"),
        "md5_hash": (r"hashlib\.md5\b", "low"),
    }

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"text": ctx.inputs.get("text", "") or ctx.inputs.get("code", "")}

    async def decide(self, ctx: AgentContext) -> str | None:
        if ctx.iteration > 0:
            return None
        return (ctx.observations[-1] if ctx.observations else {}).get("text", "")

    async def act(self, decision: str, ctx: AgentContext) -> dict[str, Any]:
        secrets = self._scan_secrets(decision)
        vulns = self._scan_vulns(decision)
        findings = secrets + vulns
        return {"findings": findings,
                 "by_severity": self._tally(findings),
                 "is_clean": not findings}

    def _scan_secrets(self, text: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for name, pat in self.SECRET_PATTERNS.items():
            for m in re.finditer(pat, text):
                out.append({"kind": "secret", "type": name, "severity": "critical",
                             "position": m.start(), "snippet": m.group(0)[:24] + "***"})
        return out

    def _scan_vulns(self, text: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for name, (pat, sev) in self.VULN_PATTERNS.items():
            for m in re.finditer(pat, text):
                out.append({"kind": "vuln", "type": name, "severity": sev,
                             "position": m.start(), "snippet": m.group(0)[:80]})
        return out

    @staticmethod
    def _tally(findings: list[dict[str, Any]]) -> dict[str, int]:
        out: dict[str, int] = {}
        for f in findings:
            out[f["severity"]] = out.get(f["severity"], 0) + 1
        return out
