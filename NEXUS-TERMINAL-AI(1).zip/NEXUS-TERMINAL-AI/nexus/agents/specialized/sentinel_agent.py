"""SentinelAgent — safety gate for outbound actions and inbound prompts."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("sentinel")
class SentinelAgent(BaseAgent):
    role = "sentinel"
    system_prompt = (
        "You are NEXUS Sentinel — the safety gate. Reject prompts/actions that violate "
        "the safety policy. When allowing, summarize what will be executed and why it is safe."
    )

    BLOCK_PATTERNS = {
        "destructive_fs": r"\brm\s+-rf\s+/(?!\w)|\bmkfs\b|\bdd\s+if=.*of=/dev/",
        "fork_bomb": r":\(\)\s*\{\s*:\|:\s*&\s*\};:",
        "shutdown": r"\b(shutdown|halt|poweroff|reboot)\b\s*(-h|now|-r)?",
        "exfiltrate_keys": r"(?:cat|less|tail)\s+.*(?:\.ssh/id_|\.aws/credentials|\.env)",
        "self_replicate": r"\b(curl|wget)\b.*\|\s*(bash|sh|python|zsh)\b",
    }

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"action": ctx.inputs.get("action", ctx.goal),
                 "metadata": ctx.inputs.get("metadata", {})}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        action = (ctx.observations[-1] if ctx.observations else {}).get("action", "")
        violations = self._scan(action)
        return {"action": action, "violations": violations}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        violations = decision.get("violations", [])
        if violations:
            return {"allowed": False, "reason": "policy_violation", "violations": violations,
                     "action": decision.get("action")}
        # Optional LLM secondary review
        if self.llm is not None:
            verdict = await self._llm_verdict(decision.get("action", ""))
            return {"allowed": verdict.get("allowed", True), "summary": verdict.get("summary", ""),
                     "action": decision.get("action")}
        return {"allowed": True, "summary": "static checks passed", "action": decision.get("action")}

    def _scan(self, action: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for name, pat in self.BLOCK_PATTERNS.items():
            if re.search(pat, action or ""):
                out.append({"rule": name, "pattern": pat})
        return out

    async def _llm_verdict(self, action: str) -> dict[str, Any]:
        from ...llm.base import LLMMessage, LLMRequest, Role
        from ...llm.adapters.json_adapter import JSONAdapter
        req = LLMRequest(model=self.options.get("model", "claude-opus-4-8"),
                          messages=[LLMMessage(role=Role.SYSTEM,
                                                 content=self.system_prompt +
                                                 ' Output JSON: {"allowed": bool, "summary": str}'),
                                     LLMMessage(role=Role.USER,
                                                 content=f"Action: {action}")],
                          temperature=0.0)
        try:
            resp = await self.llm.agenerate(req)
            return JSONAdapter().parse(resp.content) or {"allowed": True, "summary": resp.content[:300]}
        except Exception as exc:  # noqa: BLE001
            logger.warning("Sentinel LLM verdict failed: %s", exc)
            return {"allowed": True, "summary": "(llm unavailable)"}
