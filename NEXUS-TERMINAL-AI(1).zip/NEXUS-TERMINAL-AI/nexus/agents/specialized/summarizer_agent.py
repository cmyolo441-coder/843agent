"""SummarizerAgent — summarizes long text or transcripts."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("summarizer")
class SummarizerAgent(BaseAgent):
    role = "summarizer"
    system_prompt = (
        "You are a summarization agent. Produce a faithful, compressed summary "
        "preserving names, numbers, decisions, and action items. "
        "Output bullet points unless asked otherwise."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        text = ctx.inputs.get("text", ctx.goal)
        return {"text": text, "length": len(text),
                 "max_bullets": ctx.inputs.get("max_bullets", 7)}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        text = decision.get("text", "")
        if self.llm is None:
            summary = self._extractive(text, decision.get("max_bullets", 7))
        else:
            summary = await self._abstractive(text, decision.get("max_bullets", 7))
        return {"summary": summary, "compression_ratio": len(summary) / max(1, len(text))}

    def _extractive(self, text: str, k: int) -> str:
        sentences = re.split(r"(?<=[.!?])\s+", text.strip())
        scored = sorted(sentences, key=lambda s: -len(s))[:k]
        ordered = sorted(scored, key=lambda s: sentences.index(s))
        return "\n".join(f"- {s.strip()}" for s in ordered if s.strip())

    async def _abstractive(self, text: str, k: int) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER,
                                                 content=f"Summarize in <= {k} bullets:\n\n{text[:8000]}")],
                          temperature=0.2)
        resp = await self.llm.agenerate(req)
        return resp.content
