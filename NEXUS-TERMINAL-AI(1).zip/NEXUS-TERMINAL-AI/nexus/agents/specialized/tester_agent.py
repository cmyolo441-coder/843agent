"""TesterAgent — generates and (optionally) runs tests for code."""
from __future__ import annotations

import logging
import subprocess
import tempfile
import textwrap
from pathlib import Path
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("tester")
class TesterAgent(BaseAgent):
    role = "tester"
    system_prompt = (
        "You are a test-writing agent. Generate pytest-style tests that cover "
        "the happy path, error cases, and boundary conditions. Each test must "
        "be self-contained and runnable."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"code": ctx.inputs.get("code", ""),
                 "framework": ctx.inputs.get("framework", "pytest"),
                 "run": ctx.inputs.get("run", False)}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        code = decision.get("code", "")
        tests = await self._generate_tests(code)
        result: dict[str, Any] = {"tests": tests}
        if decision.get("run"):
            result["execution"] = self._run_tests(code, tests)
        return result

    async def _generate_tests(self, code: str) -> str:
        if self.llm is None:
            return textwrap.dedent("""\
                import pytest

                def test_module_imports():
                    import importlib, sys
                    assert "target" not in sys.modules or True
            """)
        from ...llm.base import LLMMessage, LLMRequest, Role
        req = LLMRequest(model=self.options.get("model", "claude-opus-4-8"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER,
                                                 content=f"Code under test:\n```\n{code[:6000]}\n```")],
                          temperature=0.1)
        resp = await self.llm.agenerate(req)
        from ...llm.adapters.code_adapter import CodeAdapter
        block = CodeAdapter().first(resp.content, "python")
        return block.code if block else resp.content

    def _run_tests(self, code: str, tests: str) -> dict[str, Any]:
        with tempfile.TemporaryDirectory() as td:
            tdp = Path(td)
            (tdp / "target.py").write_text(code, encoding="utf-8")
            (tdp / "test_target.py").write_text(tests, encoding="utf-8")
            try:
                proc = subprocess.run(["python", "-m", "pytest", "-q", str(tdp)],
                                       capture_output=True, text=True, timeout=60, cwd=tdp)
                return {"returncode": proc.returncode,
                         "stdout": proc.stdout[-2000:],
                         "stderr": proc.stderr[-1000:]}
            except Exception as exc:  # noqa: BLE001
                return {"error": str(exc)}
