"""TranslatorAgent — translates text between languages."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("translator")
class TranslatorAgent(BaseAgent):
    role = "translator"
    system_prompt = (
        "You are a professional translator. Preserve meaning, tone, and idioms. "
        "Keep technical terms accurate. Return only the translated text."
    )

    SUPPORTED = {"en", "es", "fr", "de", "it", "pt", "zh", "ja", "ko", "ar", "ru", "hi"}

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"text": ctx.inputs.get("text", ""),
                 "source": ctx.inputs.get("source", "auto"),
                 "target": ctx.inputs.get("target", "en")}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        decision = ctx.observations[-1] if ctx.observations else {}
        if decision.get("target") not in self.SUPPORTED:
            logger.warning("Target language %s not in supported set", decision.get("target"))
        return decision

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        text = decision.get("text", "")
        target = decision.get("target", "en")
        source = decision.get("source", "auto")
        if self.llm is None:
            translated = f"[stub {source}->{target}] {text}"
        else:
            translated = await self._translate(text, source, target)
        return {"source": source, "target": target, "text": translated}

    async def _translate(self, text: str, src: str, tgt: str) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        user = f"Translate from {src} to {tgt}:\n\n{text}"
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=user)],
                          temperature=0.2)
        resp = await self.llm.agenerate(req)
        return resp.content
