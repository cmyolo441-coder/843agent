"""TutorAgent — explains concepts at the requested level."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("tutor")
class TutorAgent(BaseAgent):
    role = "tutor"
    system_prompt = (
        "You are a patient tutor. Explain concepts step by step, use analogies, "
        "provide worked examples, then ask one check-for-understanding question."
    )

    LEVELS = ("beginner", "intermediate", "advanced", "expert")

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"topic": ctx.goal,
                 "level": ctx.inputs.get("level", "beginner"),
                 "style": ctx.inputs.get("style", "socratic"),
                 "examples": ctx.inputs.get("examples", 1)}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        level = decision.get("level", "beginner")
        if level not in self.LEVELS:
            logger.warning("Unknown level %s; defaulting to beginner", level)
            level = "beginner"
        explanation = await self._explain(ctx.goal, level, decision) if self.llm is not None \
            else self._stub_explain(ctx.goal, level)
        return {"topic": ctx.goal, "level": level, "explanation": explanation,
                 "check_question": f"In your own words, what is {ctx.goal}?"}

    def _stub_explain(self, topic: str, level: str) -> str:
        return (f"At {level} level, {topic} can be understood as a sequence of steps. "
                f"First, identify inputs. Next, apply transformations. Finally, observe outputs.")

    async def _explain(self, topic: str, level: str, params: dict[str, Any]) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        user = (f"Topic: {topic}\nLevel: {level}\nStyle: {params.get('style')}\n"
                f"Examples to include: {params.get('examples', 1)}")
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=user)],
                          temperature=0.4)
        resp = await self.llm.agenerate(req)
        return resp.content
