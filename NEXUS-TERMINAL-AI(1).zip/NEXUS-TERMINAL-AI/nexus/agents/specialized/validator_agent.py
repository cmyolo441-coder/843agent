"""ValidatorAgent — checks outputs against a schema or rule set."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("validator")
class ValidatorAgent(BaseAgent):
    role = "validator"
    system_prompt = "Validate the candidate output against the provided schema or rules."

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"candidate": ctx.inputs.get("candidate"),
                 "schema": ctx.inputs.get("schema"),
                 "rules": ctx.inputs.get("rules", [])}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        violations: list[dict[str, Any]] = []
        cand = decision.get("candidate")
        schema = decision.get("schema")
        rules = decision.get("rules", [])
        if schema:
            violations.extend(self._schema_validate(cand, schema))
        for r in rules:
            violations.extend(self._rule_validate(cand, r))
        return {"valid": not violations, "violations": violations,
                 "violation_count": len(violations)}

    def _schema_validate(self, value: Any, schema: dict[str, Any]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        t = schema.get("type")
        if t == "object" and not isinstance(value, dict):
            out.append({"path": "$", "error": f"expected object, got {type(value).__name__}"})
            return out
        if t == "array" and not isinstance(value, list):
            out.append({"path": "$", "error": f"expected array, got {type(value).__name__}"})
            return out
        if t == "object" and isinstance(value, dict):
            for k in schema.get("required", []):
                if k not in value:
                    out.append({"path": f"$.{k}", "error": "missing required field"})
            for k, sub in (schema.get("properties") or {}).items():
                if k in value:
                    out.extend(self._schema_validate(value[k], sub))
        return out

    def _rule_validate(self, value: Any, rule: dict[str, Any]) -> list[dict[str, Any]]:
        pat = rule.get("regex")
        text = str(value)
        if pat and not re.search(pat, text):
            return [{"rule": rule.get("name", pat), "error": "regex not matched"}]
        if "max_len" in rule and len(text) > int(rule["max_len"]):
            return [{"rule": rule.get("name", "max_len"), "error": "too long"}]
        return []
