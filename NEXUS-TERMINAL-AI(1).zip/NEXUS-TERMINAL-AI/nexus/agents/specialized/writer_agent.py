"""WriterAgent — produces long-form prose for a topic."""
from __future__ import annotations

import logging
from typing import Any

from ..agent_registry import agent_registry
from ..base_agent import BaseAgent, AgentContext

logger = logging.getLogger(__name__)


@agent_registry.register("writer")
class WriterAgent(BaseAgent):
    role = "writer"
    system_prompt = (
        "You are a skilled writer. Produce clear, engaging, well-structured prose. "
        "Match the requested tone and audience. Avoid filler."
    )

    async def perceive(self, ctx: AgentContext) -> dict[str, Any]:
        return {"tone": ctx.inputs.get("tone", "neutral"),
                 "audience": ctx.inputs.get("audience", "general"),
                 "max_words": ctx.inputs.get("max_words", 600)}

    async def decide(self, ctx: AgentContext) -> dict[str, Any] | None:
        if ctx.iteration > 0:
            return None
        return ctx.observations[-1] if ctx.observations else {}

    async def act(self, decision: dict[str, Any], ctx: AgentContext) -> dict[str, Any]:
        if self.llm is None:
            text = f"Draft for: {ctx.goal}\n\n(Stub — connect an LLM to generate prose.)"
        else:
            text = await self._write(ctx.goal, decision)
        return {"text": text, "word_count": len(text.split())}

    async def _write(self, goal: str, params: dict[str, Any]) -> str:
        from ...llm.base import LLMMessage, LLMRequest, Role
        user = (f"Write a piece on: {goal}\nTone: {params.get('tone')}\n"
                f"Audience: {params.get('audience')}\nMax words: {params.get('max_words')}.")
        req = LLMRequest(model=self.options.get("model", "claude-sonnet-4-5"),
                          messages=[LLMMessage(role=Role.SYSTEM, content=self.system_prompt),
                                     LLMMessage(role=Role.USER, content=user)],
                          temperature=0.7,
                          max_tokens=params.get("max_words", 600) * 2)
        resp = await self.llm.agenerate(req)
        return resp.content
