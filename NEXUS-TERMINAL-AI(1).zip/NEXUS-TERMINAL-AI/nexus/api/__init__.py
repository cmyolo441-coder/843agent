"""nexus.api — FastAPI-based REST, WebSocket, and gRPC server.

Provides route handlers, middleware, authentication, rate limiting,
WebSocket management, gRPC services, and Pydantic schemas.
"""
from __future__ import annotations

from nexus.api.server import create_app

__all__ = ["create_app"]
