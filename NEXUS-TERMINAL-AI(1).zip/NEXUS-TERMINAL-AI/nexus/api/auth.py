"""API authentication — JWT, API key, and OAuth2 Bearer validation."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import time
from typing import Any

from fastapi import Request
from nexus.exceptions import SecurityError
from nexus.registry import SERVICES

_log = logging.getLogger(__name__)


def _get_secret() -> str:
    """Retrieve the auth signing secret from config or environment."""
    from nexus.core.config_manager import config_manager  # noqa: PLC0415
    return config_manager.get("api.secret_key", "nexus-default-secret")


async def verify_request(request: Request) -> dict[str, Any]:
    """Validate and return the authenticated user payload."""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
        return verify_jwt(token)
    api_key = request.headers.get("X-API-Key", "")
    if api_key:
        return verify_api_key(api_key)
    raise SecurityError("No authentication credentials provided")


def verify_jwt(token: str) -> dict[str, Any]:
    """Simple HMAC-based JWT verification (no external libs)."""
    parts = token.split(".")
    if len(parts) != 3:
        raise SecurityError("Invalid JWT format")
    header_b64, payload_b64, sig_b64 = parts
    secret = _get_secret()
    expected_sig = hmac.new(
        secret.encode(), f"{header_b64}.{payload_b64}".encode(), hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(expected_sig, sig_b64):
        raise SecurityError("Invalid JWT signature")
    payload_json = _b64decode(payload_b64)
    payload = json.loads(payload_json)
    exp = payload.get("exp", 0)
    if exp and time.time() > exp:
        raise SecurityError("JWT expired")
    return payload


def verify_api_key(key: str) -> dict[str, Any]:
    """Validate an API key against the registry."""
    keys_registry = SERVICES.get("api_keys")
    if keys_registry is None:
        raise SecurityError("API key registry not available")
    entry = keys_registry.get(key)
    if entry is None:
        raise SecurityError("Invalid API key")
    return {"sub": entry.get("user_id", "unknown"), "scopes": entry.get("scopes", [])}


def create_jwt(payload: dict[str, Any], ttl_s: int = 3600) -> str:
    """Create a signed JWT token."""
    import base64  # noqa: PLC0415
    header = base64.urlsafe_b64encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode()).rstrip(b"=").decode()
    payload = {**payload, "exp": int(time.time()) + ttl_s, "iat": int(time.time())}
    payload_b64 = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=").decode()
    secret = _get_secret()
    sig = hmac.new(secret.encode(), f"{header}.{payload_b64}".encode(), hashlib.sha256).hexdigest()
    return f"{header}.{payload_b64}.{sig}"


def _b64decode(data: str) -> str:
    import base64  # noqa: PLC0415
    padded = data + "=" * (4 - len(data) % 4)
    return base64.urlsafe_b64decode(padded).decode()
