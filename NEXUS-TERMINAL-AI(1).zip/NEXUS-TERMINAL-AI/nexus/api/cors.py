"""CORS configuration for the NEXUS API server."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware

_log = logging.getLogger(__name__)

DEFAULT_ALLOW_ORIGINS: list[str] = ["*"]
DEFAULT_ALLOW_METHODS: list[str] = ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"]
DEFAULT_ALLOW_HEADERS: list[str] = ["*"]


def configure_cors(
    app: FastAPI,
    origins: list[str] | None = None,
    methods: list[str] | None = None,
    headers: list[str] | None = None,
) -> None:
    """Attach CORS middleware to the FastAPI application."""
    config: dict[str, Any] = {
        "allow_origins": origins or DEFAULT_ALLOW_ORIGINS,
        "allow_methods": methods or DEFAULT_ALLOW_METHODS,
        "allow_headers": headers or DEFAULT_ALLOW_HEADERS,
        "allow_credentials": True,
        "max_age": 600,
    }
    app.add_middleware(CORSMiddleware, **config)
    _log.debug("CORS configured with origins=%s", config["allow_origins"])
