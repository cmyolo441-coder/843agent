"""Error handlers — convert exceptions to structured JSON responses."""
from __future__ import annotations

import logging
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from nexus.api.schemas.error_schema import ErrorResponse
from nexus.exceptions import NexusError

_log = logging.getLogger(__name__)


def nexus_error_handler(request: Request, exc: NexusError) -> JSONResponse:
    """Handle all NexusError subclasses."""
    _log.warning("NexusError at %s: %s", request.url.path, exc)
    status_map: dict[type, int] = {
        "ConfigError": 400,
        "ValidationError": 422,
        "SecurityError": 403,
        "ToolNotFound": 404,
        "MemoryError": 404,
    }
    status = 500
    for exc_type, code in status_map.items():
        if type(exc).__name__ == exc_type:
            status = code
            break
    error = ErrorResponse(
        error=type(exc).__name__,
        detail=str(exc),
        details=exc.details,
    )
    return JSONResponse(status_code=status, content=error.model_dump())


def generic_error_handler(request: Request, exc: Exception) -> JSONResponse:
    """Handle uncaught exceptions with a 500 response."""
    _log.exception("Unhandled exception at %s", request.url.path)
    error = ErrorResponse(error="InternalError", detail="An unexpected error occurred")
    return JSONResponse(status_code=500, content=error.model_dump())


def register_error_handlers(app: FastAPI) -> None:
    """Register all custom error handlers on the FastAPI app."""
    app.add_exception_handler(NexusError, nexus_error_handler)  # type: ignore[arg-type]
    app.add_exception_handler(Exception, generic_error_handler)
    _log.debug("Error handlers registered")
