"""gRPC Agent service — agent lifecycle management RPCs."""
from __future__ import annotations

import logging
from typing import Any

from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)


class AgentService:
    """gRPC servicer for Agent management RPCs."""

    def __init__(self, engine: NexusEngine | None = None) -> None:
        self._engine = engine

    async def create_agent(self, name: str, role: str = "assistant", model: str | None = None) -> dict[str, str]:
        """Create a new agent and return its metadata."""
        engine = self._engine or NexusEngine()
        agent = await engine.create_agent(name=name, role=role, model=model)
        return {"name": agent.name, "role": agent.role, "status": getattr(agent, "status", "created")}

    async def list_agents(self) -> list[dict[str, str]]:
        """List all registered agents."""
        engine = self._engine or NexusEngine()
        agents = await engine.list_agents()
        return [{"name": a.name, "role": a.role, "status": getattr(a, "status", "unknown")} for a in agents]

    async def delete_agent(self, name: str) -> bool:
        """Delete an agent by name. Returns True on success."""
        engine = self._engine or NexusEngine()
        await engine.delete_agent(name)
        return True

    async def inspect_agent(self, name: str) -> dict[str, Any]:
        """Get detailed information about an agent."""
        engine = self._engine or NexusEngine()
        return await engine.inspect_agent(name)
