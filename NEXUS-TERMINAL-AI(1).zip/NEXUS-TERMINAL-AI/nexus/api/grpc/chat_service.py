"""gRPC Chat service — unary and streaming chat RPCs."""
from __future__ import annotations

import asyncio
import logging
from typing import Any, AsyncIterator

from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)


class ChatService:
    """gRPC servicer for Chat RPCs (unary + server-side streaming)."""

    def __init__(self, engine: NexusEngine | None = None) -> None:
        self._engine = engine

    async def chat(self, agent: str, message: str, model: str | None = None) -> dict[str, Any]:
        """Unary chat RPC — send message, get response."""
        engine = self._engine or NexusEngine()
        result = await engine.chat(agent=agent, message=message, model=model)
        return {"agent": agent, "response": result}

    async def stream_chat(self, agent: str, message: str, model: str | None = None) -> AsyncIterator[str]:
        """Server-side streaming chat RPC — yield tokens as they arrive."""
        engine = self._engine or NexusEngine()
        async for token in engine.chat_stream(agent=agent, message=message, model=model):
            yield token

    async def get_history(self, agent: str, limit: int = 20) -> list[dict[str, Any]]:
        """Retrieve chat history for an agent."""
        engine = self._engine or NexusEngine()
        return await engine.get_chat_history(agent=agent, limit=limit)
