"""ASGI middleware — auth enforcement, rate limiting, request ID injection."""
from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import FastAPI, Request
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse, Response

from nexus.api.auth import verify_request
from nexus.context import child, use
from nexus.exceptions import SecurityError

_log = logging.getLogger(__name__)


class AuthMiddleware(BaseHTTPMiddleware):
    """Validate JWT or API key on every request (except health/docs)."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        if request.url.path in ("/api/v1/health", "/api/v1/health/", "/docs", "/redoc", "/openapi.json"):
            return await call_next(request)
        try:
            payload = await verify_request(request)
            request.state.user = payload
        except SecurityError as exc:
            _log.warning("Auth failed for %s: %s", request.url.path, exc)
            return JSONResponse(status_code=403, content={"detail": str(exc)})
        return await call_next(request)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Inject a unique request ID and execution context."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        req_id = request.headers.get("X-Request-ID", uuid.uuid4().hex)
        ctx = child(request_id=req_id)
        with use(ctx):
            response = await call_next(request)
        response.headers["X-Request-ID"] = req_id
        return response


def register_middleware(app: FastAPI) -> None:
    """Register all middleware in the correct order."""
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(AuthMiddleware)
    _log.debug("Middleware registered")
