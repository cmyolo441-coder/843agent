"""Rate limiting — token-bucket based per-client throttling."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from typing import Any

from nexus.exceptions import NexusError

_log = logging.getLogger(__name__)


class RateLimitError(NexusError):
    """Raised when the client exceeds its rate limit."""


class Bucket:
    """Token-bucket rate limiter for a single key."""

    def __init__(self, capacity: int, refill_rate: float) -> None:
        self.capacity = capacity
        self.refill_rate = refill_rate
        self.tokens = float(capacity)
        self.last_refill = time.monotonic()

    def allow(self, cost: int = 1) -> bool:
        now = time.monotonic()
        elapsed = now - self.last_refill
        self.tokens = min(self.capacity, self.tokens + elapsed * self.refill_rate)
        self.last_refill = now
        if self.tokens >= cost:
            self.tokens -= cost
            return True
        return False

    @property
    def retry_after(self) -> float:
        return (1.0 - self.tokens) / self.refill_rate if self.tokens < 1.0 else 0.0


class RateLimiter:
    """Token-bucket rate limiter indexed by client key."""

    def __init__(self, capacity: int = 60, refill_rate: float = 1.0) -> None:
        self._capacity = capacity
        self._refill_rate = refill_rate
        self._buckets: dict[str, Bucket] = defaultdict(
            lambda: Bucket(capacity, refill_rate)
        )
        self._cleanup_task: asyncio.Task[Any] | None = None

    def check(self, key: str, cost: int = 1) -> None:
        """Raise RateLimitError if the key exceeds limits."""
        bucket = self._buckets[key]
        if not bucket.allow(cost):
            raise RateLimitError(
                f"Rate limit exceeded for {key!r}",
                details={"retry_after": bucket.retry_after},
            )

    async def close(self) -> None:
        """Cancel background cleanup."""
        if self._cleanup_task:
            self._cleanup_task.cancel()
