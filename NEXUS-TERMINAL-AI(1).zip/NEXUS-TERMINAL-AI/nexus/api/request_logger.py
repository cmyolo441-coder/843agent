"""Request logger — structured HTTP request/response logging."""
from __future__ import annotations

import logging
import time
from typing import Any

from fastapi import FastAPI, Request
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import Response

_log = logging.getLogger(__name__)


class RequestLogger:
    """Log structured request summaries after each response."""

    async def log(self, request: Request, response: Response, duration_s: float) -> None:
        """Emit a structured log line for the request."""
        extra: dict[str, Any] = {
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "duration_ms": round(duration_s * 1000, 2),
            "client": request.client.host if request.client else "unknown",
            "user_agent": request.headers.get("user-agent", ""),
        }
        _log.info("HTTP %s %s → %d (%.1fms)", extra["method"], extra["path"], extra["status"], extra["duration_ms"])


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware that measures and logs every request."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        duration = time.perf_counter() - start
        logger: RequestLogger = request.app.state.request_logger
        await logger.log(request, response, duration)
        return response


def register_request_logging(app: FastAPI) -> None:
    """Attach the request logging middleware."""
    app.add_middleware(RequestLoggingMiddleware)
