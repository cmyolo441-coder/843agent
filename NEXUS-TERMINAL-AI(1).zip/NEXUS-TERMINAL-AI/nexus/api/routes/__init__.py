"""nexus.api.routes — FastAPI route handlers organized by domain."""
from __future__ import annotations

__all__ = [
    "admin_routes",
    "agent_routes",
    "chat_routes",
    "config_routes",
    "health_routes",
    "knowledge_routes",
    "memory_routes",
    "metrics_routes",
    "plugin_routes",
    "rag_routes",
    "tool_routes",
    "workflow_routes",
]
