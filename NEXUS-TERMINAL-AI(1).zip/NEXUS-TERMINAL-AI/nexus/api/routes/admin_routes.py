"""Admin routes — system administration and management endpoints."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request

from nexus.core.engine import NexusEngine
from nexus.exceptions import SecurityError

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


def require_admin(request: Request) -> None:
    """Check that the request has admin privileges."""
    user = getattr(request.state, "user", {})
    if "admin" not in user.get("scopes", []):
        raise HTTPException(status_code=403, detail="Admin privileges required")


@router.post("/admin/shutdown")
async def shutdown_server(request: Request, engine: NexusEngine = Depends(get_engine)) -> dict[str, str]:
    """Gracefully shut down the server (admin only)."""
    require_admin(request)
    await engine.stop()
    return {"status": "shutting_down"}


@router.post("/admin/restart")
async def restart_server(request: Request, engine: NexusEngine = Depends(get_engine)) -> dict[str, str]:
    """Restart the engine (admin only)."""
    require_admin(request)
    await engine.stop()
    await engine.start()
    return {"status": "restarted"}


@router.get("/admin/status")
async def admin_status(request: Request, engine: NexusEngine = Depends(get_engine)) -> dict[str, str]:
    """Full system status for administrators."""
    require_admin(request)
    info = await engine.system_info()
    return info


@router.post("/admin/log-level")
async def set_log_level(level: str, request: Request, engine: NexusEngine = Depends(get_engine)) -> dict[str, str]:
    """Change runtime log level (admin only)."""
    require_admin(request)
    import logging as _logging
    numeric = getattr(_logging, level.upper(), None)
    if numeric is None:
        raise HTTPException(status_code=400, detail=f"Invalid log level: {level}")
    _logging.getLogger("nexus").setLevel(numeric)
    return {"status": "ok", "level": level.upper()}
