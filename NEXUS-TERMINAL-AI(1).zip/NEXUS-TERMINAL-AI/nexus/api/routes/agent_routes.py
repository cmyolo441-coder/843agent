"""Agent routes — CRUD operations for agent lifecycle."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from nexus.api.schemas.agent_schema import (
    AgentCreateRequest,
    AgentListResponse,
    AgentResponse,
)
from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.get("/agents", response_model=AgentListResponse)
async def list_agents(engine: NexusEngine = Depends(get_engine)) -> AgentListResponse:
    """List all registered agents."""
    agents = await engine.list_agents()
    return AgentListResponse(agents=[AgentResponse(name=a.name, role=a.role, status=a.status) for a in agents])


@router.post("/agents", response_model=AgentResponse, status_code=201)
async def create_agent(body: AgentCreateRequest, engine: NexusEngine = Depends(get_engine)) -> AgentResponse:
    """Create a new agent."""
    agent = await engine.create_agent(name=body.name, role=body.role, model=body.model)
    return AgentResponse(name=agent.name, role=agent.role, status=agent.status)


@router.get("/agents/{name}", response_model=AgentResponse)
async def inspect_agent(name: str, engine: NexusEngine = Depends(get_engine)) -> AgentResponse:
    """Get agent details by name."""
    info = await engine.inspect_agent(name)
    return AgentResponse(name=info.get("name", name), role=info.get("role", ""), status=info.get("status", ""))


@router.delete("/agents/{name}", status_code=204)
async def delete_agent(name: str, engine: NexusEngine = Depends(get_engine)) -> None:
    """Delete an agent."""
    await engine.delete_agent(name)
