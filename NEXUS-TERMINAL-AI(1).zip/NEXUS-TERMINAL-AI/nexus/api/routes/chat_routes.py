"""Chat routes — send messages and stream responses."""
from __future__ import annotations

import logging
from typing import AsyncIterator

from fastapi import APIRouter, Depends, HTTPException, Request
from sse_starlette.sse import EventSourceResponse

from nexus.api.schemas.chat_schema import ChatRequest, ChatResponse, ChatHistoryResponse
from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.post("/chat", response_model=ChatResponse)
async def chat_endpoint(body: ChatRequest, engine: NexusEngine = Depends(get_engine)) -> ChatResponse:
    """Send a chat message and receive a response."""
    result = await engine.chat(agent=body.agent, message=body.message, model=body.model)
    return ChatResponse(agent=body.agent, message=result, usage=body.usage)


@router.post("/chat/stream")
async def chat_stream_endpoint(body: ChatRequest, engine: NexusEngine = Depends(get_engine)) -> EventSourceResponse:
    """Stream a chat response token by token."""
    async def event_generator() -> AsyncIterator[dict[str, str]]:
        async for token in engine.chat_stream(agent=body.agent, message=body.message, model=body.model):
            yield {"event": "token", "data": token}
        yield {"event": "done", "data": ""}

    return EventSourceResponse(event_generator())


@router.get("/chat/history", response_model=ChatHistoryResponse)
async def chat_history_endpoint(
    agent: str = "default",
    limit: int = 20,
    engine: NexusEngine = Depends(get_engine),
) -> ChatHistoryResponse:
    """Retrieve recent chat history for an agent."""
    messages = await engine.get_chat_history(agent=agent, limit=limit)
    return ChatHistoryResponse(agent=agent, messages=messages)
