"""Config routes — get, set, list configuration values."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from nexus.api.schemas.config_schema import ConfigListResponse, ConfigSetRequest, ConfigSetResponse
from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.get("/config", response_model=ConfigListResponse)
async def list_config(engine: NexusEngine = Depends(get_engine)) -> ConfigListResponse:
    """List all configuration values."""
    items = await engine.config_list()
    return ConfigListResponse(items=items)


@router.get("/config/{key:path}")
async def get_config(key: str, engine: NexusEngine = Depends(get_engine)) -> Any:
    """Get a specific configuration value."""
    value = await engine.config_get(key)
    if value is None:
        raise HTTPException(status_code=404, detail=f"Config key {key!r} not found")
    return {"key": key, "value": value}


@router.put("/config/{key:path}", response_model=ConfigSetResponse)
async def set_config(key: str, body: ConfigSetRequest, engine: NexusEngine = Depends(get_engine)) -> ConfigSetResponse:
    """Set a configuration value."""
    await engine.config_set(key, body.value)
    return ConfigSetResponse(key=key, value=body.value)


@router.delete("/config/{key:path}", status_code=204)
async def delete_config(key: str, engine: NexusEngine = Depends(get_engine)) -> None:
    """Delete a configuration value."""
    await engine.config_delete(key)
