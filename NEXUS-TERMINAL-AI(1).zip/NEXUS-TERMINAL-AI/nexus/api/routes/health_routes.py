"""Health routes — liveness, readiness, and dependency checks."""
from __future__ import annotations

import logging
import time

from fastapi import APIRouter, Request

_log = logging.getLogger(__name__)

router = APIRouter()


@router.get("/health")
async def health_check(request: Request) -> dict[str, str]:
    """Basic liveness probe."""
    return {"status": "ok", "timestamp": str(time.time())}


@router.get("/health/ready")
async def readiness_check(request: Request) -> dict[str, str]:
    """Readiness probe — confirms the engine is available."""
    engine = getattr(request.app.state, "engine", None)
    if engine is None:
        return {"status": "not_ready", "reason": "Engine not initialized"}
    return {"status": "ready", "uptime": str(time.time())}


@router.get("/health/dependencies")
async def dependency_health(request: Request) -> dict[str, str]:
    """Check critical dependency statuses."""
    from nexus.registry import SERVICES  # noqa: PLC0415
    checks = {
        "engine": "ok" if getattr(request.app.state, "engine", None) else "missing",
        "rate_limiter": "ok" if getattr(request.app.state, "rate_limiter", None) else "missing",
    }
    for svc in ("memory", "rag", "plugins"):
        checks[svc] = "ok" if SERVICES.get(svc) else "not_registered"
    overall = "ok" if all(v == "ok" for v in checks.values()) else "degraded"
    return {"status": overall, "checks": checks}
