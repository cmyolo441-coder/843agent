"""Knowledge routes — CRUD for knowledge base triples."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


class TripleCreate(BaseModel):
    subject: str
    predicate: str
    object: str


class TripleResponse(BaseModel):
    subject: str
    predicate: str
    object: str


class TripleListResponse(BaseModel):
    triples: list[TripleResponse]


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.post("/knowledge", status_code=201)
async def add_knowledge(triple: TripleCreate, engine: NexusEngine = Depends(get_engine)) -> TripleResponse:
    """Add a knowledge triple."""
    await engine.knowledge_add(triple.subject, triple.predicate, triple.object)
    return TripleResponse(subject=triple.subject, predicate=triple.predicate, object=triple.object)


@router.get("/knowledge/{subject}", response_model=TripleListResponse)
async def query_knowledge(subject: str, engine: NexusEngine = Depends(get_engine)) -> TripleListResponse:
    """Query all triples for a subject."""
    triples = await engine.knowledge_query(subject)
    return TripleListResponse(triples=[TripleResponse(subject=t.subject, predicate=t.predicate, object=t.object) for t in triples])


@router.delete("/knowledge", status_code=204)
async def delete_knowledge(triple: TripleCreate, engine: NexusEngine = Depends(get_engine)) -> None:
    """Delete a knowledge triple."""
    await engine.knowledge_delete(triple.subject, triple.predicate, triple.object)
