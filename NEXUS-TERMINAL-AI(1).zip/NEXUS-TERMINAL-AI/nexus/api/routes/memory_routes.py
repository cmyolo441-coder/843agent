"""Memory routes — read, write, search memory stores."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request

from nexus.api.schemas.memory_schema import (
    MemoryReadResponse,
    MemorySearchResponse,
    MemoryWriteRequest,
    MemoryWriteResponse,
)
from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.post("/memory", response_model=MemoryWriteResponse, status_code=201)
async def write_memory(body: MemoryWriteRequest, engine: NexusEngine = Depends(get_engine)) -> MemoryWriteResponse:
    """Write a value to memory."""
    await engine.memory_write(key=body.key, value=body.value, namespace=body.namespace)
    return MemoryWriteResponse(key=body.key, namespace=body.namespace, stored=True)


@router.get("/memory/{key}", response_model=MemoryReadResponse)
async def read_memory(key: str, namespace: str = "default", engine: NexusEngine = Depends(get_engine)) -> MemoryReadResponse:
    """Read a value from memory."""
    value = await engine.memory_read(key=key, namespace=namespace)
    if value is None:
        raise HTTPException(status_code=404, detail=f"Key {key!r} not found in namespace {namespace!r}")
    return MemoryReadResponse(key=key, namespace=namespace, value=value)


@router.get("/memory/search", response_model=MemorySearchResponse)
async def search_memory(query: str, namespace: str = "default", k: int = 5, engine: NexusEngine = Depends(get_engine)) -> MemorySearchResponse:
    """Search memory by semantic similarity."""
    results = await engine.memory_search(query=query, namespace=namespace, k=k)
    return MemorySearchResponse(query=query, namespace=namespace, results=results)
