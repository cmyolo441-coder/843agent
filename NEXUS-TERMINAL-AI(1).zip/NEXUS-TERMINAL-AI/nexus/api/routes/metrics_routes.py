"""Metrics routes — Prometheus-style metrics and instrumentation."""
from __future__ import annotations

import logging
import time
from typing import Any

from fastapi import APIRouter, Request

_log = logging.getLogger(__name__)

router = APIRouter()


@router.get("/metrics")
async def prometheus_metrics(request: Request) -> dict[str, Any]:
    """Return runtime metrics in structured JSON (Prometheus-style)."""
    engine = getattr(request.app.state, "engine", None)
    metrics: dict[str, Any] = {
        "uptime_seconds": time.time(),
        "requests_total": request.app.state.request_count if hasattr(request.app.state, "request_count") else 0,
    }
    if engine:
        try:
            engine_metrics = await engine.get_metrics()
            metrics.update(engine_metrics)
        except Exception as exc:
            _log.warning("Failed to collect engine metrics: %s", exc)
            metrics["engine_error"] = str(exc)
    return metrics


@router.get("/metrics/health")
async def metrics_health(request: Request) -> dict[str, Any]:
    """Quick health summary of key metrics."""
    return {
        "status": "ok",
        "active_agents": 0,
        "active_connections": 0,
        "memory_usage_mb": 0,
    }
