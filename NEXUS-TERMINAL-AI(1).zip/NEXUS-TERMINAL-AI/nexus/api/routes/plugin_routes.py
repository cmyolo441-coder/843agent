"""Plugin routes — install, list, enable, disable plugins."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request

from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.get("/plugins")
async def list_plugins(engine: NexusEngine = Depends(get_engine)) -> list[dict[str, str]]:
    """List all installed plugins."""
    plugins = await engine.list_plugins()
    return [{"name": p.name, "version": getattr(p, "version", "?"), "enabled": str(getattr(p, "enabled", False))} for p in plugins]


@router.post("/plugins", status_code=201)
async def install_plugin(source: str, engine: NexusEngine = Depends(get_engine)) -> dict[str, str]:
    """Install a plugin from path or URL."""
    plugin = await engine.install_plugin(source)
    return {"name": plugin.name, "version": getattr(plugin, "version", "?"), "status": "installed"}


@router.delete("/plugins/{name}", status_code=204)
async def uninstall_plugin(name: str, engine: NexusEngine = Depends(get_engine)) -> None:
    """Uninstall a plugin."""
    await engine.uninstall_plugin(name)


@router.post("/plugins/{name}/enable")
async def enable_plugin(name: str, engine: NexusEngine = Depends(get_engine)) -> dict[str, str]:
    """Enable a plugin."""
    await engine.enable_plugin(name)
    return {"name": name, "status": "enabled"}


@router.post("/plugins/{name}/disable")
async def disable_plugin(name: str, engine: NexusEngine = Depends(get_engine)) -> dict[str, str]:
    """Disable a plugin."""
    await engine.disable_plugin(name)
    return {"name": name, "status": "disabled"}
