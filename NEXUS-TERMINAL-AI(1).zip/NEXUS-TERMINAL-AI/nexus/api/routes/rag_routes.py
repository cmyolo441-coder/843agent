"""RAG routes — index documents and query collections."""
from __future__ import annotations

import logging
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile

from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.post("/rag/index", status_code=201)
async def index_document(
    file: UploadFile,
    collection: str = "default",
    engine: NexusEngine = Depends(get_engine),
) -> dict[str, str]:
    """Index an uploaded document."""
    content = await file.read()
    temp_path = Path(f"/tmp/nexus_upload_{file.filename}")
    temp_path.write_bytes(content)
    count = await engine.index_file(temp_path, collection=collection)
    temp_path.unlink(missing_ok=True)
    return {"collection": collection, "indexed": str(count), "file": file.filename or "unknown"}


@router.post("/rag/query")
async def query_rag(query: str, collection: str = "default", top_k: int = 5, engine: NexusEngine = Depends(get_engine)) -> list[dict[str, str]]:
    """Query a RAG collection."""
    results = await engine.rag_query(query, collection=collection, top_k=top_k)
    return [{"score": str(r.get("score", 0)), "content": r.get("content", "")[:200]} for r in results]


@router.get("/rag/collections")
async def list_rag_collections(engine: NexusEngine = Depends(get_engine)) -> list[str]:
    """List all RAG collections."""
    return await engine.list_rag_collections()
