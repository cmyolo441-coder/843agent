"""Tool routes — list, inspect, and invoke tools via REST."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from nexus.api.schemas.tool_schema import ToolCallRequest, ToolCallResponse, ToolListResponse
from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.get("/tools", response_model=ToolListResponse)
async def list_tools(engine: NexusEngine = Depends(get_engine)) -> ToolListResponse:
    """List all registered tools."""
    tools = await engine.list_tools()
    return ToolListResponse(tools=[{"name": t.name, "description": getattr(t, "description", "")} for t in tools])


@router.post("/tools/{name}/call", response_model=ToolCallResponse)
async def call_tool(name: str, body: ToolCallRequest, engine: NexusEngine = Depends(get_engine)) -> ToolCallResponse:
    """Invoke a tool with parameters."""
    result = await engine.call_tool(name, **body.params)
    return ToolCallResponse(name=name, result=result)


@router.get("/tools/{name}/schema")
async def tool_schema(name: str, engine: NexusEngine = Depends(get_engine)) -> dict[str, Any]:
    """Get the JSON schema for a tool."""
    return await engine.tool_schema(name)
