"""Workflow routes — list, run, and monitor workflow executions."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from nexus.api.schemas.workflow_schema import WorkflowListResponse, WorkflowRunRequest, WorkflowRunResponse, WorkflowStatusResponse
from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)

router = APIRouter()


async def get_engine(request: Request) -> NexusEngine:
    engine: NexusEngine | None = getattr(request.app.state, "engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not available")
    return engine


@router.get("/workflows", response_model=WorkflowListResponse)
async def list_workflows(engine: NexusEngine = Depends(get_engine)) -> WorkflowListResponse:
    """List all defined workflows."""
    workflows = await engine.list_workflows()
    return WorkflowListResponse(workflows=[{"name": w.name, "description": getattr(w, "description", ""), "status": getattr(w, "status", "")} for w in workflows])


@router.post("/workflows/{name}/run", response_model=WorkflowRunResponse)
async def run_workflow(name: str, body: WorkflowRunRequest, engine: NexusEngine = Depends(get_engine)) -> WorkflowRunResponse:
    """Execute a workflow."""
    result = await engine.run_workflow(name, **body.params)
    return WorkflowRunResponse(workflow=name, result=str(result), run_id=body.run_id or "")


@router.get("/workflows/runs/{run_id}", response_model=WorkflowStatusResponse)
async def workflow_status(run_id: str, engine: NexusEngine = Depends(get_engine)) -> WorkflowStatusResponse:
    """Get the status of a workflow run."""
    status = await engine.workflow_status(run_id)
    return WorkflowStatusResponse(run_id=run_id, status=status.get("status", "unknown"), details=status)
