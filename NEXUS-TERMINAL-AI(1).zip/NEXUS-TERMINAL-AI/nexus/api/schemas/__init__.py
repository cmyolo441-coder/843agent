"""nexus.api.schemas — Pydantic models for API request/response validation.

Each schema package matches a route domain and provides typed models
for serialization, deserialization, and OpenAPI generation.
"""
from __future__ import annotations
