"""Agent request/response schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class AgentCreateRequest(BaseModel):
    name: str = Field(..., description="Agent name")
    role: str = Field("assistant", description="Agent role")
    model: str | None = Field(None, description="LLM model override")


class AgentResponse(BaseModel):
    name: str = Field(..., description="Agent name")
    role: str = Field(..., description="Agent role")
    status: str = Field(..., description="Current status")


class AgentListResponse(BaseModel):
    agents: list[AgentResponse] = Field(default_factory=list, description="List of agents")
