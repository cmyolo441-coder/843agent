"""Chat request/response schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    agent: str = Field("default", description="Target agent name")
    message: str = Field(..., description="User message text")
    model: str | None = Field(None, description="LLM model override")
    stream: bool = Field(False, description="Enable streaming response")
    usage: dict[str, Any] | None = Field(None, description="Usage metadata")


class ChatResponse(BaseModel):
    agent: str = Field(..., description="Agent that produced the response")
    message: str = Field(..., description="Response text")
    usage: dict[str, Any] | None = Field(None, description="Token usage info")


class ChatHistoryResponse(BaseModel):
    agent: str = Field(..., description="Agent name")
    messages: list[dict[str, Any]] = Field(default_factory=list, description="Chat message list")
