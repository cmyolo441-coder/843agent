"""Configuration request/response schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ConfigSetRequest(BaseModel):
    value: Any = Field(..., description="Configuration value")


class ConfigSetResponse(BaseModel):
    key: str = Field(..., description="Configuration key")
    value: Any = Field(..., description="Configuration value")


class ConfigListResponse(BaseModel):
    items: dict[str, Any] = Field(default_factory=dict, description="Configuration key-value pairs")
