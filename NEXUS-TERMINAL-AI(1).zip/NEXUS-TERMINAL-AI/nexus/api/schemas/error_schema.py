"""Standard error response schema."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ErrorResponse(BaseModel):
    error: str = Field(..., description="Error type identifier")
    detail: str = Field("", description="Human-readable error message")
    details: dict[str, Any] = Field(default_factory=dict, description="Additional error context")
    request_id: str | None = Field(None, description="Correlated request ID")
