"""Memory request/response schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class MemoryWriteRequest(BaseModel):
    key: str = Field(..., description="Memory key")
    value: Any = Field(..., description="Value to store")
    namespace: str = Field("default", description="Memory namespace")


class MemoryWriteResponse(BaseModel):
    key: str = Field(..., description="Memory key")
    namespace: str = Field(..., description="Memory namespace")
    stored: bool = Field(..., description="Whether the value was stored")


class MemoryReadResponse(BaseModel):
    key: str = Field(..., description="Memory key")
    namespace: str = Field(..., description="Memory namespace")
    value: Any = Field(None, description="Stored value")


class MemorySearchResponse(BaseModel):
    query: str = Field(..., description="Search query")
    namespace: str = Field(..., description="Memory namespace")
    results: list[Any] = Field(default_factory=list, description="Search results")
