"""Tool request/response schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ToolCallRequest(BaseModel):
    params: dict[str, Any] = Field(default_factory=dict, description="Tool parameters")


class ToolCallResponse(BaseModel):
    name: str = Field(..., description="Tool name")
    result: Any = Field(None, description="Tool execution result")


class ToolInfo(BaseModel):
    name: str = Field(..., description="Tool name")
    description: str = Field("", description="Tool description")


class ToolListResponse(BaseModel):
    tools: list[ToolInfo] = Field(default_factory=list, description="Registered tools")
