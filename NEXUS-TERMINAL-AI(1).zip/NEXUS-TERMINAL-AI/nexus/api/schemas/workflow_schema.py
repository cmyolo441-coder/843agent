"""Workflow request/response schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class WorkflowRunRequest(BaseModel):
    params: dict[str, Any] = Field(default_factory=dict, description="Workflow parameters")
    run_id: str | None = Field(None, description="Optional run ID override")


class WorkflowRunResponse(BaseModel):
    workflow: str = Field(..., description="Workflow name")
    result: str = Field(..., description="Execution result summary")
    run_id: str = Field("", description="Run identifier")


class WorkflowStatusResponse(BaseModel):
    run_id: str = Field(..., description="Run identifier")
    status: str = Field(..., description="Current status")
    details: dict[str, Any] = Field(default_factory=dict, description="Status details")


class WorkflowInfo(BaseModel):
    name: str = Field(..., description="Workflow name")
    description: str = Field("", description="Workflow description")
    status: str = Field("", description="Current status")


class WorkflowListResponse(BaseModel):
    workflows: list[WorkflowInfo] = Field(default_factory=list, description="Defined workflows")
