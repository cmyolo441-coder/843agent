"""FastAPI application factory and entry point."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI

from nexus.api.cors import configure_cors
from nexus.api.error_handler import register_error_handlers
from nexus.api.middleware import register_middleware
from nexus.api.rate_limit import RateLimiter
from nexus.api.request_logger import RequestLogger
from nexus.api.routes import (
    admin_routes,
    agent_routes,
    chat_routes,
    config_routes,
    health_routes,
    knowledge_routes,
    memory_routes,
    metrics_routes,
    plugin_routes,
    rag_routes,
    tool_routes,
    workflow_routes,
)
from nexus.api.websocket.ws_handler import websocket_handler

_log = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """FastAPI lifespan context — start/stop background services."""
    _log.info("NEXUS API starting ...")
    rate_limiter = RateLimiter()
    app.state.rate_limiter = rate_limiter
    request_logger = RequestLogger()
    app.state.request_logger = request_logger
    yield
    _log.info("NEXUS API shutting down ...")
    await rate_limiter.close()


def create_app() -> FastAPI:
    """Build and return a fully configured FastAPI application."""
    app = FastAPI(
        title="NEXUS Terminal AI API",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
    )
    configure_cors(app)
    register_middleware(app)
    register_error_handlers(app)

    app.include_router(health_routes.router, prefix="/api/v1", tags=["Health"])
    app.include_router(chat_routes.router, prefix="/api/v1", tags=["Chat"])
    app.include_router(agent_routes.router, prefix="/api/v1", tags=["Agents"])
    app.include_router(tool_routes.router, prefix="/api/v1", tags=["Tools"])
    app.include_router(memory_routes.router, prefix="/api/v1", tags=["Memory"])
    app.include_router(config_routes.router, prefix="/api/v1", tags=["Config"])
    app.include_router(plugin_routes.router, prefix="/api/v1", tags=["Plugins"])
    app.include_router(workflow_routes.router, prefix="/api/v1", tags=["Workflows"])
    app.include_router(rag_routes.router, prefix="/api/v1", tags=["RAG"])
    app.include_router(knowledge_routes.router, prefix="/api/v1", tags=["Knowledge"])
    app.include_router(metrics_routes.router, prefix="/api/v1", tags=["Metrics"])
    app.include_router(admin_routes.router, prefix="/api/v1", tags=["Admin"])

    app.add_websocket_route("/ws", websocket_handler)

    return app


app = create_app()
