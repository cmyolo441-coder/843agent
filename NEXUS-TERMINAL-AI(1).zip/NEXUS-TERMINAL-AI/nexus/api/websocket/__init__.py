"""nexus.api.websocket — WebSocket connection management and event streaming.

Provides connection lifecycle, message routing, streaming, and event
broadcasting for real-time NEXUS functionality.
"""
from __future__ import annotations

from nexus.api.websocket.ws_manager import ConnectionManager

__all__ = ["ConnectionManager"]
