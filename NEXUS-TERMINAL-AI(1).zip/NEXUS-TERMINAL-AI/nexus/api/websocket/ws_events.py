"""WebSocket events — subscribe, dispatch, and broadcast events."""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Coroutine

_log = logging.getLogger(__name__)

EventHandler = Callable[[str, dict[str, Any]], Coroutine[Any, Any, Any]]


class EventDispatcher:
    """Route WebSocket messages to registered event handlers."""

    def __init__(self) -> None:
        self._handlers: dict[str, EventHandler] = {}
        self._subscriptions: dict[str, list[str]] = {}

    def register(self, event_type: str, handler: EventHandler) -> None:
        """Register a handler for a specific event type."""
        self._handlers[event_type] = handler
        _log.debug("Registered handler for event %r", event_type)

    async def subscribe(self, client_id: str, events: list[str]) -> None:
        """Subscribe a client to one or more event types."""
        self._subscriptions.setdefault(client_id, []).extend(events)

    async def unsubscribe(self, client_id: str) -> None:
        """Remove all subscriptions for a client."""
        self._subscriptions.pop(client_id, None)

    async def dispatch(self, client_id: str, message: dict[str, Any]) -> Any:
        """Dispatch a message to its registered handler."""
        event_type = message.get("type", "")
        handler = self._handlers.get(event_type)
        if handler is None:
            _log.warning("No handler for event %r from %s", event_type, client_id)
            return None
        return await handler(client_id, message)

    async def broadcast_event(self, event_type: str, data: dict[str, Any]) -> None:
        """Emit an event to all subscribed clients."""
        from nexus.api.websocket.ws_manager import manager  # noqa: PLC0415
        payload = {"type": event_type, "data": data}
        for cid, events in list(self._subscriptions.items()):
            if event_type in events:
                await manager.send(cid, payload)
