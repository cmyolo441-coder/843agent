"""WebSocket handler — accept, route, and manage incoming WS messages."""
from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import WebSocket, WebSocketDisconnect

from nexus.api.websocket.ws_events import EventDispatcher
from nexus.api.websocket.ws_manager import manager
from nexus.api.websocket.ws_stream import StreamManager

_log = logging.getLogger(__name__)


async def websocket_handler(ws: WebSocket) -> None:
    """Main WebSocket endpoint — handshake and message loop."""
    client_id = ws.headers.get("X-Client-ID", f"anon-{id(ws)}")
    await manager.connect(client_id, ws)
    dispatcher = EventDispatcher()
    stream_manager = StreamManager()
    try:
        while True:
            raw = await ws.receive_text()
            try:
                message = json.loads(raw)
            except json.JSONDecodeError:
                await ws.send_json({"error": "Invalid JSON", "type": "error"})
                continue
            msg_type = message.get("type", "")
            if msg_type == "ping":
                await ws.send_json({"type": "pong"})
            elif msg_type == "stream":
                await stream_manager.handle_stream(ws, client_id, message)
            elif msg_type == "subscribe":
                await dispatcher.subscribe(client_id, message.get("events", []))
                await ws.send_json({"type": "subscribed", "events": message.get("events", [])})
            else:
                result = await dispatcher.dispatch(client_id, message)
                if result is not None:
                    await ws.send_json({"type": "response", "data": result})
    except WebSocketDisconnect:
        _log.info("WebSocket disconnected: %s", client_id)
    except Exception as exc:
        _log.exception("WebSocket error for %s", client_id)
        try:
            await ws.send_json({"type": "error", "data": str(exc)})
        except Exception:
            pass
    finally:
        await manager.disconnect(client_id)
