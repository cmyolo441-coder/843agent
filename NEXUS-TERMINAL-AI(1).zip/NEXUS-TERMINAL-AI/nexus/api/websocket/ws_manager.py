"""WebSocket connection manager — track and broadcast to connected clients."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import WebSocket

_log = logging.getLogger(__name__)


class ConnectionManager:
    """Manage active WebSocket connections with per-client tracking."""

    def __init__(self) -> None:
        self._connections: dict[str, WebSocket] = {}
        self._lock = asyncio.Lock()

    async def connect(self, client_id: str, ws: WebSocket) -> None:
        """Register a new WebSocket connection."""
        await ws.accept()
        async with self._lock:
            self._connections[client_id] = ws
        _log.info("WebSocket connected: %s (total=%d)", client_id, len(self._connections))

    async def disconnect(self, client_id: str) -> None:
        """Remove a WebSocket connection."""
        async with self._lock:
            self._connections.pop(client_id, None)
        _log.info("WebSocket disconnected: %s (total=%d)", client_id, len(self._connections))

    async def send(self, client_id: str, data: dict[str, Any]) -> bool:
        """Send JSON data to a specific client. Returns True on success."""
        ws = self._connections.get(client_id)
        if ws is None:
            return False
        try:
            await ws.send_json(data)
            return True
        except Exception as exc:
            _log.warning("Failed to send to %s: %s", client_id, exc)
            await self.disconnect(client_id)
            return False

    async def broadcast(self, data: dict[str, Any]) -> int:
        """Send JSON data to all connected clients. Returns count of recipients."""
        sent = 0
        async with self._lock:
            for cid, ws in list(self._connections.items()):
                try:
                    await ws.send_json(data)
                    sent += 1
                except Exception as exc:
                    _log.warning("Broadcast failed to %s: %s", cid, exc)
                    self._connections.pop(cid, None)
        return sent

    @property
    def active_connections(self) -> int:
        return len(self._connections)

    @property
    def client_ids(self) -> list[str]:
        return list(self._connections.keys())


manager = ConnectionManager()
