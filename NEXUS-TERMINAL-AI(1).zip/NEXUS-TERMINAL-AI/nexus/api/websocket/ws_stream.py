"""WebSocket streaming — stream data to clients chunk by chunk."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import WebSocket

from nexus.core.engine import NexusEngine

_log = logging.getLogger(__name__)


class StreamManager:
    """Manage streaming data flows to WebSocket clients."""

    def __init__(self) -> None:
        self._active_streams: dict[str, asyncio.Task[Any]] = {}

    async def handle_stream(self, ws: WebSocket, client_id: str, message: dict[str, Any]) -> None:
        """Start a streaming task based on the message type."""
        stream_type = message.get("stream_type", "chat")
        if stream_type == "chat":
            task = asyncio.create_task(self._stream_chat(ws, client_id, message))
        elif stream_type == "log":
            task = asyncio.create_task(self._stream_logs(ws, client_id, message))
        else:
            await ws.send_json({"type": "error", "data": f"Unknown stream type: {stream_type}"})
            return
        self._active_streams[client_id] = task

    async def _stream_chat(self, ws: WebSocket, client_id: str, message: dict[str, Any]) -> None:
        """Stream chat response tokens to the client."""
        agent = message.get("agent", "default")
        text = message.get("message", "")
        engine = NexusEngine()
        try:
            async for token in engine.chat_stream(agent=agent, message=text):
                await ws.send_json({"type": "token", "data": token})
            await ws.send_json({"type": "done"})
        except Exception as exc:
            _log.exception("Chat stream error for %s", client_id)
            await ws.send_json({"type": "error", "data": str(exc)})

    async def _stream_logs(self, ws: WebSocket, client_id: str, message: dict[str, Any]) -> None:
        """Stream live log entries to the client."""
        import asyncio.queues  # noqa: PLC0415
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        try:
            for _ in range(100):
                entry = await asyncio.wait_for(queue.get(), timeout=30.0)
                await ws.send_json({"type": "log", "data": entry})
        except asyncio.TimeoutError:
            await ws.send_json({"type": "done"})

    def cancel_stream(self, client_id: str) -> None:
        task = self._active_streams.pop(client_id, None)
        if task:
            task.cancel()
