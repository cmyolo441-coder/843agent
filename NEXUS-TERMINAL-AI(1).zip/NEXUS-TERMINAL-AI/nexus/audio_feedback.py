"""Terminal bell + simple beep sequences for non-visual feedback."""
from __future__ import annotations

import asyncio
import sys


def bell() -> None:
    """Emit a single terminal BEL."""
    sys.stdout.write("\a")
    sys.stdout.flush()


async def beep_sequence(pattern: str = "...---...", *, dot: float = 0.08, dash: float = 0.24, gap: float = 0.1) -> None:
    """Play a morse-like beep pattern.

    `pattern` accepts ``.`` (dot), ``-`` (dash), and space (longer gap).
    """
    for ch in pattern:
        if ch == ".":
            bell()
            await asyncio.sleep(dot)
        elif ch == "-":
            bell()
            await asyncio.sleep(dash)
        elif ch == " ":
            await asyncio.sleep(gap * 3)
        await asyncio.sleep(gap)


SUCCESS = ".-."
WARNING = "--"
ERROR = "..."


async def play(kind: str) -> None:
    """Play one of the named feedback sequences (success, warning, error)."""
    patterns = {"success": SUCCESS, "warning": WARNING, "error": ERROR}
    await beep_sequence(patterns.get(kind, "."))
