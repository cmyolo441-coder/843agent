"""Three-state circuit breaker: closed → open → half-open → closed."""
from __future__ import annotations

import asyncio
import logging
import time
from enum import Enum
from typing import Any, Awaitable, Callable, TypeVar

from nexus.exceptions import NexusError

T = TypeVar("T")
_log = logging.getLogger(__name__)


class CircuitOpen(NexusError):
    """Raised when the breaker is open and a call is attempted."""


class State(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Fails fast after `threshold` consecutive errors; re-checks after `cooldown`."""

    def __init__(self, *, threshold: int = 5, cooldown: float = 30.0, half_open_max: int = 1) -> None:
        self.threshold = threshold
        self.cooldown = cooldown
        self.half_open_max = half_open_max
        self.state = State.CLOSED
        self.failures = 0
        self.opened_at: float | None = None
        self._half_open_inflight = 0
        self._lock = asyncio.Lock()

    def _maybe_recover(self) -> None:
        if self.state is State.OPEN and self.opened_at is not None \
                and time.monotonic() - self.opened_at >= self.cooldown:
            self.state = State.HALF_OPEN
            self._half_open_inflight = 0
            _log.info("breaker half-open")

    async def call(self, fn: Callable[..., Awaitable[T]], /, *args: Any, **kwargs: Any) -> T:
        async with self._lock:
            self._maybe_recover()
            if self.state is State.OPEN:
                raise CircuitOpen("circuit breaker is open")
            if self.state is State.HALF_OPEN and self._half_open_inflight >= self.half_open_max:
                raise CircuitOpen("circuit breaker is half-open and saturated")
            if self.state is State.HALF_OPEN:
                self._half_open_inflight += 1

        try:
            result = await fn(*args, **kwargs)
        except Exception:
            await self._on_failure()
            raise
        else:
            await self._on_success()
            return result

    async def _on_success(self) -> None:
        async with self._lock:
            self.failures = 0
            if self.state is State.HALF_OPEN:
                self.state = State.CLOSED
                self.opened_at = None
                _log.info("breaker closed")
            elif self.state is State.OPEN:
                self.state = State.CLOSED

    async def _on_failure(self) -> None:
        async with self._lock:
            self.failures += 1
            if self.state is State.HALF_OPEN or self.failures >= self.threshold:
                self.state = State.OPEN
                self.opened_at = time.monotonic()
                _log.warning("breaker tripped (failures=%d)", self.failures)
