"""Minimal ANSI color builder. Standalone — no rich dependency required."""
from __future__ import annotations

import os
import sys
from enum import IntEnum


class Fg(IntEnum):
    BLACK = 30
    RED = 31
    GREEN = 32
    YELLOW = 33
    BLUE = 34
    MAGENTA = 35
    CYAN = 36
    WHITE = 37
    DEFAULT = 39


class Style(IntEnum):
    RESET = 0
    BOLD = 1
    DIM = 2
    ITALIC = 3
    UNDERLINE = 4
    REVERSE = 7


_RESET = "\x1b[0m"


def supports_color(stream: Any = sys.stdout) -> bool:  # type: ignore[type-arg]
    """Heuristic: respect NO_COLOR + isatty."""
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    try:
        return stream.isatty()
    except Exception:
        return False


def paint(text: str, fg: Fg | None = None, *styles: Style) -> str:
    """Wrap `text` in ANSI escape codes."""
    if not supports_color():
        return text
    codes: list[str] = []
    if fg is not None:
        codes.append(str(int(fg)))
    codes.extend(str(int(s)) for s in styles)
    if not codes:
        return text
    return f"\x1b[{';'.join(codes)}m{text}{_RESET}"


def red(t: str) -> str: return paint(t, Fg.RED)
def green(t: str) -> str: return paint(t, Fg.GREEN)
def yellow(t: str) -> str: return paint(t, Fg.YELLOW)
def cyan(t: str) -> str: return paint(t, Fg.CYAN)
def bold(t: str) -> str: return paint(t, None, Style.BOLD)
