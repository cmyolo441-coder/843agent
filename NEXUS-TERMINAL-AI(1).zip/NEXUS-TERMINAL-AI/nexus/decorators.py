"""Reusable decorators: timing, retry, deprecated, singleton, cached, validate_args."""
from __future__ import annotations

import asyncio
import functools
import inspect
import logging
import random
import time
import warnings
from typing import Any, Callable, TypeVar

F = TypeVar("F", bound=Callable[..., Any])
_log = logging.getLogger(__name__)


def timing(func: F) -> F:
    """Log the wall-clock duration of a function (sync or async)."""
    if asyncio.iscoroutinefunction(func):
        @functools.wraps(func)
        async def awrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.perf_counter()
            try:
                return await func(*args, **kwargs)
            finally:
                _log.debug("%s took %.3fs", func.__qualname__, time.perf_counter() - start)
        return awrapper  # type: ignore[return-value]

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start = time.perf_counter()
        try:
            return func(*args, **kwargs)
        finally:
            _log.debug("%s took %.3fs", func.__qualname__, time.perf_counter() - start)
    return wrapper  # type: ignore[return-value]


def retry(times: int = 3, base: float = 0.2, exc: type[BaseException] = Exception) -> Callable[[F], F]:
    """Retry with exponential backoff + jitter."""
    def deco(func: F) -> F:
        @functools.wraps(func)
        async def awrapper(*args: Any, **kwargs: Any) -> Any:
            for attempt in range(1, times + 1):
                try:
                    return await func(*args, **kwargs)
                except exc:
                    if attempt == times:
                        raise
                    delay = base * (2 ** (attempt - 1)) + random.random() * base
                    _log.warning("retry %d/%d for %s in %.2fs", attempt, times, func.__qualname__, delay)
                    await asyncio.sleep(delay)
        return awrapper  # type: ignore[return-value]
    return deco


def deprecated(reason: str = "") -> Callable[[F], F]:
    """Emit DeprecationWarning when the wrapped callable is invoked."""
    def deco(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            warnings.warn(f"{func.__qualname__} is deprecated. {reason}", DeprecationWarning, stacklevel=2)
            return func(*args, **kwargs)
        return wrapper  # type: ignore[return-value]
    return deco


def singleton_decorator(cls: type) -> type:
    """Turn a class into a single-instance class."""
    instances: dict[type, Any] = {}

    @functools.wraps(cls, updated=())
    class Wrapped(cls):  # type: ignore[misc, valid-type]
        def __new__(kls, *args: Any, **kwargs: Any) -> Any:
            if kls not in instances:
                instances[kls] = super().__new__(kls)
            return instances[kls]
    return Wrapped


def cached(maxsize: int = 128) -> Callable[[F], F]:
    """Thin wrapper around functools.lru_cache for symmetry with other decorators."""
    def deco(func: F) -> F:
        return functools.lru_cache(maxsize=maxsize)(func)  # type: ignore[return-value]
    return deco


def validate_args(**validators: Callable[[Any], bool]) -> Callable[[F], F]:
    """Validate kwargs against simple boolean predicates."""
    def deco(func: F) -> F:
        sig = inspect.signature(func)

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            bound = sig.bind_partial(*args, **kwargs)
            for name, predicate in validators.items():
                if name in bound.arguments and not predicate(bound.arguments[name]):
                    raise ValueError(f"validate_args: {name}={bound.arguments[name]!r} failed predicate")
            return func(*args, **kwargs)
        return wrapper  # type: ignore[return-value]
    return deco
