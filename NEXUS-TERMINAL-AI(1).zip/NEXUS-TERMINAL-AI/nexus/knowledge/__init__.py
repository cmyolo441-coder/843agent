"""Nexus knowledge subsystem.

Knowledge graph management: entity extraction, relation extraction, graph
traversal, reasoning, ontology management, graph embeddings, and GraphRAG.
Backends include Neo4j, ArangoDB, NetworkX, iGraph, SPARQL, JanusGraph, and
Memgraph. Domain ontologies cover software, medical, legal, finance, and
scientific domains.
"""
from __future__ import annotations

from .knowledge_manager import KnowledgeManager
from .graph_engine import GraphEngine
from .entity_extractor import EntityExtractor
from .relation_extractor import RelationExtractor
from .ontology_manager import OntologyManager
from .schema_builder import SchemaBuilder
from .reasoner import Reasoner
from .path_finder import PathFinder
from .community_detector import CommunityDetector
from .centrality import CentralityAnalyzer
from .anomaly_detector import GraphAnomalyDetector
from .temporal_graph import TemporalGraph
from .graph_embedding import GraphEmbedding
from .graph_rag import GraphRAG

__all__ = [
    "KnowledgeManager",
    "GraphEngine",
    "EntityExtractor",
    "RelationExtractor",
    "OntologyManager",
    "SchemaBuilder",
    "Reasoner",
    "PathFinder",
    "CommunityDetector",
    "CentralityAnalyzer",
    "GraphAnomalyDetector",
    "TemporalGraph",
    "GraphEmbedding",
    "GraphRAG",
]
