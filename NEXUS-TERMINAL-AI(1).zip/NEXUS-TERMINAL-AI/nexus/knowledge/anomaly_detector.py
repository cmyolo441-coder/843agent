"""Graph anomaly detection — identify unusual nodes, edges, or patterns."""
from __future__ import annotations

import logging
import statistics
from typing import Any

_log = logging.getLogger(__name__)


class GraphAnomalyDetector:
    """Detects anomalies in graph structure (unusual nodes/edges/patterns)."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}

    async def detect_degree_anomalies(self, graph_data: dict[str, Any], z_threshold: float = 2.0) -> list[dict[str, Any]]:
        """Find nodes with unusually high/low degree using z-scores."""
        degrees: dict[str, int] = {}
        for e in graph_data.get("edges", []):
            degrees[e["source"]] = degrees.get(e["source"], 0) + 1
            degrees[e["target"]] = degrees.get(e["target"], 0) + 1

        if len(degrees) < 3:
            return []

        values = list(degrees.values())
        mean = statistics.mean(values)
        stdev = statistics.stdev(values) if len(values) > 1 else 1.0

        anomalies: list[dict[str, Any]] = []
        for node, degree in degrees.items():
            z_score = (degree - mean) / stdev if stdev > 0 else 0.0
            if abs(z_score) > z_threshold:
                anomalies.append({
                    "node": node,
                    "degree": degree,
                    "z_score": round(z_score, 3),
                    "type": "high_degree" if z_score > 0 else "low_degree",
                })
        return anomalies

    async def detect_isolated_nodes(self, graph_data: dict[str, Any]) -> list[str]:
        """Find nodes with no edges."""
        connected: set[str] = set()
        for e in graph_data.get("edges", []):
            connected.add(e["source"])
            connected.add(e["target"])
        all_nodes = {n["name"] for n in graph_data.get("nodes", [])}
        return list(all_nodes - connected)

    async def detect_multiple_edges(self, graph_data: dict[str, Any]) -> list[dict[str, Any]]:
        """Find duplicate edges between the same node pair."""
        edge_counts: dict[tuple[str, str], int] = {}
        for e in graph_data.get("edges", []):
            key = (e["source"], e["target"])
            edge_counts[key] = edge_counts.get(key, 0) + 1
        return [
            {"source": s, "target": t, "count": c}
            for (s, t), c in edge_counts.items() if c > 1
        ]

    async def detect_hub_nodes(self, graph_data: dict[str, Any], threshold: float = 0.8) -> list[str]:
        """Find highly connected hub nodes (top threshold percentile)."""
        degrees: dict[str, int] = {}
        for e in graph_data.get("edges", []):
            degrees[e["source"]] = degrees.get(e["source"], 0) + 1
            degrees[e["target"]] = degrees.get(e["target"], 0) + 1
        if not degrees:
            return []
        max_deg = max(degrees.values())
        return [n for n, d in degrees.items() if d / max_deg >= threshold]

    async def detect_singletons(self, graph_data: dict[str, Any], min_edges: int = 2) -> list[str]:
        """Find nodes with fewer than min_edges connections."""
        degrees: dict[str, int] = {}
        for e in graph_data.get("edges", []):
            degrees[e["source"]] = degrees.get(e["source"], 0) + 1
            degrees[e["target"]] = degrees.get(e["target"], 0) + 1
        return [n for n, d in degrees.items() if d < min_edges]
