"""Knowledge graph backends — database-specific adapters."""
from __future__ import annotations

from .neo4j import Neo4jBackend
from .arangodb import ArangoDBBackend
from .networkx import NetworkXBackend
from .igraph import IGraphBackend
from .sparql import SPARQLBackend
from .janusgraph import JanusGraphBackend
from .memgraph import MemgraphBackend

__all__ = [
    "Neo4jBackend",
    "ArangoDBBackend",
    "NetworkXBackend",
    "IGraphBackend",
    "SPARQLBackend",
    "JanusGraphBackend",
    "MemgraphBackend",
]
