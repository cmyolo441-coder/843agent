"""ArangoDB backend — multi-model graph database adapter."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

try:
    from arango import ArangoClient
except ImportError:
    ArangoClient = None  # type: ignore[assignment]

_log = logging.getLogger(__name__)


class ArangoDBBackend:
    """ArangoDB graph database backend."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._hosts = self.config.get("hosts", "http://localhost:8529")
        self._username = self.config.get("username", "root")
        self._password = self.config.get("password", "")
        self._db_name = self.config.get("database", "nexus")
        self._client: Any = None
        self._db: Any = None

    async def connect(self) -> None:
        if ArangoClient is None:
            raise RuntimeError("python-arango not installed — run `pip install python-arango`")
        self._client = ArangoClient(hosts=self._hosts)
        sys_db = self._client.db("_system", username=self._username, password=self._password)
        if not sys_db.has_database(self._db_name):
            sys_db.create_database(self._db_name)
        self._db = self._client.db(self._db_name, username=self._username, password=self._password)
        _log.info("Connected to ArangoDB at %s", self._hosts)

    async def disconnect(self) -> None:
        self._client = None

    async def add_entity(self, entity: Entity) -> str:
        col = self._db.collection("entities") if self._db.has_collection("entities") else self._db.create_collection("entities")
        meta = col.insert({"_key": entity.name, "type": entity.type, **entity.properties})
        return meta["_key"]

    async def add_relation(self, relation: Relation) -> str:
        edge_col = self._db.collection("relations") if self._db.has_collection("relations") else self._db.create_collection("relations", edge=True)
        meta = edge_col.insert({
            "_from": f"entities/{relation.source}",
            "_to": f"entities/{relation.target}",
            "type": relation.type,
            "weight": relation.weight,
            **relation.properties,
        })
        return meta["_key"]

    async def get_entity(self, name: str) -> Entity | None:
        try:
            doc = self._db.collection("entities").get(name)
            if doc:
                return Entity(name=doc["_key"], type=doc.get("type", "unknown"), properties={k: v for k, v in doc.items() if k.startswith("_")})
        except Exception:
            pass
        return None

    async def get_neighbors(self, entity_name: str, depth: int = 1) -> list[dict[str, Any]]:
        aql = "FOR v, e IN 1..@depth ANY @start GRAPH 'knowledge_graph' RETURN {name: v._key, relation: e.type, type: v.type}"
        cursor = self._db.aql.execute(aql, bind_vars={"start": f"entities/{entity_name}", "depth": depth})
        return [dict(r) for r in cursor]

    async def get_subgraph(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        aql = "FOR v, e IN 1..@depth ANY @start GRAPH 'knowledge_graph' RETURN DISTINCT {name: v._key, type: v.type}"
        cursor = self._db.aql.execute(aql, bind_vars={"start": f"entities/{entity_name}", "depth": depth})
        nodes = [dict(r) for r in cursor]
        return {"nodes": nodes, "edges": []}

    async def search_entities(self, query: str, limit: int = 20) -> list[Entity]:
        aql = "FOR doc IN entities FILTER CONTAINS(doc._key, @query) LIMIT @limit RETURN doc"
        cursor = self._db.aql.execute(aql, bind_vars={"query": query, "limit": limit})
        return [Entity(name=r["_key"], type=r.get("type", "unknown")) for r in cursor]
