"""igraph backend — in-memory graph using the igraph library."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

try:
    import igraph as ig
except ImportError:
    ig = None  # type: ignore[assignment]

_log = logging.getLogger(__name__)


class IGraphBackend:
    """In-memory graph backend using the igraph library."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._graph: Any = None

    async def connect(self) -> None:
        if ig is None:
            raise RuntimeError("igraph not installed — run `pip install igraph`")
        self._graph = ig.Graph(directed=True)
        _log.info("igraph backend initialised")

    async def disconnect(self) -> None:
        self._graph = None

    async def add_entity(self, entity: Entity) -> str:
        self._graph.add_vertex(entity.name, type=entity.type, **entity.properties)
        return entity.name

    async def add_relation(self, relation: Relation) -> str:
        source_id = self._graph.vs.find(name=relation.source).index
        target_id = self._graph.vs.find(name=relation.target).index
        self._graph.add_edge(source_id, target_id, type=relation.type, weight=relation.weight)
        return f"{relation.source}->{relation.target}"

    async def get_entity(self, name: str) -> Entity | None:
        try:
            v = self._graph.vs.find(name=name)
            return Entity(name=v["name"], type=v.get("type", "unknown"), properties={k: v[k] for k in v.attribute_names() if k not in ("name", "type")})
        except (ValueError, KeyError):
            return None

    async def get_neighbors(self, entity_name: str, depth: int = 1) -> list[dict[str, Any]]:
        try:
            v = self._graph.vs.find(name=entity_name)
            neighbors = self._graph.neighbors(v, mode="all")
            result: list[dict[str, Any]] = []
            for n in neighbors:
                nv = self._graph.vs[n]
                edges = self._graph.es.select(_source=v.index, _target=n) or self._graph.es.select(_source=n, _target=v.index)
                rel = edges[0]["type"] if edges else "related"
                result.append({"name": nv["name"], "relation": rel, "type": nv.get("type", "entity")})
            return result
        except (ValueError, KeyError):
            return []

    async def get_subgraph(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        try:
            v = self._graph.vs.find(name=entity_name)
            neighborhood = self._graph.neighborhood(v, order=depth, mode="all")
            sub = self._graph.subgraph(neighborhood)
            nodes = [{"name": v["name"], "type": v.get("type", "entity")} for v in sub.vs]
            edges = [{"source": sub.vs[e.source]["name"], "target": sub.vs[e.target]["name"], "type": e.get("type", "related")} for e in sub.es]
            return {"nodes": nodes, "edges": edges}
        except (ValueError, KeyError):
            return {"nodes": [], "edges": []}

    async def search_entities(self, query: str, limit: int = 20) -> list[Entity]:
        if self._graph is None:
            return []
        results: list[Entity] = []
        for v in self._graph.vs:
            if query.lower() in v["name"].lower():
                results.append(Entity(name=v["name"], type=v.get("type", "unknown")))
                if len(results) >= limit:
                    break
        return results
