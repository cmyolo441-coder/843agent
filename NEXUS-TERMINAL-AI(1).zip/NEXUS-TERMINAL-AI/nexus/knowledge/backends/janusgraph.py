"""JanusGraph backend — distributed graph database via Gremlin."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

try:
    from gremlin_python.driver import client, serializer
except ImportError:
    client = None  # type: ignore[assignment]
    serializer = None  # type: ignore[assignment]

_log = logging.getLogger(__name__)


class JanusGraphBackend:
    """JanusGraph backend using the Gremlin query language."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._url = self.config.get("url", "ws://localhost:8182/gremlin")
        self._client: Any = None

    async def connect(self) -> None:
        if client is None:
            raise RuntimeError("gremlinpython not installed — run `pip install gremlinpython`")
        self._client = client.Client(self._url, "g", message_serializer=serializer.GraphSONSerializersV3d0())
        _log.info("Connected to JanusGraph at %s", self._url)

    async def disconnect(self) -> None:
        if self._client:
            self._client.close()

    async def add_entity(self, entity: Entity) -> str:
        query = f"g.V().has('name', '{entity.name}').fold().coalesce(unfold(), addV('entity').property('name', '{entity.name}').property('type', '{entity.type}'))"
        result = self._client.submit(query)
        return entity.name

    async def add_relation(self, relation: Relation) -> str:
        query = (
            f"g.V().has('name', '{relation.source}').as('s').V().has('name', '{relation.target}').as('t')"
            f".addE('{relation.type}').from('s').to('t').property('weight', {relation.weight})"
        )
        result = self._client.submit(query)
        return f"{relation.source}->{relation.target}"

    async def get_entity(self, name: str) -> Entity | None:
        query = f"g.V().has('name', '{name}').elementMap()"
        result = self._client.submit(query)
        for item in result:
            props = {k: v for k, v in item.items() if isinstance(k, str)}
            return Entity(name=props.get("name", name), type=props.get("type", "unknown"), properties=props)
        return None

    async def get_neighbors(self, entity_name: str, depth: int = 1) -> list[dict[str, Any]]:
        query = f"g.V().has('name', '{entity_name}').bothE().otherV().elementMap()"
        result = self._client.submit(query)
        return [{"name": r.get("name", ""), "relation": "", "type": r.get("type", "entity")} for r in result]

    async def get_subgraph(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        return {"nodes": [], "edges": []}

    async def search_entities(self, query: str, limit: int = 20) -> list[Entity]:
        q = f"g.V().hasLabel('entity').has('name', containing('{query}')).limit({limit}).elementMap()"
        result = self._client.submit(q)
        return [Entity(name=r.get("name", ""), type=r.get("type", "unknown")) for r in result]
