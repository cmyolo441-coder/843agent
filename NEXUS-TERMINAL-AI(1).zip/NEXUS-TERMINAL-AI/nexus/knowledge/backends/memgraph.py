"""Memgraph backend — in-memory graph database via Bolt protocol."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

try:
    import mgclient
except ImportError:
    mgclient = None  # type: ignore[assignment]

_log = logging.getLogger(__name__)


class MemgraphBackend:
    """Memgraph graph database backend using mgclient."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._host = self.config.get("host", "localhost")
        self._port = self.config.get("port", 7687)
        self._connection: Any = None

    async def connect(self) -> None:
        if mgclient is None:
            raise RuntimeError("mgclient not installed — run `pip install mgclient`")
        self._connection = mgclient.connect(host=self._host, port=self._port)
        self._connection.autocommit = True
        _log.info("Connected to Memgraph at %s:%d", self._host, self._port)

    async def disconnect(self) -> None:
        if self._connection:
            self._connection.close()

    async def add_entity(self, entity: Entity) -> str:
        cursor = self._connection.cursor()
        cursor.execute(
            "MERGE (n:Entity {name: %s}) SET n.type = %s, n += %s RETURN n.name",
            (entity.name, entity.type, entity.properties),
        )
        result = cursor.fetchone()
        return result[0]

    async def add_relation(self, relation: Relation) -> str:
        cursor = self._connection.cursor()
        cursor.execute(
            "MATCH (s:Entity {name: %s}) MATCH (t:Entity {name: %s}) "
            "MERGE (s)-[r:RELATED {type: %s}]->(t) SET r.weight = %s RETURN id(r)",
            (relation.source, relation.target, relation.type, relation.weight),
        )
        result = cursor.fetchone()
        return str(result[0]) if result else ""

    async def get_entity(self, name: str) -> Entity | None:
        cursor = self._connection.cursor()
        cursor.execute("MATCH (n:Entity {name: %s}) RETURN n", (name,))
        result = cursor.fetchone()
        if result:
            node = result[0]
            return Entity(name=node.properties.get("name", name), type=node.properties.get("type", "unknown"), properties=dict(node.properties))
        return None

    async def get_neighbors(self, entity_name: str, depth: int = 1) -> list[dict[str, Any]]:
        cursor = self._connection.cursor()
        cursor.execute(
            "MATCH (s:Entity {name: %s})-[r]-(t) RETURN t.name, r.type, t.type LIMIT 100",
            (entity_name,),
        )
        return [{"name": row[0], "relation": row[1], "type": row[2]} for row in cursor.fetchall()]

    async def get_subgraph(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        cursor = self._connection.cursor()
        cursor.execute(
            "MATCH (s:Entity {name: %s})-[*1..%d]-(t) RETURN DISTINCT t.name, t.type LIMIT 200",
            (entity_name, depth),
        )
        nodes = [{"name": row[0], "type": row[1]} for row in cursor.fetchall()]
        return {"nodes": nodes, "edges": []}

    async def search_entities(self, query: str, limit: int = 20) -> list[Entity]:
        cursor = self._connection.cursor()
        cursor.execute(
            "MATCH (n:Entity) WHERE n.name CONTAINS %s RETURN n.name, n.type LIMIT %d",
            (query, limit),
        )
        return [Entity(name=row[0], type=row[1] or "unknown") for row in cursor.fetchall()]
