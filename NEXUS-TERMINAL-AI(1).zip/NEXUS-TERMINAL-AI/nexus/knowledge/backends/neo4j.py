"""Neo4j backend — graph database adapter using the Bolt protocol."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

try:
    from neo4j import AsyncGraphDatabase, AsyncDriver
except ImportError:
    AsyncGraphDatabase = None  # type: ignore[assignment]
    AsyncDriver = None  # type: ignore[assignment]

_log = logging.getLogger(__name__)


class Neo4jBackend:
    """Neo4j graph database backend via async Bolt driver."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._uri = self.config.get("uri", "bolt://localhost:7687")
        self._user = self.config.get("user", "neo4j")
        self._password = self.config.get("password", "password")
        self._driver: Any = None

    async def connect(self) -> None:
        if AsyncGraphDatabase is None:
            raise RuntimeError("neo4j package not installed — run `pip install neo4j`")
        self._driver = AsyncGraphDatabase.driver(self._uri, auth=(self._user, self._password))
        await self._driver.verify_connectivity()
        _log.info("Connected to Neo4j at %s", self._uri)

    async def disconnect(self) -> None:
        if self._driver:
            await self._driver.close()

    async def add_entity(self, entity: Entity) -> str:
        async with self._driver.session() as session:
            result = await session.run(
                "MERGE (n:Entity {name: $name}) SET n.type = $type, n += $props RETURN n.name",
                name=entity.name, type=entity.type, props=entity.properties,
            )
            record = await result.single()
            return record[0]

    async def add_relation(self, relation: Relation) -> str:
        async with self._driver.session() as session:
            result = await session.run(
                "MATCH (s:Entity {name: $source}) MATCH (t:Entity {name: $target}) "
                "MERGE (s)-[r:RELATED {type: $rel_type}]->(t) SET r.weight = $weight RETURN id(r)",
                source=relation.source, target=relation.target, rel_type=relation.type, weight=relation.weight,
            )
            record = await result.single()
            return str(record[0]) if record else ""

    async def get_entity(self, name: str) -> Entity | None:
        async with self._driver.session() as session:
            result = await session.run("MATCH (n:Entity {name: $name}) RETURN n", name=name)
            record = await result.single()
            if record:
                node = record[0]
                return Entity(name=node["name"], type=node.get("type", "unknown"), properties=dict(node))
            return None

    async def get_neighbors(self, entity_name: str, depth: int = 1) -> list[dict[str, Any]]:
        async with self._driver.session() as session:
            result = await session.run(
                "MATCH (s:Entity {name: $name})-[r]-(t) RETURN t.name AS name, r.type AS relation, t.type AS type LIMIT 100",
                name=entity_name,
            )
            return [{"name": r["name"], "relation": r["relation"], "type": r["type"]} async for r in result]

    async def get_subgraph(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        async with self._driver.session() as session:
            result = await session.run(
                "MATCH (s:Entity {name: $name})-[*1..$depth]-(t) RETURN DISTINCT t.name AS name, "
                "t.type AS type, labels(t) AS labels LIMIT 200",
                name=entity_name, depth=depth,
            )
            nodes = [{"name": r["name"], "type": r["type"]} async for r in result]
            return {"nodes": nodes, "edges": []}

    async def search_entities(self, query: str, limit: int = 20) -> list[Entity]:
        async with self._driver.session() as session:
            result = await session.run(
                "MATCH (n:Entity) WHERE n.name CONTAINS $query RETURN n.name AS name, n.type AS type LIMIT $limit",
                query=query, limit=limit,
            )
            return [Entity(name=r["name"], type=r.get("type", "unknown")) async for r in result]
