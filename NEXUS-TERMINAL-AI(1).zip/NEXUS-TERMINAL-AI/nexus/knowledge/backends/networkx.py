"""NetworkX backend — in-memory graph backend using NetworkX."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

try:
    import networkx as nx
except ImportError:
    nx = None  # type: ignore[assignment]

_log = logging.getLogger(__name__)


class NetworkXBackend:
    """In-memory graph backend using NetworkX."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._graph: Any = None

    async def connect(self) -> None:
        if nx is None:
            raise RuntimeError("NetworkX not installed — run `pip install networkx`")
        self._graph = nx.MultiDiGraph()
        _log.info("NetworkX backend initialised")

    async def disconnect(self) -> None:
        self._graph = None

    async def add_entity(self, entity: Entity) -> str:
        self._graph.add_node(entity.name, type=entity.type, **entity.properties)
        return entity.name

    async def add_relation(self, relation: Relation) -> str:
        rid = f"{relation.source}->{relation.target}[{relation.type}]"
        self._graph.add_edge(relation.source, relation.target, key=relation.type, type=relation.type, weight=relation.weight, **relation.properties)
        return rid

    async def get_entity(self, name: str) -> Entity | None:
        if name not in self._graph:
            return None
        data = self._graph.nodes[name]
        return Entity(name=name, type=data.get("type", "unknown"), properties={k: v for k, v in data.items() if k != "type"})

    async def get_neighbors(self, entity_name: str, depth: int = 1) -> list[dict[str, Any]]:
        if self._graph is None or entity_name not in self._graph:
            return []
        neighbors: list[dict[str, Any]] = []
        for _, target, data in self._graph.edges(entity_name, data=True):
            neighbors.append({"name": target, "relation": data.get("type", "related"), "type": self._graph.nodes[target].get("type", "entity")})
        for source, _, data in self._graph.in_edges(entity_name, data=True):
            neighbors.append({"name": source, "relation": data.get("type", "related"), "type": self._graph.nodes[source].get("type", "entity")})
        return neighbors

    async def get_subgraph(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        if self._graph is None:
            return {"nodes": [], "edges": []}
        visited: set[str] = set()
        frontier = {entity_name}
        for _ in range(depth):
            new_frontier: set[str] = set()
            for node in frontier:
                if node in self._graph:
                    visited.add(node)
                    for _, target in self._graph.edges(node):
                        if target not in visited:
                            new_frontier.add(target)
                    for source in self._graph.predecessors(node):
                        if source not in visited:
                            new_frontier.add(source)
            frontier = new_frontier
        visited.update(frontier)
        nodes = [{"name": n, "type": self._graph.nodes[n].get("type", "entity")} for n in visited]
        edges = [
            {"source": u, "target": v, "type": d.get("type", "related")}
            for u, v, d in self._graph.edges(data=True) if u in visited and v in visited
        ]
        return {"nodes": nodes, "edges": edges}

    async def search_entities(self, query: str, limit: int = 20) -> list[Entity]:
        if self._graph is None:
            return []
        results: list[Entity] = []
        query_lower = query.lower()
        for node, data in self._graph.nodes(data=True):
            if query_lower in node.lower() or any(query_lower in str(v).lower() for v in data.values()):
                results.append(Entity(name=node, type=data.get("type", "unknown")))
                if len(results) >= limit:
                    break
        return results
