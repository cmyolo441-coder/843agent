"""SPARQL backend — RDF graph query via SPARQL endpoint."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

try:
    import httpx
except ImportError:
    httpx = None  # type: ignore[assignment]

_log = logging.getLogger(__name__)


class SPARQLBackend:
    """RDF graph backend using SPARQL protocol over HTTP."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._endpoint = self.config.get("endpoint", "http://localhost:8890/sparql")
        self._update_endpoint = self.config.get("update_endpoint", "http://localhost:8890/sparql-auth")
        self._prefixes = self.config.get("prefixes", {
            "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
            "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
            "nexus": "http://nexus.ai/ontology/",
        })

    async def connect(self) -> None:
        if httpx is None:
            raise RuntimeError("httpx not installed — run `pip install httpx`")
        self._client = httpx.AsyncClient(timeout=30.0)
        _log.info("SPARQL backend connected to %s", self._endpoint)

    async def disconnect(self) -> None:
        if self._client:
            await self._client.aclose()

    def _prefixed(self, uri: str) -> str:
        for prefix, ns in self._prefixes.items():
            if uri.startswith(ns):
                return uri.replace(ns, f"{prefix}:")
        return uri

    async def add_entity(self, entity: Entity) -> str:
        uri = f"nexus:{entity.name.replace(' ', '_')}"
        query = f"""
        PREFIX nexus: <http://nexus.ai/ontology/>
        INSERT DATA {{
            <{uri}> rdf:type nexus:{entity.type} ;
                      rdfs:label "{entity.name}" .
        }}
        """
        await self._client.post(self._update_endpoint, data={"query": query})
        return uri

    async def add_relation(self, relation: Relation) -> str:
        s = f"nexus:{relation.source.replace(' ', '_')}"
        o = f"nexus:{relation.target.replace(' ', '_')}"
        query = f"""
        PREFIX nexus: <http://nexus.ai/ontology/>
        INSERT DATA {{
            <{s}> nexus:{relation.type} <{o}> .
        }}
        """
        await self._client.post(self._update_endpoint, data={"query": query})
        return f"{s}->{o}"

    async def get_entity(self, name: str) -> Entity | None:
        uri = f"nexus:{name.replace(' ', '_')}"
        q = f"""
        PREFIX nexus: <http://nexus.ai/ontology/>
        SELECT ?type WHERE {{ <{uri}> rdf:type ?type }}
        """
        resp = await self._client.get(self._endpoint, params={"query": q})
        if resp.status_code == 200 and "results" in resp.text:
            return Entity(name=name, type=resp.text.split("\n")[1].strip() if "\n" in resp.text else "unknown")
        return None

    async def get_neighbors(self, entity_name: str, depth: int = 1) -> list[dict[str, Any]]:
        uri = f"nexus:{entity_name.replace(' ', '_')}"
        q = f"""
        PREFIX nexus: <http://nexus.ai/ontology/>
        SELECT ?pred ?obj WHERE {{ <{uri}> ?pred ?obj }}
        """
        resp = await self._client.get(self._endpoint, params={"query": q})
        results: list[dict[str, Any]] = []
        if resp.status_code == 200:
            for line in resp.text.split("\n")[1:]:
                if line.strip():
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        results.append({"name": parts[-1], "relation": parts[0], "type": "resource"})
        return results

    async def get_subgraph(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        return {"nodes": [], "edges": []}

    async def search_entities(self, query: str, limit: int = 20) -> list[Entity]:
        q = f"""
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        SELECT ?s ?label WHERE {{
            ?s rdfs:label ?label .
            FILTER(CONTAINS(LCASE(?label), LCASE("{query}")))
        }} LIMIT {limit}
        """
        resp = await self._client.get(self._endpoint, params={"query": q})
        results: list[Entity] = []
        if resp.status_code == 200:
            for line in resp.text.split("\n")[1:]:
                if line.strip():
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        results.append(Entity(name=parts[-1].strip('"'), type="rdf_resource"))
        return results
