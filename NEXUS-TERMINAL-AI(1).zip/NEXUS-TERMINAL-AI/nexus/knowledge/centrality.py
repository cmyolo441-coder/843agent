"""Centrality analysis — degree, betweenness, eigenvector centrality."""
from __future__ import annotations

import logging
from collections import deque
from typing import Any

_log = logging.getLogger(__name__)


class CentralityAnalyzer:
    """Computes centrality metrics for entities in the knowledge graph."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}

    async def degree_centrality(self, graph_data: dict[str, Any]) -> dict[str, float]:
        nodes = {n["name"]: 0 for n in graph_data.get("nodes", [])}
        if not nodes:
            return {}
        for e in graph_data.get("edges", []):
            nodes[e["source"]] = nodes.get(e["source"], 0) + 1
            nodes[e["target"]] = nodes.get(e["target"], 0) + 1
        max_degree = max(nodes.values()) if nodes else 1
        return {name: deg / max_degree for name, deg in nodes.items()}

    async def betweenness_centrality(self, graph_data: dict[str, Any]) -> dict[str, float]:
        nodes = [n["name"] for n in graph_data.get("nodes", [])]
        edges = graph_data.get("edges", [])
        adj: dict[str, list[str]] = {n: [] for n in nodes}
        for e in edges:
            adj.setdefault(e["source"], []).append(e["target"])
            adj.setdefault(e["target"], []).append(e["source"])

        centrality: dict[str, float] = {n: 0.0 for n in nodes}
        for s in nodes:
            stack: list[str] = []
            pred: dict[str, list[str]] = {n: [] for n in nodes}
            sigma: dict[str, float] = {n: 0.0 for n in nodes}
            dist: dict[str, float] = {n: -1.0 for n in nodes}
            sigma[s] = 1.0
            dist[s] = 0.0
            q: deque[str] = deque([s])

            while q:
                v = q.popleft()
                stack.append(v)
                for w in adj.get(v, []):
                    if dist[w] < 0:
                        q.append(w)
                        dist[w] = dist[v] + 1
                    if dist[w] == dist[v] + 1:
                        sigma[w] += sigma[v]
                        pred[w].append(v)

            delta: dict[str, float] = {n: 0.0 for n in nodes}
            while stack:
                w = stack.pop()
                for v in pred.get(w, []):
                    delta[v] += (sigma[v] / sigma[w]) * (1.0 + delta[w])
                if w != s:
                    centrality[w] += delta[w]

        n = len(nodes)
        if n > 2:
            for node in centrality:
                centrality[node] /= (n - 1) * (n - 2)
            max_val = max(centrality.values()) if centrality else 1
            if max_val > 0:
                for node in centrality:
                    centrality[node] /= max_val
        return centrality

    async def eigenvector_centrality(self, graph_data: dict[str, Any], iterations: int = 100) -> dict[str, float]:
        nodes = [n["name"] for n in graph_data.get("nodes", [])]
        edges = graph_data.get("edges", [])
        adj: dict[str, list[str]] = {n: [] for n in nodes}
        for e in edges:
            adj.setdefault(e["source"], []).append(e["target"])
            adj.setdefault(e["target"], []).append(e["source"])

        centrality: dict[str, float] = {n: 1.0 for n in nodes}
        for _ in range(iterations):
            new: dict[str, float] = {n: 0.0 for n in nodes}
            for node in nodes:
                for neighbor in adj.get(node, []):
                    new[node] += centrality[neighbor]
            norm = sum(v * v for v in new.values()) ** 0.5 or 1.0
            for node in nodes:
                centrality[node] = new[node] / norm
        return centrality
