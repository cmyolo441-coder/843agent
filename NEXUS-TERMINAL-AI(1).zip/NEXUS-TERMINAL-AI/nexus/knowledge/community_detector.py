"""Community detector — detect communities/clusters in knowledge graphs."""
from __future__ import annotations

import logging
from typing import Any

_log = logging.getLogger(__name__)


class CommunityDetector:
    """Detects communities in graph data using label propagation and clustering."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}

    async def detect(self, graph_data: dict[str, Any]) -> dict[str, list[str]]:
        """Detect communities using label propagation."""
        nodes = {n["name"]: n for n in graph_data.get("nodes", [])}
        edges = graph_data.get("edges", [])

        labels: dict[str, str] = {name: name for name in nodes}
        adj: dict[str, list[str]] = {name: [] for name in nodes}
        for e in edges:
            adj.setdefault(e["source"], []).append(e["target"])
            adj.setdefault(e["target"], []).append(e["source"])

        for _ in range(10):
            for node in nodes:
                neighbor_labels: dict[str, int] = {}
                for neighbor in adj.get(node, []):
                    nl = labels.get(neighbor, node)
                    neighbor_labels[nl] = neighbor_labels.get(nl, 0) + 1
                if neighbor_labels:
                    labels[node] = max(neighbor_labels, key=neighbor_labels.get)

        communities: dict[str, list[str]] = {}
        for node, label in labels.items():
            communities.setdefault(label, []).append(node)

        _log.info("Detected %d communities", len(communities))
        return communities

    async def detect_louvain(self, graph_data: dict[str, Any]) -> dict[str, list[str]]:
        """Community detection using modularity optimization (simplified)."""
        try:
            import networkx as nx
            from networkx.algorithms.community import louvain_communities

            G = nx.Graph()
            for n in graph_data.get("nodes", []):
                G.add_node(n["name"])
            for e in graph_data.get("edges", []):
                G.add_edge(e["source"], e["target"], weight=e.get("weight", 1.0))

            communities = louvain_communities(G)
            result: dict[str, list[str]] = {}
            for i, comm in enumerate(communities):
                result[f"community_{i}"] = list(comm)
            return result
        except (ImportError, ValueError) as exc:
            _log.warning("Louvain detection failed: %s", exc)
            return await self.detect(graph_data)

    async def get_community_stats(self, communities: dict[str, list[str]]) -> list[dict[str, Any]]:
        stats: list[dict[str, Any]] = []
        for label, members in communities.items():
            stats.append({"label": label, "size": len(members), "members": members[:10]})
        return sorted(stats, key=lambda x: x["size"], reverse=True)
