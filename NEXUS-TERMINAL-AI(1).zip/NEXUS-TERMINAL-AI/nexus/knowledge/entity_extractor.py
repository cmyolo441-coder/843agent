"""Entity extractor — extract named entities from unstructured text."""
from __future__ import annotations

import logging
import re
from typing import Any

from nexus.knowledge.graph_engine import Entity

_log = logging.getLogger(__name__)


class EntityExtractor:
    """Extracts named entities from text using pattern matching and heuristics."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._patterns: dict[str, list[re.Pattern]] = {
            "PERSON": [re.compile(r"\b[A-Z][a-z]+ [A-Z][a-z]+\b")],
            "ORGANIZATION": [re.compile(r"\b[A-Z][a-zA-Z]+(?: [A-Z][a-zA-Z]+)*(?: Inc| Corp| LLC| Ltd| GmbH| SA| PLC)\b")],
            "LOCATION": [re.compile(r"\b(?:in|at|from|to)\s+([A-Z][a-zA-Z]+(?:\s[A-Z][a-zA-Z]+)*)\b")],
            "DATE": [re.compile(r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b"), re.compile(r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \d{1,2},?\s?\d{4}\b")],
            "TECHNOLOGY": [re.compile(r"\b(Python|JavaScript|TypeScript|Rust|Go|React|Angular|Docker|Kubernetes|AWS|GCP|Azure)\b", re.I)],
            "URL": [re.compile(r"https?://[^\s]+")],
            "EMAIL": [re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")],
        }

    async def extract(self, text: str) -> list[Entity]:
        """Extract all entities from text."""
        entities: dict[str, Entity] = {}
        for etype, patterns in self._patterns.items():
            for pattern in patterns:
                for match in pattern.finditer(text):
                    value = match.group().strip()
                    if etype == "LOCATION":
                        value = match.group(1)
                    if value and len(value) > 1:
                        key = f"{value}:{etype}"
                        if key not in entities:
                            entities[key] = Entity(name=value, type=etype, properties={"extracted": True})
                            _log.debug("Extracted entity: %s (%s)", value, etype)
        return list(entities.values())

    async def extract_custom(self, text: str, pattern: str, entity_type: str) -> list[Entity]:
        """Extract entities using a custom regex pattern."""
        compiled = re.compile(pattern)
        entities: list[Entity] = []
        for match in compiled.finditer(text):
            value = match.group().strip()
            if value:
                entities.append(Entity(name=value, type=entity_type))
        return entities
