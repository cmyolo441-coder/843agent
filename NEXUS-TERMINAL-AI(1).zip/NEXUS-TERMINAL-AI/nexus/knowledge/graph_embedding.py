"""Graph embedding — generate vector embeddings for graph entities."""
from __future__ import annotations

import logging
import random
from typing import Any

_log = logging.getLogger(__name__)


class GraphEmbedding:
    """Generates vector embeddings for graph entities using random walks."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._dimensions = self.config.get("dimensions", 128)
        self._walk_length = self.config.get("walk_length", 20)
        self._num_walks = self.config.get("num_walks", 10)
        self._embeddings: dict[str, list[float]] = {}

    async def generate(self, graph_data: dict[str, Any]) -> dict[str, list[float]]:
        """Generate embeddings using simplified random-walk-based method."""
        nodes = [n["name"] for n in graph_data.get("nodes", [])]
        edges = graph_data.get("edges", [])
        adj: dict[str, list[str]] = {n: [] for n in nodes}
        for e in edges:
            adj.setdefault(e["source"], []).append(e["target"])
            adj.setdefault(e["target"], []).append(e["source"])

        if not nodes:
            return {}

        walks: list[list[str]] = []
        for _ in range(self._num_walks):
            random.shuffle(nodes)
            for start in nodes:
                walk = [start]
                for _ in range(self._walk_length - 1):
                    current = walk[-1]
                    neighbors = adj.get(current, [])
                    if not neighbors:
                        break
                    walk.append(random.choice(neighbors))
                walks.append(walk)

        co_occurrence: dict[str, dict[str, int]] = {n: {} for n in nodes}
        for walk in walks:
            for i, node in enumerate(walk):
                for j in range(max(0, i - 5), min(len(walk), i + 5)):
                    if i != j:
                        co_occurrence[node][walk[j]] = co_occurrence[node].get(walk[j], 0) + 1

        for node in nodes:
            embedding: list[float] = [random.gauss(0, 0.1) for _ in range(self._dimensions)]
            neighbors = co_occurrence.get(node, {})
            if neighbors:
                max_count = max(neighbors.values())
                for neighbor, count in neighbors.items():
                    if neighbor in self._embeddings:
                        for d in range(self._dimensions):
                            embedding[d] += (count / max_count) * self._embeddings[neighbor][d]
                norm = sum(v * v for v in embedding) ** 0.5 or 1.0
                embedding = [v / norm for v in embedding]
            self._embeddings[node] = embedding

        _log.info("Generated embeddings for %d nodes (dim=%d)", len(self._embeddings), self._dimensions)
        return self._embeddings

    async def similarity(self, entity_a: str, entity_b: str) -> float:
        """Compute cosine similarity between two entity embeddings."""
        emb_a = self._embeddings.get(entity_a)
        emb_b = self._embeddings.get(entity_b)
        if not emb_a or not emb_b:
            return 0.0
        dot = sum(a * b for a, b in zip(emb_a, emb_b))
        norm_a = sum(v * v for v in emb_a) ** 0.5 or 1.0
        norm_b = sum(v * v for v in emb_b) ** 0.5 or 1.0
        return dot / (norm_a * norm_b)

    async def most_similar(self, entity: str, top_k: int = 10) -> list[tuple[str, float]]:
        """Return top-k most similar entities by embedding similarity."""
        if entity not in self._embeddings:
            return []
        scores: list[tuple[str, float]] = []
        for other in self._embeddings:
            if other != entity:
                sim = await self.similarity(entity, other)
                scores.append((other, sim))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]
