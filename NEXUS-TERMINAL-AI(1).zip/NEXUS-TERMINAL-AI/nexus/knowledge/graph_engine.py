"""Graph engine — core graph operations and backend abstraction."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class Entity:
    """A node in the knowledge graph."""
    name: str
    type: str
    properties: dict[str, Any] = field(default_factory=dict)
    id: str = ""


@dataclass
class Relation:
    """An edge in the knowledge graph."""
    source: str
    target: str
    type: str
    properties: dict[str, Any] = field(default_factory=dict)
    weight: float = 1.0
    id: str = ""


class GraphEngine:
    """Core graph engine abstracting over backend databases."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._backend = self.config.get("backend", "networkx")
        self._driver: Any = None
        self._entities: dict[str, Entity] = {}
        self._relations: list[Relation] = []

    async def connect(self) -> None:
        if self._backend == "neo4j":
            from nexus.knowledge.backends.neo4j import Neo4jBackend
            self._driver = Neo4jBackend(self.config)
        elif self._backend == "arangodb":
            from nexus.knowledge.backends.arangodb import ArangoDBBackend
            self._driver = ArangoDBBackend(self.config)
        else:
            from nexus.knowledge.backends.networkx import NetworkXBackend
            self._driver = NetworkXBackend(self.config)
        await self._driver.connect()
        _log.info("GraphEngine connected (backend=%s)", self._backend)

    async def disconnect(self) -> None:
        if self._driver:
            await self._driver.disconnect()

    async def add_entity(self, entity: Entity) -> str:
        eid = await self._driver.add_entity(entity)
        self._entities[entity.name] = entity
        return eid

    async def add_entities(self, entities: list[Entity]) -> list[str]:
        return [await self.add_entity(e) for e in entities]

    async def add_relation(self, relation: Relation) -> str:
        rid = await self._driver.add_relation(relation)
        self._relations.append(relation)
        return rid

    async def add_relations(self, relations: list[Relation], source: str = "") -> list[str]:
        return [await self.add_relation(r) for r in relations]

    async def get_entity(self, name: str) -> Entity | None:
        return await self._driver.get_entity(name)

    async def get_neighbors(self, entity_name: str, depth: int = 1) -> list[dict[str, Any]]:
        return await self._driver.get_neighbors(entity_name, depth)

    async def get_subgraph(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        return await self._driver.get_subgraph(entity_name, depth)

    async def search_entities(self, query: str, limit: int = 20) -> list[Entity]:
        return await self._driver.search_entities(query, limit)

    async def count(self) -> dict[str, int]:
        return {"entities": len(self._entities), "relations": len(self._relations)}
