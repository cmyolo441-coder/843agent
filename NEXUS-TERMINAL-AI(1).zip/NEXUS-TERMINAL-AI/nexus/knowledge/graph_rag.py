"""GraphRAG — retrieval-augmented generation over knowledge graphs."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import GraphEngine

_log = logging.getLogger(__name__)


class GraphRAG:
    """Retrieves graph context and augments LLM prompts with structured knowledge."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.graph: GraphEngine | None = None

    async def set_graph(self, graph: GraphEngine) -> None:
        self.graph = graph

    async def query(self, query: str, top_k: int = 10) -> list[dict[str, Any]]:
        """Query the graph and return relevant context as structured results."""
        if self.graph is None:
            return []
        entities = await self.graph.search_entities(query, limit=top_k)
        results: list[dict[str, Any]] = []
        for entity in entities:
            neighbors = await self.graph.get_neighbors(entity.name, depth=1)
            context = {
                "entity": entity.name,
                "type": entity.type,
                "properties": entity.properties,
                "neighbors": [
                    {"name": n.get("name", ""), "relation": n.get("relation", ""), "type": n.get("type", "")}
                    for n in neighbors
                ],
            }
            results.append(context)
        _log.debug("GraphRAG returned %d results for query: %.60s", len(results), query)
        return results

    async def build_prompt_context(self, query: str, max_entities: int = 5) -> str:
        """Build a text context string from graph data for LLM augmentation."""
        results = await self.query(query, top_k=max_entities)
        if not results:
            return ""
        lines: list[str] = ["Relevant knowledge graph context:"]
        for r in results:
            lines.append(f"- {r['entity']} ({r['type']})")
            for n in r["neighbors"]:
                lines.append(f"  --[{n.get('relation', 'related_to')}]--> {n['name']} ({n.get('type', 'entity')})")
        return "\n".join(lines)

    async def hybrid_search(self, query: str, vector_results: list[dict[str, Any]], graph_weight: float = 0.3) -> list[dict[str, Any]]:
        """Combine vector search results with graph context."""
        graph_results = await self.query(query, top_k=10)
        seen: set[str] = set()
        combined: list[dict[str, Any]] = []

        for r in graph_results:
            key = r["entity"]
            if key not in seen:
                r["score"] = graph_weight
                r["source"] = "graph"
                combined.append(r)
                seen.add(key)

        for r in vector_results:
            key = r.get("entity") or r.get("id", "")
            if key in seen:
                for existing in combined:
                    if existing["entity"] == key:
                        existing["score"] = existing.get("score", 0) + (1 - graph_weight) * r.get("score", 0.5)
                        existing["sources"] = ["graph", "vector"]
                        break
            else:
                r["score"] = (1 - graph_weight) * r.get("score", 0.5)
                r["source"] = "vector"
                combined.append(r)
                seen.add(key)

        combined.sort(key=lambda x: x.get("score", 0), reverse=True)
        return combined
