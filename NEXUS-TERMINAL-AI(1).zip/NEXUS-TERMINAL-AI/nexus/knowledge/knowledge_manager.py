"""Knowledge manager — central orchestrator for the knowledge subsystem."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import GraphEngine
from nexus.knowledge.entity_extractor import EntityExtractor
from nexus.knowledge.relation_extractor import RelationExtractor
from nexus.knowledge.ontology_manager import OntologyManager
from nexus.knowledge.schema_builder import SchemaBuilder
from nexus.knowledge.reasoner import Reasoner
from nexus.knowledge.path_finder import PathFinder
from nexus.knowledge.community_detector import CommunityDetector
from nexus.knowledge.centrality import CentralityAnalyzer
from nexus.knowledge.anomaly_detector import GraphAnomalyDetector
from nexus.knowledge.temporal_graph import TemporalGraph
from nexus.knowledge.graph_embedding import GraphEmbedding
from nexus.knowledge.graph_rag import GraphRAG

_log = logging.getLogger(__name__)


class KnowledgeManager:
    """Central orchestrator that wires up all knowledge subsystems."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.graph = GraphEngine(self.config.get("graph", {}))
        self.entities = EntityExtractor(self.config.get("entities", {}))
        self.relations = RelationExtractor(self.config.get("relations", {}))
        self.ontologies = OntologyManager(self.config.get("ontologies", {}))
        self.schemas = SchemaBuilder(self.config.get("schemas", {}))
        self.reasoner = Reasoner(self.config.get("reasoner", {}))
        self.path_finder = PathFinder(self.config.get("path_finder", {}))
        self.communities = CommunityDetector(self.config.get("communities", {}))
        self.centrality = CentralityAnalyzer(self.config.get("centrality", {}))
        self.anomalies = GraphAnomalyDetector(self.config.get("anomalies", {}))
        self.temporal = TemporalGraph(self.config.get("temporal", {}))
        self.embeddings = GraphEmbedding(self.config.get("embeddings", {}))
        self.graph_rag = GraphRAG(self.config.get("graph_rag", {}))

    async def initialize(self) -> None:
        await self.graph.connect()
        await self.ontologies.load()
        _log.info("KnowledgeManager initialised")

    async def shutdown(self) -> None:
        await self.graph.disconnect()
        _log.info("KnowledgeManager shut down")

    async def ingest(self, text: str, source: str = "text") -> dict[str, Any]:
        entities = await self.entities.extract(text)
        relations = await self.relations.extract(text, entities)
        nodes = await self.graph.add_entities(entities)
        edges = await self.graph.add_relations(relations, source)
        return {"entities": len(nodes), "relations": len(edges), "source": source}

    async def query(self, query: str, top_k: int = 10) -> list[dict[str, Any]]:
        return await self.graph_rag.query(query, top_k)

    async def explore(self, entity_name: str, depth: int = 2) -> dict[str, Any]:
        subgraph = await self.graph.get_subgraph(entity_name, depth)
        paths = await self.path_finder.shortest_paths(entity_name, depth=depth)
        communities = await self.communities.detect(subgraph)
        return {"subgraph": subgraph, "paths": paths, "communities": communities}
