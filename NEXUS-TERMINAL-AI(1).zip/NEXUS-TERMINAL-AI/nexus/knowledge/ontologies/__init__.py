"""Domain ontologies for constrained entity/relation extraction."""
from __future__ import annotations
