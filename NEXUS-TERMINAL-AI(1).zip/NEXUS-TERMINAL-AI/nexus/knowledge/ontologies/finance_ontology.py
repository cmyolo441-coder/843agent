"""Finance domain ontology."""
from __future__ import annotations

ONTOLOGY = {
    "name": "finance",
    "description": "Finance domain — instruments, markets, organizations, indicators",
    "classes": [
        {"name": "FinancialInstrument", "parent": None, "properties": ["name", "ticker", "type"], "description": "A financial instrument"},
        {"name": "Company", "parent": None, "properties": ["name", "ticker", "sector", "exchange"], "description": "A publicly traded company"},
        {"name": "Market", "parent": None, "properties": ["name", "location", "type"], "description": "A financial market"},
        {"name": "Investor", "parent": None, "properties": ["name", "type", "aum"], "description": "An investor or institution"},
        {"name": "Index", "parent": None, "properties": ["name", "ticker", "constituents"], "description": "A market index"},
        {"name": "EconomicIndicator", "parent": None, "properties": ["name", "frequency", "unit"], "description": "An economic indicator"},
        {"name": "Currency", "parent": None, "properties": ["code", "name", "symbol"], "description": "A currency"},
        {"name": "Commodity", "parent": None, "properties": ["name", "ticker", "category"], "description": "A commodity"},
        {"name": "Exchange", "parent": None, "properties": ["name", "location", "mic"], "description": "A stock exchange"},
        {"name": "Fund", "parent": None, "properties": ["name", "ticker", "type", "nav"], "description": "An investment fund"},
    ],
    "relations": [
        {"name": "listed_on", "domain": "Company", "range": "Exchange", "description": "Company listed on exchange"},
        {"name": "trades_on", "domain": "FinancialInstrument", "range": "Market", "description": "Instrument trades on market"},
        {"name": "owned_by", "domain": "FinancialInstrument", "range": "Investor", "description": "Instrument owned by investor"},
        {"name": "part_of", "domain": "Company", "range": "Index", "description": "Company part of index"},
        {"name": "denominated_in", "domain": "FinancialInstrument", "range": "Currency", "description": "Instrument denominated in currency"},
        {"name": "competes_with", "domain": "Company", "range": "Company", "description": "Company competes with another company"},
        {"name": "acquired", "domain": "Company", "range": "Company", "description": "Company acquired another company"},
        {"name": "subsidiary_of", "domain": "Company", "range": "Company", "description": "Company is subsidiary of another"},
        {"name": "invests_in", "domain": "Fund", "range": "FinancialInstrument", "description": "Fund invests in instrument"},
        {"name": "measures", "domain": "EconomicIndicator", "range": "Market", "description": "Indicator measures market condition"},
    ],
}
