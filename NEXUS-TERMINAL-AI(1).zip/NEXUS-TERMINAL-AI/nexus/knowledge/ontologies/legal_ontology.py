"""Legal domain ontology."""
from __future__ import annotations

ONTOLOGY = {
    "name": "legal",
    "description": "Legal domain — laws, regulations, cases, parties, jurisdictions",
    "classes": [
        {"name": "Law", "parent": None, "properties": ["name", "jurisdiction", "year"], "description": "A statute or law"},
        {"name": "Regulation", "parent": None, "properties": ["name", "agency", "effective_date"], "description": "A government regulation"},
        {"name": "Case", "parent": None, "properties": ["name", "court", "citation", "year"], "description": "A legal case"},
        {"name": "Party", "parent": None, "properties": ["name", "role", "entity_type"], "description": "A party in a legal matter"},
        {"name": "Court", "parent": None, "properties": ["name", "level", "jurisdiction"], "description": "A court of law"},
        {"name": "Judge", "parent": None, "properties": ["name", "appointed_by"], "description": "A judge"},
        {"name": "Attorney", "parent": None, "properties": ["name", "firm", "specialty"], "description": "An attorney or lawyer"},
        {"name": "Contract", "parent": None, "properties": ["name", "type", "effective_date"], "description": "A legal contract"},
        {"name": "Jurisdiction", "parent": None, "properties": ["name", "type"], "description": "A legal jurisdiction"},
        {"name": "LegalDoctrine", "parent": None, "properties": ["name", "description"], "description": "A legal doctrine or principle"},
    ],
    "relations": [
        {"name": "governed_by", "domain": "Contract", "range": "Jurisdiction", "description": "Contract governed by jurisdiction"},
        {"name": "cited_in", "domain": "Case", "range": "Case", "description": "Case cited in another case"},
        {"name": "interpreted_by", "domain": "Law", "range": "Case", "description": "Law interpreted by case"},
        {"name": "represented_by", "domain": "Party", "range": "Attorney", "description": "Party represented by attorney"},
        {"name": "presided_by", "domain": "Case", "range": "Judge", "description": "Case presided over by judge"},
        {"name": "hears", "domain": "Court", "range": "Case", "description": "Court hears case"},
        {"name": "applies", "domain": "Court", "range": "Jurisdiction", "description": "Court applies jurisdiction"},
        {"name": "enforces", "domain": "Regulation", "range": "Agency", "description": "Regulation enforced by agency"},
        {"name": "amends", "domain": "Law", "range": "Law", "description": "Law amends another law"},
        {"name": "challenges", "domain": "Case", "range": "Law", "description": "Case challenges law/constitutionality"},
    ],
}
