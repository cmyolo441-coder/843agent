"""Medical / Healthcare domain ontology."""
from __future__ import annotations

ONTOLOGY = {
    "name": "medical",
    "description": "Medical and healthcare domain — diseases, symptoms, treatments, drugs",
    "classes": [
        {"name": "Disease", "parent": None, "properties": ["name", "icd_code", "category"], "description": "A medical disease or condition"},
        {"name": "Symptom", "parent": None, "properties": ["name", "severity"], "description": "A symptom of a disease"},
        {"name": "Treatment", "parent": None, "properties": ["name", "type"], "description": "A medical treatment"},
        {"name": "Medication", "parent": None, "properties": ["name", "dose", "route"], "description": "A pharmaceutical drug"},
        {"name": "Anatomy", "parent": None, "properties": ["name", "system"], "description": "An anatomical structure"},
        {"name": "Procedure", "parent": None, "properties": ["name", "code"], "description": "A medical procedure"},
        {"name": "Provider", "parent": None, "properties": ["name", "specialty"], "description": "A healthcare provider"},
        {"name": "Organization", "parent": None, "properties": ["name", "type"], "description": "A healthcare organization"},
        {"name": "Patient", "parent": None, "properties": ["age", "gender"], "description": "A patient"},
        {"name": "DiagnosticTest", "parent": None, "properties": ["name", "type"], "description": "A diagnostic test"},
    ],
    "relations": [
        {"name": "causes", "domain": "Disease", "range": "Symptom", "description": "Disease causes symptom"},
        {"name": "treats", "domain": "Treatment", "range": "Disease", "description": "Treatment treats disease"},
        {"name": "prescribed_for", "domain": "Medication", "range": "Disease", "description": "Medication prescribed for disease"},
        {"name": "affects", "domain": "Disease", "range": "Anatomy", "description": "Disease affects anatomical structure"},
        {"name": "diagnosed_by", "domain": "Disease", "range": "DiagnosticTest", "description": "Disease diagnosed by test"},
        {"name": "side_effect_of", "domain": "Symptom", "range": "Medication", "description": "Symptom is side effect of medication"},
        {"name": "performed_by", "domain": "Procedure", "range": "Provider", "description": "Procedure performed by provider"},
        {"name": "located_in", "domain": "Anatomy", "range": "Anatomy", "description": "Anatomical location"},
        {"name": "contraindicated_with", "domain": "Medication", "range": "Medication", "description": "Medication contraindicated with another"},
        {"name": "complication_of", "domain": "Disease", "range": "Disease", "description": "Disease is complication of another disease"},
    ],
}
