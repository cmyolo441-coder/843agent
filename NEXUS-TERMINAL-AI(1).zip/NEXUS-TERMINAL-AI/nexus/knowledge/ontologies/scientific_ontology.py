"""Scientific research domain ontology."""
from __future__ import annotations

ONTOLOGY = {
    "name": "scientific",
    "description": "Scientific research domain — papers, authors, fields, experiments",
    "classes": [
        {"name": "Paper", "parent": None, "properties": ["title", "doi", "venue", "year"], "description": "A research paper"},
        {"name": "Author", "parent": None, "properties": ["name", "affiliation", "orcid"], "description": "A research author"},
        {"name": "Field", "parent": None, "properties": ["name", "parent_field"], "description": "A scientific field of study"},
        {"name": "Venue", "parent": None, "properties": ["name", "type", "publisher"], "description": "A publication venue"},
        {"name": "Institution", "parent": None, "properties": ["name", "country", "type"], "description": "A research institution"},
        {"name": "Experiment", "parent": None, "properties": ["name", "methodology", "year"], "description": "A scientific experiment"},
        {"name": "Dataset", "parent": None, "properties": ["name", "size", "format"], "description": "A research dataset"},
        {"name": "Methodology", "parent": None, "properties": ["name", "category"], "description": "A research methodology"},
        {"name": "Grant", "parent": None, "properties": ["name", "funder", "amount"], "description": "A research grant"},
        {"name": "Result", "parent": None, "properties": ["name", "significance", "metric"], "description": "A research finding"},
    ],
    "relations": [
        {"name": "authored_by", "domain": "Paper", "range": "Author", "description": "Paper authored by researcher"},
        {"name": "published_in", "domain": "Paper", "range": "Venue", "description": "Paper published in venue"},
        {"name": "affiliated_with", "domain": "Author", "range": "Institution", "description": "Author affiliated with institution"},
        {"name": "cites", "domain": "Paper", "range": "Paper", "description": "Paper cites another paper"},
        {"name": "belongs_to", "domain": "Paper", "range": "Field", "description": "Paper belongs to field"},
        {"name": "funded_by", "domain": "Paper", "range": "Grant", "description": "Paper funded by grant"},
        {"name": "uses", "domain": "Experiment", "range": "Methodology", "description": "Experiment uses methodology"},
        {"name": "produces", "domain": "Experiment", "range": "Result", "description": "Experiment produces result"},
        {"name": "based_on", "domain": "Paper", "range": "Dataset", "description": "Paper based on dataset"},
        {"name": "collaborates_with", "domain": "Institution", "range": "Institution", "description": "Institution collaborates with another"},
    ],
}
