"""Software engineering domain ontology."""
from __future__ import annotations

ONTOLOGY = {
    "name": "software",
    "description": "Software engineering domain — languages, frameworks, tools, concepts",
    "classes": [
        {"name": "ProgrammingLanguage", "parent": None, "properties": ["name", "paradigm"], "description": "A programming language"},
        {"name": "Framework", "parent": None, "properties": ["name", "language", "type"], "description": "A software framework"},
        {"name": "Library", "parent": None, "properties": ["name", "language"], "description": "A software library"},
        {"name": "Tool", "parent": None, "properties": ["name", "category"], "description": "A developer tool"},
        {"name": "Database", "parent": None, "properties": ["name", "type"], "description": "A database system"},
        {"name": "Protocol", "parent": None, "properties": ["name", "layer"], "description": "A communication protocol"},
        {"name": "Platform", "parent": None, "properties": ["name", "provider"], "description": "A computing platform"},
        {"name": "Concept", "parent": None, "properties": ["name", "field"], "description": "A software engineering concept"},
        {"name": "Company", "parent": None, "properties": ["name", "industry"], "description": "A technology company"},
        {"name": "Person", "parent": None, "properties": ["name", "role"], "description": "A person in tech"},
    ],
    "relations": [
        {"name": "written_in", "domain": "Framework", "range": "ProgrammingLanguage", "description": "Framework is written in language"},
        {"name": "uses", "domain": "Framework", "range": "Library", "description": "Framework uses library"},
        {"name": "built_on", "domain": "Framework", "range": "Framework", "description": "Framework built on another framework"},
        {"name": "developed_by", "domain": "Tool", "range": "Company", "description": "Tool developed by company"},
        {"name": "implements", "domain": "Library", "range": "Protocol", "description": "Library implements protocol"},
        {"name": "depends_on", "domain": "Library", "range": "Library", "description": "Library depends on another library"},
        {"name": "runs_on", "domain": "Platform", "range": "Platform", "description": "Platform runs on another platform"},
        {"name": "created_by", "domain": "Concept", "range": "Person", "description": "Concept created by person"},
        {"name": "replaces", "domain": "Tool", "range": "Tool", "description": "Tool replaces another tool"},
        {"name": "related_to", "domain": "Concept", "range": "Concept", "description": "Related concepts"},
    ],
}
