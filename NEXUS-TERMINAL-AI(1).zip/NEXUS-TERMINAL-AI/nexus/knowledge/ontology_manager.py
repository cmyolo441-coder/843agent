"""Ontology manager — load, query, and manage domain ontologies."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class OntologyClass:
    """A class/concept in an ontology."""
    name: str
    parent: str | None = None
    properties: list[str] = field(default_factory=list)
    description: str = ""


@dataclass
class OntologyRelation:
    """A relation type defined in an ontology."""
    name: str
    domain: str
    range: str
    description: str = ""


class OntologyManager:
    """Manages domain ontologies for constrained entity/relation extraction."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._ontologies: dict[str, dict[str, Any]] = {}

    async def load(self) -> None:
        builtin = self.config.get("builtin_ontologies", ["software", "medical", "legal", "finance", "scientific"])
        for name in builtin:
            try:
                module = __import__(f"nexus.knowledge.ontologies.{name}_ontology", fromlist=["ONTOLOGY"])
                self._ontologies[name] = module.ONTOLOGY
                _log.info("Loaded ontology: %s", name)
            except (ImportError, AttributeError) as exc:
                _log.warning("Could not load ontology %s: %s", name, exc)

    async def get(self, name: str) -> dict[str, Any] | None:
        return self._ontologies.get(name)

    async def list_ontologies(self) -> list[str]:
        return list(self._ontologies.keys())

    async def get_classes(self, ontology: str) -> list[OntologyClass]:
        on = self._ontologies.get(ontology, {})
        return [OntologyClass(**c) for c in on.get("classes", [])]

    async def get_relations(self, ontology: str) -> list[OntologyRelation]:
        on = self._ontologies.get(ontology, {})
        return [OntologyRelation(**r) for r in on.get("relations", [])]

    async def register(self, name: str, ontology: dict[str, Any]) -> None:
        self._ontologies[name] = ontology
        _log.info("Registered ontology: %s", name)

    async def validate_entity(self, entity_type: str, ontology: str) -> bool:
        on = self._ontologies.get(ontology, {})
        class_names = [c["name"] for c in on.get("classes", [])]
        return entity_type in class_names

    async def validate_relation(self, rel_type: str, source_type: str, target_type: str, ontology: str) -> bool:
        on = self._ontologies.get(ontology, {})
        for r in on.get("relations", []):
            if r["name"] == rel_type and r["domain"] == source_type and r["range"] == target_type:
                return True
        return False
