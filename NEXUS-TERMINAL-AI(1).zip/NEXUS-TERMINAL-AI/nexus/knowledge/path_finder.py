"""Path finder — shortest path and path analysis in knowledge graphs."""
from __future__ import annotations

import logging
from collections import deque
from typing import Any

_log = logging.getLogger(__name__)


class PathFinder:
    """Finds paths between entities using BFS and shortest-path algorithms."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}

    def _build_adjacency(self, graph_data: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
        adj: dict[str, list[dict[str, Any]]] = {}
        for edge in graph_data.get("edges", []):
            adj.setdefault(edge["source"], []).append(edge)
            adj.setdefault(edge["target"], []).append({**edge, "source": edge["target"], "target": edge["source"]})
        return adj

    async def shortest_path(self, source: str, target: str, graph_data: dict[str, Any]) -> list[dict[str, Any]]:
        """BFS shortest path between two entities."""
        adj = self._build_adjacency(graph_data)
        if source not in adj or target not in adj:
            return []

        queue: deque[tuple[str, list[dict[str, Any]]]] = deque([(source, [])])
        visited: set[str] = {source}

        while queue:
            current, path = queue.popleft()
            for edge in adj.get(current, []):
                neighbor = edge["target"]
                if neighbor == target:
                    return path + [edge]
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [edge]))
        return []

    async def shortest_paths(self, source: str, depth: int = 2, graph_data: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Find all paths from source up to a given depth."""
        if graph_data is None:
            return []
        adj = self._build_adjacency(graph_data)
        results: list[dict[str, Any]] = []
        queue: deque[tuple[str, list[dict[str, Any]], int]] = deque([(source, [], 0)])
        visited: set[str] = {source}

        while queue:
            current, path, d = queue.popleft()
            if d > 0:
                results.append({"from": source, "to": current, "path": path, "depth": d})
            if d >= depth:
                continue
            for edge in adj.get(current, []):
                neighbor = edge["target"]
                if neighbor not in visited or d < depth - 1:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [edge], d + 1))
        return results

    async def find_all_paths(self, source: str, target: str, graph_data: dict[str, Any], max_depth: int = 5) -> list[list[dict[str, Any]]]:
        """DFS to find all paths up to max_depth."""
        adj = self._build_adjacency(graph_data)
        all_paths: list[list[dict[str, Any]]] = []

        def dfs(current: str, target: str, path: list[dict[str, Any]], visited: set[str]) -> None:
            if len(path) > max_depth:
                return
            if current == target and path:
                all_paths.append(list(path))
                return
            for edge in adj.get(current, []):
                neighbor = edge["target"]
                if neighbor not in visited:
                    visited.add(neighbor)
                    path.append(edge)
                    dfs(neighbor, target, path, visited)
                    path.pop()
                    visited.remove(neighbor)

        dfs(source, target, [], {source})
        return all_paths
