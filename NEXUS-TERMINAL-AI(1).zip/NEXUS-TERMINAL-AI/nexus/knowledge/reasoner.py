"""Reasoner — inference and logical reasoning over the knowledge graph."""
from __future__ import annotations

import logging
from typing import Any

_log = logging.getLogger(__name__)


class Reasoner:
    """Performs logical inference over graph entities and relations."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._rules: list[dict[str, Any]] = []
        self._inferred: list[dict[str, Any]] = []

    async def add_rule(self, premise: str, conclusion: str, confidence: float = 0.8) -> None:
        self._rules.append({"premise": premise, "conclusion": conclusion, "confidence": confidence})
        _log.debug("Added reasoning rule: %s -> %s", premise, conclusion)

    async def infer(self, graph_data: dict[str, Any]) -> list[dict[str, Any]]:
        """Run inference rules against graph data and return inferred facts."""
        inferred: list[dict[str, Any]] = []
        nodes = {n["name"]: n for n in graph_data.get("nodes", [])}
        edges = graph_data.get("edges", [])

        edge_index: dict[str, list[dict[str, Any]]] = {}
        for e in edges:
            edge_index.setdefault(e["source"], []).append(e)

        for rule in self._rules:
            if rule["premise"] == "transitive" and rule["conclusion"] == "inherits":
                for edge in edges:
                    for e2 in edge_index.get(edge["target"], []):
                        inferred.append({
                            "source": edge["source"],
                            "target": e2["target"],
                            "type": edge["type"],
                            "confidence": rule["confidence"],
                            "rule": "transitive_inheritance",
                        })

            if rule["premise"] == "same_relation_chain":
                rel_type = rule.get("relation_type", "")
                for e1 in edges:
                    if e1["type"] == rel_type:
                        for e2 in edge_index.get(e1["target"], []):
                            if e2["type"] == rel_type:
                                inferred.append({
                                    "source": e1["source"],
                                    "target": e2["target"],
                                    "type": rel_type,
                                    "confidence": rule["confidence"],
                                    "rule": "relation_chain",
                                })

        self._inferred.extend(inferred)
        return inferred

    async def query(self, question: str, graph: dict[str, Any]) -> list[dict[str, Any]]:
        """Answer queries using inference results."""
        results: list[dict[str, Any]] = []
        question_lower = question.lower()
        for fact in self._inferred:
            if fact["type"].lower() in question_lower:
                results.append(fact)
        return results

    async def get_inferred_facts(self) -> list[dict[str, Any]]:
        return list(self._inferred)
