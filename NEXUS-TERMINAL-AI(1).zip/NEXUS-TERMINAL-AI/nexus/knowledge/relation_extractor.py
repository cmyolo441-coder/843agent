"""Relation extractor — extract relationships between entities from text."""
from __future__ import annotations

import logging
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

_log = logging.getLogger(__name__)


class RelationExtractor:
    """Extracts semantic relations between entities from unstructured text."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._patterns = [
            ("WORKS_FOR", r"{person}\s+(?:works|is employed|is)\s+(?:at|by)\s+{org}"),
            ("LOCATED_IN", r"{org}\s+(?:is|are|based)\s+(?:in|at)\s+{loc}"),
            ("FOUNDED_BY", r"{org}\s+(?:was|is)\s+(?:founded|created|established)\s+by\s+{person}"),
            ("DEVELOPS", r"{org}\s+(?:develops|builds|creates|maintains)\s+{tech}"),
            ("USES", r"{person|org}\s+uses\s+{tech}"),
            ("PART_OF", r"{tech}\s+(?:is|runs|works)\s+(?:on|in|using)\s+{tech2}"),
            ("ACQUIRED", r"{org}\s+(?:acquired|bought|purchased)\s+{org2}"),
            ("PARTNERED_WITH", r"{org}\s+(?:partnered|collaborated|teamed up)\s+(?:with)\s+{org2}"),
            ("LED_BY", r"{org}\s+(?:is|was)\s+(?:led|run|managed)\s+by\s+{person}"),
        ]

    async def extract(self, text: str, entities: list[Entity]) -> list[Relation]:
        """Extract relations between known entities from text."""
        relations: list[Relation] = []
        text_lower = text.lower()
        entity_map = {e.name.lower(): e for e in entities}

        for rel_type, raw_pattern in self._patterns:
            for e1_name, e1 in entity_map.items():
                for e2_name, e2 in entity_map.items():
                    if e1_name >= e2_name:
                        continue
                    pattern = raw_pattern.replace("{person}", re.escape(e1_name) if e1.type == "PERSON" else "__skip__")
                    pattern = pattern.replace("{org}", re.escape(e1_name) if e1.type == "ORGANIZATION" else "__skip__")
                    pattern = pattern.replace("{loc}", re.escape(e1_name) if e1.type == "LOCATION" else "__skip__")
                    pattern = pattern.replace("{tech}", re.escape(e1_name) if e1.type == "TECHNOLOGY" else "__skip__")
                    pattern = pattern.replace("{org2}", re.escape(e2_name) if e2.type == "ORGANIZATION" else "__skip__")
                    pattern = pattern.replace("{tech2}", re.escape(e2_name) if e2.type == "TECHNOLOGY" else "__skip__")

                    import re
                    try:
                        compiled = re.compile(pattern.replace("__skip__", r"\b\w+\b"), re.I)
                        if compiled.search(text_lower):
                            relations.append(Relation(source=e1.name, target=e2.name, type=rel_type))
                            _log.debug("Extracted relation: %s --[%s]--> %s", e1.name, rel_type, e2.name)
                    except re.error:
                        continue
        return relations

    async def extract_direct(self, source: str, target: str, rel_type: str) -> Relation:
        """Create a direct relation without text analysis."""
        return Relation(source=source, target=target, type=rel_type)
