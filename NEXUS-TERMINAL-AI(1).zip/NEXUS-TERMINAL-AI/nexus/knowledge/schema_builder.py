"""Schema builder — define and enforce graph schemas."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from nexus.knowledge.graph_engine import Entity, Relation

_log = logging.getLogger(__name__)


@dataclass
class PropertySchema:
    """Schema definition for a property."""
    name: str
    type: str  # string, number, boolean, list
    required: bool = False
    default: Any = None


@dataclass
class EntitySchema:
    """Schema definition for an entity type."""
    type: str
    properties: list[PropertySchema] = field(default_factory=list)


@dataclass
class RelationSchema:
    """Schema definition for a relation type."""
    type: str
    source_types: list[str] = field(default_factory=list)
    target_types: list[str] = field(default_factory=list)
    properties: list[PropertySchema] = field(default_factory=list)


class SchemaBuilder:
    """Define and enforce graph schemas for entities and relations."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._entity_schemas: dict[str, EntitySchema] = {}
        self._relation_schemas: dict[str, RelationSchema] = {}

    async def define_entity(self, schema: EntitySchema) -> None:
        self._entity_schemas[schema.type] = schema
        _log.debug("Defined entity schema: %s", schema.type)

    async def define_relation(self, schema: RelationSchema) -> None:
        self._relation_schemas[schema.type] = schema
        _log.debug("Defined relation schema: %s", schema.type)

    async def validate_entity(self, entity: Entity) -> tuple[bool, str]:
        schema = self._entity_schemas.get(entity.type)
        if schema is None:
            return True, ""
        for prop in schema.properties:
            if prop.required and prop.name not in entity.properties:
                return False, f"Missing required property '{prop.name}' on {entity.type}"
            if prop.name in entity.properties:
                value = entity.properties[prop.name]
                if prop.type == "string" and not isinstance(value, str):
                    return False, f"Property '{prop.name}' should be string, got {type(value).__name__}"
                if prop.type == "number" and not isinstance(value, (int, float)):
                    return False, f"Property '{prop.name}' should be number, got {type(value).__name__}"
        return True, ""

    async def validate_relation(self, relation: Relation) -> tuple[bool, str]:
        schema = self._relation_schemas.get(relation.type)
        if schema is None:
            return True, ""
        if schema.source_types and relation.source.split(":")[0] not in schema.source_types:
            return False, f"Source type not allowed for relation '{relation.type}'"
        if schema.target_types and relation.target.split(":")[0] not in schema.target_types:
            return False, f"Target type not allowed for relation '{relation.type}'"
        return True, ""
