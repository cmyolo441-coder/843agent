"""Temporal graph — time-respecting graph operations and analysis."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class TemporalEdge:
    """An edge with a timestamp."""
    source: str
    target: str
    type: str
    timestamp: float
    properties: dict[str, Any] = field(default_factory=dict)


class TemporalGraph:
    """Knowledge graph with time-respecting edges and queries."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._edges: list[TemporalEdge] = []

    async def add_edge(self, source: str, target: str, rel_type: str, timestamp: float | None = None) -> None:
        te = TemporalEdge(source=source, target=target, type=rel_type, timestamp=timestamp or time.time())
        self._edges.append(te)

    async def query_range(self, start: float, end: float) -> list[TemporalEdge]:
        return [e for e in self._edges if start <= e.timestamp <= end]

    async def query_before(self, timestamp: float) -> list[TemporalEdge]:
        return [e for e in self._edges if e.timestamp <= timestamp]

    async def query_after(self, timestamp: float) -> list[TemporalEdge]:
        return [e for e in self._edges if e.timestamp >= timestamp]

    async def get_snapshot(self, timestamp: float) -> list[TemporalEdge]:
        """Get the state of the graph at a specific point in time."""
        return [e for e in self._edges if e.timestamp <= timestamp]

    async def get_evolution(self, entity: str, window_s: float = 3600) -> list[dict[str, Any]]:
        """Get the evolution of connections for an entity over time."""
        entity_edges = [e for e in self._edges if e.source == entity or e.target == entity]
        if not entity_edges:
            return []
        entity_edges.sort(key=lambda e: e.timestamp)
        start_time = entity_edges[0].timestamp
        end_time = entity_edges[-1].timestamp
        windows: list[dict[str, Any]] = []
        current = start_time
        while current <= end_time:
            window_edges = [e for e in entity_edges if current <= e.timestamp < current + window_s]
            windows.append({
                "window_start": current,
                "window_end": current + window_s,
                "edge_count": len(window_edges),
                "unique_neighbors": len(set(e.source if e.target == entity else e.target for e in window_edges)),
            })
            current += window_s
        return windows

    async def count_by_time(self, interval_s: float = 86400) -> list[dict[str, Any]]:
        if not self._edges:
            return []
        self._edges.sort(key=lambda e: e.timestamp)
        start = self._edges[0].timestamp
        end = self._edges[-1].timestamp
        result: list[dict[str, Any]] = []
        current = start
        while current <= end:
            count = sum(1 for e in self._edges if current <= e.timestamp < current + interval_s)
            result.append({"start": current, "end": current + interval_s, "count": count})
            current += interval_s
        return result
