"""Storage backends for the Nexus memory layer.

All backends expose the same async key/value protocol: ``put``, ``get``,
``delete``, ``scan`` (async iterator of ``(key, value)``), and ``close``.
"""
from __future__ import annotations

from .memory_backend import InMemoryBackend
from .file_backend import FileBackend
from .sqlite_backend import SQLiteBackend
from .postgres_backend import PostgresBackend
from .redis_backend import RedisBackend
from .mongo_backend import MongoBackend
from .rocksdb_backend import RocksDBBackend
from .leveldb_backend import LevelDBBackend
from .duckdb_backend import DuckDBBackend
from .tiered_backend import TieredBackend

__all__ = [
    "InMemoryBackend",
    "FileBackend",
    "SQLiteBackend",
    "PostgresBackend",
    "RedisBackend",
    "MongoBackend",
    "RocksDBBackend",
    "LevelDBBackend",
    "DuckDBBackend",
    "TieredBackend",
]
