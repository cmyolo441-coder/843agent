"""DuckDBBackend: columnar OLAP-flavoured backend for analytical recall."""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncIterator

from .sqlite_backend import SQLiteBackend

logger = logging.getLogger(__name__)

try:  # pragma: no cover
    import duckdb  # type: ignore
except ImportError:  # pragma: no cover
    duckdb = None  # type: ignore


class DuckDBBackend:
    """DuckDB-backed KV; falls back to sqlite when duckdb isn't installed."""

    def __init__(self, path: str = ":memory:") -> None:
        self.path = path
        self._lock = asyncio.Lock()
        if duckdb:
            self._conn = duckdb.connect(path)
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS memory(key VARCHAR PRIMARY KEY, value VARCHAR)"
            )
            self._fallback: SQLiteBackend | None = None
        else:
            self._conn = None
            self._fallback = SQLiteBackend(path)

    async def put(self, key: str, value: Any) -> None:
        if self._fallback:
            return await self._fallback.put(key, value)
        async with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO memory VALUES (?, ?)", [key, json.dumps(value)]
            )

    async def get(self, key: str) -> Any | None:
        if self._fallback:
            return await self._fallback.get(key)
        row = self._conn.execute("SELECT value FROM memory WHERE key=?", [key]).fetchone()
        return json.loads(row[0]) if row else None

    async def delete(self, key: str) -> bool:
        if self._fallback:
            return await self._fallback.delete(key)
        async with self._lock:
            self._conn.execute("DELETE FROM memory WHERE key=?", [key])
        return True

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        if self._fallback:
            async for k, v in self._fallback.scan():
                yield k, v
            return
        for k, v in self._conn.execute("SELECT key, value FROM memory").fetchall():
            yield k, json.loads(v)

    async def close(self) -> None:
        if self._fallback:
            await self._fallback.close()
        elif self._conn:
            self._conn.close()
