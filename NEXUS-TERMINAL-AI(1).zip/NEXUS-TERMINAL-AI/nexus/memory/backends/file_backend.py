"""FileBackend: one JSON file per record under a base directory."""
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)


class FileBackend:
    """Filesystem-backed KV; suitable for small/medium memory volumes."""

    def __init__(self, directory: str | Path) -> None:
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()

    def _path(self, key: str) -> Path:
        safe = key.replace("/", "_")
        return self.dir / f"{safe}.json"

    async def put(self, key: str, value: Any) -> None:
        async with self._lock:
            self._path(key).write_text(json.dumps(value), encoding="utf-8")

    async def get(self, key: str) -> Any | None:
        p = self._path(key)
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))

    async def delete(self, key: str) -> bool:
        p = self._path(key)
        if p.exists():
            p.unlink()
            return True
        return False

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        for p in self.dir.glob("*.json"):
            try:
                yield p.stem, json.loads(p.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                logger.warning("skipping corrupt %s", p)

    async def count(self) -> int:
        return sum(1 for _ in self.dir.glob("*.json"))

    async def close(self) -> None:
        return None
