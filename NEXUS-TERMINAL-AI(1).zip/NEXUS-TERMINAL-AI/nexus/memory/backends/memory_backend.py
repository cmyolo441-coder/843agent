"""InMemoryBackend: a process-local dict-backed store used as the default."""
from __future__ import annotations

import asyncio
import logging
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)


class InMemoryBackend:
    """Async dict store with a single shared lock."""

    def __init__(self) -> None:
        self._data: dict[str, Any] = {}
        self._lock = asyncio.Lock()

    async def put(self, key: str, value: Any) -> None:
        async with self._lock:
            self._data[key] = value

    async def get(self, key: str) -> Any | None:
        async with self._lock:
            return self._data.get(key)

    async def delete(self, key: str) -> bool:
        async with self._lock:
            return self._data.pop(key, None) is not None

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        async with self._lock:
            items = list(self._data.items())
        for k, v in items:
            yield k, v

    async def count(self) -> int:
        return len(self._data)

    async def close(self) -> None:
        self._data.clear()
