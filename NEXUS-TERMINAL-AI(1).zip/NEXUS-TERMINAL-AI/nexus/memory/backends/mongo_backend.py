"""MongoBackend: motor-style async adapter with dict fallback."""
from __future__ import annotations

import logging
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)

try:  # pragma: no cover
    from motor.motor_asyncio import AsyncIOMotorClient  # type: ignore
except ImportError:  # pragma: no cover
    AsyncIOMotorClient = None  # type: ignore


class MongoBackend:
    """MongoDB-backed KV using a single ``memory`` collection."""

    def __init__(self, uri: str = "mongodb://localhost:27017", db: str = "nexus", coll: str = "memory") -> None:
        self.uri = uri
        self.db_name = db
        self.coll_name = coll
        self._client: Any = None
        self._coll: Any = None
        self._fallback: dict[str, Any] = {}

    def _ensure(self) -> None:
        if self._client or AsyncIOMotorClient is None:
            return
        self._client = AsyncIOMotorClient(self.uri)
        self._coll = self._client[self.db_name][self.coll_name]

    async def put(self, key: str, value: Any) -> None:
        self._ensure()
        if self._coll is None:
            self._fallback[key] = value
            return
        await self._coll.replace_one({"_id": key}, {"_id": key, "value": value}, upsert=True)

    async def get(self, key: str) -> Any | None:
        self._ensure()
        if self._coll is None:
            return self._fallback.get(key)
        doc = await self._coll.find_one({"_id": key})
        return doc["value"] if doc else None

    async def delete(self, key: str) -> bool:
        self._ensure()
        if self._coll is None:
            return self._fallback.pop(key, None) is not None
        res = await self._coll.delete_one({"_id": key})
        return res.deleted_count > 0

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        self._ensure()
        if self._coll is None:
            for k, v in self._fallback.items():
                yield k, v
            return
        async for doc in self._coll.find({}):
            yield doc["_id"], doc["value"]

    async def close(self) -> None:
        if self._client:
            self._client.close()
