"""PostgresBackend: asyncpg-style adapter (lazy/optional).

Falls back to an in-process dict if asyncpg is unavailable so the rest of
Nexus can still import this module in dev environments.
"""
from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)

try:  # pragma: no cover - exercised in production only
    import asyncpg  # type: ignore
except ImportError:  # pragma: no cover
    asyncpg = None  # type: ignore


class PostgresBackend:
    """Postgres KV backend; uses a `memory(key text primary key, value jsonb)` table."""

    def __init__(self, dsn: str, table: str = "memory") -> None:
        self.dsn = dsn
        self.table = table
        self._pool: Any = None
        self._fallback: dict[str, Any] = {}

    async def _ensure(self) -> None:
        if self._pool or asyncpg is None:
            return
        self._pool = await asyncpg.create_pool(self.dsn)
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"CREATE TABLE IF NOT EXISTS {self.table} (key TEXT PRIMARY KEY, value JSONB)"
            )

    async def put(self, key: str, value: Any) -> None:
        await self._ensure()
        if not self._pool:
            self._fallback[key] = value
            return
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"INSERT INTO {self.table}(key,value) VALUES($1,$2) "
                f"ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value",
                key, json.dumps(value),
            )

    async def get(self, key: str) -> Any | None:
        await self._ensure()
        if not self._pool:
            return self._fallback.get(key)
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(f"SELECT value FROM {self.table} WHERE key=$1", key)
        return json.loads(row["value"]) if row else None

    async def delete(self, key: str) -> bool:
        await self._ensure()
        if not self._pool:
            return self._fallback.pop(key, None) is not None
        async with self._pool.acquire() as conn:
            status = await conn.execute(f"DELETE FROM {self.table} WHERE key=$1", key)
        return status.endswith(" 1")

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        await self._ensure()
        if not self._pool:
            for k, v in self._fallback.items():
                yield k, v
            return
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(f"SELECT key, value FROM {self.table}")
        for r in rows:
            yield r["key"], json.loads(r["value"])

    async def close(self) -> None:
        if self._pool:
            await self._pool.close()
