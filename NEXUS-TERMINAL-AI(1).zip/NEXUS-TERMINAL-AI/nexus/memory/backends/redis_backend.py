"""RedisBackend: redis.asyncio-style adapter with dict fallback."""
from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)

try:  # pragma: no cover
    import redis.asyncio as aioredis  # type: ignore
except ImportError:  # pragma: no cover
    aioredis = None  # type: ignore


class RedisBackend:
    """Hash-namespaced Redis KV backend."""

    def __init__(self, url: str = "redis://localhost:6379", namespace: str = "nexus:mem") -> None:
        self.url = url
        self.namespace = namespace
        self._client: Any = None
        self._fallback: dict[str, Any] = {}

    async def _ensure(self) -> None:
        if self._client or aioredis is None:
            return
        self._client = aioredis.from_url(self.url, decode_responses=True)

    def _k(self, key: str) -> str:
        return f"{self.namespace}:{key}"

    async def put(self, key: str, value: Any) -> None:
        await self._ensure()
        if not self._client:
            self._fallback[key] = value
            return
        await self._client.set(self._k(key), json.dumps(value))

    async def get(self, key: str) -> Any | None:
        await self._ensure()
        if not self._client:
            return self._fallback.get(key)
        raw = await self._client.get(self._k(key))
        return json.loads(raw) if raw else None

    async def delete(self, key: str) -> bool:
        await self._ensure()
        if not self._client:
            return self._fallback.pop(key, None) is not None
        return bool(await self._client.delete(self._k(key)))

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        await self._ensure()
        if not self._client:
            for k, v in self._fallback.items():
                yield k, v
            return
        async for k in self._client.scan_iter(match=f"{self.namespace}:*"):
            raw = await self._client.get(k)
            if raw:
                yield k.split(":", 2)[-1], json.loads(raw)

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
