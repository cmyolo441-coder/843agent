"""RocksDBBackend: python-rocksdb adapter with sqlite fallback."""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncIterator

from .sqlite_backend import SQLiteBackend

logger = logging.getLogger(__name__)

try:  # pragma: no cover
    import rocksdb  # type: ignore
except ImportError:  # pragma: no cover
    rocksdb = None  # type: ignore


class RocksDBBackend:
    """Embedded LSM-tree KV store with a sqlite fallback for portability."""

    def __init__(self, path: str = "./rocksdb-memory") -> None:
        self.path = path
        if rocksdb:
            opts = rocksdb.Options(create_if_missing=True)
            self._db = rocksdb.DB(path, opts)
            self._fallback: SQLiteBackend | None = None
        else:
            logger.info("rocksdb not installed; using sqlite fallback")
            self._db = None
            self._fallback = SQLiteBackend(":memory:")
        self._lock = asyncio.Lock()

    async def put(self, key: str, value: Any) -> None:
        if self._fallback:
            return await self._fallback.put(key, value)
        async with self._lock:
            self._db.put(key.encode(), json.dumps(value).encode())

    async def get(self, key: str) -> Any | None:
        if self._fallback:
            return await self._fallback.get(key)
        async with self._lock:
            raw = self._db.get(key.encode())
        return json.loads(raw) if raw else None

    async def delete(self, key: str) -> bool:
        if self._fallback:
            return await self._fallback.delete(key)
        async with self._lock:
            self._db.delete(key.encode())
        return True

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        if self._fallback:
            async for k, v in self._fallback.scan():
                yield k, v
            return
        it = self._db.iteritems()
        it.seek_to_first()
        for k, v in it:
            yield k.decode(), json.loads(v)

    async def close(self) -> None:
        if self._fallback:
            await self._fallback.close()
