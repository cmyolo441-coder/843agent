"""SQLiteBackend: durable single-file backend backed by stdlib sqlite3."""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)


class SQLiteBackend:
    """Synchronous sqlite3 driver wrapped behind an async facade."""

    SCHEMA = (
        "CREATE TABLE IF NOT EXISTS memory ("
        " key TEXT PRIMARY KEY, value TEXT NOT NULL,"
        " created REAL DEFAULT (strftime('%s','now')))"
    )

    def __init__(self, path: str = ":memory:") -> None:
        self.path = path
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.execute(self.SCHEMA)
        self._conn.commit()
        self._lock = asyncio.Lock()

    async def put(self, key: str, value: Any) -> None:
        async with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO memory(key,value) VALUES(?,?)",
                (key, json.dumps(value)),
            )
            self._conn.commit()

    async def get(self, key: str) -> Any | None:
        async with self._lock:
            cur = self._conn.execute("SELECT value FROM memory WHERE key=?", (key,))
            row = cur.fetchone()
        return json.loads(row[0]) if row else None

    async def delete(self, key: str) -> bool:
        async with self._lock:
            cur = self._conn.execute("DELETE FROM memory WHERE key=?", (key,))
            self._conn.commit()
        return cur.rowcount > 0

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        cur = self._conn.execute("SELECT key, value FROM memory")
        for k, v in cur.fetchall():
            yield k, json.loads(v)

    async def count(self) -> int:
        cur = self._conn.execute("SELECT COUNT(*) FROM memory")
        return int(cur.fetchone()[0])

    async def close(self) -> None:
        self._conn.close()
