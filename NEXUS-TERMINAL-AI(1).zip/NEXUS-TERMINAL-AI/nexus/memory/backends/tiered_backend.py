"""TieredBackend: hot/warm/cold composition over arbitrary sub-backends."""
from __future__ import annotations

import logging
import time
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)


class TieredBackend:
    """Read-through, write-through tiered cache with age-based demotion."""

    def __init__(
        self,
        hot: Any,
        warm: Any,
        cold: Any,
        warm_after: float = 60.0,
        cold_after: float = 3600.0,
    ) -> None:
        self.hot = hot
        self.warm = warm
        self.cold = cold
        self.warm_after = warm_after
        self.cold_after = cold_after
        self._inserted: dict[str, float] = {}

    async def put(self, key: str, value: Any) -> None:
        await self.hot.put(key, value)
        self._inserted[key] = time.time()

    async def get(self, key: str) -> Any | None:
        for tier in (self.hot, self.warm, self.cold):
            val = await tier.get(key)
            if val is not None:
                if tier is not self.hot:
                    await self.hot.put(key, val)
                return val
        return None

    async def delete(self, key: str) -> bool:
        ok = False
        for tier in (self.hot, self.warm, self.cold):
            ok = await tier.delete(key) or ok
        self._inserted.pop(key, None)
        return ok

    async def scan(self) -> AsyncIterator[tuple[str, Any]]:
        seen: set[str] = set()
        for tier in (self.hot, self.warm, self.cold):
            async for k, v in tier.scan():
                if k not in seen:
                    seen.add(k)
                    yield k, v

    async def age(self) -> None:
        """Demote items older than configured thresholds."""
        now = time.time()
        for key, inserted in list(self._inserted.items()):
            age = now - inserted
            if age > self.cold_after:
                val = await self.hot.get(key) or await self.warm.get(key)
                if val is not None:
                    await self.cold.put(key, val)
                    await self.hot.delete(key)
                    await self.warm.delete(key)
            elif age > self.warm_after:
                val = await self.hot.get(key)
                if val is not None:
                    await self.warm.put(key, val)
                    await self.hot.delete(key)

    async def close(self) -> None:
        for tier in (self.hot, self.warm, self.cold):
            if hasattr(tier, "close"):
                await tier.close()
