"""Memory consolidation: replay, abstraction, forgetting, sleep-phase passes."""
from __future__ import annotations

from .consolidator import Consolidator
from .replay import ExperienceReplay
from .abstraction import AbstractionEngine
from .generalization import GeneralizationEngine
from .forgetting import ControlledForgetting
from .interference import InterferenceResolver
from .sleep import SleepConsolidator

__all__ = [
    "Consolidator",
    "ExperienceReplay",
    "AbstractionEngine",
    "GeneralizationEngine",
    "ControlledForgetting",
    "InterferenceResolver",
    "SleepConsolidator",
]
