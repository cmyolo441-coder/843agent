"""SleepConsolidator: simulated sleep-phase batch consolidation."""
from __future__ import annotations

import asyncio
import logging
from enum import Enum

from .consolidator import Consolidator, ConsolidationStats

logger = logging.getLogger(__name__)


class SleepPhase(str, Enum):
    NREM = "nrem"  # slow-wave: memory replay & abstraction
    REM = "rem"    # rapid-eye: creative recombination & forgetting


class SleepConsolidator:
    """Cycles through NREM and REM phases over a single 'sleep' invocation."""

    def __init__(self, consolidator: Consolidator) -> None:
        self.consolidator = consolidator
        self.history: list[tuple[SleepPhase, ConsolidationStats]] = []

    async def sleep(self, cycles: int = 3, phase_seconds: float = 1.0) -> list[tuple[SleepPhase, ConsolidationStats]]:
        out: list[tuple[SleepPhase, ConsolidationStats]] = []
        for cycle in range(cycles):
            for phase in (SleepPhase.NREM, SleepPhase.REM):
                stats = await self._run_phase(phase)
                out.append((phase, stats))
                logger.info("cycle=%d phase=%s stats=%s", cycle, phase, stats)
                await asyncio.sleep(phase_seconds)
        self.history.extend(out)
        return out

    async def _run_phase(self, phase: SleepPhase) -> ConsolidationStats:
        stats = ConsolidationStats()
        if phase is SleepPhase.NREM:
            await self.consolidator.replay.replay(batch=32)
            stats.abstracted = await self.consolidator.abstraction.abstract_recent(batch=16)
        else:  # REM
            stats.forgotten = await self.consolidator.forgetting.prune(min_score=0.1)
        return stats
