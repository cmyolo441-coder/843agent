"""nexus.multimodal — Multi-modal perception subsystem.

Integrates vision (image, OCR, chart, face, object, scene, screenshot),
audio (STT, TTS, analysis, speaker-id, music, noise reduction),
video (analysis, frame extraction, subtitles, action detection, summarization),
and structured-data (tables, forms, diagrams, schema inference) pipelines.
"""
from __future__ import annotations

from .multimodal_engine import MultiModalEngine

__all__ = [
    "MultiModalEngine",
]
