"""nexus.multimodal.audio — Audio perception pipelines.

Provides speech-to-text, text-to-speech, audio analysis, speaker
identification, music transcription, and noise reduction capabilities.
"""
from __future__ import annotations

from .stt_engine import STTEngine, STTResult
from .tts_engine import TTSEngine, TTSResult
from .audio_analyzer import AudioAnalyzer, AudioAnalysis
from .speaker_identify import SpeakerIdentifier, SpeakerResult
from .music_transcriber import MusicTranscriber, MusicResult
from .noise_reducer import NoiseReducer, NoiseReductionResult

__all__ = [
    "STTEngine",
    "STTResult",
    "TTSEngine",
    "TTSResult",
    "AudioAnalyzer",
    "AudioAnalysis",
    "SpeakerIdentifier",
    "SpeakerResult",
    "MusicTranscriber",
    "MusicResult",
    "NoiseReducer",
    "NoiseReductionResult",
]
