"""Speech-to-Text engine — transcribe audio to text.

The STTEngine converts audio input (files, bytes, or streams) into
text using local models or cloud speech recognition APIs.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator

_log = logging.getLogger(__name__)


@dataclass
class WordTiming:
    """A single word with its time offset."""
    word: str = ""
    start: float = 0.0
    end: float = 0.0
    confidence: float = 0.0


@dataclass
class STTResult:
    """Transcription result from the STT engine."""
    text: str = ""
    segments: list[str] = field(default_factory=list)
    word_timings: list[WordTiming] = field(default_factory=list)
    language: str = "en"
    duration: float = 0.0
    processing_time: float = 0.0
    confidence: float = 0.0


class STTEngine:
    """Transcribe audio to text using speech recognition."""

    def __init__(self, model: str = "whisper-base", language: str = "en") -> None:
        self.model = model
        self.language = language
        self._loaded: bool = False

    async def _ensure_loaded(self) -> None:
        if not self._loaded:
            _log.info("Loading STT model=%s (lang=%s)", self.model, self.language)
            self._loaded = True

    async def run(self, source: Any, **kwargs: Any) -> STTResult:
        """Transcribe audio to text."""
        await self._ensure_loaded()
        lang = kwargs.get("language", self.language)
        _log.debug("Transcribing audio (%s)", lang)
        audio = await self._load_audio(source)
        start = time.perf_counter()
        raw = await self._transcribe(audio, lang)
        elapsed = time.perf_counter() - start
        words = [WordTiming(**w) for w in raw.get("words", [])]
        return STTResult(
            text=raw.get("text", ""),
            segments=raw.get("segments", []),
            word_timings=words,
            language=lang,
            duration=raw.get("duration", 0.0),
            processing_time=elapsed,
            confidence=raw.get("confidence", 0.0),
        )

    async def _load_audio(self, source: Any) -> dict:
        if isinstance(source, (str, Path)):
            return {"path": str(source)}
        if isinstance(source, bytes):
            return {"bytes": source}
        if isinstance(source, dict):
            return source
        raise TypeError(f"Unsupported audio source: {type(source).__name__}")

    async def _transcribe(self, audio: dict, language: str) -> dict:
        _log.debug("STT inference on %s", audio.get("path", "bytes"))
        return {"text": "", "segments": [], "words": [], "duration": 0.0, "confidence": 0.0}

    async def transcribe_stream(self, source: Any, **kwargs: Any) -> AsyncIterator[STTResult]:
        """Transcribe audio as it arrives (streaming mode)."""
        yield STTResult(text="[partial]")

    async def shutdown(self) -> None:
        """Release STT model resources."""
        _log.info("Shutting down STTEngine")
        self._loaded = False
