"""Central orchestrator for all multi-modal processing pipelines.

The MultiModalEngine dispatches requests to the appropriate sub-modules
(vision, audio, video, structured) and optionally fuses results from
multiple modalities into a unified output.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from nexus.multimodal.vision.image_analyzer import ImageAnalyzer
from nexus.multimodal.vision.ocr_engine import OCREngine
from nexus.multimodal.vision.image_generator import ImageGenerator
from nexus.multimodal.vision.image_editor import ImageEditor
from nexus.multimodal.vision.chart_reader import ChartReader
from nexus.multimodal.vision.face_detector import FaceDetector
from nexus.multimodal.vision.object_detector import ObjectDetector
from nexus.multimodal.vision.scene_descriptor import SceneDescriptor
from nexus.multimodal.vision.screenshot_analyzer import ScreenshotAnalyzer
from nexus.multimodal.audio.stt_engine import STTEngine
from nexus.multimodal.audio.tts_engine import TTSEngine
from nexus.multimodal.audio.audio_analyzer import AudioAnalyzer
from nexus.multimodal.audio.speaker_identify import SpeakerIdentifier
from nexus.multimodal.audio.music_transcriber import MusicTranscriber
from nexus.multimodal.audio.noise_reducer import NoiseReducer
from nexus.multimodal.video.video_analyzer import VideoAnalyzer
from nexus.multimodal.video.frame_extractor import FrameExtractor
from nexus.multimodal.video.subtitle_generator import SubtitleGenerator
from nexus.multimodal.video.action_detector import ActionDetector
from nexus.multimodal.video.video_summarizer import VideoSummarizer
from nexus.multimodal.structured.table_parser import TableParser
from nexus.multimodal.structured.form_parser import FormParser
from nexus.multimodal.structured.diagram_reader import DiagramReader
from nexus.multimodal.structured.schema_inferrer import SchemaInferrer

_log = logging.getLogger(__name__)

ProcessingResult = dict[str, Any]


@dataclass
class MultiModalEngine:
    """Top-level dispatcher for all multi-modal operations."""

    vision: ImageAnalyzer = field(default_factory=ImageAnalyzer)
    ocr: OCREngine = field(default_factory=OCREngine)
    image_gen: ImageGenerator = field(default_factory=ImageGenerator)
    image_editor: ImageEditor = field(default_factory=ImageEditor)
    chart_reader: ChartReader = field(default_factory=ChartReader)
    face_detector: FaceDetector = field(default_factory=FaceDetector)
    object_detector: ObjectDetector = field(default_factory=ObjectDetector)
    scene_desc: SceneDescriptor = field(default_factory=SceneDescriptor)
    screenshot: ScreenshotAnalyzer = field(default_factory=ScreenshotAnalyzer)
    stt: STTEngine = field(default_factory=STTEngine)
    tts: TTSEngine = field(default_factory=TTSEngine)
    audio: AudioAnalyzer = field(default_factory=AudioAnalyzer)
    speaker_id: SpeakerIdentifier = field(default_factory=SpeakerIdentifier)
    music: MusicTranscriber = field(default_factory=MusicTranscriber)
    noise: NoiseReducer = field(default_factory=NoiseReducer)
    video: VideoAnalyzer = field(default_factory=VideoAnalyzer)
    frames: FrameExtractor = field(default_factory=FrameExtractor)
    subtitles: SubtitleGenerator = field(default_factory=SubtitleGenerator)
    actions: ActionDetector = field(default_factory=ActionDetector)
    video_summary: VideoSummarizer = field(default_factory=VideoSummarizer)
    tables: TableParser = field(default_factory=TableParser)
    forms: FormParser = field(default_factory=FormParser)
    diagrams: DiagramReader = field(default_factory=DiagramReader)
    schema_infer: SchemaInferrer = field(default_factory=SchemaInferrer)

    async def process(self, modality: str, data: Any, **kwargs: Any) -> ProcessingResult:
        """Route *data* to the pipeline identified by *modality*."""
        _log.info("Processing modality=%s", modality)
        start = time.perf_counter()
        try:
            return await self._dispatch(modality, data, **kwargs)
        except Exception:
            _log.exception("Failed to process modality=%s", modality)
            raise
        finally:
            elapsed = time.perf_counter() - start
            _log.debug("Finished modality=%s in %.3fs", modality, elapsed)

    async def _dispatch(self, modality: str, data: Any, **kwargs: Any) -> ProcessingResult:
        m = modality.lower().replace("-", "_")
        handlers: dict[str, str] = {
            "analyze_image": "vision",
            "ocr": "ocr",
            "generate_image": "image_gen",
            "edit_image": "image_editor",
            "read_chart": "chart_reader",
            "detect_faces": "face_detector",
            "detect_objects": "object_detector",
            "describe_scene": "scene_desc",
            "analyze_screenshot": "screenshot",
            "transcribe_audio": "stt",
            "synthesize_speech": "tts",
            "analyze_audio": "audio",
            "identify_speaker": "speaker_id",
            "transcribe_music": "music",
            "reduce_noise": "noise",
            "analyze_video": "video",
            "extract_frames": "frames",
            "generate_subtitles": "subtitles",
            "detect_actions": "actions",
            "summarize_video": "video_summary",
            "parse_table": "tables",
            "parse_form": "forms",
            "read_diagram": "diagrams",
            "infer_schema": "schema_infer",
        }
        attr = handlers.get(m)
        if attr is None:
            raise ValueError(f"Unknown modality: {modality}")
        handler = getattr(self, attr)
        if not hasattr(handler, "run"):
            raise NotImplementedError(f"{attr} does not implement run()")
        return await handler.run(data, **kwargs)

    async def process_multi(self, inputs: list[tuple[str, Any]]) -> list[ProcessingResult]:
        """Process multiple modality inputs concurrently."""
        tasks = [self.process(modality, data) for modality, data in inputs]
        return await asyncio.gather(*tasks)

    async def shutdown(self) -> None:
        """Release resources held by all sub-engines."""
        _log.info("Shutting down MultiModalEngine")
        for name in dir(self):
            obj = getattr(self, name)
            if hasattr(obj, "shutdown") and callable(obj.shutdown):
                try:
                    await obj.shutdown()
                except Exception:
                    _log.exception("Error shutting down %s", name)
