"""nexus.multimodal.structured — Structured data extraction pipelines.

Provides parsing and schema inference for tables, forms, diagrams,
and other structured visual information.
"""
from __future__ import annotations

from .table_parser import TableParser, TableResult
from .form_parser import FormParser, FormResult
from .diagram_reader import DiagramReader, DiagramResult
from .schema_inferrer import SchemaInferrer, InferredSchema

__all__ = [
    "TableParser",
    "TableResult",
    "FormParser",
    "FormResult",
    "DiagramReader",
    "DiagramResult",
    "SchemaInferrer",
    "InferredSchema",
]
