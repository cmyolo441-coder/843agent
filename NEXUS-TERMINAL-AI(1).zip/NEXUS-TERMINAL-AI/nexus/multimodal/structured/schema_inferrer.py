"""Schema inference — infer data schemas from structured documents and tables.

The SchemaInferrer analyzes tabular data, forms, and JSON-like structures
to produce typed schema definitions (similar to JSON Schema or DDL).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class FieldSchema:
    """Schema definition for a single field."""
    name: str = ""
    dtype: str = "string"
    nullable: bool = True
    inferred_type: str = ""
    unique_values: int = 0
    sample_values: list[str] = field(default_factory=list)
    constraints: dict[str, Any] = field(default_factory=dict)


@dataclass
class InferredSchema:
    """Complete inferred schema for a dataset."""
    fields: list[FieldSchema] = field(default_factory=list)
    row_count: int = 0
    detected_format: str = "table"
    primary_key: str | None = None
    confidence: float = 0.0


class SchemaInferrer:
    """Infer typed schemas from structured data sources."""

    TYPE_MAPPING: dict[str, str] = {
        "int": "integer", "float": "number", "str": "string",
        "bool": "boolean", "datetime": "datetime", "date": "date",
        "list": "array", "dict": "object", "NoneType": "null",
    }

    def __init__(self) -> None:
        self._initialized: bool = False

    async def _ensure_initialized(self) -> None:
        if not self._initialized:
            _log.info("Initializing SchemaInferrer")
            self._initialized = True

    async def run(self, source: Any, **kwargs: Any) -> InferredSchema:
        """Infer a schema from structured data (rows, table, JSON)."""
        await self._ensure_initialized()
        _log.debug("Inferring schema from %s", type(source).__name__)
        data = await self._load(source)
        raw_fields = await self._analyze_fields(data)
        fields = [FieldSchema(**f) for f in raw_fields]
        row_count = data.get("row_count", 0)
        fmt = data.get("format", "table")
        pk = await self._detect_primary_key(fields)
        return InferredSchema(
            fields=fields, row_count=row_count,
            detected_format=fmt, primary_key=pk,
        )

    async def _load(self, source: Any) -> dict:
        if isinstance(source, dict):
            return source
        if isinstance(source, list):
            return {"rows": source, "row_count": len(source), "format": "table"}
        if isinstance(source, (str, bytes)):
            return {"raw": source, "format": "unknown"}
        raise TypeError(f"Unsupported source: {type(source).__name__}")

    async def _analyze_fields(self, data: dict) -> list[dict]:
        rows = data.get("rows", [])
        if not rows:
            return [{"name": "col_1", "dtype": "string", "nullable": True}]
        fields: dict[str, dict] = {}
        for row in rows:
            if isinstance(row, dict):
                for key, value in row.items():
                    if key not in fields:
                        fields[key] = {
                            "name": key,
                            "dtype": self._infer_type(value),
                            "nullable": value is None,
                            "unique_values": 0,
                            "sample_values": [],
                            "constraints": {},
                        }
        return list(fields.values())

    def _infer_type(self, value: Any) -> str:
        return self.TYPE_MAPPING.get(type(value).__name__, "string")

    async def _detect_primary_key(self, fields: list[FieldSchema]) -> str | None:
        for f in fields:
            if "id" in f.name.lower() or "key" in f.name.lower():
                return f.name
        return None

    async def shutdown(self) -> None:
        """Release schema inference resources."""
        _log.info("Shutting down SchemaInferrer")
        self._initialized = False
