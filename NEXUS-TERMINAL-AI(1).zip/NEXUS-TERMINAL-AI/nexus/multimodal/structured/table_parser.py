"""Table parsing — extract tabular data from images, PDFs, and documents.

The TableParser detects table structures, extracts cells with their
coordinates, and reconstructs the data into structured rows/columns.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class TableCell:
    """A single cell in a parsed table."""
    text: str = ""
    row: int = 0
    col: int = 0
    rowspan: int = 1
    colspan: int = 1
    confidence: float = 1.0


@dataclass
class TableResult:
    """Parsed tabular data."""
    headers: list[str] = field(default_factory=list)
    rows: list[list[str]] = field(default_factory=list)
    cells: list[TableCell] = field(default_factory=list)
    num_rows: int = 0
    num_cols: int = 0
    table_type: str = ""
    confidence: float = 0.0


class TableParser:
    """Detect and extract tabular data from structured documents."""

    TABLE_TYPES: tuple[str, ...] = (
        "grid", "borderless", "matrix", "key_value", "spreadsheet"
    )

    def __init__(self) -> None:
        self._initialized: bool = False

    async def _ensure_initialized(self) -> None:
        if not self._initialized:
            _log.info("Initializing TableParser")
            self._initialized = True

    async def run(self, source: Any, **kwargs: Any) -> TableResult:
        """Parse a table from the provided document or image."""
        await self._ensure_initialized()
        _log.debug("Parsing table from %s", type(source).__name__)
        doc = await self._load(source)
        raw_cells = await self._detect_cells(doc)
        cells = [TableCell(**c) for c in raw_cells]
        headers = await self._extract_headers(cells)
        rows = await self._build_rows(cells, headers)
        num_rows = max((c.row for c in cells), default=0) + 1
        num_cols = max((c.col for c in cells), default=0) + 1
        table_type = await self._classify_table(cells)
        return TableResult(
            headers=headers, rows=rows, cells=cells,
            num_rows=num_rows, num_cols=num_cols,
            table_type=table_type,
        )

    async def _load(self, source: Any) -> dict:
        if isinstance(source, (str, bytes, dict)):
            return {}
        raise TypeError(f"Unsupported source: {type(source).__name__}")

    async def _detect_cells(self, doc: dict) -> list[dict]:
        return []

    async def _extract_headers(self, cells: list[TableCell]) -> list[str]:
        return [c.text for c in cells if c.row == 0]

    async def _build_rows(self, cells: list[TableCell], headers: list[str]) -> list[list[str]]:
        rows: dict[int, dict[int, str]] = {}
        for c in cells:
            if c.row not in rows:
                rows[c.row] = {}
            rows[c.row][c.col] = c.text
        return [[rows[r].get(c, "") for c in range(len(headers))] for r in sorted(rows) if r > 0]

    async def _classify_table(self, cells: list[TableCell]) -> str:
        return "grid"

    async def shutdown(self) -> None:
        """Release table parser resources."""
        _log.info("Shutting down TableParser")
        self._initialized = False
