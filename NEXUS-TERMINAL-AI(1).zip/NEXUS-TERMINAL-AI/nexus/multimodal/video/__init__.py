"""nexus.multimodal.video — Video perception pipelines.

Provides video analysis, frame extraction, subtitle generation,
action detection, and video summarization capabilities.
"""
from __future__ import annotations

from .video_analyzer import VideoAnalyzer, VideoAnalysis
from .frame_extractor import FrameExtractor, FrameExtraction
from .subtitle_generator import SubtitleGenerator, SubtitleResult
from .action_detector import ActionDetector, ActionResult
from .video_summarizer import VideoSummarizer, SummaryResult

__all__ = [
    "VideoAnalyzer",
    "VideoAnalysis",
    "FrameExtractor",
    "FrameExtraction",
    "SubtitleGenerator",
    "SubtitleResult",
    "ActionDetector",
    "ActionResult",
    "VideoSummarizer",
    "SummaryResult",
]
