"""Action detection — identify human actions and activities in video.

The ActionDetector analyzes video frames to recognize human actions
and activities using spatio-temporal models.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class ActionInstance:
    """A single detected action instance."""
    action: str = ""
    confidence: float = 0.0
    start_time: float = 0.0
    end_time: float = 0.0
    bbox: tuple[float, float, float, float] | None = None


@dataclass
class ActionResult:
    """Results from action detection on a video."""
    actions: list[ActionInstance] = field(default_factory=list)
    action_count: int = 0
    unique_actions: list[str] = field(default_factory=list)
    total_duration: float = 0.0


class ActionDetector:
    """Detect human actions and activities in video."""

    COMMON_ACTIONS: tuple[str, ...] = (
        "walking", "running", "sitting", "standing", "jumping",
        "waving", "pointing", "throwing", "kicking", "dancing",
        "talking", "eating", "drinking", "typing", "reading",
    )

    def __init__(self, model: str = "mmaction2", threshold: float = 0.5) -> None:
        self.model = model
        self.threshold = threshold
        self._loaded: bool = False

    async def _ensure_loaded(self) -> None:
        if not self._loaded:
            _log.info("Loading ActionDetector model=%s (thresh=%.2f)", self.model, self.threshold)
            self._loaded = True

    async def run(self, source: Any, **kwargs: Any) -> ActionResult:
        """Detect actions in the provided video."""
        await self._ensure_loaded()
        threshold = kwargs.get("threshold", self.threshold)
        _log.debug("Detecting actions (threshold=%.2f)", threshold)
        video = await self._load(source)
        raw_actions = await self._detect(video)
        actions = []
        for a in raw_actions:
            if a.get("confidence", 0) >= threshold:
                bbox = tuple(a["bbox"]) if "bbox" in a else None
                actions.append(ActionInstance(
                    action=a.get("action", "unknown"),
                    confidence=a.get("confidence", 0.0),
                    start_time=a.get("start", 0.0),
                    end_time=a.get("end", 0.0),
                    bbox=bbox,
                ))
        unique = list({a.action for a in actions})
        return ActionResult(
            actions=actions, action_count=len(actions),
            unique_actions=sorted(unique),
            total_duration=video.get("duration", 0.0),
        )

    async def _load(self, source: Any) -> dict:
        if isinstance(source, (str, dict)):
            return source if isinstance(source, dict) else {"path": str(source)}
        raise TypeError(f"Unsupported source: {type(source).__name__}")

    async def _detect(self, video: dict) -> list[dict]:
        _log.debug("Running action detection with %s", self.model)
        return []

    async def shutdown(self) -> None:
        """Release action detection model."""
        _log.info("Shutting down ActionDetector")
        self._loaded = False
