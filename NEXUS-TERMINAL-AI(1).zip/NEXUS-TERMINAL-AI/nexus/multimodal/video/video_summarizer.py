"""Video summarization — generate concise summaries of video content.

The VideoSummarizer analyzes video and produces textual summaries,
highlight reels, or condensed versions of the original content.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class SummarySegment:
    """A segment of the video with a textual description."""
    start: float = 0.0
    end: float = 0.0
    description: str = ""
    importance: float = 0.0


@dataclass
class SummaryResult:
    """Generated summary of a video."""
    segments: list[SummarySegment] = field(default_factory=list)
    full_summary: str = ""
    key_moments: list[dict] = field(default_factory=list)
    duration_original: float = 0.0
    duration_summary: float = 0.0
    compression_ratio: float = 0.0


class VideoSummarizer:
    """Generate text and highlight summaries of video content."""

    def __init__(self, model: str = "clip-vit", max_summary_len: int = 512) -> None:
        self.model = model
        self.max_summary_len = max_summary_len
        self._loaded: bool = False

    async def _ensure_loaded(self) -> None:
        if not self._loaded:
            _log.info("Loading VideoSummarizer model=%s", self.model)
            self._loaded = True

    async def run(self, source: Any, **kwargs: Any) -> SummaryResult:
        """Generate a summary of the video."""
        await self._ensure_loaded()
        _log.debug("Summarizing video from %s", type(source).__name__)
        video = await self._load(source)
        raw_segments = await self._segment_and_describe(video)
        segments = [SummarySegment(**s) for s in raw_segments]
        full_text = " ".join(s.description for s in segments)
        key_moments = await self._extract_key_moments(video, segments)
        duration_orig = video.get("duration", 0.0)
        duration_sum = sum(s.end - s.start for s in segments) if segments else 0.0
        compression = duration_sum / duration_orig if duration_orig > 0 else 0.0
        return SummaryResult(
            segments=segments,
            full_summary=full_text[:self.max_summary_len],
            key_moments=key_moments,
            duration_original=duration_orig,
            duration_summary=duration_sum,
            compression_ratio=compression,
        )

    async def _load(self, source: Any) -> dict:
        if isinstance(source, (str, dict)):
            return source if isinstance(source, dict) else {"path": str(source)}
        raise TypeError(f"Unsupported source: {type(source).__name__}")

    async def _segment_and_describe(self, video: dict) -> list[dict]:
        _log.debug("Segmenting and describing video")
        return [{"start": 0.0, "end": 10.0, "description": "Video introduction", "importance": 0.8}]

    async def _extract_key_moments(self, video: dict, segments: list[SummarySegment]) -> list[dict]:
        return [
            {"time": s.start, "description": s.description, "importance": s.importance}
            for s in sorted(segments, key=lambda x: x.importance, reverse=True)[:5]
        ]

    async def shutdown(self) -> None:
        """Release video summarization model."""
        _log.info("Shutting down VideoSummarizer")
        self._loaded = False
