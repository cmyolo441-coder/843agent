"""nexus.multimodal.vision — Visual perception pipelines.

Provides image analysis, OCR, generation, editing, chart reading,
face detection, object detection, scene description, and screenshot
analysis capabilities.
"""
from __future__ import annotations

from .image_analyzer import ImageAnalyzer, AnalysisResult
from .ocr_engine import OCREngine, OCRResult
from .image_generator import ImageGenerator, GenerationResult
from .image_editor import ImageEditor, EditResult
from .chart_reader import ChartReader, ChartData
from .face_detector import FaceDetector, FaceResult
from .object_detector import ObjectDetector, DetectionResult
from .scene_descriptor import SceneDescriptor, SceneResult
from .screenshot_analyzer import ScreenshotAnalyzer, ScreenshotResult

__all__ = [
    "ImageAnalyzer",
    "AnalysisResult",
    "OCREngine",
    "OCRResult",
    "ImageGenerator",
    "GenerationResult",
    "ImageEditor",
    "EditResult",
    "ChartReader",
    "ChartData",
    "FaceDetector",
    "FaceResult",
    "ObjectDetector",
    "DetectionResult",
    "SceneDescriptor",
    "SceneResult",
    "ScreenshotAnalyzer",
    "ScreenshotResult",
]
