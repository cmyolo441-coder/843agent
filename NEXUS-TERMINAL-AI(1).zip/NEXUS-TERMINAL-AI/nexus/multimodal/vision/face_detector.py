"""Face detection and landmark localization in images.

The FaceDetector locates faces, extracts bounding boxes, landmarks,
and optionally computes embeddings for recognition tasks.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class FaceResult:
    """Detection result for a single face."""
    bbox: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)
    confidence: float = 0.0
    landmarks: list[tuple[float, float]] = field(default_factory=list)
    embedding: list[float] | None = None


@dataclass
class DetectionSummary:
    """Aggregated face detection results per image."""
    faces: list[FaceResult] = field(default_factory=list)
    count: int = 0
    processing_time: float = 0.0


class FaceDetector:
    """Detect faces in images with landmark localization."""

    def __init__(self, model: str = "retinaface", min_confidence: float = 0.5) -> None:
        self.model = model
        self.min_confidence = min_confidence
        self._loaded: bool = False

    async def _ensure_loaded(self) -> None:
        if not self._loaded:
            _log.info("Loading FaceDetector model=%s", self.model)
            self._loaded = True

    async def run(self, source: Any, **kwargs: Any) -> DetectionSummary:
        """Detect faces in the provided image."""
        await self._ensure_loaded()
        _log.debug("Detecting faces in image (min_conf=%.2f)", self.min_confidence)
        image = await self._load(source)
        raw_faces = await self._detect(image)
        faces = []
        for f in raw_faces:
            if f.get("confidence", 0) >= self.min_confidence:
                faces.append(FaceResult(
                    bbox=tuple(f.get("bbox", [0, 0, 0, 0])),
                    confidence=f.get("confidence", 0.0),
                    landmarks=[tuple(lm) for lm in f.get("landmarks", [])],
                ))
        return DetectionSummary(faces=faces, count=len(faces))

    async def _load(self, source: Any) -> dict:
        if isinstance(source, (str, bytes, dict)):
            return {}
        raise TypeError(f"Unsupported source: {type(source).__name__}")

    async def _detect(self, image: dict) -> list[dict]:
        return []

    async def shutdown(self) -> None:
        """Unload face detection model."""
        _log.info("Shutting down FaceDetector")
        self._loaded = False
