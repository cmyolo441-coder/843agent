"""Image editing operations — resize, crop, filter, overlay, inpaint.

The ImageEditor provides composable editing primitives that can be
chained together and applied to image sources.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class EditResult:
    """Result of an image editing operation."""
    image: bytes = b""
    format: str = "png"
    operations: list[str] = field(default_factory=list)
    width: int = 0
    height: int = 0


class ImageEditor:
    """Apply editing operations to images."""

    SUPPORTED_OPS: tuple[str, ...] = ("resize", "crop", "rotate", "flip",
                                       "grayscale", "blur", "overlay", "inpaint")

    def __init__(self) -> None:
        self._initialized: bool = False

    async def _ensure_initialized(self) -> None:
        if not self._initialized:
            _log.info("Initializing ImageEditor")
            self._initialized = True

    async def run(self, source: Any, **kwargs: Any) -> EditResult:
        """Apply editing operations to the source image."""
        await self._ensure_initialized()
        image = await self._load(source)
        ops = kwargs.get("operations", [])
        applied: list[str] = []
        for op in ops:
            name = op.get("type", "")
            if name not in self.SUPPORTED_OPS:
                _log.warning("Unsupported operation: %s", name)
                continue
            params = {k: v for k, v in op.items() if k != "type"}
            image = await self._apply_op(name, image, **params)
            applied.append(name)
        result_bytes = await self._serialize(image, kwargs.get("format", "png"))
        return EditResult(
            image=result_bytes, format=kwargs.get("format", "png"),
            operations=applied, width=image.get("width", 0),
            height=image.get("height", 0),
        )

    async def _load(self, source: Any) -> dict:
        if isinstance(source, (str, Path)):
            return {"path": str(source), "width": 0, "height": 0}
        if isinstance(source, bytes):
            return {"bytes": source, "width": 0, "height": 0}
        if isinstance(source, dict):
            return source
        raise TypeError(f"Unsupported source: {type(source).__name__}")

    async def _apply_op(self, name: str, image: dict, **params: Any) -> dict:
        _log.debug("Applying %s with %s", name, params)
        return {**image, "last_op": name}

    async def _serialize(self, image: dict, fmt: str) -> bytes:
        return b"edited_image_bytes"

    async def shutdown(self) -> None:
        """Clean up editor resources."""
        _log.info("Shutting down ImageEditor")
        self._initialized = False
