"""AI Image generation using diffusion models or cloud APIs.

The ImageGenerator produces images from text prompts with configurable
dimensions, style, and negative prompts.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class GenerationResult:
    """Result from an image generation request."""
    images: list[bytes] = field(default_factory=list)
    seed: int = 0
    prompt: str = ""
    width: int = 512
    height: int = 512
    steps: int = 20
    guidance_scale: float = 7.5
    elapsed: float = 0.0


class ImageGenerator:
    """Generate images from text prompts."""

    def __init__(self, model: str = "stable-diffusion", device: str = "auto") -> None:
        self.model = model
        self.device = device
        self._loaded: bool = False

    async def _ensure_loaded(self) -> None:
        if not self._loaded:
            _log.info("Loading image generator model=%s on %s", self.model, self.device)
            self._loaded = True

    async def run(self, prompt: str, **kwargs: Any) -> GenerationResult:
        """Generate an image from *prompt*."""
        await self._ensure_loaded()
        width = kwargs.get("width", 512)
        height = kwargs.get("height", 512)
        steps = kwargs.get("steps", 20)
        seed = kwargs.get("seed", int(time.time()))
        guidance = kwargs.get("guidance_scale", 7.5)
        negative = kwargs.get("negative_prompt", "")
        count = kwargs.get("n", 1)
        _log.info("Generating %d image(s) for prompt=%r", count, prompt[:60])
        start = time.perf_counter()
        images = await self._infer(prompt, negative, width, height, steps, seed, guidance, count)
        elapsed = time.perf_counter() - start
        _log.debug("Generated %d image(s) in %.2fs", len(images), elapsed)
        return GenerationResult(
            images=images, seed=seed, prompt=prompt,
            width=width, height=height, steps=steps,
            guidance_scale=guidance, elapsed=elapsed,
        )

    async def _infer(self, prompt: str, negative: str, width: int, height: int,
                     steps: int, seed: int, guidance: float, count: int) -> list[bytes]:
        _log.debug("Inference: %s (neg=%s) %dx%d steps=%d seed=%d",
                    prompt[:40], negative[:20], width, height, steps, seed)
        return [b"placeholder_image_data"] * count

    async def shutdown(self) -> None:
        """Unload models and free VRAM."""
        _log.info("Shutting down ImageGenerator")
        self._loaded = False
