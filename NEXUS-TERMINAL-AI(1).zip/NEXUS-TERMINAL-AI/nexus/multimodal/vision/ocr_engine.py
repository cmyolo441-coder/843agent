"""Optical Character Recognition — extract text from images and documents.

The OCREngine wraps OCR services (tesseract, cloud APIs, or local models)
and returns structured text with bounding boxes and confidence scores.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class TextBlock:
    """A single block of recognized text with position."""
    text: str
    confidence: float = 0.0
    x: int = 0
    y: int = 0
    width: int = 0
    height: int = 0


@dataclass
class OCRResult:
    """Full OCR extraction result."""
    full_text: str = ""
    blocks: list[TextBlock] = field(default_factory=list)
    language: str = "eng"
    page_count: int = 1
    processing_time: float = 0.0


class OCREngine:
    """Extract text from images using OCR."""

    def __init__(self, lang: str = "eng", engine: str = "tesseract") -> None:
        self.lang = lang
        self.engine = engine
        self._initialized: bool = False

    async def _ensure_initialized(self) -> None:
        if not self._initialized:
            _log.info("Initializing OCREngine (engine=%s, lang=%s)", self.engine, self.lang)
            self._initialized = True

    async def run(self, source: Any, **kwargs: Any) -> OCRResult:
        """Run OCR on the provided image source."""
        await self._ensure_initialized()
        lang = kwargs.get("lang", self.lang)
        _log.debug("Running OCR with lang=%s on %s", lang, type(source).__name__)
        image_data = await self._prepare_image(source)
        raw_blocks = await self._recognize(image_data, lang)
        blocks = [TextBlock(**b) for b in raw_blocks]
        full_text = "\n".join(b.text for b in blocks)
        return OCRResult(
            full_text=full_text,
            blocks=blocks,
            language=lang,
            processing_time=0.0,
        )

    async def _prepare_image(self, source: Any) -> dict:
        if isinstance(source, (str, Path)):
            return {"path": str(source)}
        if isinstance(source, bytes):
            return {"bytes": source}
        if isinstance(source, dict):
            return source
        raise TypeError(f"Unsupported OCR source: {type(source).__name__}")

    async def _recognize(self, image: dict, lang: str) -> list[dict]:
        _log.debug("OCR recognition on %s", image.get("path", "bytes"))
        return []

    async def detect_language(self, source: Any) -> list[str]:
        """Detect languages present in the image text."""
        await self._ensure_initialized()
        return [self.lang]

    async def shutdown(self) -> None:
        """Release OCR resources."""
        _log.info("Shutting down OCREngine")
        self._initialized = False
