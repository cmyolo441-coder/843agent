"""First-party Nexus plugins bundled with the distribution."""
