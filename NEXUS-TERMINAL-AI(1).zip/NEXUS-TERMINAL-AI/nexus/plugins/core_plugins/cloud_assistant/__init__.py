"""cloud_assistant plugin: AWS/GCP/Azure/K8s/Terraform/Ansible helpers."""
from nexus.plugins.core_plugins.cloud_assistant.plugin import CloudAssistantPlugin, setup

__all__ = ["CloudAssistantPlugin", "setup"]
