"""AnsibleHelper: drive ansible-playbook + inventory checks."""
from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class AnsibleHelper:
    inventory: str = "inventory.ini"

    def available(self) -> bool:
        return shutil.which("ansible-playbook") is not None

    def ping(self) -> bool:
        if not shutil.which("ansible"):
            return False
        proc = subprocess.run(
            ["ansible", "all", "-i", self.inventory, "-m", "ping"],
            capture_output=True, text=True, timeout=60,
        )
        return proc.returncode == 0

    def syntax_check(self, playbook: str) -> bool:
        if not self.available():
            return False
        proc = subprocess.run(
            ["ansible-playbook", "--syntax-check", "-i", self.inventory, playbook],
            capture_output=True, text=True, timeout=60,
        )
        return proc.returncode == 0

    def run(self, playbook: str, extra_vars: dict[str, str] | None = None, check: bool = False) -> int:
        if not self.available():
            return -1
        cmd = ["ansible-playbook", "-i", self.inventory, playbook]
        if check:
            cmd.append("--check")
        if extra_vars:
            for k, v in extra_vars.items():
                cmd.extend(["-e", f"{k}={v}"])
        proc = subprocess.run(cmd, timeout=1800)
        return proc.returncode
