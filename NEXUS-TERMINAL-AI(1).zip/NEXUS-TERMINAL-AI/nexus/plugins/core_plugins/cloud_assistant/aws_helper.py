"""AWSHelper: thin wrapper around the AWS CLI / boto3 for common operations."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class AWSHelper:
    region: str = "us-east-1"
    profile: str | None = None

    def _base(self) -> list[str]:
        cmd = ["aws", "--region", self.region, "--output", "json"]
        if self.profile:
            cmd.extend(["--profile", self.profile])
        return cmd

    def available(self) -> bool:
        return shutil.which("aws") is not None

    def list_s3_buckets(self) -> list[str]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["s3api", "list-buckets"],
                                  capture_output=True, text=True, timeout=30)
            data = json.loads(proc.stdout or "{}")
            return [b["Name"] for b in data.get("Buckets", [])]
        except Exception:
            logger.exception("list_s3_buckets failed")
            return []

    def list_instances(self) -> list[dict]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["ec2", "describe-instances"],
                                  capture_output=True, text=True, timeout=60)
            data = json.loads(proc.stdout or "{}")
            instances: list[dict] = []
            for r in data.get("Reservations", []):
                instances.extend(r.get("Instances", []))
            return instances
        except Exception:
            logger.exception("list_instances failed")
            return []

    def presign_url(self, bucket: str, key: str, expires: int = 3600) -> str:
        if not self.available():
            return ""
        cmd = self._base() + ["s3", "presign", f"s3://{bucket}/{key}", "--expires-in", str(expires)]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        return proc.stdout.strip()
