"""AzureHelper: thin wrapper over the `az` CLI."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class AzureHelper:
    subscription: str | None = None
    region: str = "eastus"

    def available(self) -> bool:
        return shutil.which("az") is not None

    def _base(self) -> list[str]:
        cmd = ["az", "--output", "json"]
        if self.subscription:
            cmd.extend(["--subscription", self.subscription])
        return cmd

    def list_resource_groups(self) -> list[dict]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["group", "list"],
                                  capture_output=True, text=True, timeout=30)
            return json.loads(proc.stdout or "[]")
        except Exception:
            logger.exception("list_resource_groups failed")
            return []

    def list_vms(self) -> list[dict]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["vm", "list", "-d"],
                                  capture_output=True, text=True, timeout=60)
            return json.loads(proc.stdout or "[]")
        except Exception:
            logger.exception("list_vms failed")
            return []

    def list_storage_accounts(self) -> list[dict]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["storage", "account", "list"],
                                  capture_output=True, text=True, timeout=60)
            return json.loads(proc.stdout or "[]")
        except Exception:
            return []
