"""GCPHelper: gcloud CLI wrapper for common Google Cloud queries."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class GCPHelper:
    project: str = ""
    region: str = "us-central1"

    def available(self) -> bool:
        return shutil.which("gcloud") is not None

    def _base(self) -> list[str]:
        cmd = ["gcloud", "--format=json", f"--quiet"]
        if self.project:
            cmd.append(f"--project={self.project}")
        return cmd

    def list_projects(self) -> list[dict]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["projects", "list"],
                                  capture_output=True, text=True, timeout=30)
            return json.loads(proc.stdout or "[]")
        except Exception:
            logger.exception("list_projects failed")
            return []

    def list_instances(self) -> list[dict]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["compute", "instances", "list"],
                                  capture_output=True, text=True, timeout=60)
            return json.loads(proc.stdout or "[]")
        except Exception:
            logger.exception("list_instances failed")
            return []

    def list_buckets(self) -> list[str]:
        if not shutil.which("gsutil"):
            return []
        try:
            proc = subprocess.run(["gsutil", "ls"], capture_output=True, text=True, timeout=30)
            return [line.strip() for line in proc.stdout.splitlines() if line.strip()]
        except Exception:
            return []
