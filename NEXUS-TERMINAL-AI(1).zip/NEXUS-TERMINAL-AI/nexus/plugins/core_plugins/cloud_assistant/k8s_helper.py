"""K8sHelper: kubectl CLI wrapper for common cluster queries."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class K8sHelper:
    context: str = ""
    namespace: str = "default"

    def available(self) -> bool:
        return shutil.which("kubectl") is not None

    def _base(self) -> list[str]:
        cmd = ["kubectl", "-o", "json", "-n", self.namespace]
        if self.context:
            cmd.extend(["--context", self.context])
        return cmd

    def list_pods(self) -> list[dict]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["get", "pods"],
                                  capture_output=True, text=True, timeout=30)
            return json.loads(proc.stdout or "{}").get("items", [])
        except Exception:
            logger.exception("list_pods failed")
            return []

    def list_deployments(self) -> list[dict]:
        if not self.available():
            return []
        try:
            proc = subprocess.run(self._base() + ["get", "deployments"],
                                  capture_output=True, text=True, timeout=30)
            return json.loads(proc.stdout or "{}").get("items", [])
        except Exception:
            return []

    def logs(self, pod: str, container: str | None = None, tail: int = 100) -> str:
        if not self.available():
            return ""
        cmd = ["kubectl", "-n", self.namespace, "logs", pod, f"--tail={tail}"]
        if container:
            cmd.extend(["-c", container])
        if self.context:
            cmd.extend(["--context", self.context])
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout
        except Exception:
            return ""
