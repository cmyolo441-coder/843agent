"""CloudAssistantPlugin: aggregate cloud/IaC helpers under a single facade."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from nexus.plugins.core_plugins.cloud_assistant.aws_helper import AWSHelper
from nexus.plugins.core_plugins.cloud_assistant.gcp_helper import GCPHelper
from nexus.plugins.core_plugins.cloud_assistant.azure_helper import AzureHelper
from nexus.plugins.core_plugins.cloud_assistant.k8s_helper import K8sHelper
from nexus.plugins.core_plugins.cloud_assistant.terraform_helper import TerraformHelper
from nexus.plugins.core_plugins.cloud_assistant.ansible_helper import AnsibleHelper

logger = logging.getLogger(__name__)


@dataclass
class CloudAssistantPlugin:
    name: str = "cloud_assistant"
    version: str = "1.0.0"
    aws: AWSHelper = field(default_factory=AWSHelper)
    gcp: GCPHelper = field(default_factory=GCPHelper)
    azure: AzureHelper = field(default_factory=AzureHelper)
    k8s: K8sHelper = field(default_factory=K8sHelper)
    terraform: TerraformHelper = field(default_factory=TerraformHelper)
    ansible: AnsibleHelper = field(default_factory=AnsibleHelper)


def setup() -> CloudAssistantPlugin:
    logger.info("cloud_assistant initialized")
    return CloudAssistantPlugin()
