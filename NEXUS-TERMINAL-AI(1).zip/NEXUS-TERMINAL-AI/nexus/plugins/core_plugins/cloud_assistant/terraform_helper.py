"""TerraformHelper: drive terraform CLI for plan/apply/show/state operations."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class TerraformHelper:
    workdir: str = "."

    def available(self) -> bool:
        return shutil.which("terraform") is not None

    def _run(self, *args: str, timeout: int = 600) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["terraform", *args], cwd=self.workdir,
            capture_output=True, text=True, timeout=timeout,
        )

    def init(self) -> bool:
        if not self.available():
            return False
        return self._run("init", "-input=false", "-no-color").returncode == 0

    def plan(self, out: str = "plan.tfplan") -> bool:
        if not self.available():
            return False
        return self._run("plan", "-input=false", "-no-color", f"-out={out}").returncode == 0

    def apply(self, plan_file: str = "plan.tfplan") -> bool:
        if not self.available():
            return False
        return self._run("apply", "-input=false", "-no-color", plan_file).returncode == 0

    def show_plan(self, plan_file: str = "plan.tfplan") -> dict:
        if not self.available():
            return {}
        proc = self._run("show", "-json", plan_file)
        try:
            return json.loads(proc.stdout or "{}")
        except json.JSONDecodeError:
            return {}

    def list_resources(self) -> list[str]:
        if not self.available():
            return []
        proc = self._run("state", "list")
        return [line.strip() for line in proc.stdout.splitlines() if line.strip()]
