"""code_assistant plugin: lint/type/security/complexity analyzers + formatters."""
from nexus.plugins.core_plugins.code_assistant.plugin import CodeAssistantPlugin, setup

__all__ = ["CodeAssistantPlugin", "setup"]
