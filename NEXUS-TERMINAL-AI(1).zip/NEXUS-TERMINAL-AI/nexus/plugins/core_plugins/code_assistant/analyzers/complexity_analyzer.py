"""ComplexityAnalyzer: cyclomatic complexity via radon."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from typing import Any

logger = logging.getLogger(__name__)


class ComplexityAnalyzer:
    """Wraps the radon CLI for cyclomatic complexity analysis."""

    def __init__(self, executable: str = "radon", threshold: int = 10) -> None:
        self.executable = executable
        self.threshold = threshold

    def available(self) -> bool:
        return shutil.which(self.executable) is not None

    def run(self, path: str) -> dict[str, Any]:
        if not self.available():
            return self._fallback(path)
        cmd = [self.executable, "cc", "-j", "-s", path]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            data = json.loads(proc.stdout or "{}")
        except (subprocess.TimeoutExpired, json.JSONDecodeError):
            return {"available": True, "files": {}, "error": "invocation_failed"}
        flagged = []
        for fname, blocks in data.items():
            for b in blocks:
                if b.get("complexity", 0) >= self.threshold:
                    flagged.append({"file": fname, "name": b.get("name"), "complexity": b.get("complexity")})
        return {"available": True, "files": data, "flagged": flagged, "threshold": self.threshold}

    def _fallback(self, path: str) -> dict[str, Any]:
        """Very rough complexity proxy: count branches per file."""
        try:
            text = open(path).read()
        except OSError:
            return {"available": False, "flagged": []}
        branches = sum(text.count(k) for k in ("if ", "elif ", "for ", "while ", "except", "case "))
        return {"available": False, "branches": branches, "flagged": []}
