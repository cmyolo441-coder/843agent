"""LintAnalyzer: runs pylint as a subprocess and parses its JSON output."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class LintFinding:
    path: str
    line: int
    column: int
    code: str
    message: str
    severity: str


class LintAnalyzer:
    """Wraps the pylint CLI for one-shot file analysis."""

    def __init__(self, executable: str = "pylint") -> None:
        self.executable = executable

    def available(self) -> bool:
        return shutil.which(self.executable) is not None

    def run(self, path: str, args: list[str] | None = None) -> dict[str, Any]:
        if not self.available():
            logger.warning("pylint not on PATH; returning empty analysis")
            return {"available": False, "findings": []}
        cmd = [self.executable, "--output-format=json", path]
        if args:
            cmd.extend(args)
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            payload = json.loads(proc.stdout or "[]")
        except (subprocess.TimeoutExpired, json.JSONDecodeError):
            logger.exception("pylint invocation failed for %s", path)
            return {"available": True, "findings": [], "error": "invocation_failed"}
        findings = [
            LintFinding(
                path=item.get("path", path),
                line=int(item.get("line", 0)),
                column=int(item.get("column", 0)),
                code=item.get("message-id", ""),
                message=item.get("message", ""),
                severity=item.get("type", "info"),
            ).__dict__
            for item in payload
        ]
        return {"available": True, "findings": findings, "count": len(findings)}
