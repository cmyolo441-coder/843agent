"""SecurityAnalyzer: runs bandit for Python security smell detection."""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from typing import Any

logger = logging.getLogger(__name__)


class SecurityAnalyzer:
    """Wraps the bandit CLI."""

    def __init__(self, executable: str = "bandit", severity: str = "medium") -> None:
        self.executable = executable
        self.severity = severity

    def available(self) -> bool:
        return shutil.which(self.executable) is not None

    def run(self, path: str) -> dict[str, Any]:
        if not self.available():
            return {"available": False, "issues": []}
        cmd = [self.executable, "-r", path, "-f", "json", "-q", "-l"]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            data = json.loads(proc.stdout or "{}")
        except (subprocess.TimeoutExpired, json.JSONDecodeError):
            logger.exception("bandit failed for %s", path)
            return {"available": True, "issues": [], "error": "invocation_failed"}
        issues = [
            {
                "file": r.get("filename"),
                "line": r.get("line_number"),
                "test_id": r.get("test_id"),
                "severity": r.get("issue_severity"),
                "confidence": r.get("issue_confidence"),
                "message": r.get("issue_text"),
            }
            for r in data.get("results", [])
            if r.get("issue_severity", "LOW").lower() != "low" or self.severity == "low"
        ]
        return {"available": True, "issues": issues, "count": len(issues)}
