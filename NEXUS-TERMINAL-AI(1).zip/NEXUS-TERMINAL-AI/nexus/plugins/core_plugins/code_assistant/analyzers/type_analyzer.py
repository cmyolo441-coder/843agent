"""TypeAnalyzer: runs mypy and parses the stdout report."""
from __future__ import annotations

import logging
import re
import shutil
import subprocess
from typing import Any

logger = logging.getLogger(__name__)

_LINE_RE = re.compile(r"^(?P<file>[^:]+):(?P<line>\d+):(?:(?P<col>\d+):)?\s*(?P<sev>\w+):\s*(?P<msg>.*)$")


class TypeAnalyzer:
    """Lightweight wrapper around mypy."""

    def __init__(self, executable: str = "mypy", strict: bool = False) -> None:
        self.executable = executable
        self.strict = strict

    def available(self) -> bool:
        return shutil.which(self.executable) is not None

    def run(self, path: str) -> dict[str, Any]:
        if not self.available():
            return {"available": False, "errors": []}
        cmd = [self.executable, "--no-color-output", "--show-column-numbers"]
        if self.strict:
            cmd.append("--strict")
        cmd.append(path)
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        except subprocess.TimeoutExpired:
            return {"available": True, "errors": [], "error": "timeout"}
        errors: list[dict[str, Any]] = []
        for line in proc.stdout.splitlines():
            m = _LINE_RE.match(line)
            if m:
                errors.append({
                    "file": m.group("file"),
                    "line": int(m.group("line")),
                    "col": int(m.group("col") or 0),
                    "severity": m.group("sev"),
                    "message": m.group("msg"),
                })
        return {"available": True, "errors": errors, "count": len(errors), "exit_code": proc.returncode}
