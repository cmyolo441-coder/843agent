"""BlackFormatter: format Python source via the `black` CLI."""
from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


class BlackFormatter:
    """Wraps black for in-place or piped formatting."""

    def __init__(self, line_length: int = 100, executable: str = "black") -> None:
        self.line_length = line_length
        self.executable = executable

    def available(self) -> bool:
        return shutil.which(self.executable) is not None

    def format(self, path: str) -> str:
        text = Path(path).read_text()
        if not self.available():
            logger.warning("black not on PATH; returning original")
            return text
        cmd = [self.executable, "-q", "-l", str(self.line_length), "-"]
        try:
            proc = subprocess.run(cmd, input=text, capture_output=True, text=True, timeout=60, check=False)
            return proc.stdout or text
        except subprocess.TimeoutExpired:
            return text

    def format_string(self, source: str) -> str:
        if not self.available():
            return source
        proc = subprocess.run(
            [self.executable, "-q", "-l", str(self.line_length), "-"],
            input=source, capture_output=True, text=True, timeout=60,
        )
        return proc.stdout or source
