"""IsortFormatter: sort Python imports via the `isort` CLI."""
from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


class IsortFormatter:
    """Wraps isort."""

    def __init__(self, profile: str = "black", executable: str = "isort") -> None:
        self.profile = profile
        self.executable = executable

    def available(self) -> bool:
        return shutil.which(self.executable) is not None

    def format(self, path: str) -> str:
        text = Path(path).read_text()
        if not self.available():
            return text
        cmd = [self.executable, f"--profile={self.profile}", "-"]
        try:
            proc = subprocess.run(cmd, input=text, capture_output=True, text=True, timeout=60)
            return proc.stdout or text
        except subprocess.TimeoutExpired:
            return text

    def format_string(self, source: str) -> str:
        if not self.available():
            return source
        proc = subprocess.run(
            [self.executable, f"--profile={self.profile}", "-"],
            input=source, capture_output=True, text=True, timeout=60,
        )
        return proc.stdout or source
