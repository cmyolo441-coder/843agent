"""PrettierFormatter: format JS/TS/JSON/MD via the `prettier` Node CLI."""
from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


class PrettierFormatter:
    """Wraps prettier."""

    def __init__(self, print_width: int = 100, executable: str = "prettier") -> None:
        self.print_width = print_width
        self.executable = executable

    def available(self) -> bool:
        return shutil.which(self.executable) is not None

    def format(self, path: str) -> str:
        text = Path(path).read_text()
        if not self.available():
            logger.warning("prettier not on PATH; returning original")
            return text
        cmd = [self.executable, "--stdin-filepath", path, f"--print-width={self.print_width}"]
        try:
            proc = subprocess.run(cmd, input=text, capture_output=True, text=True, timeout=60)
            return proc.stdout or text
        except subprocess.TimeoutExpired:
            return text
