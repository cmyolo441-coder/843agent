"""CodeAssistantPlugin: orchestrates analyzers + formatters for source code."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from nexus.plugins.core_plugins.code_assistant.analyzers.lint_analyzer import LintAnalyzer
from nexus.plugins.core_plugins.code_assistant.analyzers.type_analyzer import TypeAnalyzer
from nexus.plugins.core_plugins.code_assistant.analyzers.security_analyzer import SecurityAnalyzer
from nexus.plugins.core_plugins.code_assistant.analyzers.complexity_analyzer import ComplexityAnalyzer
from nexus.plugins.core_plugins.code_assistant.formatters.black_formatter import BlackFormatter
from nexus.plugins.core_plugins.code_assistant.formatters.isort_formatter import IsortFormatter
from nexus.plugins.core_plugins.code_assistant.formatters.prettier_formatter import PrettierFormatter

logger = logging.getLogger(__name__)


@dataclass
class CodeAssistantPlugin:
    name: str = "code_assistant"
    version: str = "1.0.0"
    analyzers: dict[str, Any] = field(default_factory=dict)
    formatters: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.analyzers = {
            "lint": LintAnalyzer(),
            "type": TypeAnalyzer(),
            "security": SecurityAnalyzer(),
            "complexity": ComplexityAnalyzer(),
        }
        self.formatters = {
            "black": BlackFormatter(),
            "isort": IsortFormatter(),
            "prettier": PrettierFormatter(),
        }

    def analyze(self, path: str | Path) -> dict[str, Any]:
        return {k: a.run(str(path)) for k, a in self.analyzers.items()}

    def format(self, path: str | Path, tool: str = "black") -> str:
        return self.formatters[tool].format(str(path))


def setup() -> CodeAssistantPlugin:
    logger.info("code_assistant plugin initialized")
    return CodeAssistantPlugin()
