"""data_analyzer plugin: statistics, ML pipelines, visualization, reporting."""
from nexus.plugins.core_plugins.data_analyzer.plugin import DataAnalyzerPlugin, setup

__all__ = ["DataAnalyzerPlugin", "setup"]
