"""MLPipeline: lightweight scikit-learn-style train/eval orchestration stub."""
from __future__ import annotations

import logging
import random
from dataclasses import dataclass, field
from typing import Any, Sequence

logger = logging.getLogger(__name__)


@dataclass
class TrainResult:
    model_name: str
    accuracy: float
    metrics: dict[str, float] = field(default_factory=dict)


class MLPipeline:
    """A tiny pipeline placeholder: split, train, evaluate without external deps."""

    def __init__(self, test_size: float = 0.2, seed: int = 42) -> None:
        self.test_size = test_size
        self.rng = random.Random(seed)

    def split(self, X: Sequence[Any], y: Sequence[Any]) -> tuple[list, list, list, list]:
        if len(X) != len(y):
            raise ValueError("X and y length mismatch")
        idx = list(range(len(X)))
        self.rng.shuffle(idx)
        cut = int(len(idx) * (1 - self.test_size))
        train_idx, test_idx = idx[:cut], idx[cut:]
        Xt = [X[i] for i in train_idx]
        yt = [y[i] for i in train_idx]
        Xv = [X[i] for i in test_idx]
        yv = [y[i] for i in test_idx]
        return Xt, Xv, yt, yv

    def train(self, X: Sequence[Any], y: Sequence[Any], model: str = "random_forest") -> TrainResult:
        """Baseline majority-class classifier for the demo stub."""
        Xt, Xv, yt, yv = self.split(X, y)
        if not yt:
            return TrainResult(model, 0.0)
        majority = max(set(yt), key=yt.count)
        correct = sum(1 for label in yv if label == majority)
        acc = correct / len(yv) if yv else 0.0
        return TrainResult(model, accuracy=acc, metrics={"baseline_majority": acc, "support": len(yv)})

    def cross_validate(self, X: Sequence[Any], y: Sequence[Any], folds: int = 5) -> list[float]:
        scores = []
        for _ in range(folds):
            r = self.train(X, y)
            scores.append(r.accuracy)
        return scores
