"""DataAnalyzerPlugin: facade combining stats, ML pipeline, viz and reporting."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from nexus.plugins.core_plugins.data_analyzer.stat_analyzer import StatAnalyzer
from nexus.plugins.core_plugins.data_analyzer.ml_pipeline import MLPipeline
from nexus.plugins.core_plugins.data_analyzer.visualization import Visualizer
from nexus.plugins.core_plugins.data_analyzer.report_generator import ReportGenerator

logger = logging.getLogger(__name__)


@dataclass
class DataAnalyzerPlugin:
    name: str = "data_analyzer"
    version: str = "1.0.0"
    stats: StatAnalyzer = field(default_factory=StatAnalyzer)
    ml: MLPipeline = field(default_factory=MLPipeline)
    viz: Visualizer = field(default_factory=Visualizer)
    report: ReportGenerator = field(default_factory=ReportGenerator)


def setup() -> DataAnalyzerPlugin:
    logger.info("data_analyzer initialized")
    return DataAnalyzerPlugin()
