"""ReportGenerator: assemble markdown/HTML reports from analysis artifacts."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ReportSection:
    title: str
    body: str
    artifacts: list[str] = field(default_factory=list)


class ReportGenerator:
    """Builds reports in markdown or simple HTML."""

    def __init__(self, format: str = "markdown") -> None:
        self.format = format
        self.sections: list[ReportSection] = []

    def add(self, title: str, body: str, artifacts: list[str] | None = None) -> None:
        self.sections.append(ReportSection(title=title, body=body, artifacts=artifacts or []))

    def add_dict(self, title: str, data: dict[str, Any]) -> None:
        body = "\n".join(f"- **{k}**: {v}" for k, v in data.items())
        self.sections.append(ReportSection(title=title, body=body))

    def render_markdown(self) -> str:
        out = ["# Data Analysis Report", ""]
        for s in self.sections:
            out.append(f"## {s.title}")
            out.append("")
            out.append(s.body)
            if s.artifacts:
                out.append("")
                out.append("**Artifacts:** " + ", ".join(s.artifacts))
            out.append("")
        return "\n".join(out)

    def render_html(self) -> str:
        parts = ["<html><body><h1>Data Analysis Report</h1>"]
        for s in self.sections:
            parts.append(f"<h2>{s.title}</h2><pre>{s.body}</pre>")
        parts.append("</body></html>")
        return "\n".join(parts)

    def render(self) -> str:
        return self.render_html() if self.format == "html" else self.render_markdown()

    def save(self, path: str | Path) -> Path:
        p = Path(path)
        p.write_text(self.render())
        logger.info("Report saved to %s", p)
        return p
