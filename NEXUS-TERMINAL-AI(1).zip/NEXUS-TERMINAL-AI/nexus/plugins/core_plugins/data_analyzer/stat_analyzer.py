"""StatAnalyzer: pure-Python descriptive statistics over numeric sequences."""
from __future__ import annotations

import logging
import math
import statistics
from dataclasses import dataclass
from typing import Iterable, Sequence

logger = logging.getLogger(__name__)


@dataclass
class Summary:
    n: int
    mean: float
    median: float
    stdev: float
    minimum: float
    maximum: float
    skewness: float
    kurtosis: float


class StatAnalyzer:
    """Compute summary stats without numpy/pandas dependencies."""

    def summarize(self, data: Sequence[float]) -> Summary:
        if not data:
            return Summary(0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        n = len(data)
        mean = statistics.fmean(data)
        median = statistics.median(data)
        stdev = statistics.pstdev(data) if n > 1 else 0.0
        m3 = sum((x - mean) ** 3 for x in data) / n
        m4 = sum((x - mean) ** 4 for x in data) / n
        skew = m3 / (stdev ** 3) if stdev else 0.0
        kurt = (m4 / (stdev ** 4) - 3) if stdev else 0.0
        return Summary(n, mean, median, stdev, min(data), max(data), skew, kurt)

    def correlate(self, x: Sequence[float], y: Sequence[float]) -> float:
        if len(x) != len(y) or len(x) < 2:
            return 0.0
        mx, my = statistics.fmean(x), statistics.fmean(y)
        num = sum((a - mx) * (b - my) for a, b in zip(x, y))
        denx = math.sqrt(sum((a - mx) ** 2 for a in x))
        deny = math.sqrt(sum((b - my) ** 2 for b in y))
        return num / (denx * deny) if denx and deny else 0.0

    def quantiles(self, data: Sequence[float], n: int = 4) -> list[float]:
        if len(data) < 2:
            return list(data)
        return statistics.quantiles(data, n=n)

    def histogram(self, data: Iterable[float], bins: int = 10) -> list[int]:
        items = list(data)
        if not items:
            return [0] * bins
        lo, hi = min(items), max(items)
        if lo == hi:
            return [len(items)] + [0] * (bins - 1)
        width = (hi - lo) / bins
        counts = [0] * bins
        for v in items:
            idx = min(bins - 1, int((v - lo) / width))
            counts[idx] += 1
        return counts
