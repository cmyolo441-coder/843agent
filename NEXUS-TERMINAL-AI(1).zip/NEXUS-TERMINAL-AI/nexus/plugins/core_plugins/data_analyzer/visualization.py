"""Visualizer: render simple ASCII charts (and optionally matplotlib if available)."""
from __future__ import annotations

import logging
from typing import Iterable, Sequence

logger = logging.getLogger(__name__)


class Visualizer:
    """ASCII-first visualizer; falls back to matplotlib if installed."""

    def bar(self, labels: Sequence[str], values: Sequence[float], width: int = 40) -> str:
        if not values:
            return ""
        max_v = max(values) or 1
        lines = []
        for label, v in zip(labels, values):
            bar = "█" * int((v / max_v) * width)
            lines.append(f"{label:<12} | {bar} {v:.2f}")
        return "\n".join(lines)

    def line(self, values: Sequence[float], height: int = 10) -> str:
        if not values:
            return ""
        lo, hi = min(values), max(values)
        if lo == hi:
            return "─" * len(values)
        grid = [[" "] * len(values) for _ in range(height)]
        for x, v in enumerate(values):
            y = height - 1 - int((v - lo) / (hi - lo) * (height - 1))
            grid[y][x] = "•"
        return "\n".join("".join(row) for row in grid)

    def histogram(self, counts: Iterable[int], width: int = 30) -> str:
        items = list(counts)
        if not items:
            return ""
        max_c = max(items) or 1
        lines = []
        for i, c in enumerate(items):
            bar = "▇" * int((c / max_c) * width)
            lines.append(f"bin{i:>2} | {bar} {c}")
        return "\n".join(lines)
