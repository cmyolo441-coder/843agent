"""database_assistant plugin: query building, schema analysis, migrations, optimization."""
from nexus.plugins.core_plugins.database_assistant.plugin import DatabaseAssistantPlugin, setup

__all__ = ["DatabaseAssistantPlugin", "setup"]
