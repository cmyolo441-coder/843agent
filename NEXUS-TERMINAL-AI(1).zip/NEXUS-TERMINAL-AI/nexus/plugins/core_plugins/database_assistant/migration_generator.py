"""MigrationGenerator: emit forward/backward SQL from schema diffs."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path

from nexus.plugins.core_plugins.database_assistant.schema_analyzer import TableSchema

logger = logging.getLogger(__name__)


@dataclass
class Migration:
    name: str
    up: str
    down: str

    def write(self, dest_dir: str | Path) -> Path:
        path = Path(dest_dir)
        path.mkdir(parents=True, exist_ok=True)
        f = path / f"{self.name}.sql"
        f.write_text(f"-- up\n{self.up}\n\n-- down\n{self.down}\n")
        return f


class MigrationGenerator:
    """Build CREATE/ALTER/DROP statements from schema diffs."""

    def __init__(self, dialect: str = "postgresql") -> None:
        self.dialect = dialect

    def _ts_name(self, label: str) -> str:
        return f"{int(time.time())}_{label.lower().replace(' ', '_')}"

    def create_table(self, schema: TableSchema) -> Migration:
        cols = []
        for c in schema.columns:
            parts = [c.name, c.type]
            if not c.nullable:
                parts.append("NOT NULL")
            if c.primary_key:
                parts.append("PRIMARY KEY")
            cols.append("  " + " ".join(parts))
        up = f"CREATE TABLE {schema.name} (\n" + ",\n".join(cols) + "\n);"
        down = f"DROP TABLE {schema.name};"
        return Migration(self._ts_name(f"create_{schema.name}"), up, down)

    def add_column(self, table: str, column: str, sql_type: str) -> Migration:
        up = f"ALTER TABLE {table} ADD COLUMN {column} {sql_type};"
        down = f"ALTER TABLE {table} DROP COLUMN {column};"
        return Migration(self._ts_name(f"add_{column}_to_{table}"), up, down)

    def diff_to_migrations(self, before: TableSchema, after: TableSchema) -> list[Migration]:
        before_cols = {c.name: c for c in before.columns}
        after_cols = {c.name: c for c in after.columns}
        migs: list[Migration] = []
        for name in after_cols.keys() - before_cols.keys():
            migs.append(self.add_column(after.name, name, after_cols[name].type))
        return migs
