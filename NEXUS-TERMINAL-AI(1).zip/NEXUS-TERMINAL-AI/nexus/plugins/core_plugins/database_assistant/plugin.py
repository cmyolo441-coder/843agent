"""DatabaseAssistantPlugin: orchestrate query, schema, migration and optimization tools."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from nexus.plugins.core_plugins.database_assistant.query_builder import QueryBuilder
from nexus.plugins.core_plugins.database_assistant.schema_analyzer import SchemaAnalyzer
from nexus.plugins.core_plugins.database_assistant.migration_generator import MigrationGenerator
from nexus.plugins.core_plugins.database_assistant.query_optimizer import QueryOptimizer

logger = logging.getLogger(__name__)


@dataclass
class DatabaseAssistantPlugin:
    name: str = "database_assistant"
    version: str = "1.0.0"
    query: QueryBuilder = field(default_factory=QueryBuilder)
    schema: SchemaAnalyzer = field(default_factory=SchemaAnalyzer)
    migrations: MigrationGenerator = field(default_factory=MigrationGenerator)
    optimizer: QueryOptimizer = field(default_factory=QueryOptimizer)


def setup() -> DatabaseAssistantPlugin:
    logger.info("database_assistant initialized")
    return DatabaseAssistantPlugin()
