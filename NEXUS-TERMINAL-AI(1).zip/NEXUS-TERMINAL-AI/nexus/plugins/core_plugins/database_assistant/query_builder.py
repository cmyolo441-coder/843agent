"""QueryBuilder: fluent SQL builder with parameter binding."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class QueryBuilder:
    """Compose parameterised SELECT statements safely."""

    _table: str = ""
    _columns: list[str] = field(default_factory=lambda: ["*"])
    _where: list[tuple[str, Any]] = field(default_factory=list)
    _joins: list[str] = field(default_factory=list)
    _order: list[str] = field(default_factory=list)
    _limit: int | None = None
    _offset: int | None = None

    def select(self, *columns: str) -> "QueryBuilder":
        self._columns = list(columns) or ["*"]
        return self

    def from_(self, table: str) -> "QueryBuilder":
        self._table = table
        return self

    def where(self, predicate: str, value: Any = None) -> "QueryBuilder":
        self._where.append((predicate, value))
        return self

    def join(self, clause: str) -> "QueryBuilder":
        self._joins.append(clause)
        return self

    def order_by(self, *columns: str) -> "QueryBuilder":
        self._order.extend(columns)
        return self

    def limit(self, n: int, offset: int | None = None) -> "QueryBuilder":
        self._limit, self._offset = n, offset
        return self

    def build(self) -> tuple[str, list[Any]]:
        if not self._table:
            raise ValueError("table is required")
        parts = [f"SELECT {', '.join(self._columns)}", f"FROM {self._table}"]
        parts.extend(self._joins)
        params: list[Any] = []
        if self._where:
            wh = " AND ".join(p for p, _ in self._where)
            parts.append(f"WHERE {wh}")
            params.extend(v for _, v in self._where if v is not None)
        if self._order:
            parts.append("ORDER BY " + ", ".join(self._order))
        if self._limit is not None:
            parts.append(f"LIMIT {self._limit}")
        if self._offset is not None:
            parts.append(f"OFFSET {self._offset}")
        return " ".join(parts), params
