"""QueryOptimizer: detect bad SQL patterns and propose index/rewrite hints."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class Hint:
    severity: str
    message: str


class QueryOptimizer:
    """Static SQL inspection for common anti-patterns."""

    def analyze(self, sql: str) -> list[Hint]:
        text = sql.strip()
        upper = text.upper()
        hints: list[Hint] = []

        if re.search(r"\bSELECT\s+\*", upper):
            hints.append(Hint("warning", "Avoid SELECT * — list explicit columns"))
        if "LIKE '%" in upper:
            hints.append(Hint("warning", "Leading % in LIKE prevents index usage"))
        if "NOT IN" in upper:
            hints.append(Hint("info", "NOT IN with NULLs may surprise — consider NOT EXISTS"))
        if "ORDER BY" in upper and "LIMIT" not in upper:
            hints.append(Hint("info", "ORDER BY without LIMIT may sort entire result"))
        if re.search(r"\bOR\b", upper) and "WHERE" in upper:
            hints.append(Hint("info", "OR conditions often defeat indexes; consider UNION ALL"))
        if "DISTINCT" in upper and "JOIN" in upper:
            hints.append(Hint("info", "DISTINCT after JOIN may indicate missing predicate"))
        if upper.count("JOIN") >= 5:
            hints.append(Hint("warning", f"{upper.count('JOIN')} joins — consider materialized view"))
        return hints

    def suggest_indexes(self, sql: str) -> list[str]:
        cols = re.findall(r"WHERE\s+([\w\.]+)\s*=", sql, flags=re.IGNORECASE)
        return [f"CREATE INDEX ON ({c});" for c in cols]
