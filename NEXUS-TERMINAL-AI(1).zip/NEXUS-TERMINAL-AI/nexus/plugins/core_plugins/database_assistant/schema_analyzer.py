"""SchemaAnalyzer: introspect table definitions for indexes, FKs, and bloat hints."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class Column:
    name: str
    type: str
    nullable: bool = True
    primary_key: bool = False


@dataclass
class TableSchema:
    name: str
    columns: list[Column] = field(default_factory=list)
    indexes: list[str] = field(default_factory=list)
    foreign_keys: list[tuple[str, str]] = field(default_factory=list)


class SchemaAnalyzer:
    """Inspect a schema dictionary and emit improvement suggestions."""

    def analyze(self, schema: TableSchema) -> dict[str, list[str]]:
        suggestions: list[str] = []
        warnings: list[str] = []
        pk = [c for c in schema.columns if c.primary_key]
        if not pk:
            warnings.append(f"{schema.name}: no primary key")
        for col in schema.columns:
            if col.name.endswith("_id") and col.name not in schema.indexes:
                suggestions.append(f"add index on {schema.name}.{col.name}")
            if col.type.lower() == "text" and not col.nullable:
                suggestions.append(f"{schema.name}.{col.name}: consider VARCHAR with bound")
        for fk_col, ref in schema.foreign_keys:
            if fk_col not in schema.indexes:
                suggestions.append(f"index FK {schema.name}.{fk_col} -> {ref}")
        return {"suggestions": suggestions, "warnings": warnings}

    def diff(self, before: TableSchema, after: TableSchema) -> dict[str, list[str]]:
        before_names = {c.name for c in before.columns}
        after_names = {c.name for c in after.columns}
        return {
            "added": sorted(after_names - before_names),
            "removed": sorted(before_names - after_names),
            "kept": sorted(before_names & after_names),
        }
