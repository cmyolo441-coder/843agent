"""git_assistant plugin: conventional commits, PR review, conflict resolve, changelog."""
from nexus.plugins.core_plugins.git_assistant.plugin import GitAssistantPlugin, setup

__all__ = ["GitAssistantPlugin", "setup"]
