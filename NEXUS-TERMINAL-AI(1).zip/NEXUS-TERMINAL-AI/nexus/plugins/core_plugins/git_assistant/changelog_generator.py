"""ChangelogGenerator: build a markdown changelog from conventional commit history."""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable

logger = logging.getLogger(__name__)

_COMMIT_RE = re.compile(
    r"^(?P<type>feat|fix|chore|docs|refactor|test|perf|build|ci|style|revert)"
    r"(?:\((?P<scope>[^)]+)\))?(?P<breaking>!)?:\s*(?P<subject>.+)$"
)
_TYPE_TITLES = {
    "feat": "Features",
    "fix": "Bug Fixes",
    "perf": "Performance",
    "refactor": "Refactoring",
    "docs": "Documentation",
    "test": "Tests",
    "build": "Build",
    "ci": "CI",
    "style": "Style",
    "chore": "Chores",
    "revert": "Reverts",
}


@dataclass
class ChangelogEntry:
    type: str
    scope: str
    subject: str
    sha: str
    breaking: bool = False


class ChangelogGenerator:
    """Group conventional commits by type and render markdown."""

    def parse_commits(self, log_lines: Iterable[str]) -> list[ChangelogEntry]:
        entries: list[ChangelogEntry] = []
        for raw in log_lines:
            sha, _, message = raw.partition(" ")
            m = _COMMIT_RE.match(message.strip())
            if not m:
                continue
            entries.append(ChangelogEntry(
                type=m.group("type"),
                scope=m.group("scope") or "",
                subject=m.group("subject").strip(),
                sha=sha,
                breaking=bool(m.group("breaking")),
            ))
        return entries

    def render(self, entries: Iterable[ChangelogEntry], version: str = "Unreleased") -> str:
        grouped: dict[str, list[ChangelogEntry]] = defaultdict(list)
        for e in entries:
            grouped[e.type].append(e)
        lines = [f"## {version}", ""]
        for type_key, title in _TYPE_TITLES.items():
            items = grouped.get(type_key, [])
            if not items:
                continue
            lines.append(f"### {title}")
            for e in items:
                scope = f"**{e.scope}**: " if e.scope else ""
                bang = " :boom:" if e.breaking else ""
                lines.append(f"- {scope}{e.subject}{bang} ({e.sha[:7]})")
            lines.append("")
        return "\n".join(lines)
