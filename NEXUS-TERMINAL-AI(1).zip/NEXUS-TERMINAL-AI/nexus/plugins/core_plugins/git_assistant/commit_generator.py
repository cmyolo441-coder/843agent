"""CommitGenerator: produce conventional commit messages from a diff."""
from __future__ import annotations

import logging
import re
from collections import Counter
from dataclasses import dataclass

logger = logging.getLogger(__name__)

_FILE_RE = re.compile(r"^diff --git a/(.*?) b/", re.MULTILINE)
_TYPE_HINTS = (
    ("test", ("tests/", "test_", "_test.py", ".spec.")),
    ("docs", ("README", ".md", "docs/")),
    ("ci", (".github/", ".gitlab", "Jenkinsfile")),
    ("build", ("Dockerfile", "pyproject.toml", "package.json", "Makefile")),
    ("style", (".css", ".scss")),
)


@dataclass
class CommitMessage:
    type: str
    scope: str
    subject: str
    body: str = ""

    def render(self) -> str:
        scope = f"({self.scope})" if self.scope else ""
        head = f"{self.type}{scope}: {self.subject}"
        return f"{head}\n\n{self.body}".strip()


class CommitGenerator:
    """Heuristic conventional-commits generator."""

    def _classify(self, files: list[str]) -> str:
        for ctype, suffixes in _TYPE_HINTS:
            if any(any(s in f for s in suffixes) for f in files):
                return ctype
        added = sum(1 for f in files if "feat" in f.lower())
        return "feat" if added else "fix"

    def _scope(self, files: list[str]) -> str:
        tops = [f.split("/")[0] for f in files if "/" in f]
        if not tops:
            return ""
        return Counter(tops).most_common(1)[0][0]

    def generate(self, diff: str) -> str:
        files = _FILE_RE.findall(diff)
        if not files:
            return "chore: update"
        ctype = self._classify(files)
        scope = self._scope(files)
        added = sum(1 for line in diff.splitlines() if line.startswith("+") and not line.startswith("+++"))
        removed = sum(1 for line in diff.splitlines() if line.startswith("-") and not line.startswith("---"))
        subject = f"update {len(files)} file(s)"
        body = f"Changed {len(files)} files (+{added}/-{removed})."
        msg = CommitMessage(type=ctype, scope=scope, subject=subject, body=body)
        return msg.render()
