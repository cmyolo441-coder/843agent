"""ConflictResolver: parse and propose resolutions for git merge conflict markers."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Iterable

logger = logging.getLogger(__name__)

_CONFLICT_RE = re.compile(
    r"<<<<<<< (?P<ours_label>[^\n]*)\n(?P<ours>.*?)\n=======\n(?P<theirs>.*?)\n>>>>>>> (?P<theirs_label>[^\n]*)",
    re.DOTALL,
)


@dataclass
class Conflict:
    ours: str
    theirs: str
    ours_label: str
    theirs_label: str


class ConflictResolver:
    """Detects conflict hunks and proposes resolutions via strategies."""

    def __init__(self, default_strategy: str = "union") -> None:
        self.default_strategy = default_strategy

    def find_conflicts(self, text: str) -> list[Conflict]:
        return [
            Conflict(m.group("ours"), m.group("theirs"), m.group("ours_label"), m.group("theirs_label"))
            for m in _CONFLICT_RE.finditer(text)
        ]

    def _resolve(self, c: Conflict, strategy: str) -> str:
        if strategy == "ours":
            return c.ours
        if strategy == "theirs":
            return c.theirs
        if strategy == "union":
            return c.ours + "\n" + c.theirs
        return c.ours

    def resolve(self, text: str, strategy: str | None = None) -> str:
        strat = strategy or self.default_strategy

        def _sub(m: re.Match) -> str:
            return self._resolve(
                Conflict(m.group("ours"), m.group("theirs"), m.group("ours_label"), m.group("theirs_label")),
                strat,
            )

        return _CONFLICT_RE.sub(_sub, text)

    def summarize(self, conflicts: Iterable[Conflict]) -> str:
        items = list(conflicts)
        return f"{len(items)} conflict(s) detected"
