"""GitAssistantPlugin: AI-assisted git workflows (commits, PR review, conflicts, changelog)."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from nexus.plugins.core_plugins.git_assistant.commit_generator import CommitGenerator
from nexus.plugins.core_plugins.git_assistant.pr_reviewer import PRReviewer
from nexus.plugins.core_plugins.git_assistant.conflict_resolver import ConflictResolver
from nexus.plugins.core_plugins.git_assistant.changelog_generator import ChangelogGenerator

logger = logging.getLogger(__name__)


@dataclass
class GitAssistantPlugin:
    name: str = "git_assistant"
    version: str = "1.0.0"
    commit: CommitGenerator = field(default_factory=CommitGenerator)
    review: PRReviewer = field(default_factory=PRReviewer)
    conflict: ConflictResolver = field(default_factory=ConflictResolver)
    changelog: ChangelogGenerator = field(default_factory=ChangelogGenerator)

    def generate_commit_message(self, diff: str) -> str:
        return self.commit.generate(diff)


def setup() -> GitAssistantPlugin:
    logger.info("git_assistant plugin initialized")
    return GitAssistantPlugin()
