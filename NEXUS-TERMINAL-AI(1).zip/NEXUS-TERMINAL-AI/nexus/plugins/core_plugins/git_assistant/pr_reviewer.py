"""PRReviewer: produce a structured review summary for a PR diff."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class ReviewComment:
    file: str
    line: int
    severity: str
    message: str


@dataclass
class ReviewReport:
    summary: str
    approve: bool
    comments: list[ReviewComment] = field(default_factory=list)


class PRReviewer:
    """Heuristic PR reviewer: flags TODOs, prints, large files, secrets."""

    _patterns = [
        (re.compile(r"\bTODO\b|\bFIXME\b"), "info", "Unresolved TODO/FIXME"),
        (re.compile(r"\bprint\("), "warning", "Debug print statement"),
        (re.compile(r"AKIA[0-9A-Z]{16}"), "critical", "Possible AWS access key"),
        (re.compile(r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----"), "critical", "Private key committed"),
    ]

    def review_diff(self, diff: str) -> ReviewReport:
        comments: list[ReviewComment] = []
        current_file = ""
        line_no = 0
        for line in diff.splitlines():
            if line.startswith("+++ b/"):
                current_file = line[6:]
                line_no = 0
                continue
            if line.startswith("@@"):
                m = re.search(r"\+(\d+)", line)
                line_no = int(m.group(1)) if m else 0
                continue
            if line.startswith("+") and not line.startswith("+++"):
                line_no += 1
                payload = line[1:]
                for pat, sev, msg in self._patterns:
                    if pat.search(payload):
                        comments.append(ReviewComment(current_file, line_no, sev, msg))
            elif not line.startswith("-"):
                line_no += 1
        critical = any(c.severity == "critical" for c in comments)
        summary = f"{len(comments)} comment(s); {'block' if critical else 'approve with notes' if comments else 'looks good'}"
        return ReviewReport(summary=summary, approve=not critical, comments=comments)
