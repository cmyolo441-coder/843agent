"""security_scanner plugin: vuln/dep/secret/compliance scanners."""
from nexus.plugins.core_plugins.security_scanner.plugin import SecurityScannerPlugin, setup

__all__ = ["SecurityScannerPlugin", "setup"]
