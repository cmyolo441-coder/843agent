"""ComplianceChecker: declarative rule engine for GDPR/HIPAA/SOC2 hygiene checks."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

logger = logging.getLogger(__name__)


@dataclass
class ComplianceRule:
    framework: str
    rule_id: str
    description: str
    check: Callable[[Path], bool]


@dataclass
class ComplianceFinding:
    framework: str
    rule_id: str
    description: str
    passed: bool


def _has_file(name: str) -> Callable[[Path], bool]:
    return lambda root: (root / name).exists()


DEFAULT_RULES: list[ComplianceRule] = [
    ComplianceRule("gdpr", "GDPR-001", "Privacy policy file present", _has_file("PRIVACY.md")),
    ComplianceRule("gdpr", "GDPR-002", "Data retention doc present", _has_file("docs/retention.md")),
    ComplianceRule("hipaa", "HIPAA-001", "Encryption-at-rest config", _has_file("config/encryption.yaml")),
    ComplianceRule("hipaa", "HIPAA-002", "Audit log enabled doc", _has_file("docs/audit.md")),
    ComplianceRule("soc2", "SOC2-001", "Incident response runbook", _has_file("docs/incident_response.md")),
    ComplianceRule("soc2", "SOC2-002", "Access review log", _has_file("docs/access_review.md")),
]


@dataclass
class ComplianceChecker:
    rules: list[ComplianceRule] = field(default_factory=lambda: list(DEFAULT_RULES))

    def evaluate(self, root: str | Path) -> list[dict]:
        root_path = Path(root)
        findings = [
            ComplianceFinding(r.framework, r.rule_id, r.description, bool(r.check(root_path)))
            for r in self.rules
        ]
        return [f.__dict__ for f in findings]

    def summary(self, findings: list[dict]) -> dict[str, int]:
        passed = sum(1 for f in findings if f.get("passed"))
        return {"total": len(findings), "passed": passed, "failed": len(findings) - passed}
