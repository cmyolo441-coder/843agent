"""DependencyChecker: parse manifests and flag pinned-but-vulnerable packages."""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class Dependency:
    name: str
    version: str
    manifest: str


# Tiny illustrative advisory DB (name -> set of vulnerable versions).
_ADVISORIES: dict[str, set[str]] = {
    "requests": {"2.19.0", "2.20.0"},
    "django": {"3.2.0"},
    "lodash": {"4.17.20"},
    "log4j": {"2.14.0", "2.14.1"},
}


class DependencyChecker:
    """Inspect project manifests for known vulnerable versions."""

    _reqs_re = re.compile(r"^([A-Za-z0-9_.\-]+)\s*==\s*([0-9A-Za-z.\-+]+)")

    def parse_requirements(self, path: Path) -> list[Dependency]:
        deps: list[Dependency] = []
        for line in path.read_text(errors="ignore").splitlines():
            m = self._reqs_re.match(line.strip())
            if m:
                deps.append(Dependency(m.group(1).lower(), m.group(2), str(path)))
        return deps

    def parse_package_json(self, path: Path) -> list[Dependency]:
        try:
            data = json.loads(path.read_text(errors="ignore"))
        except json.JSONDecodeError:
            return []
        deps: list[Dependency] = []
        for section in ("dependencies", "devDependencies"):
            for name, ver in (data.get(section) or {}).items():
                deps.append(Dependency(name.lower(), str(ver).lstrip("^~"), str(path)))
        return deps

    def scan(self, root: str | Path) -> list[dict]:
        root_path = Path(root)
        all_deps: list[Dependency] = []
        for p in root_path.rglob("requirements*.txt"):
            all_deps.extend(self.parse_requirements(p))
        for p in root_path.rglob("package.json"):
            if "node_modules" in p.parts:
                continue
            all_deps.extend(self.parse_package_json(p))
        flagged = []
        for d in all_deps:
            if d.version in _ADVISORIES.get(d.name, set()):
                flagged.append({**d.__dict__, "advisory": True})
        return flagged
