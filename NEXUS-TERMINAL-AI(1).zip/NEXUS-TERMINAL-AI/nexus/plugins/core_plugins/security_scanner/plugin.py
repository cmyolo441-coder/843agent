"""SecurityScannerPlugin: roll-up vuln/dep/secret/compliance scanners."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from nexus.plugins.core_plugins.security_scanner.vuln_scanner import VulnScanner
from nexus.plugins.core_plugins.security_scanner.dependency_checker import DependencyChecker
from nexus.plugins.core_plugins.security_scanner.secret_detector import SecretDetector
from nexus.plugins.core_plugins.security_scanner.compliance_checker import ComplianceChecker

logger = logging.getLogger(__name__)


@dataclass
class SecurityScannerPlugin:
    name: str = "security_scanner"
    version: str = "1.0.0"
    vuln: VulnScanner = field(default_factory=VulnScanner)
    deps: DependencyChecker = field(default_factory=DependencyChecker)
    secrets: SecretDetector = field(default_factory=SecretDetector)
    compliance: ComplianceChecker = field(default_factory=ComplianceChecker)

    def scan_project(self, path: str) -> dict[str, Any]:
        return {
            "vulnerabilities": self.vuln.scan(path),
            "dependencies": self.deps.scan(path),
            "secrets": self.secrets.scan_path(path),
            "compliance": self.compliance.evaluate(path),
        }


def setup() -> SecurityScannerPlugin:
    logger.info("security_scanner initialized")
    return SecurityScannerPlugin()
