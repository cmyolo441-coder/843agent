"""SecretDetector: regex-based detector for cloud/API secrets in source code."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

_PATTERNS: dict[str, re.Pattern[str]] = {
    "aws_access_key": re.compile(r"AKIA[0-9A-Z]{16}"),
    "aws_secret": re.compile(r"(?i)aws.{0,20}['\"][0-9a-zA-Z/+]{40}['\"]"),
    "gcp_service_account": re.compile(r'"type":\s*"service_account"'),
    "stripe_live": re.compile(r"sk_live_[0-9a-zA-Z]{24,}"),
    "stripe_test": re.compile(r"sk_test_[0-9a-zA-Z]{24,}"),
    "github_token": re.compile(r"gh[pousr]_[A-Za-z0-9]{36,}"),
    "slack_token": re.compile(r"xox[abprs]-[0-9A-Za-z-]{10,}"),
    "private_key": re.compile(r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"),
    "jwt": re.compile(r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"),
    "generic_api_key": re.compile(r"(?i)api[_-]?key['\"]?\s*[:=]\s*['\"][A-Za-z0-9_\-]{20,}['\"]"),
}

_DEFAULT_IGNORES = {".git", "node_modules", "vendor", "dist", "build", "__pycache__"}


@dataclass
class SecretMatch:
    kind: str
    file: str
    line: int
    snippet: str


class SecretDetector:
    """Walk a directory and flag lines matching secret patterns."""

    def __init__(self, ignore: set[str] | None = None) -> None:
        self.ignore = ignore or _DEFAULT_IGNORES

    def scan_text(self, text: str, file: str = "<buffer>") -> list[SecretMatch]:
        out: list[SecretMatch] = []
        for i, line in enumerate(text.splitlines(), start=1):
            for kind, pat in _PATTERNS.items():
                if pat.search(line):
                    out.append(SecretMatch(kind, file, i, line[:120]))
        return out

    def scan_path(self, root: str | Path) -> list[dict]:
        root_path = Path(root)
        results: list[SecretMatch] = []
        for p in root_path.rglob("*"):
            if not p.is_file():
                continue
            if any(part in self.ignore for part in p.parts):
                continue
            try:
                text = p.read_text(errors="ignore")
            except OSError:
                continue
            results.extend(self.scan_text(text, str(p)))
        return [m.__dict__ for m in results]
