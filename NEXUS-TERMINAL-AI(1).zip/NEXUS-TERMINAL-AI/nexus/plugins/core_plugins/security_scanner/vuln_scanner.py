"""VulnScanner: signature-based vulnerability scanner with pluggable rules."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class VulnRule:
    rule_id: str
    pattern: re.Pattern[str]
    severity: str
    description: str


@dataclass
class VulnFinding:
    rule_id: str
    file: str
    line: int
    severity: str
    description: str


DEFAULT_RULES: list[VulnRule] = [
    VulnRule("PY-EVAL", re.compile(r"\beval\s*\("), "high", "Use of eval() — RCE risk"),
    VulnRule("PY-PICKLE", re.compile(r"\bpickle\.load(s)?\("), "high", "Untrusted pickle deserialization"),
    VulnRule("SQL-CONCAT", re.compile(r"execute\(.*\+.*\)"), "high", "Likely SQL injection via concatenation"),
    VulnRule("SHELL-INJ", re.compile(r"subprocess\.[A-Za-z]+\([^)]*shell=True"), "high", "subprocess shell=True"),
    VulnRule("WEAK-HASH", re.compile(r"hashlib\.(md5|sha1)\("), "medium", "Weak hash algorithm"),
]


class VulnScanner:
    """Scan source files for known dangerous patterns."""

    def __init__(self, rules: list[VulnRule] | None = None) -> None:
        self.rules = rules or DEFAULT_RULES

    def scan_file(self, path: str | Path) -> list[VulnFinding]:
        findings: list[VulnFinding] = []
        try:
            text = Path(path).read_text(errors="ignore")
        except OSError:
            return findings
        for i, line in enumerate(text.splitlines(), start=1):
            for rule in self.rules:
                if rule.pattern.search(line):
                    findings.append(VulnFinding(rule.rule_id, str(path), i, rule.severity, rule.description))
        return findings

    def scan(self, root: str | Path) -> list[dict]:
        root_path = Path(root)
        results: list[VulnFinding] = []
        if root_path.is_file():
            results.extend(self.scan_file(root_path))
        else:
            for p in root_path.rglob("*.py"):
                results.extend(self.scan_file(p))
        return [f.__dict__ for f in results]
