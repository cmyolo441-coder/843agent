"""Per-plugin configuration namespacing with layered overrides."""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PluginConfigEntry:
    plugin: str
    data: dict[str, Any] = field(default_factory=dict)

    def get(self, key: str, default: Any = None) -> Any:
        cur: Any = self.data
        for part in key.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                return default
        return cur

    def set(self, key: str, value: Any) -> None:
        cur = self.data
        parts = key.split(".")
        for part in parts[:-1]:
            cur = cur.setdefault(part, {})
        cur[parts[-1]] = value


class PluginConfig:
    """Manages per-plugin configuration files (json) under a root dir."""

    def __init__(self, root: str | Path = "config/plugins") -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self._cache: dict[str, PluginConfigEntry] = {}

    def _path(self, plugin: str) -> Path:
        return self.root / f"{plugin}.json"

    def load(self, plugin: str) -> PluginConfigEntry:
        if plugin in self._cache:
            return self._cache[plugin]
        p = self._path(plugin)
        data: dict[str, Any] = {}
        if p.exists():
            try:
                data = json.loads(p.read_text())
            except Exception:
                logger.exception("failed to read config %s", p)
        entry = PluginConfigEntry(plugin=plugin, data=data)
        self._cache[plugin] = entry
        return entry

    def save(self, plugin: str) -> None:
        entry = self._cache.get(plugin)
        if entry is None:
            return
        self._path(plugin).write_text(json.dumps(entry.data, indent=2, sort_keys=True))

    def update(self, plugin: str, updates: dict[str, Any]) -> None:
        entry = self.load(plugin)
        for k, v in updates.items():
            entry.set(k, v)
        self.save(plugin)
