"""Plugin event bus: hook registration for on_load/on_unload/before_call/after_call."""
from __future__ import annotations

import asyncio
import inspect
import logging
from collections import defaultdict
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

HookFn = Callable[..., Any | Awaitable[Any]]
KNOWN_HOOKS: frozenset[str] = frozenset({
    "on_load", "on_unload", "before_call", "after_call",
    "on_error", "on_config_change", "on_enable", "on_disable",
})


class PluginEventBus:
    """Async-aware pub/sub bus for plugin lifecycle events."""

    def __init__(self) -> None:
        self._hooks: dict[str, list[HookFn]] = defaultdict(list)

    def on(self, event: str, fn: HookFn) -> None:
        if event not in KNOWN_HOOKS:
            logger.warning("registering unknown hook: %s", event)
        self._hooks[event].append(fn)

    def off(self, event: str, fn: HookFn) -> None:
        if fn in self._hooks[event]:
            self._hooks[event].remove(fn)

    async def emit(self, event: str, **payload: Any) -> list[Any]:
        results: list[Any] = []
        for fn in list(self._hooks.get(event, [])):
            try:
                value = fn(**payload)
                if inspect.isawaitable(value):
                    value = await value
                results.append(value)
            except Exception:
                logger.exception("hook %s for %s raised", fn, event)
        return results

    def hooks_for(self, event: str) -> list[HookFn]:
        return list(self._hooks.get(event, []))
