"""Hot reload watcher: detect plugin file changes and importlib.reload modules."""
from __future__ import annotations

import asyncio
import importlib
import logging
import sys
import time
from pathlib import Path
from typing import Callable

logger = logging.getLogger(__name__)


class HotReloader:
    """Polls plugin source files; reloads modules when mtime changes."""

    def __init__(self, plugin_dir: str | Path, interval: float = 1.0) -> None:
        self.plugin_dir = Path(plugin_dir)
        self.interval = interval
        self._mtimes: dict[Path, float] = {}
        self._callbacks: list[Callable[[str], None]] = []
        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()

    def on_reload(self, cb: Callable[[str], None]) -> None:
        self._callbacks.append(cb)

    def _scan(self) -> list[Path]:
        if not self.plugin_dir.exists():
            return []
        return list(self.plugin_dir.rglob("*.py"))

    def _module_name(self, path: Path) -> str:
        rel = path.relative_to(self.plugin_dir).with_suffix("")
        return ".".join(rel.parts)

    async def _watch(self) -> None:
        for f in self._scan():
            self._mtimes[f] = f.stat().st_mtime
        while not self._stop.is_set():
            try:
                for f in self._scan():
                    mtime = f.stat().st_mtime
                    if self._mtimes.get(f) != mtime:
                        self._mtimes[f] = mtime
                        modname = self._module_name(f)
                        self._reload(modname)
            except Exception:
                logger.exception("hot reload scan failed")
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=self.interval)
            except asyncio.TimeoutError:
                pass

    def _reload(self, modname: str) -> None:
        if modname in sys.modules:
            try:
                importlib.reload(sys.modules[modname])
                logger.info("Reloaded module %s", modname)
            except Exception:
                logger.exception("reload failed for %s", modname)
        for cb in self._callbacks:
            try:
                cb(modname)
            except Exception:
                logger.exception("reload callback error")

    async def start(self) -> None:
        self._stop.clear()
        self._task = asyncio.create_task(self._watch())

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            await self._task
            self._task = None
