"""PluginLoader: importlib-based dynamic loader for Python plugins."""
from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class PluginLoader:
    """Loads Python plugins dynamically using importlib."""

    def __init__(self) -> None:
        self._loaded: dict[str, Any] = {}

    async def load(self, name: str, path: Path | None = None) -> Any:
        """Load a plugin module by name (or from file path) and call setup()."""
        if name in self._loaded:
            return self._loaded[name]

        if path and path.exists():
            spec = importlib.util.spec_from_file_location(name, path)
            if spec is None or spec.loader is None:
                raise ImportError(f"Cannot build spec for {path}")
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
        else:
            module = importlib.import_module(name)

        instance: Any = module
        if hasattr(module, "setup"):
            try:
                result = module.setup()
                if hasattr(result, "__await__"):
                    instance = await result
                else:
                    instance = result or module
            except Exception:
                logger.exception("Plugin setup() raised for %s", name)
                raise

        self._loaded[name] = instance
        logger.debug("Loaded plugin module %s", name)
        return instance

    async def unload(self, name: str) -> None:
        instance = self._loaded.pop(name, None)
        if instance and hasattr(instance, "teardown"):
            try:
                result = instance.teardown()
                if hasattr(result, "__await__"):
                    await result
            except Exception:
                logger.exception("teardown raised for %s", name)
        sys.modules.pop(name, None)

    def reload(self, name: str) -> Any:
        module = sys.modules.get(name)
        if module is None:
            raise KeyError(name)
        reloaded = importlib.reload(module)
        self._loaded[name] = reloaded
        return reloaded
