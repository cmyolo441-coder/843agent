"""PluginManager: lifecycle install/load/unload/enable/disable for Nexus plugins."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

from nexus.plugins.plugin_loader import PluginLoader
from nexus.plugins.plugin_registry import PluginRegistry
from nexus.plugins.plugin_resolver import PluginResolver
from nexus.plugins.plugin_events import PluginEventBus

logger = logging.getLogger(__name__)


class PluginState(Enum):
    DISCOVERED = "discovered"
    INSTALLED = "installed"
    LOADED = "loaded"
    ENABLED = "enabled"
    DISABLED = "disabled"
    FAILED = "failed"


@dataclass
class PluginRecord:
    name: str
    version: str
    state: PluginState = PluginState.DISCOVERED
    path: Path | None = None
    instance: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)


class PluginManager:
    """Central orchestrator for plugin lifecycle."""

    def __init__(self, plugin_dir: Path | str = "plugins") -> None:
        self.plugin_dir = Path(plugin_dir)
        self.loader = PluginLoader()
        self.registry = PluginRegistry()
        self.resolver = PluginResolver()
        self.events = PluginEventBus()
        self._plugins: dict[str, PluginRecord] = {}
        self._lock = asyncio.Lock()

    async def install(self, name: str, version: str = "latest") -> PluginRecord:
        """Install a plugin into the local registry."""
        async with self._lock:
            rec = PluginRecord(name=name, version=version, state=PluginState.INSTALLED)
            self._plugins[name] = rec
            logger.info("Installed plugin %s@%s", name, version)
            return rec

    async def load(self, name: str) -> PluginRecord:
        """Load and instantiate a plugin."""
        async with self._lock:
            rec = self._plugins.get(name)
            if rec is None:
                raise KeyError(f"Plugin {name} not installed")
            try:
                instance = await self.loader.load(name, rec.path)
                rec.instance = instance
                rec.state = PluginState.LOADED
                await self.events.emit("on_load", plugin=name)
            except Exception as exc:
                rec.state = PluginState.FAILED
                logger.exception("Failed to load %s: %s", name, exc)
                raise
            return rec

    async def unload(self, name: str) -> None:
        async with self._lock:
            rec = self._plugins.get(name)
            if rec and rec.instance is not None:
                await self.events.emit("on_unload", plugin=name)
                await self.loader.unload(name)
                rec.instance = None
                rec.state = PluginState.INSTALLED

    async def enable(self, name: str) -> None:
        rec = self._plugins[name]
        rec.state = PluginState.ENABLED
        logger.info("Enabled plugin %s", name)

    async def disable(self, name: str) -> None:
        rec = self._plugins[name]
        rec.state = PluginState.DISABLED
        logger.info("Disabled plugin %s", name)

    def list_plugins(self) -> list[PluginRecord]:
        return list(self._plugins.values())

    async def load_all(self, names: list[str]) -> None:
        order = self.resolver.resolve(names)
        for name in order:
            await self.load(name)
