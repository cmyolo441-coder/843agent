"""PluginMarketplace: HTTP client for the Nexus plugin marketplace API."""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any
from urllib.parse import urljoin
from urllib.request import Request, urlopen

logger = logging.getLogger(__name__)


@dataclass
class MarketplacePlugin:
    name: str
    version: str
    description: str
    author: str
    download_url: str
    checksum: str
    signature: str | None = None


class PluginMarketplace:
    """Remote plugin marketplace client (search/info/download)."""

    def __init__(self, base_url: str = "https://marketplace.nexus.ai", token: str | None = None) -> None:
        self.base_url = base_url.rstrip("/") + "/"
        self.token = token
        self._timeout = 30

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        url = urljoin(self.base_url, path.lstrip("/"))
        if params:
            from urllib.parse import urlencode
            url = f"{url}?{urlencode(params)}"
        req = Request(url, headers={"Accept": "application/json"})
        if self.token:
            req.add_header("Authorization", f"Bearer {self.token}")
        with urlopen(req, timeout=self._timeout) as resp:  # noqa: S310
            return json.loads(resp.read().decode("utf-8"))

    def search(self, query: str, limit: int = 20) -> list[MarketplacePlugin]:
        data = self._get("v1/search", {"q": query, "limit": limit})
        return [MarketplacePlugin(**item) for item in data.get("results", [])]

    def info(self, name: str, version: str = "latest") -> MarketplacePlugin:
        data = self._get(f"v1/plugins/{name}", {"version": version})
        return MarketplacePlugin(**data)

    def download(self, plugin: MarketplacePlugin, dest_path: str) -> str:
        req = Request(plugin.download_url)
        with urlopen(req, timeout=self._timeout) as resp:  # noqa: S310
            data = resp.read()
        with open(dest_path, "wb") as fh:
            fh.write(data)
        logger.info("Downloaded %s@%s -> %s", plugin.name, plugin.version, dest_path)
        return dest_path
