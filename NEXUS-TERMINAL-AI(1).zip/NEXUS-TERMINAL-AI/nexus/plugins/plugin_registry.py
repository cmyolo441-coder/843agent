"""PluginRegistry: entry-point discovery via importlib.metadata."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from importlib import metadata as importlib_metadata
from typing import Iterable

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PluginEntry:
    name: str
    module: str
    version: str
    group: str = "nexus.plugins"


class PluginRegistry:
    """Discovers plugins via Python entry points (group: nexus.plugins)."""

    def __init__(self, group: str = "nexus.plugins") -> None:
        self.group = group
        self._entries: dict[str, PluginEntry] = {}

    def discover(self) -> list[PluginEntry]:
        """Scan installed packages for entry points in our group."""
        entries: list[PluginEntry] = []
        try:
            eps = importlib_metadata.entry_points(group=self.group)
        except TypeError:  # py<3.10 fallback
            eps = importlib_metadata.entry_points().get(self.group, [])  # type: ignore
        for ep in eps:
            version = ""
            try:
                dist = ep.dist  # type: ignore[attr-defined]
                if dist:
                    version = dist.version
            except Exception:
                pass
            entry = PluginEntry(name=ep.name, module=ep.value, version=version, group=self.group)
            self._entries[ep.name] = entry
            entries.append(entry)
        logger.info("Discovered %d plugins under %s", len(entries), self.group)
        return entries

    def register(self, entry: PluginEntry) -> None:
        self._entries[entry.name] = entry

    def get(self, name: str) -> PluginEntry | None:
        return self._entries.get(name)

    def all(self) -> Iterable[PluginEntry]:
        return list(self._entries.values())

    def __contains__(self, name: str) -> bool:
        return name in self._entries

    def __len__(self) -> int:
        return len(self._entries)
