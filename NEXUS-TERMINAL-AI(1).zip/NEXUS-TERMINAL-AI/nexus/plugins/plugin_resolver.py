"""PluginResolver: dependency graph + topological sort for safe plugin load order."""
from __future__ import annotations

import logging
from collections import defaultdict, deque
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class PluginNode:
    name: str
    requires: list[str] = field(default_factory=list)
    optional: list[str] = field(default_factory=list)


class CircularDependencyError(RuntimeError):
    """Raised when plugin dependencies form a cycle."""


class PluginResolver:
    """Resolve plugin load order via Kahn's algorithm."""

    def __init__(self) -> None:
        self._nodes: dict[str, PluginNode] = {}

    def add(self, node: PluginNode) -> None:
        self._nodes[node.name] = node

    def add_dep(self, plugin: str, depends_on: str, optional: bool = False) -> None:
        node = self._nodes.setdefault(plugin, PluginNode(name=plugin))
        target = node.optional if optional else node.requires
        if depends_on not in target:
            target.append(depends_on)

    def resolve(self, names: list[str] | None = None) -> list[str]:
        """Return plugin names in dependency-respecting order."""
        nodes = {n: self._nodes[n] for n in (names or self._nodes) if n in self._nodes}
        if not nodes and names:
            return list(names)

        indeg: dict[str, int] = defaultdict(int)
        edges: dict[str, list[str]] = defaultdict(list)
        for name, node in nodes.items():
            indeg.setdefault(name, 0)
            for dep in node.requires:
                if dep in nodes:
                    edges[dep].append(name)
                    indeg[name] += 1

        q = deque([n for n, d in indeg.items() if d == 0])
        order: list[str] = []
        while q:
            n = q.popleft()
            order.append(n)
            for nb in edges[n]:
                indeg[nb] -= 1
                if indeg[nb] == 0:
                    q.append(nb)

        if len(order) != len(nodes):
            unresolved = set(nodes) - set(order)
            raise CircularDependencyError(f"Cycle among: {unresolved}")
        logger.debug("Resolved order: %s", order)
        return order
