"""PluginSandbox: RestrictedPython-style execution environment for untrusted plugins."""
from __future__ import annotations

import builtins
import logging
import resource
import signal
from contextlib import contextmanager
from typing import Any

logger = logging.getLogger(__name__)

# Builtins considered safe inside plugin code.
SAFE_BUILTINS: frozenset[str] = frozenset({
    "abs", "all", "any", "bool", "dict", "enumerate", "float", "int",
    "len", "list", "map", "max", "min", "print", "range", "repr",
    "reversed", "round", "set", "sorted", "str", "sum", "tuple", "zip",
})

BLOCKED_MODULES: frozenset[str] = frozenset({
    "os", "subprocess", "sys", "socket", "ctypes", "shutil",
})


class SandboxViolation(RuntimeError):
    """Raised when a plugin attempts a blocked operation."""


class PluginSandbox:
    """Lightweight in-process sandbox restricting builtins, imports, and CPU time."""

    def __init__(self, cpu_seconds: int = 5, memory_mb: int = 256) -> None:
        self.cpu_seconds = cpu_seconds
        self.memory_mb = memory_mb

    def _safe_import(self, name: str, *args: Any, **kwargs: Any) -> Any:
        root = name.split(".")[0]
        if root in BLOCKED_MODULES:
            raise SandboxViolation(f"Import of '{name}' blocked in sandbox")
        return __import__(name, *args, **kwargs)

    def build_globals(self) -> dict[str, Any]:
        safe = {k: getattr(builtins, k) for k in SAFE_BUILTINS if hasattr(builtins, k)}
        safe["__import__"] = self._safe_import
        return {"__builtins__": safe}

    @contextmanager
    def _limits(self):
        prev_cpu = resource.getrlimit(resource.RLIMIT_CPU)
        try:
            resource.setrlimit(resource.RLIMIT_CPU, (self.cpu_seconds, self.cpu_seconds))
        except (ValueError, OSError):
            logger.debug("Could not set RLIMIT_CPU")
        try:
            yield
        finally:
            try:
                resource.setrlimit(resource.RLIMIT_CPU, prev_cpu)
            except (ValueError, OSError):
                pass

    def execute(self, source: str, locals_: dict[str, Any] | None = None) -> dict[str, Any]:
        """Execute Python source in the sandbox; return resulting locals namespace."""
        ns_locals: dict[str, Any] = locals_ or {}
        ns_globals = self.build_globals()
        with self._limits():
            try:
                exec(compile(source, "<sandbox>", "exec"), ns_globals, ns_locals)
            except SandboxViolation:
                raise
            except Exception:
                logger.exception("Sandbox execution failed")
                raise
        return ns_locals
