"""PluginSigner: sign plugin artifacts with RSA-PSS via the cryptography library."""
from __future__ import annotations

import base64
import hashlib
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding, rsa
    _HAS_CRYPTO = True
except Exception:  # pragma: no cover - optional
    _HAS_CRYPTO = False


class PluginSigner:
    """Generate keypairs and sign plugin archives."""

    def __init__(self, key_size: int = 3072) -> None:
        self.key_size = key_size
        self._private_key = None

    def generate_keypair(self) -> tuple[bytes, bytes]:
        if not _HAS_CRYPTO:
            raise RuntimeError("cryptography not installed")
        priv = rsa.generate_private_key(public_exponent=65537, key_size=self.key_size)
        self._private_key = priv
        priv_pem = priv.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        pub_pem = priv.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        return priv_pem, pub_pem

    def load_private_key(self, pem: bytes) -> None:
        if not _HAS_CRYPTO:
            raise RuntimeError("cryptography not installed")
        self._private_key = serialization.load_pem_private_key(pem, password=None)

    def sign(self, data: bytes) -> str:
        if not _HAS_CRYPTO or self._private_key is None:
            raise RuntimeError("Signer not initialized")
        sig = self._private_key.sign(
            data,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256(),
        )
        return base64.b64encode(sig).decode("ascii")

    def sign_file(self, path: str | Path) -> tuple[str, str]:
        """Sign file content; returns (sha256 hex, base64 signature)."""
        p = Path(path)
        data = p.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        signature = self.sign(data)
        logger.info("Signed %s sha256=%s", p, digest[:12])
        return digest, signature
