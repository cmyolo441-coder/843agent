"""PluginVerifier: verify plugin signatures and checksums prior to load."""
from __future__ import annotations

import base64
import hashlib
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.exceptions import InvalidSignature
    _HAS_CRYPTO = True
except Exception:
    _HAS_CRYPTO = False
    InvalidSignature = Exception  # type: ignore


class VerificationError(RuntimeError):
    """Raised when a plugin fails signature/checksum verification."""


class PluginVerifier:
    """Verify plugin authenticity against trusted public keys."""

    def __init__(self) -> None:
        self._trusted_keys: list = []

    def add_trusted_key(self, pem: bytes) -> None:
        if not _HAS_CRYPTO:
            raise RuntimeError("cryptography not installed")
        self._trusted_keys.append(serialization.load_pem_public_key(pem))

    def verify_checksum(self, data: bytes, expected_sha256: str) -> bool:
        actual = hashlib.sha256(data).hexdigest()
        ok = actual.lower() == expected_sha256.lower()
        if not ok:
            logger.warning("checksum mismatch: %s != %s", actual, expected_sha256)
        return ok

    def verify_signature(self, data: bytes, signature_b64: str) -> bool:
        if not _HAS_CRYPTO:
            raise RuntimeError("cryptography not installed")
        if not self._trusted_keys:
            raise VerificationError("No trusted keys configured")
        sig = base64.b64decode(signature_b64)
        for key in self._trusted_keys:
            try:
                key.verify(
                    sig, data,
                    padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                    hashes.SHA256(),
                )
                return True
            except InvalidSignature:
                continue
        return False

    def verify_file(self, path: str | Path, sha256: str, signature: str) -> None:
        p = Path(path)
        data = p.read_bytes()
        if not self.verify_checksum(data, sha256):
            raise VerificationError(f"Checksum mismatch for {p}")
        if not self.verify_signature(data, signature):
            raise VerificationError(f"Signature invalid for {p}")
        logger.info("Verified %s", p)
