"""Generic async object pool with min/max + factory."""
from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from contextlib import asynccontextmanager
from typing import AsyncIterator, Generic, TypeVar

T = TypeVar("T")
_log = logging.getLogger(__name__)


class ObjectPool(Generic[T]):
    """Async object pool with lazy growth up to `max_size`."""

    def __init__(
        self,
        factory: Callable[[], Awaitable[T]],
        *,
        min_size: int = 0,
        max_size: int = 16,
        finalizer: Callable[[T], Awaitable[None]] | None = None,
    ) -> None:
        self._factory = factory
        self._finalizer = finalizer
        self.min_size = min_size
        self.max_size = max_size
        self._idle: asyncio.LifoQueue[T] = asyncio.LifoQueue()
        self._sem = asyncio.Semaphore(max_size)
        self._created = 0
        self._lock = asyncio.Lock()

    async def warmup(self) -> None:
        """Pre-allocate `min_size` objects."""
        async with self._lock:
            while self._created < self.min_size:
                obj = await self._factory()
                self._created += 1
                self._idle.put_nowait(obj)

    async def acquire(self) -> T:
        await self._sem.acquire()
        try:
            return self._idle.get_nowait()
        except asyncio.QueueEmpty:
            pass
        async with self._lock:
            if self._created < self.max_size:
                self._created += 1
                return await self._factory()
        # Should not happen, but fall back to blocking wait
        return await self._idle.get()

    async def release(self, obj: T) -> None:
        self._idle.put_nowait(obj)
        self._sem.release()

    @asynccontextmanager
    async def take(self) -> AsyncIterator[T]:
        obj = await self.acquire()
        try:
            yield obj
        finally:
            await self.release(obj)

    async def close(self) -> None:
        while not self._idle.empty():
            obj = self._idle.get_nowait()
            if self._finalizer is not None:
                try:
                    await self._finalizer(obj)
                except Exception:
                    _log.exception("pool finalizer raised")
        self._created = 0

    @property
    def size(self) -> int:
        return self._created
