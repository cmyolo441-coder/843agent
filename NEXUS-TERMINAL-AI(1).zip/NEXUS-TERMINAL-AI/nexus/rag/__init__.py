"""NEXUS RAG subsystem: retrieval-augmented generation pipeline.

Exposes the high-level RAGPipeline and the principal engines that compose it
(ingestion, embedding, vector stores, retrieval, reranking, synthesis).
"""
from __future__ import annotations

from .pipeline import RAGPipeline
from .query_engine import QueryEngine
from .retrieval_engine import RetrievalEngine
from .generation_engine import GenerationEngine
from .evaluation import RAGEvaluator

__all__ = [
    "RAGPipeline",
    "QueryEngine",
    "RetrievalEngine",
    "GenerationEngine",
    "RAGEvaluator",
]

__version__ = "0.1.0"
