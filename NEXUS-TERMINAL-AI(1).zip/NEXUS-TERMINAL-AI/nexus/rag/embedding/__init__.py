"""Embedding subsystem: dense, sparse, and hybrid vector encoders."""
from __future__ import annotations

from .embedder import BaseEmbedder, EmbedderFactory

__all__ = ["BaseEmbedder", "EmbedderFactory"]
