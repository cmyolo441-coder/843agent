"""BGE (BAAI General Embedding) wrapper around SentenceTransformerEmbedder."""
from __future__ import annotations

import logging
from typing import Sequence

from .embedder import EmbedderFactory, Vector
from .sentence_transformer import SentenceTransformerEmbedder

logger = logging.getLogger(__name__)


class BGEEmbedder(SentenceTransformerEmbedder):
    """BGE family models with optional instruction prefix on queries."""

    name = "bge"

    def __init__(self, model: str = "BAAI/bge-large-en-v1.5", device: str = "cpu",
                 batch_size: int = 32, dim: int = 1024,
                 query_instruction: str = "Represent this sentence for searching relevant passages: ") -> None:
        super().__init__(model=model, device=device, batch_size=batch_size,
                         dim=dim, normalize=True)
        self.query_instruction = query_instruction

    def embed_query(self, text: str) -> Vector:
        return self.embed([self.query_instruction + text])[0]


EmbedderFactory.register("bge", BGEEmbedder)
