"""Cohere embedder."""
from __future__ import annotations

import hashlib
import logging
from typing import Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector

logger = logging.getLogger(__name__)


class CohereEmbedder(BaseEmbedder):
    """Wraps Cohere's embed endpoint."""

    name = "cohere"

    def __init__(self, model: str = "embed-english-v3.0", api_key: str | None = None,
                 batch_size: int = 96, dim: int = 1024,
                 input_type: str = "search_document") -> None:
        super().__init__(model=model, batch_size=batch_size)
        self.api_key = api_key
        self.dim = dim
        self.input_type = input_type
        self._client = None

    def _client_lazy(self):
        if self._client is None:
            try:
                import cohere  # type: ignore
                self._client = cohere.Client(self.api_key) if self.api_key else cohere.Client()
            except Exception as exc:
                logger.warning("cohere SDK unavailable: %s", exc)
                self._client = False
        return self._client

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        client = self._client_lazy()
        if not client:
            return [self._fallback(t) for t in texts]
        try:
            resp = client.embed(texts=list(texts), model=self.model,
                                input_type=self.input_type)
            return list(resp.embeddings)
        except Exception as exc:
            logger.warning("Cohere embed failed: %s", exc)
            return [self._fallback(t) for t in texts]

    def _fallback(self, text: str) -> Vector:
        digest = hashlib.blake2b(text.encode("utf-8"), digest_size=self.dim).digest()
        return [(b - 128) / 128.0 for b in digest]


EmbedderFactory.register("cohere", CohereEmbedder)
