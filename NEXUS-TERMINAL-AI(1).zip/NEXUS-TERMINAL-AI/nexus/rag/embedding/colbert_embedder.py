"""ColBERT late-interaction embedder: emits one vector per token."""
from __future__ import annotations

import hashlib
import logging
import re
from typing import Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector

logger = logging.getLogger(__name__)


class ColBERTEmbedder(BaseEmbedder):
    """Returns the AVERAGE token vector for compatibility with dense stores,
    but exposes `embed_tokens` for true late-interaction reranking.
    """

    name = "colbert"

    def __init__(self, model: str = "colbert-ir/colbertv2.0", dim: int = 128,
                 max_tokens: int = 128, batch_size: int = 16) -> None:
        super().__init__(model=model, batch_size=batch_size)
        self.dim = dim
        self.max_tokens = max_tokens

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        return [self._avg(self.embed_tokens(t)) for t in texts]

    def embed_tokens(self, text: str) -> list[Vector]:
        tokens = re.findall(r"[A-Za-z0-9]+", text)[: self.max_tokens]
        return [self._token_vec(t) for t in tokens] or [[0.0] * self.dim]

    def _token_vec(self, token: str) -> Vector:
        digest = hashlib.blake2b(token.lower().encode(), digest_size=self.dim).digest()
        return [(b - 128) / 128.0 for b in digest]

    @staticmethod
    def _avg(vectors: list[Vector]) -> Vector:
        if not vectors:
            return []
        n = len(vectors)
        dim = len(vectors[0])
        return [sum(v[i] for v in vectors) / n for i in range(dim)]


EmbedderFactory.register("colbert", ColBERTEmbedder)
