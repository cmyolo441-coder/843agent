"""CustomEmbedder: wraps any user-supplied callable as a BaseEmbedder."""
from __future__ import annotations

import logging
from typing import Callable, Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector

logger = logging.getLogger(__name__)


class CustomEmbedder(BaseEmbedder):
    """Adapter from a function (texts -> vectors) to the BaseEmbedder contract."""

    name = "custom"

    def __init__(self, encode_fn: Callable[[Sequence[str]], list[Vector]],
                 dim: int, model: str = "custom", batch_size: int = 32) -> None:
        super().__init__(model=model, batch_size=batch_size)
        if not callable(encode_fn):
            raise TypeError("encode_fn must be callable")
        self._encode_fn = encode_fn
        self.dim = dim

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        vectors = self._encode_fn(list(texts))
        if not isinstance(vectors, list) or any(len(v) != self.dim for v in vectors):
            raise ValueError(f"encode_fn must return list of len-{self.dim} vectors")
        return vectors


EmbedderFactory.register("custom", CustomEmbedder)
