"""E5 (intfloat/e5) embedder: requires 'query: '/'passage: ' prefixes."""
from __future__ import annotations

import logging
from typing import Sequence

from .embedder import EmbedderFactory, Vector
from .sentence_transformer import SentenceTransformerEmbedder

logger = logging.getLogger(__name__)


class E5Embedder(SentenceTransformerEmbedder):
    """E5 family with passage/query input-side prompting."""

    name = "e5"

    def __init__(self, model: str = "intfloat/e5-large-v2", device: str = "cpu",
                 batch_size: int = 32, dim: int = 1024) -> None:
        super().__init__(model=model, device=device, batch_size=batch_size,
                         dim=dim, normalize=True)

    def embed(self, texts: Sequence[str]) -> list[Vector]:
        prefixed = [t if t.startswith(("query: ", "passage: ")) else f"passage: {t}"
                    for t in texts]
        return super().embed(prefixed)

    def embed_query(self, text: str) -> Vector:
        return super().embed([f"query: {text}"])[0]


EmbedderFactory.register("e5", E5Embedder)
