"""Embedder ABC + factory used by all concrete embedders."""
from __future__ import annotations

import abc
import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Sequence

logger = logging.getLogger(__name__)

Vector = list[float]


@dataclass
class EmbeddingResult:
    """Output of a batched embedding call."""

    vectors: list[Vector]
    model: str
    dim: int
    tokens: int = 0

    def __len__(self) -> int:
        return len(self.vectors)


class BaseEmbedder(abc.ABC):
    """Abstract base for all text embedders."""

    name: str = "base"
    dim: int = 0

    def __init__(self, model: str | None = None, batch_size: int = 32) -> None:
        self.model = model or self.name
        self.batch_size = batch_size

    @abc.abstractmethod
    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        """Synchronous batch embedding, implemented by subclasses."""

    def embed(self, texts: Sequence[str]) -> list[Vector]:
        out: list[Vector] = []
        for i in range(0, len(texts), self.batch_size):
            out.extend(self._embed_batch(texts[i:i + self.batch_size]))
        return out

    async def aembed(self, texts: Sequence[str]) -> list[Vector]:
        return await asyncio.to_thread(self.embed, list(texts))

    def embed_query(self, text: str) -> Vector:
        return self.embed([text])[0]


class EmbedderFactory:
    """Builds embedder instances by name."""

    _registry: dict[str, type[BaseEmbedder]] = {}

    @classmethod
    def register(cls, name: str, klass: type[BaseEmbedder]) -> None:
        cls._registry[name.lower()] = klass

    @classmethod
    def create(cls, name: str, **kwargs: Any) -> BaseEmbedder:
        key = name.lower()
        if key not in cls._registry:
            raise KeyError(f"Unknown embedder '{name}'. Available: {sorted(cls._registry)}")
        return cls._registry[key](**kwargs)

    @classmethod
    def available(cls) -> list[str]:
        return sorted(cls._registry)
