"""HuggingFace transformers embedder (mean-pooled CLS or token average)."""
from __future__ import annotations

import hashlib
import logging
from typing import Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector

logger = logging.getLogger(__name__)


class HuggingFaceEmbedder(BaseEmbedder):
    """Encodes text with a HuggingFace transformers model + mean pooling."""

    name = "huggingface"

    def __init__(self, model: str = "sentence-transformers/all-MiniLM-L6-v2",
                 device: str = "cpu", batch_size: int = 32, dim: int = 384) -> None:
        super().__init__(model=model, batch_size=batch_size)
        self.device = device
        self.dim = dim
        self._tokenizer = None
        self._model = None

    def _load(self) -> bool:
        if self._model is not None:
            return True
        try:
            from transformers import AutoTokenizer, AutoModel  # type: ignore
            import torch  # noqa: F401
            self._tokenizer = AutoTokenizer.from_pretrained(self.model)
            self._model = AutoModel.from_pretrained(self.model).to(self.device)
            self._model.eval()
            return True
        except Exception as exc:
            logger.warning("transformers unavailable: %s", exc)
            return False

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        if not self._load():
            return [self._fallback(t) for t in texts]
        import torch  # type: ignore
        enc = self._tokenizer(list(texts), padding=True, truncation=True,
                              return_tensors="pt").to(self.device)
        with torch.no_grad():
            out = self._model(**enc)
        mask = enc["attention_mask"].unsqueeze(-1).float()
        summed = (out.last_hidden_state * mask).sum(1)
        counts = mask.sum(1).clamp(min=1e-6)
        vectors = (summed / counts).cpu().tolist()
        return vectors

    def _fallback(self, text: str) -> Vector:
        digest = hashlib.blake2b(text.encode("utf-8"), digest_size=self.dim).digest()
        return [(b - 128) / 128.0 for b in digest]


EmbedderFactory.register("huggingface", HuggingFaceEmbedder)
