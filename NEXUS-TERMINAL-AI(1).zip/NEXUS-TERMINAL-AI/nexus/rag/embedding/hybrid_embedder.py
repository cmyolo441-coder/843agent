"""HybridEmbedder: concatenates dense + sparse vectors."""
from __future__ import annotations

import logging
from typing import Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector
from .local_embedder import LocalEmbedder
from .sparse_embedder import SparseEmbedder

logger = logging.getLogger(__name__)


class HybridEmbedder(BaseEmbedder):
    """Stacks one dense and one sparse vector with configurable weights."""

    name = "hybrid"

    def __init__(self, dense: BaseEmbedder | None = None,
                 sparse: BaseEmbedder | None = None,
                 alpha: float = 0.7, batch_size: int = 32) -> None:
        super().__init__(model="hybrid", batch_size=batch_size)
        self.dense = dense or LocalEmbedder()
        self.sparse = sparse or SparseEmbedder()
        if not 0.0 <= alpha <= 1.0:
            raise ValueError("alpha must be in [0, 1]")
        self.alpha = alpha
        self.dim = self.dense.dim + self.sparse.dim

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        dense_vecs = self.dense.embed(list(texts))
        sparse_vecs = self.sparse.embed(list(texts))
        out: list[Vector] = []
        for d, s in zip(dense_vecs, sparse_vecs):
            scaled_d = [self.alpha * x for x in d]
            scaled_s = [(1 - self.alpha) * x for x in s]
            out.append(scaled_d + scaled_s)
        return out


EmbedderFactory.register("hybrid", HybridEmbedder)
