"""Local embedder: deterministic hash-based embedding, no external deps."""
from __future__ import annotations

import hashlib
import logging
import math
import re
from collections import Counter
from typing import Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector

logger = logging.getLogger(__name__)


class LocalEmbedder(BaseEmbedder):
    """Hashed-bag-of-words embedder for offline / unit-test usage."""

    name = "local"

    def __init__(self, dim: int = 256, model: str = "local-hashed-bow",
                 batch_size: int = 256) -> None:
        super().__init__(model=model, batch_size=batch_size)
        self.dim = dim

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        return [self._encode(t) for t in texts]

    def _encode(self, text: str) -> Vector:
        tokens = re.findall(r"[a-z0-9]+", text.lower())
        counts: Counter[str] = Counter(tokens)
        vec = [0.0] * self.dim
        for tok, c in counts.items():
            idx = int.from_bytes(hashlib.blake2b(tok.encode(), digest_size=4).digest(),
                                 "big") % self.dim
            vec[idx] += float(c)
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]


EmbedderFactory.register("local", LocalEmbedder)
