"""Multilingual embedder (paraphrase-multilingual-MiniLM)."""
from __future__ import annotations

import logging

from .embedder import EmbedderFactory
from .sentence_transformer import SentenceTransformerEmbedder

logger = logging.getLogger(__name__)


class MultilingualEmbedder(SentenceTransformerEmbedder):
    """Default multilingual model good for 50+ languages."""

    name = "multilingual"

    def __init__(self, model: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
                 device: str = "cpu", batch_size: int = 64, dim: int = 384) -> None:
        super().__init__(model=model, device=device, batch_size=batch_size,
                         dim=dim, normalize=True)


EmbedderFactory.register("multilingual", MultilingualEmbedder)
