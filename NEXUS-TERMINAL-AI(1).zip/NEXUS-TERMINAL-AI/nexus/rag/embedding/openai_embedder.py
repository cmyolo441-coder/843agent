"""OpenAI embedder using the openai SDK."""
from __future__ import annotations

import hashlib
import logging
from typing import Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector

logger = logging.getLogger(__name__)


class OpenAIEmbedder(BaseEmbedder):
    """Wraps the OpenAI text-embedding-3 family."""

    name = "openai"

    def __init__(self, model: str = "text-embedding-3-small", api_key: str | None = None,
                 batch_size: int = 64, dim: int = 1536) -> None:
        super().__init__(model=model, batch_size=batch_size)
        self.api_key = api_key
        self.dim = dim
        self._client = None

    def _client_lazy(self):
        if self._client is None:
            try:
                from openai import OpenAI  # type: ignore
                self._client = OpenAI(api_key=self.api_key) if self.api_key else OpenAI()
            except Exception as exc:
                logger.warning("openai SDK unavailable: %s", exc)
                self._client = False
        return self._client

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        client = self._client_lazy()
        if not client:
            return [self._fallback(t) for t in texts]
        try:
            resp = client.embeddings.create(model=self.model, input=list(texts))
            return [d.embedding for d in resp.data]
        except Exception as exc:
            logger.warning("OpenAI embed failed: %s; using fallback", exc)
            return [self._fallback(t) for t in texts]

    def _fallback(self, text: str) -> Vector:
        """Deterministic pseudo-embedding for offline / failure cases."""
        digest = hashlib.blake2b(text.encode("utf-8"), digest_size=self.dim).digest()
        return [(b - 128) / 128.0 for b in digest]


EmbedderFactory.register("openai", OpenAIEmbedder)
