"""Sentence-Transformers embedder."""
from __future__ import annotations

import hashlib
import logging
from typing import Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector

logger = logging.getLogger(__name__)


class SentenceTransformerEmbedder(BaseEmbedder):
    """Uses sentence-transformers SentenceTransformer.encode."""

    name = "sentence_transformer"

    def __init__(self, model: str = "sentence-transformers/all-MiniLM-L6-v2",
                 device: str = "cpu", batch_size: int = 64, dim: int = 384,
                 normalize: bool = True) -> None:
        super().__init__(model=model, batch_size=batch_size)
        self.device = device
        self.dim = dim
        self.normalize = normalize
        self._model = None

    def _load(self) -> bool:
        if self._model is not None:
            return True
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore
            self._model = SentenceTransformer(self.model, device=self.device)
            return True
        except Exception as exc:
            logger.warning("sentence-transformers unavailable: %s", exc)
            return False

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        if not self._load():
            return [self._fallback(t) for t in texts]
        vectors = self._model.encode(
            list(texts), batch_size=self.batch_size,
            normalize_embeddings=self.normalize, convert_to_numpy=True,
        )
        return [v.tolist() for v in vectors]

    def _fallback(self, text: str) -> Vector:
        digest = hashlib.blake2b(text.encode("utf-8"), digest_size=self.dim).digest()
        return [(b - 128) / 128.0 for b in digest]


EmbedderFactory.register("sentence_transformer", SentenceTransformerEmbedder)
