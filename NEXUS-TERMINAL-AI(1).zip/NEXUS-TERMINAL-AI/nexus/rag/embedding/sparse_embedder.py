"""Sparse embedder: BM25-style term weight vectors as {token_id: weight}."""
from __future__ import annotations

import logging
import math
import re
from collections import Counter
from typing import Sequence

from .embedder import BaseEmbedder, EmbedderFactory, Vector

logger = logging.getLogger(__name__)


class SparseEmbedder(BaseEmbedder):
    """Produces L2-normalized sparse-as-dense vectors via hashed BM25 weights."""

    name = "sparse"

    def __init__(self, dim: int = 4096, k1: float = 1.5, b: float = 0.75,
                 model: str = "bm25-hashed", batch_size: int = 256,
                 avg_doc_len: float = 200.0) -> None:
        super().__init__(model=model, batch_size=batch_size)
        self.dim = dim
        self.k1 = k1
        self.b = b
        self.avg_doc_len = avg_doc_len

    def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        return [self._encode(t) for t in texts]

    def _encode(self, text: str) -> Vector:
        import hashlib
        tokens = re.findall(r"[a-z0-9]+", text.lower())
        if not tokens:
            return [0.0] * self.dim
        counts: Counter[str] = Counter(tokens)
        length = len(tokens)
        vec = [0.0] * self.dim
        for tok, tf in counts.items():
            idx = int.from_bytes(hashlib.blake2b(tok.encode(), digest_size=4).digest(),
                                 "big") % self.dim
            weight = (tf * (self.k1 + 1)) / (
                tf + self.k1 * (1 - self.b + self.b * length / self.avg_doc_len)
            )
            vec[idx] += weight
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]


EmbedderFactory.register("sparse", SparseEmbedder)
