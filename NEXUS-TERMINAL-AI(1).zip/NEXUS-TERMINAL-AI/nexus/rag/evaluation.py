"""RAG evaluation metrics in the spirit of RAGAS: faithfulness, relevance, recall."""
from __future__ import annotations

import logging
import math
import re
from dataclasses import dataclass, field
from typing import Iterable, Sequence

from .pipeline import Document

logger = logging.getLogger(__name__)


@dataclass
class EvaluationReport:
    """Aggregated evaluation scores for a single (question, answer, contexts) example."""

    faithfulness: float
    answer_relevance: float
    context_recall: float
    context_precision: float
    details: dict[str, float] = field(default_factory=dict)

    def overall(self) -> float:
        return (self.faithfulness + self.answer_relevance +
                self.context_recall + self.context_precision) / 4.0


def _tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]+", text.lower()) if len(t) > 2}


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


class RAGEvaluator:
    """Lightweight RAGAS-style evaluator using lexical heuristics."""

    def __init__(self, ground_truth_key: str = "ground_truth") -> None:
        self.ground_truth_key = ground_truth_key

    def faithfulness(self, answer: str, contexts: Sequence[Document]) -> float:
        """Fraction of answer tokens supported by the union of contexts."""
        ans = _tokens(answer)
        if not ans:
            return 0.0
        supp: set[str] = set()
        for d in contexts:
            supp |= _tokens(d.text)
        return len(ans & supp) / len(ans)

    def answer_relevance(self, question: str, answer: str) -> float:
        return _jaccard(_tokens(question), _tokens(answer))

    def context_recall(self, ground_truth: str, contexts: Sequence[Document]) -> float:
        gt = _tokens(ground_truth)
        if not gt:
            return 0.0
        supp: set[str] = set()
        for d in contexts:
            supp |= _tokens(d.text)
        return len(gt & supp) / len(gt)

    def context_precision(self, question: str, contexts: Sequence[Document]) -> float:
        q = _tokens(question)
        if not q or not contexts:
            return 0.0
        per_doc = [(_jaccard(q, _tokens(d.text)), i) for i, d in enumerate(contexts)]
        weights = [1.0 / math.log2(i + 2) for _, i in per_doc]
        weighted = sum(s * w for (s, _), w in zip(per_doc, weights))
        return weighted / sum(weights)

    def evaluate(
        self,
        question: str,
        answer: str,
        contexts: Sequence[Document],
        ground_truth: str = "",
    ) -> EvaluationReport:
        return EvaluationReport(
            faithfulness=self.faithfulness(answer, contexts),
            answer_relevance=self.answer_relevance(question, answer),
            context_recall=self.context_recall(ground_truth or answer, contexts),
            context_precision=self.context_precision(question, contexts),
        )

    def evaluate_many(self, examples: Iterable[dict]) -> list[EvaluationReport]:
        return [
            self.evaluate(
                question=ex["question"],
                answer=ex["answer"],
                contexts=ex["contexts"],
                ground_truth=ex.get(self.ground_truth_key, ""),
            )
            for ex in examples
        ]
