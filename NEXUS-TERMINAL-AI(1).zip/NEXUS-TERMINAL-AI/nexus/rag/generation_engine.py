"""GenerationEngine: wraps an LLM with prompt templates and retrieved context."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Optional, Sequence

from .pipeline import Document

logger = logging.getLogger(__name__)


DEFAULT_TEMPLATE = (
    "You are a careful assistant. Use ONLY the context below to answer.\n"
    "If the answer is not in the context, say you do not know.\n\n"
    "CONTEXT:\n{context}\n\n"
    "QUESTION: {question}\n\n"
    "ANSWER:"
)


@dataclass
class GenerationConfig:
    """Decoding params for the LLM."""

    temperature: float = 0.2
    max_tokens: int = 128000
    top_p: float = 0.95
    stop: Optional[list[str]] = None


class GenerationEngine:
    """Formats a context-aware prompt and queries the underlying LLM."""

    def __init__(
        self,
        llm: Any,
        template: str = DEFAULT_TEMPLATE,
        config: Optional[GenerationConfig] = None,
        max_context_chars: int = 8000,
    ) -> None:
        self.llm = llm
        self.template = template
        self.config = config or GenerationConfig()
        self.max_context_chars = max_context_chars

    async def generate(self, question: str, contexts: Sequence[Document]) -> str:
        prompt = self._render_prompt(question, contexts)
        logger.debug("Generating with prompt of %d chars", len(prompt))
        return await self._call_llm(prompt)

    def _render_prompt(self, question: str, contexts: Sequence[Document]) -> str:
        chunks: list[str] = []
        budget = self.max_context_chars
        for i, doc in enumerate(contexts, 1):
            piece = f"[{i}] {doc.text}"
            if budget - len(piece) < 0:
                piece = piece[:budget]
            chunks.append(piece)
            budget -= len(piece)
            if budget <= 0:
                break
        ctx = "\n\n".join(chunks)
        return self.template.format(context=ctx, question=question)

    async def _call_llm(self, prompt: str) -> str:
        if hasattr(self.llm, "agenerate"):
            return await self.llm.agenerate(prompt, **self.config.__dict__)
        if hasattr(self.llm, "complete"):
            return self.llm.complete(prompt, **self.config.__dict__)
        if callable(self.llm):
            return self.llm(prompt)
        raise TypeError(f"LLM type {type(self.llm).__name__} is not callable")
