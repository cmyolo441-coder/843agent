"""Ingestion subsystem: loaders, chunkers, cleaning, dedup, metadata, enrichment."""
from __future__ import annotations

from .loader import UniversalLoader
from .chunker import UniversalChunker
from .cleaner import TextCleaner
from .deduplicator import Deduplicator
from .metadata_extractor import MetadataExtractor
from .enricher import Enricher

__all__ = [
    "UniversalLoader",
    "UniversalChunker",
    "TextCleaner",
    "Deduplicator",
    "MetadataExtractor",
    "Enricher",
]
