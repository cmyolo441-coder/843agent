"""UniversalChunker: dispatches chunking strategies by name or content heuristic."""
from __future__ import annotations

import logging
from typing import Any, Iterable

from ..pipeline import Document

logger = logging.getLogger(__name__)


class UniversalChunker:
    """Strategy dispatcher around the chunking/ subpackage."""

    def __init__(self, default_strategy: str = "recursive", chunk_size: int = 512,
                 overlap: int = 64) -> None:
        from .chunking import (
            fixed_size, sentence, paragraph, semantic, recursive,
            markdown_header, code_ast, sliding_window, agentic,
            parent_child, context_aware,
        )
        self._strategies: dict[str, Any] = {
            "fixed_size": fixed_size.FixedSizeChunker(chunk_size),
            "sentence": sentence.SentenceChunker(),
            "paragraph": paragraph.ParagraphChunker(),
            "semantic": semantic.SemanticChunker(),
            "recursive": recursive.RecursiveChunker(chunk_size, overlap),
            "markdown_header": markdown_header.MarkdownHeaderChunker(),
            "code_ast": code_ast.CodeASTChunker(),
            "sliding_window": sliding_window.SlidingWindowChunker(chunk_size, overlap),
            "agentic": agentic.AgenticChunker(),
            "parent_child": parent_child.ParentChildChunker(chunk_size),
            "context_aware": context_aware.ContextAwareChunker(chunk_size),
        }
        self.default_strategy = default_strategy

    def chunk(self, docs: Iterable[Document], strategy: str | None = None) -> list[Document]:
        out: list[Document] = []
        for doc in docs:
            name = strategy or self._auto_select(doc)
            chunker = self._strategies.get(name) or self._strategies[self.default_strategy]
            out.extend(chunker.split(doc))
        logger.debug("Chunked into %d pieces", len(out))
        return out

    @staticmethod
    def _auto_select(doc: Document) -> str:
        fmt = (doc.metadata.get("format") or "").lower()
        if fmt == "markdown":
            return "markdown_header"
        if fmt == "code":
            return "code_ast"
        if fmt in ("html", "web"):
            return "paragraph"
        return "recursive"
