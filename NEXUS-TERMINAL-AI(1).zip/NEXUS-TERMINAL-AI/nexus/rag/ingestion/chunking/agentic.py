"""Agentic chunker: uses an LLM to propose semantic break points."""
from __future__ import annotations

import logging
import re
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class AgenticChunker:
    """Asks an LLM to label chunk boundaries; falls back to paragraph splitting."""

    def __init__(self, llm: Any | None = None, target_chars: int = 1200) -> None:
        self.llm = llm
        self.target_chars = target_chars

    def split(self, doc: Document) -> list[Document]:
        if self.llm is None:
            return self._fallback(doc)
        prompt = (
            "Identify natural topical break points in the text. "
            "Return a list of integer character offsets where a new section begins.\n\n"
            f"TEXT:\n{doc.text}"
        )
        try:
            response = self.llm.complete(prompt) if hasattr(self.llm, "complete") else self.llm(prompt)
            offsets = sorted({int(x) for x in re.findall(r"\d+", str(response))})
            offsets = [o for o in offsets if 0 < o < len(doc.text)]
        except Exception as exc:
            logger.warning("Agentic chunker LLM failed: %s", exc)
            return self._fallback(doc)
        if not offsets:
            return self._fallback(doc)
        chunks: list[Document] = []
        prev = 0
        for i, off in enumerate([*offsets, len(doc.text)]):
            piece = doc.text[prev:off].strip()
            if piece:
                meta = {**doc.metadata, "chunk_index": i, "chunk_strategy": "agentic",
                        "char_start": prev, "char_end": off}
                chunks.append(Document(text=piece, metadata=meta))
            prev = off
        return chunks

    def _fallback(self, doc: Document) -> list[Document]:
        from .paragraph import ParagraphChunker
        return ParagraphChunker(self.target_chars).split(doc)
