"""AST-aware code chunker: one chunk per top-level function/class for Python."""
from __future__ import annotations

import ast
import logging

from ...pipeline import Document

logger = logging.getLogger(__name__)


class CodeASTChunker:
    """For Python sources, splits into top-level definitions. Falls back to line groups."""

    def __init__(self, fallback_lines: int = 80) -> None:
        self.fallback_lines = fallback_lines

    def split(self, doc: Document) -> list[Document]:
        lang = doc.metadata.get("language") or doc.metadata.get("format")
        if lang == "py" or doc.metadata.get("language", "").lower() == "python":
            return self._split_python(doc)
        return self._line_groups(doc)

    def _split_python(self, doc: Document) -> list[Document]:
        try:
            tree = ast.parse(doc.text)
        except SyntaxError:
            return self._line_groups(doc)
        lines = doc.text.splitlines()
        chunks: list[Document] = []
        for i, node in enumerate(tree.body):
            if not hasattr(node, "lineno"):
                continue
            start = node.lineno - 1
            end = getattr(node, "end_lineno", start + 1)
            piece = "\n".join(lines[start:end])
            meta = {**doc.metadata, "chunk_index": i, "chunk_strategy": "code_ast",
                    "symbol": getattr(node, "name", type(node).__name__),
                    "kind": type(node).__name__}
            chunks.append(Document(text=piece, metadata=meta))
        return chunks or self._line_groups(doc)

    def _line_groups(self, doc: Document) -> list[Document]:
        lines = doc.text.splitlines()
        chunks: list[Document] = []
        for i in range(0, len(lines), self.fallback_lines):
            piece = "\n".join(lines[i:i + self.fallback_lines])
            meta = {**doc.metadata, "chunk_index": len(chunks),
                    "chunk_strategy": "code_ast_fallback",
                    "line_start": i, "line_end": i + self.fallback_lines}
            chunks.append(Document(text=piece, metadata=meta))
        return chunks or [doc]
