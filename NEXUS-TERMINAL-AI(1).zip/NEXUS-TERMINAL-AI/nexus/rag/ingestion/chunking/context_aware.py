"""Context-aware chunker: prepends a doc-level summary header to each chunk."""
from __future__ import annotations

import logging

from ...pipeline import Document
from .recursive import RecursiveChunker

logger = logging.getLogger(__name__)


class ContextAwareChunker:
    """Wraps RecursiveChunker but injects a short doc summary as a chunk prefix."""

    def __init__(self, chunk_size: int = 512, overlap: int = 64,
                 summary_chars: int = 200) -> None:
        self.inner = RecursiveChunker(chunk_size=chunk_size, overlap=overlap)
        self.summary_chars = summary_chars

    def split(self, doc: Document) -> list[Document]:
        summary = self._summary(doc)
        out: list[Document] = []
        for piece in self.inner.split(doc):
            prefix = f"[CONTEXT: {summary}]\n\n" if summary else ""
            meta = {**piece.metadata, "chunk_strategy": "context_aware",
                    "doc_summary": summary}
            out.append(Document(text=prefix + piece.text, metadata=meta))
        return out

    def _summary(self, doc: Document) -> str:
        title = doc.metadata.get("title") or doc.metadata.get("source", "")
        head = doc.text[: self.summary_chars].replace("\n", " ").strip()
        return f"{title} | {head}" if title else head
