"""Fixed-size character chunker."""
from __future__ import annotations

import logging
from dataclasses import replace
from typing import Iterable

from ...pipeline import Document

logger = logging.getLogger(__name__)


class FixedSizeChunker:
    """Splits a Document into equal-size character chunks."""

    def __init__(self, size: int = 512, overlap: int = 0) -> None:
        if size <= 0:
            raise ValueError("size must be > 0")
        if not 0 <= overlap < size:
            raise ValueError("overlap must satisfy 0 <= overlap < size")
        self.size = size
        self.overlap = overlap

    def split(self, doc: Document) -> list[Document]:
        text = doc.text
        if not text:
            return [doc]
        step = self.size - self.overlap
        chunks: list[Document] = []
        for i, start in enumerate(range(0, len(text), step)):
            piece = text[start:start + self.size]
            if not piece:
                break
            meta = {**doc.metadata, "chunk_index": i, "chunk_start": start,
                    "chunk_strategy": "fixed_size"}
            chunks.append(Document(text=piece, metadata=meta))
        return chunks
