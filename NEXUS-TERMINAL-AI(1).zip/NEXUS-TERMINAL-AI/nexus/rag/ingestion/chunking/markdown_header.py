"""Markdown-aware chunker: splits at heading boundaries, preserves heading path."""
from __future__ import annotations

import logging
import re

from ...pipeline import Document

logger = logging.getLogger(__name__)

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$", re.MULTILINE)


class MarkdownHeaderChunker:
    """One chunk per heading section, with parent-heading path attached."""

    def split(self, doc: Document) -> list[Document]:
        text = doc.text
        matches = list(_HEADING_RE.finditer(text))
        if not matches:
            return [doc]
        chunks: list[Document] = []
        heading_stack: list[tuple[int, str]] = []
        for idx, match in enumerate(matches):
            level = len(match.group(1))
            title = match.group(2).strip()
            start = match.start()
            end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
            section = text[start:end].strip()
            heading_stack = [(lvl, t) for lvl, t in heading_stack if lvl < level]
            heading_stack.append((level, title))
            path = " > ".join(t for _, t in heading_stack)
            meta = {**doc.metadata, "chunk_index": idx, "chunk_strategy": "markdown_header",
                    "heading": title, "heading_level": level, "heading_path": path}
            chunks.append(Document(text=section, metadata=meta))
        return chunks
