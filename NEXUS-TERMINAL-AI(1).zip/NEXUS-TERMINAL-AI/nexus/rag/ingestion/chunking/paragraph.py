"""Paragraph-boundary chunker (blank-line separated)."""
from __future__ import annotations

import logging
import re

from ...pipeline import Document

logger = logging.getLogger(__name__)

_PARA = re.compile(r"\n\s*\n")


class ParagraphChunker:
    """Groups paragraphs into chunks until target_chars is reached."""

    def __init__(self, target_chars: int = 800) -> None:
        self.target_chars = target_chars

    def split(self, doc: Document) -> list[Document]:
        paragraphs = [p.strip() for p in _PARA.split(doc.text) if p.strip()]
        chunks: list[Document] = []
        buf: list[str] = []
        total = 0
        for p in paragraphs:
            buf.append(p)
            total += len(p) + 2
            if total >= self.target_chars:
                chunks.append(self._mk(doc, "\n\n".join(buf), len(chunks)))
                buf, total = [], 0
        if buf:
            chunks.append(self._mk(doc, "\n\n".join(buf), len(chunks)))
        return chunks or [doc]

    @staticmethod
    def _mk(doc: Document, text: str, idx: int) -> Document:
        meta = {**doc.metadata, "chunk_index": idx, "chunk_strategy": "paragraph"}
        return Document(text=text, metadata=meta)
