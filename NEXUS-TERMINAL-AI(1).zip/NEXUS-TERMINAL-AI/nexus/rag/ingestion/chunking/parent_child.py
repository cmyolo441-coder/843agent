"""Parent-child chunker: indexes small children, returns large parents on retrieval."""
from __future__ import annotations

import logging
import uuid

from ...pipeline import Document

logger = logging.getLogger(__name__)


class ParentChildChunker:
    """Emits child chunks with parent context attached via metadata."""

    def __init__(self, parent_size: int = 2000, child_size: int = 400,
                 child_overlap: int = 50) -> None:
        self.parent_size = parent_size
        self.child_size = child_size
        self.child_overlap = child_overlap

    def split(self, doc: Document) -> list[Document]:
        text = doc.text
        chunks: list[Document] = []
        for p_start in range(0, len(text), self.parent_size):
            parent_text = text[p_start:p_start + self.parent_size]
            parent_id = uuid.uuid4().hex
            step = self.child_size - self.child_overlap
            for c_start in range(0, len(parent_text), step):
                child = parent_text[c_start:c_start + self.child_size]
                if not child:
                    break
                meta = {**doc.metadata, "chunk_strategy": "parent_child",
                        "parent_id": parent_id, "parent_text": parent_text,
                        "parent_offset": p_start, "child_offset": c_start,
                        "chunk_index": len(chunks)}
                chunks.append(Document(text=child, metadata=meta))
        return chunks or [doc]
