"""Recursive character chunker: tries a hierarchy of separators."""
from __future__ import annotations

import logging
from typing import Sequence

from ...pipeline import Document

logger = logging.getLogger(__name__)


class RecursiveChunker:
    """Recursively splits by paragraph, sentence, word, then characters."""

    _DEFAULT_SEPS: Sequence[str] = ("\n\n", "\n", ". ", " ", "")

    def __init__(self, chunk_size: int = 512, overlap: int = 64,
                 separators: Sequence[str] | None = None) -> None:
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.separators = separators or self._DEFAULT_SEPS

    def split(self, doc: Document) -> list[Document]:
        pieces = self._split(doc.text, list(self.separators))
        chunks: list[Document] = []
        for i, p in enumerate(pieces):
            meta = {**doc.metadata, "chunk_index": i, "chunk_strategy": "recursive"}
            chunks.append(Document(text=p, metadata=meta))
        return chunks or [doc]

    def _split(self, text: str, seps: list[str]) -> list[str]:
        if len(text) <= self.chunk_size:
            return [text] if text else []
        if not seps:
            return [text[i:i + self.chunk_size]
                    for i in range(0, len(text), self.chunk_size - self.overlap)]
        sep = seps[0]
        parts = text.split(sep) if sep else list(text)
        out: list[str] = []
        buf = ""
        for part in parts:
            piece = (buf + sep + part) if buf else part
            if len(piece) <= self.chunk_size:
                buf = piece
            else:
                if buf:
                    out.append(buf)
                if len(part) > self.chunk_size:
                    out.extend(self._split(part, seps[1:]))
                    buf = ""
                else:
                    buf = part
        if buf:
            out.append(buf)
        return [p for p in out if p]
