"""Semantic chunker: splits on lexical-similarity drops between adjacent sentences."""
from __future__ import annotations

import logging
import math
import re
from collections import Counter
from typing import Sequence

from ...pipeline import Document

logger = logging.getLogger(__name__)

_SENT_END = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")


def _vec(text: str) -> Counter:
    return Counter(t for t in re.findall(r"[a-z0-9]+", text.lower()) if len(t) > 2)


def _cosine(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    dot = sum(a[k] * b.get(k, 0) for k in a)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    return dot / (na * nb) if na and nb else 0.0


class SemanticChunker:
    """Cut points are placed where adjacent-sentence similarity dips below threshold."""

    def __init__(self, threshold: float = 0.25, min_chunk: int = 200) -> None:
        self.threshold = threshold
        self.min_chunk = min_chunk

    def split(self, doc: Document) -> list[Document]:
        sentences = [s.strip() for s in _SENT_END.split(doc.text) if s.strip()]
        if not sentences:
            return [doc]
        chunks: list[Document] = []
        buf: list[str] = [sentences[0]]
        prev_vec = _vec(sentences[0])
        for s in sentences[1:]:
            cur_vec = _vec(s)
            sim = _cosine(prev_vec, cur_vec)
            joined_len = sum(len(x) + 1 for x in buf)
            if sim < self.threshold and joined_len >= self.min_chunk:
                chunks.append(self._mk(doc, " ".join(buf), len(chunks)))
                buf = []
            buf.append(s)
            prev_vec = cur_vec
        if buf:
            chunks.append(self._mk(doc, " ".join(buf), len(chunks)))
        return chunks

    @staticmethod
    def _mk(doc: Document, text: str, idx: int) -> Document:
        meta = {**doc.metadata, "chunk_index": idx, "chunk_strategy": "semantic"}
        return Document(text=text, metadata=meta)
