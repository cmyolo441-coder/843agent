"""Sentence-boundary chunker."""
from __future__ import annotations

import logging
import re
from typing import Iterable

from ...pipeline import Document

logger = logging.getLogger(__name__)

_SENT_END = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'])")


class SentenceChunker:
    """Splits text into sentences, then groups into chunks of ~target_chars."""

    def __init__(self, target_chars: int = 600) -> None:
        self.target_chars = target_chars

    def split(self, doc: Document) -> list[Document]:
        sentences = [s.strip() for s in _SENT_END.split(doc.text) if s.strip()]
        chunks: list[Document] = []
        buf: list[str] = []
        total = 0
        for s in sentences:
            buf.append(s)
            total += len(s) + 1
            if total >= self.target_chars:
                chunks.append(self._mk(doc, " ".join(buf), len(chunks)))
                buf, total = [], 0
        if buf:
            chunks.append(self._mk(doc, " ".join(buf), len(chunks)))
        return chunks or [doc]

    @staticmethod
    def _mk(doc: Document, text: str, idx: int) -> Document:
        meta = {**doc.metadata, "chunk_index": idx, "chunk_strategy": "sentence"}
        return Document(text=text, metadata=meta)
