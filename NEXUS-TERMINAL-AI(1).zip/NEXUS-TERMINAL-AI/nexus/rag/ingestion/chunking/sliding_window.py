"""Sliding-window chunker: token (word) based windows with overlap."""
from __future__ import annotations

import logging

from ...pipeline import Document

logger = logging.getLogger(__name__)


class SlidingWindowChunker:
    """Word-level windows for finer-grained recall."""

    def __init__(self, window: int = 256, stride: int = 128) -> None:
        if stride <= 0 or window <= 0:
            raise ValueError("window and stride must be positive")
        if stride > window:
            raise ValueError("stride must be <= window")
        self.window = window
        self.stride = stride

    def split(self, doc: Document) -> list[Document]:
        tokens = doc.text.split()
        if not tokens:
            return [doc]
        chunks: list[Document] = []
        for i in range(0, len(tokens), self.stride):
            window_tokens = tokens[i:i + self.window]
            if not window_tokens:
                break
            piece = " ".join(window_tokens)
            meta = {**doc.metadata, "chunk_index": len(chunks),
                    "chunk_strategy": "sliding_window",
                    "token_start": i, "token_end": i + len(window_tokens)}
            chunks.append(Document(text=piece, metadata=meta))
            if i + self.window >= len(tokens):
                break
        return chunks
