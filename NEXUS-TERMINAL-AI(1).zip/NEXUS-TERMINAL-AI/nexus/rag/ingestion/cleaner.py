"""TextCleaner: HTML stripping, whitespace normalization, control-char removal."""
from __future__ import annotations

import html as html_lib
import logging
import re
import unicodedata

from ..pipeline import Document

logger = logging.getLogger(__name__)


class TextCleaner:
    """Composable text-normalization pipeline."""

    _HTML_TAG = re.compile(r"<[^>]+>")
    _URL = re.compile(r"https?://\S+")
    _EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
    _WHITESPACE = re.compile(r"\s+")
    _CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

    def __init__(
        self,
        strip_html: bool = True,
        normalize_unicode: bool = True,
        lowercase: bool = False,
        replace_urls: str | None = None,
        replace_emails: str | None = None,
    ) -> None:
        self.strip_html = strip_html
        self.normalize_unicode = normalize_unicode
        self.lowercase = lowercase
        self.replace_urls = replace_urls
        self.replace_emails = replace_emails

    def clean(self, text: str) -> str:
        if not text:
            return ""
        if self.strip_html:
            text = html_lib.unescape(text)
            text = self._HTML_TAG.sub(" ", text)
        if self.normalize_unicode:
            text = unicodedata.normalize("NFKC", text)
        text = self._CTRL.sub("", text)
        if self.replace_urls is not None:
            text = self._URL.sub(self.replace_urls, text)
        if self.replace_emails is not None:
            text = self._EMAIL.sub(self.replace_emails, text)
        text = self._WHITESPACE.sub(" ", text).strip()
        if self.lowercase:
            text = text.lower()
        return text

    def clean_doc(self, doc: Document) -> Document:
        cleaned = self.clean(doc.text)
        meta = {**doc.metadata, "cleaned": True, "orig_len": len(doc.text), "new_len": len(cleaned)}
        return Document(text=cleaned, metadata=meta, id=doc.id)
