"""Deduplicator: exact hash + MinHash approximate near-duplicate detection."""
from __future__ import annotations

import hashlib
import logging
import re
from typing import Iterable

from ..pipeline import Document

logger = logging.getLogger(__name__)


class _MinHash:
    def __init__(self, num_perm: int = 64, seed: int = 1) -> None:
        self.num_perm = num_perm
        # Deterministic per-permutation salts.
        self._salts = [hashlib.blake2b(f"{seed}:{i}".encode(), digest_size=8).digest()
                       for i in range(num_perm)]

    def signature(self, tokens: Iterable[str]) -> tuple[int, ...]:
        mins = [(1 << 64) - 1] * self.num_perm
        for tok in tokens:
            base = hashlib.blake2b(tok.encode("utf-8"), digest_size=8).digest()
            for i, salt in enumerate(self._salts):
                h = int.from_bytes(bytes(a ^ b for a, b in zip(base, salt)), "big")
                if h < mins[i]:
                    mins[i] = h
        return tuple(mins)


def _shingles(text: str, k: int = 5) -> list[str]:
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    return [" ".join(tokens[i:i + k]) for i in range(max(1, len(tokens) - k + 1))]


class Deduplicator:
    """Two-stage dedup: exact SHA-256 over normalized text, then MinHash Jaccard."""

    def __init__(self, threshold: float = 0.85, num_perm: int = 64, shingle_k: int = 5) -> None:
        self.threshold = threshold
        self.shingle_k = shingle_k
        self._minhash = _MinHash(num_perm=num_perm)

    def dedupe(self, docs: Iterable[Document]) -> list[Document]:
        seen_hashes: set[str] = set()
        kept: list[tuple[Document, tuple[int, ...]]] = []
        for doc in docs:
            norm = re.sub(r"\s+", " ", doc.text.lower()).strip()
            h = hashlib.sha256(norm.encode("utf-8")).hexdigest()
            if h in seen_hashes:
                continue
            sig = self._minhash.signature(_shingles(doc.text, self.shingle_k))
            is_dup = any(self._jaccard(sig, prev_sig) >= self.threshold
                         for _, prev_sig in kept)
            if is_dup:
                continue
            seen_hashes.add(h)
            kept.append((doc, sig))
        logger.info("Deduplicator kept %d docs", len(kept))
        return [d for d, _ in kept]

    @staticmethod
    def _jaccard(a: tuple[int, ...], b: tuple[int, ...]) -> float:
        if not a or not b:
            return 0.0
        eq = sum(1 for x, y in zip(a, b) if x == y)
        return eq / len(a)
