"""Enricher: NER, keyword extraction, lightweight extractive summary."""
from __future__ import annotations

import logging
import math
import re
from collections import Counter

from ..pipeline import Document

logger = logging.getLogger(__name__)

_SENT_END = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")
_PROPER_NOUN = re.compile(r"\b[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,}){0,3}\b")
_STOPWORDS = frozenset({
    "the", "a", "an", "of", "to", "in", "on", "for", "and", "or", "is",
    "are", "was", "were", "be", "been", "this", "that", "with", "by",
    "as", "at", "it", "from", "but", "not", "have", "has", "had",
})


class Enricher:
    """Augments a Document with entities, keywords, and a 1-3 sentence summary."""

    def __init__(self, max_keywords: int = 10, summary_sentences: int = 3) -> None:
        self.max_keywords = max_keywords
        self.summary_sentences = summary_sentences

    def enrich(self, doc: Document) -> Document:
        text = doc.text or ""
        entities = self._entities(text)
        keywords = self._keywords(text)
        summary = self._summary(text)
        meta = {**doc.metadata, "entities": entities, "keywords": keywords,
                "summary": summary}
        return Document(text=text, metadata=meta, id=doc.id)

    @staticmethod
    def _entities(text: str) -> list[str]:
        return sorted({m.group(0).strip() for m in _PROPER_NOUN.finditer(text)})[:50]

    def _keywords(self, text: str) -> list[str]:
        tokens = [t.lower() for t in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", text)]
        counts = Counter(t for t in tokens if t not in _STOPWORDS)
        return [w for w, _ in counts.most_common(self.max_keywords)]

    def _summary(self, text: str) -> str:
        sentences = [s.strip() for s in _SENT_END.split(text) if s.strip()]
        if not sentences:
            return ""
        token_freq: Counter[str] = Counter()
        for s in sentences:
            for t in re.findall(r"[a-z]+", s.lower()):
                if t not in _STOPWORDS:
                    token_freq[t] += 1
        if not token_freq:
            return " ".join(sentences[: self.summary_sentences])
        scores = []
        for i, s in enumerate(sentences):
            words = re.findall(r"[a-z]+", s.lower())
            score = sum(token_freq.get(w, 0) for w in words) / (math.log2(i + 2))
            scores.append((score, i, s))
        top = sorted(scores, key=lambda x: -x[0])[: self.summary_sentences]
        top.sort(key=lambda x: x[1])
        return " ".join(s for _, _, s in top)
