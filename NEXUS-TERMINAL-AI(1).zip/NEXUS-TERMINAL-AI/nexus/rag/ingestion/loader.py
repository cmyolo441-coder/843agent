"""UniversalLoader: dispatch loading by source type / extension / scheme."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.parse import urlparse

from ..pipeline import Document

logger = logging.getLogger(__name__)


class UniversalLoader:
    """Selects an appropriate loader given a source URI or path."""

    def __init__(self) -> None:
        self._by_ext: dict[str, Any] = {}
        self._by_scheme: dict[str, Any] = {}
        self._register_defaults()

    def _register_defaults(self) -> None:
        from .loaders import (
            pdf_loader, docx_loader, xlsx_loader, csv_loader, json_loader,
            xml_loader, yaml_loader, html_loader, markdown_loader, rst_loader,
            epub_loader, pptx_loader, image_loader, audio_loader, video_loader,
            code_loader, sql_loader, mongo_loader, redis_loader, api_loader,
            graphql_loader, s3_loader, gcs_loader, azure_blob_loader,
            web_crawler_loader, git_loader, notepad_loader, latex_loader,
        )
        self.register_ext(".pdf", pdf_loader.PDFLoader())
        self.register_ext(".docx", docx_loader.DocxLoader())
        self.register_ext(".xlsx", xlsx_loader.XlsxLoader())
        self.register_ext(".csv", csv_loader.CSVLoader())
        self.register_ext(".json", json_loader.JSONLoader())
        self.register_ext(".xml", xml_loader.XMLLoader())
        for ext in (".yaml", ".yml"):
            self.register_ext(ext, yaml_loader.YAMLLoader())
        for ext in (".html", ".htm"):
            self.register_ext(ext, html_loader.HTMLLoader())
        self.register_ext(".md", markdown_loader.MarkdownLoader())
        self.register_ext(".rst", rst_loader.RSTLoader())
        self.register_ext(".epub", epub_loader.EpubLoader())
        self.register_ext(".pptx", pptx_loader.PptxLoader())
        for ext in (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff"):
            self.register_ext(ext, image_loader.ImageLoader())
        for ext in (".mp3", ".wav", ".flac", ".m4a", ".ogg"):
            self.register_ext(ext, audio_loader.AudioLoader())
        for ext in (".mp4", ".avi", ".mov", ".mkv"):
            self.register_ext(ext, video_loader.VideoLoader())
        for ext in (".py", ".js", ".ts", ".go", ".rs", ".java", ".c", ".cpp"):
            self.register_ext(ext, code_loader.CodeLoader())
        self.register_ext(".tex", latex_loader.LatexLoader())
        self.register_ext(".txt", notepad_loader.NotepadLoader())
        self.register_scheme("sql", sql_loader.SQLLoader())
        self.register_scheme("mongodb", mongo_loader.MongoLoader())
        self.register_scheme("redis", redis_loader.RedisLoader())
        self.register_scheme("http", api_loader.APILoader())
        self.register_scheme("https", api_loader.APILoader())
        self.register_scheme("graphql", graphql_loader.GraphQLLoader())
        self.register_scheme("s3", s3_loader.S3Loader())
        self.register_scheme("gs", gcs_loader.GCSLoader())
        self.register_scheme("azure", azure_blob_loader.AzureBlobLoader())
        self.register_scheme("crawl", web_crawler_loader.WebCrawlerLoader())
        self.register_scheme("git", git_loader.GitLoader())

    def register_ext(self, ext: str, loader: Any) -> None:
        self._by_ext[ext.lower()] = loader

    def register_scheme(self, scheme: str, loader: Any) -> None:
        self._by_scheme[scheme.lower()] = loader

    def select(self, source: str | Path) -> Any:
        s = str(source)
        parsed = urlparse(s)
        if parsed.scheme and parsed.scheme in self._by_scheme:
            return self._by_scheme[parsed.scheme]
        ext = Path(s).suffix.lower()
        if ext in self._by_ext:
            return self._by_ext[ext]
        raise ValueError(f"No loader registered for source: {source!r}")

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        loader = self.select(source)
        logger.debug("Dispatching %s to %s", source, type(loader).__name__)
        result = loader.load(source, **kwargs)
        return list(result) if isinstance(result, Iterable) and not isinstance(result, Document) else [result]
