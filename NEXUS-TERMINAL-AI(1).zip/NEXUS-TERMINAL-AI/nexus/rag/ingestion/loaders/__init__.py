"""Concrete document loaders for the UniversalLoader dispatcher."""
from __future__ import annotations

from . import (
    pdf_loader, docx_loader, xlsx_loader, csv_loader, json_loader,
    xml_loader, yaml_loader, html_loader, markdown_loader, rst_loader,
    epub_loader, pptx_loader, image_loader, audio_loader, video_loader,
    code_loader, sql_loader, mongo_loader, redis_loader, api_loader,
    graphql_loader, s3_loader, gcs_loader, azure_blob_loader,
    web_crawler_loader, git_loader, notepad_loader, latex_loader,
)

__all__ = [
    "pdf_loader", "docx_loader", "xlsx_loader", "csv_loader", "json_loader",
    "xml_loader", "yaml_loader", "html_loader", "markdown_loader", "rst_loader",
    "epub_loader", "pptx_loader", "image_loader", "audio_loader", "video_loader",
    "code_loader", "sql_loader", "mongo_loader", "redis_loader", "api_loader",
    "graphql_loader", "s3_loader", "gcs_loader", "azure_blob_loader",
    "web_crawler_loader", "git_loader", "notepad_loader", "latex_loader",
]
