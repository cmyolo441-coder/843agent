"""Generic HTTP API loader using urllib (no required external deps)."""
from __future__ import annotations

import json
import logging
import urllib.request
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class APILoader:
    """Fetches a JSON or text payload from an HTTP(S) endpoint."""

    def __init__(self, headers: dict[str, str] | None = None, timeout: float = 30.0) -> None:
        self.headers = headers or {}
        self.timeout = timeout

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        method = kwargs.get("method", "GET").upper()
        body = kwargs.get("body")
        extra_headers = kwargs.get("headers", {})
        all_headers = {**self.headers, **extra_headers}
        try:
            data = None
            if body is not None:
                data = body.encode("utf-8") if isinstance(body, str) else json.dumps(body).encode("utf-8")
                all_headers.setdefault("Content-Type", "application/json")
            req = urllib.request.Request(source, data=data, headers=all_headers, method=method)
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                payload = resp.read().decode("utf-8", errors="ignore")
                content_type = resp.headers.get("Content-Type", "")
                status = resp.status
        except Exception as exc:
            logger.warning("API load failed for %s: %s", source, exc)
            return [Document(text="", metadata={"source": source, "format": "api",
                                                "error": str(exc)})]
        meta = {"source": source, "format": "api", "status": status,
                "content_type": content_type, "method": method}
        if "json" in content_type.lower():
            try:
                payload = json.dumps(json.loads(payload), indent=2)
            except Exception:
                pass
        return [Document(text=payload, metadata=meta)]
