"""Audio loader: transcribes via OpenAI Whisper when available."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class AudioLoader:
    """Transcribes audio files to text using whisper."""

    def __init__(self, model_name: str = "base", language: str | None = None) -> None:
        self.model_name = model_name
        self.language = language
        self._model: Any | None = None

    def _get_model(self) -> Any:
        if self._model is None:
            import whisper  # type: ignore
            self._model = whisper.load_model(self.model_name)
        return self._model

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        text = ""
        meta: dict[str, Any] = {"source": str(path), "format": "audio",
                                "model": self.model_name}
        try:
            result = self._get_model().transcribe(
                str(path),
                language=self.language,
            )
            text = result.get("text", "").strip()
            meta["language_detected"] = result.get("language")
            meta["segments"] = len(result.get("segments", []))
        except Exception as exc:
            logger.warning("Whisper transcription failed for %s: %s", path, exc)
            meta["transcription_error"] = str(exc)
        return [Document(text=text, metadata=meta)]
