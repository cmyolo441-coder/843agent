"""Azure Blob Storage loader."""
from __future__ import annotations

import logging
from typing import Any
from urllib.parse import urlparse

from ...pipeline import Document

logger = logging.getLogger(__name__)


class AzureBlobLoader:
    """Loads blobs from Azure Storage given an azure://account/container/blob URI."""

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        parsed = urlparse(source)
        account = parsed.netloc
        path_parts = parsed.path.lstrip("/").split("/", 1)
        if len(path_parts) < 2:
            raise ValueError(f"Expected azure://account/container/blob, got {source!r}")
        container, blob_path = path_parts
        connection_string = kwargs.get("connection_string")
        try:
            from azure.storage.blob import BlobServiceClient  # type: ignore
            if connection_string:
                svc = BlobServiceClient.from_connection_string(connection_string)
            else:
                svc = BlobServiceClient(account_url=f"https://{account}.blob.core.windows.net")
            container_client = svc.get_container_client(container)
        except Exception as exc:
            logger.warning("azure-storage-blob unavailable: %s", exc)
            return [Document(text="", metadata={"source": source, "format": "azure-blob",
                                                "error": str(exc)})]
        names = ([blob_path] if not blob_path.endswith("/")
                 else [b.name for b in container_client.list_blobs(name_starts_with=blob_path)])
        docs: list[Document] = []
        for name in names:
            try:
                blob = container_client.get_blob_client(name)
                data = blob.download_blob().readall()
                text = data.decode("utf-8", errors="ignore")
            except Exception as exc:
                logger.warning("Azure blob fetch failed %s: %s", name, exc)
                continue
            docs.append(Document(text=text,
                                 metadata={"source": f"azure://{account}/{container}/{name}",
                                           "format": "azure-blob", "container": container,
                                           "name": name}))
        return docs
