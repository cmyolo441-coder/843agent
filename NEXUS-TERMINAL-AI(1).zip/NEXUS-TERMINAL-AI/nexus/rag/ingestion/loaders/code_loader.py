"""Source code loader: walks AST to extract identifiers and docstrings."""
from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class CodeLoader:
    """Loads source files; for Python uses ast to extract symbols and docstrings."""

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        raw = path.read_text(encoding="utf-8", errors="ignore")
        meta: dict[str, Any] = {"source": str(path), "format": "code",
                                "language": path.suffix.lstrip(".")}
        if path.suffix.lower() == ".py":
            symbols, docstrings = self._py_symbols(raw)
            meta["symbols"] = symbols
            meta["docstrings"] = len(docstrings)
        return [Document(text=raw, metadata=meta)]

    def _py_symbols(self, src: str) -> tuple[list[str], list[str]]:
        try:
            tree = ast.parse(src)
        except SyntaxError as exc:
            logger.warning("Failed to parse Python source: %s", exc)
            return [], []
        symbols: list[str] = []
        docstrings: list[str] = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                symbols.append(node.name)
                ds = ast.get_docstring(node)
                if ds:
                    docstrings.append(ds)
            elif isinstance(node, ast.Module):
                ds = ast.get_docstring(node)
                if ds:
                    docstrings.append(ds)
        return symbols, docstrings
