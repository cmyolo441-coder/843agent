"""CSV loader using the stdlib csv module."""
from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class CSVLoader:
    """Loads a CSV file as one Document per row, or one whole Document if requested."""

    def __init__(self, row_per_doc: bool = False, encoding: str = "utf-8") -> None:
        self.row_per_doc = row_per_doc
        self.encoding = encoding

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        with path.open("r", encoding=self.encoding, newline="") as fh:
            reader = csv.DictReader(fh)
            rows = list(reader)
        if self.row_per_doc:
            return [
                Document(
                    text=", ".join(f"{k}={v}" for k, v in row.items()),
                    metadata={"source": str(path), "format": "csv", "row": i,
                              "columns": list(row.keys())},
                )
                for i, row in enumerate(rows)
            ]
        header = ",".join(rows[0].keys()) if rows else ""
        body = "\n".join(",".join(str(v) for v in row.values()) for row in rows)
        return [Document(
            text=f"{header}\n{body}",
            metadata={"source": str(path), "format": "csv", "rows": len(rows)},
        )]
