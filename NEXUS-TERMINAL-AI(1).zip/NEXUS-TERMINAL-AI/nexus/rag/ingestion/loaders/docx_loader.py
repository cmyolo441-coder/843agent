"""DOCX loader: extracts paragraphs and tables from Microsoft Word files."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class DocxLoader:
    """Loads .docx files via python-docx, falling back to zip+xml when missing."""

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        try:
            import docx  # type: ignore
        except Exception:
            return self._fallback(path)
        document = docx.Document(str(path))
        paragraphs = [p.text for p in document.paragraphs if p.text and p.text.strip()]
        tables: list[str] = []
        for tbl in document.tables:
            for row in tbl.rows:
                tables.append(" | ".join(cell.text for cell in row.cells))
        text = "\n".join(paragraphs + tables)
        return [Document(text=text, metadata={"source": str(path), "format": "docx",
                                              "paragraphs": len(paragraphs)})]

    def _fallback(self, path: Path) -> list[Document]:
        import re
        import zipfile

        text = ""
        if path.exists():
            try:
                with zipfile.ZipFile(path) as zf:
                    with zf.open("word/document.xml") as fh:
                        raw = fh.read().decode("utf-8", errors="ignore")
                text = re.sub(r"<[^>]+>", " ", raw)
                text = re.sub(r"\s+", " ", text).strip()
            except Exception as exc:
                logger.warning("DOCX fallback failed for %s: %s", path, exc)
        return [Document(text=text, metadata={"source": str(path), "format": "docx",
                                              "fallback": True})]
