"""EPUB loader: extracts chapter HTML and strips tags."""
from __future__ import annotations

import logging
import re
import zipfile
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class EpubLoader:
    """Reads chapters out of an EPUB archive (zip of XHTML)."""

    _TAG_RE = re.compile(r"<[^>]+>")

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        docs: list[Document] = []
        try:
            with zipfile.ZipFile(path) as zf:
                xhtml = [n for n in zf.namelist() if n.lower().endswith((".xhtml", ".html"))]
                for i, name in enumerate(sorted(xhtml)):
                    raw = zf.read(name).decode("utf-8", errors="ignore")
                    text = self._TAG_RE.sub(" ", raw)
                    text = re.sub(r"\s+", " ", text).strip()
                    if not text:
                        continue
                    docs.append(Document(
                        text=text,
                        metadata={"source": str(path), "format": "epub",
                                  "chapter": name, "index": i},
                    ))
        except Exception as exc:
            logger.warning("EPUB load failed for %s: %s", path, exc)
        return docs
