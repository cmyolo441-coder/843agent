"""Google Cloud Storage loader using google-cloud-storage."""
from __future__ import annotations

import logging
from typing import Any
from urllib.parse import urlparse

from ...pipeline import Document

logger = logging.getLogger(__name__)


class GCSLoader:
    """Loads gs:// URIs (objects or prefixes)."""

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        parsed = urlparse(source)
        bucket_name = parsed.netloc
        prefix = parsed.path.lstrip("/")
        try:
            from google.cloud import storage  # type: ignore
            client = storage.Client()
            bucket = client.bucket(bucket_name)
        except Exception as exc:
            logger.warning("google-cloud-storage unavailable: %s", exc)
            return [Document(text="", metadata={"source": source, "format": "gcs",
                                                "error": str(exc)})]
        blobs = bucket.list_blobs(prefix=prefix) if prefix.endswith("/") or not prefix else [bucket.blob(prefix)]
        docs: list[Document] = []
        for blob in blobs:
            try:
                data = blob.download_as_bytes()
                text = data.decode("utf-8", errors="ignore")
            except Exception as exc:
                logger.warning("GCS fetch failed %s: %s", blob.name, exc)
                continue
            docs.append(Document(text=text,
                                 metadata={"source": f"gs://{bucket_name}/{blob.name}",
                                           "format": "gcs", "bucket": bucket_name,
                                           "name": blob.name}))
        return docs
