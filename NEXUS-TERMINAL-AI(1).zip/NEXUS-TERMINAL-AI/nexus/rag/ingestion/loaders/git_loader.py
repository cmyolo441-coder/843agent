"""Git repository loader: clones a repo and indexes file contents."""
from __future__ import annotations

import logging
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class GitLoader:
    """Clones a git URL (shallow), walks the working tree, and loads files."""

    _DEFAULT_EXTS = (".py", ".md", ".rst", ".txt", ".json", ".yaml", ".yml",
                     ".js", ".ts", ".go", ".rs", ".java", ".c", ".cpp", ".h")

    def __init__(self, extensions: tuple[str, ...] = _DEFAULT_EXTS, depth: int = 1) -> None:
        self.extensions = tuple(e.lower() for e in extensions)
        self.depth = depth

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        url = source.replace("git://", "https://", 1) if source.startswith("git://") else source
        ref = kwargs.get("ref")
        with tempfile.TemporaryDirectory() as tmp:
            repo_dir = Path(tmp) / "repo"
            cmd = ["git", "clone", "--depth", str(self.depth), url, str(repo_dir)]
            try:
                subprocess.run(cmd, check=True, capture_output=True, timeout=180)
                if ref:
                    subprocess.run(["git", "-C", str(repo_dir), "checkout", ref],
                                   check=True, capture_output=True, timeout=30)
            except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as exc:
                logger.warning("git clone failed for %s: %s", url, exc)
                return [Document(text="", metadata={"source": url, "format": "git",
                                                    "error": str(exc)})]
            docs: list[Document] = []
            for path in repo_dir.rglob("*"):
                if not path.is_file() or path.suffix.lower() not in self.extensions:
                    continue
                if ".git" in path.parts:
                    continue
                try:
                    text = path.read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    continue
                rel = path.relative_to(repo_dir).as_posix()
                docs.append(Document(text=text,
                                     metadata={"source": url, "format": "git",
                                               "path": rel, "extension": path.suffix.lower()}))
            return docs
