"""GraphQL loader: posts a query and yields the response as a Document."""
from __future__ import annotations

import json
import logging
import urllib.request
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class GraphQLLoader:
    """Executes a GraphQL query against an endpoint URL."""

    def __init__(self, headers: dict[str, str] | None = None, timeout: float = 30.0) -> None:
        self.headers = headers or {}
        self.timeout = timeout

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        endpoint = source.replace("graphql://", "https://") if source.startswith("graphql://") else source
        query = kwargs.get("query")
        if not query:
            raise ValueError("GraphQLLoader requires a 'query' kwarg")
        variables = kwargs.get("variables", {})
        payload = json.dumps({"query": query, "variables": variables}).encode("utf-8")
        headers = {"Content-Type": "application/json", **self.headers,
                   **kwargs.get("headers", {})}
        try:
            req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                body = resp.read().decode("utf-8", errors="ignore")
                status = resp.status
            data = json.loads(body)
            text = json.dumps(data.get("data", data), indent=2)
            errors = data.get("errors")
        except Exception as exc:
            logger.warning("GraphQL load failed: %s", exc)
            return [Document(text="", metadata={"source": endpoint, "format": "graphql",
                                                "error": str(exc)})]
        return [Document(text=text,
                         metadata={"source": endpoint, "format": "graphql",
                                   "status": status, "errors": errors})]
