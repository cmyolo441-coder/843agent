"""HTML loader stripping tags using BeautifulSoup when available."""
from __future__ import annotations

import logging
import re
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class _StripParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in ("script", "style"):
            self._skip += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style") and self._skip:
            self._skip -= 1

    def handle_data(self, data: str) -> None:
        if not self._skip and data.strip():
            self.parts.append(data.strip())


class HTMLLoader:
    """Strip HTML to text, preserving title and meta description as metadata."""

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        raw = path.read_text(encoding="utf-8", errors="ignore")
        try:
            from bs4 import BeautifulSoup  # type: ignore
            soup = BeautifulSoup(raw, "html.parser")
            for tag in soup(["script", "style", "noscript"]):
                tag.decompose()
            text = re.sub(r"\s+", " ", soup.get_text(separator=" ")).strip()
            title = soup.title.string.strip() if soup.title and soup.title.string else ""
        except Exception:
            parser = _StripParser()
            parser.feed(raw)
            text = " ".join(parser.parts)
            title = ""
        return [Document(text=text, metadata={"source": str(path), "format": "html",
                                              "title": title})]
