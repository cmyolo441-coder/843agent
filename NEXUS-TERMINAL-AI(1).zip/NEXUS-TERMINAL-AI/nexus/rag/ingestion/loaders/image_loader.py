"""Image loader using OCR (pytesseract) to extract text."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class ImageLoader:
    """OCR-based loader for image formats. Falls back to empty text if OCR libs missing."""

    def __init__(self, lang: str = "eng") -> None:
        self.lang = lang

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        text = ""
        meta: dict[str, Any] = {"source": str(path), "format": "image",
                                "extension": path.suffix.lower()}
        try:
            from PIL import Image  # type: ignore
            import pytesseract  # type: ignore
            img = Image.open(path)
            meta["width"], meta["height"] = img.size
            text = pytesseract.image_to_string(img, lang=self.lang)
        except Exception as exc:
            logger.warning("OCR unavailable / failed for %s: %s", path, exc)
            meta["ocr_error"] = str(exc)
        return [Document(text=text.strip(), metadata=meta)]
