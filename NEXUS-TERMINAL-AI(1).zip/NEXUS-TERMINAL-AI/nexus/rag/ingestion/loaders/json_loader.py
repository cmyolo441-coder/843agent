"""JSON loader for .json and .jsonl files."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class JSONLoader:
    """Loads JSON or JSON-Lines. Each top-level array entry becomes a Document."""

    def __init__(self, text_field: str = "text", jsonl: bool | None = None) -> None:
        self.text_field = text_field
        self.jsonl = jsonl

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        is_jsonl = self.jsonl if self.jsonl is not None else path.suffix.lower() == ".jsonl"
        docs: list[Document] = []
        if is_jsonl:
            with path.open("r", encoding="utf-8") as fh:
                for i, line in enumerate(fh):
                    line = line.strip()
                    if not line:
                        continue
                    obj = json.loads(line)
                    docs.append(self._to_doc(obj, str(path), index=i))
        else:
            obj = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(obj, list):
                for i, item in enumerate(obj):
                    docs.append(self._to_doc(item, str(path), index=i))
            else:
                docs.append(self._to_doc(obj, str(path)))
        return docs

    def _to_doc(self, obj: Any, src: str, index: int = 0) -> Document:
        if isinstance(obj, dict) and self.text_field in obj:
            text = str(obj[self.text_field])
            meta = {k: v for k, v in obj.items() if k != self.text_field}
        else:
            text = json.dumps(obj, ensure_ascii=False)
            meta = {}
        meta.update({"source": src, "format": "json", "index": index})
        return Document(text=text, metadata=meta)
