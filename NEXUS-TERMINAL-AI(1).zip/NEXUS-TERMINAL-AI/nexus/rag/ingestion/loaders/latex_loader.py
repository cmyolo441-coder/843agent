"""LaTeX loader: strips commands and comments to extract readable text."""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class LatexLoader:
    """Naive LaTeX → text converter using regex passes."""

    _COMMENT_RE = re.compile(r"(?<!\\)%.*$", re.MULTILINE)
    _ENV_RE = re.compile(r"\\begin\{([^}]+)\}.*?\\end\{\1\}", re.DOTALL)
    _CMD_RE = re.compile(r"\\[A-Za-z]+\*?(?:\[[^\]]*\])?(?:\{([^{}]*)\})?")
    _BRACE_RE = re.compile(r"[{}]")
    _DOLLAR_RE = re.compile(r"\$+[^$]*\$+")

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        raw = path.read_text(encoding="utf-8", errors="ignore")
        text = self._COMMENT_RE.sub("", raw)
        text = self._ENV_RE.sub("", text)
        text = self._DOLLAR_RE.sub(" ", text)

        def _keep_arg(match: re.Match[str]) -> str:
            return match.group(1) or " "

        text = self._CMD_RE.sub(_keep_arg, text)
        text = self._BRACE_RE.sub("", text)
        text = re.sub(r"\s+", " ", text).strip()
        return [Document(text=text,
                         metadata={"source": str(path), "format": "latex"})]
