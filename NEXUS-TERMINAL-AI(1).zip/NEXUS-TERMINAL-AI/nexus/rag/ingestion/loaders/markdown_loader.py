"""Markdown loader: preserves headings as metadata anchors."""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$", re.MULTILINE)


class MarkdownLoader:
    """Loads .md files and extracts headings for downstream chunkers."""

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        text = path.read_text(encoding="utf-8")
        headings = [(len(m.group(1)), m.group(2).strip()) for m in _HEADING_RE.finditer(text)]
        meta = {
            "source": str(path),
            "format": "markdown",
            "headings": headings,
            "n_headings": len(headings),
        }
        return [Document(text=text, metadata=meta)]
