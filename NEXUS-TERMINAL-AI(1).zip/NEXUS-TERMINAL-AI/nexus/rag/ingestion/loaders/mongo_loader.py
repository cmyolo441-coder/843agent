"""MongoDB loader: yields documents from a collection."""
from __future__ import annotations

import json
import logging
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class MongoLoader:
    """Loads documents from MongoDB via pymongo. URI as source, db/collection in kwargs."""

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        db_name = kwargs.get("database")
        coll_name = kwargs.get("collection")
        query = kwargs.get("query", {})
        limit = int(kwargs.get("limit", 1000))
        text_field = kwargs.get("text_field", "text")
        if not db_name or not coll_name:
            raise ValueError("MongoLoader requires 'database' and 'collection' kwargs")
        try:
            from pymongo import MongoClient  # type: ignore
            client = MongoClient(source)
            coll = client[db_name][coll_name]
            cursor = coll.find(query).limit(limit)
            docs = []
            for i, item in enumerate(cursor):
                item.pop("_id", None)
                text = item.get(text_field) or json.dumps(item, default=str)
                meta = {k: v for k, v in item.items() if k != text_field}
                meta.update({"source": source, "format": "mongodb",
                             "database": db_name, "collection": coll_name, "index": i})
                docs.append(Document(text=str(text), metadata=meta))
            return docs
        except Exception as exc:
            logger.warning("Mongo load failed: %s", exc)
            return [Document(text="", metadata={"source": source, "format": "mongodb",
                                                "error": str(exc)})]
