"""Plain text loader for .txt and arbitrary text files."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class NotepadLoader:
    """Reads a UTF-8 (best-effort) text file with line/byte counts in metadata."""

    def __init__(self, encoding: str = "utf-8") -> None:
        self.encoding = encoding

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        try:
            text = path.read_text(encoding=self.encoding, errors="replace")
        except FileNotFoundError:
            logger.warning("Missing text file %s", path)
            return [Document(text="", metadata={"source": str(path), "format": "text",
                                                "error": "missing"})]
        meta = {
            "source": str(path),
            "format": "text",
            "encoding": self.encoding,
            "bytes": path.stat().st_size if path.exists() else 0,
            "lines": text.count("\n") + (1 if text else 0),
        }
        return [Document(text=text, metadata=meta)]
