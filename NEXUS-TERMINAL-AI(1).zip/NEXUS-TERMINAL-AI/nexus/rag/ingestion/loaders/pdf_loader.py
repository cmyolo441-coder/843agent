"""PDF loader using pypdf / pdfminer to extract text per page."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class PDFLoader:
    """Extracts text from PDF files, one Document per page."""

    def __init__(self, password: str | None = None) -> None:
        self.password = password

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        docs: list[Document] = []
        try:
            from pypdf import PdfReader  # type: ignore
        except Exception:  # pragma: no cover
            logger.warning("pypdf not available; reading raw bytes for %s", path)
            data = path.read_bytes() if path.exists() else b""
            return [Document(text=data.decode("latin-1", errors="ignore"),
                             metadata={"source": str(path), "format": "pdf"})]
        reader = PdfReader(str(path))
        if self.password and reader.is_encrypted:
            reader.decrypt(self.password)
        for i, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            docs.append(Document(
                text=text,
                metadata={"source": str(path), "page": i + 1,
                          "pages": len(reader.pages), "format": "pdf"},
            ))
        logger.info("Loaded %d pages from %s", len(docs), path)
        return docs
