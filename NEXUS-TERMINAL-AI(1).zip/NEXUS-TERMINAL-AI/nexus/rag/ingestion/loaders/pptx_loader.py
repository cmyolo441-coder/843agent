"""PPTX loader: extracts text from slides via python-pptx."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class PptxLoader:
    """One Document per slide, text from titles, body placeholders, and notes."""

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        try:
            from pptx import Presentation  # type: ignore
        except Exception:
            logger.warning("python-pptx not available; returning empty for %s", path)
            return [Document(text="", metadata={"source": str(path), "format": "pptx",
                                                "error": "python-pptx-missing"})]
        prs = Presentation(str(path))
        docs: list[Document] = []
        for i, slide in enumerate(prs.slides, 1):
            chunks: list[str] = []
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text:
                    chunks.append(shape.text)
            note = ""
            if slide.has_notes_slide:
                note = slide.notes_slide.notes_text_frame.text or ""
            text = "\n".join(chunks)
            if note:
                text += f"\n\nNOTES: {note}"
            docs.append(Document(text=text,
                                 metadata={"source": str(path), "format": "pptx",
                                           "slide": i, "n_slides": len(prs.slides)}))
        return docs
