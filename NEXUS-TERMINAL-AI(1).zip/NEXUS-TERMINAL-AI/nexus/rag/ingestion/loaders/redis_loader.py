"""Redis loader: pulls values for a key pattern."""
from __future__ import annotations

import logging
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class RedisLoader:
    """Loads values from a Redis instance matching a SCAN pattern."""

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        pattern = kwargs.get("pattern", "*")
        count = int(kwargs.get("count", 500))
        try:
            import redis  # type: ignore
            client = redis.Redis.from_url(source)
            docs: list[Document] = []
            cursor = 0
            scanned = 0
            while True:
                cursor, keys = client.scan(cursor=cursor, match=pattern, count=100)
                for key in keys:
                    val = client.get(key)
                    if val is None:
                        continue
                    if isinstance(val, bytes):
                        val = val.decode("utf-8", errors="ignore")
                    if isinstance(key, bytes):
                        key = key.decode()
                    docs.append(Document(
                        text=val,
                        metadata={"source": source, "format": "redis", "key": key},
                    ))
                    scanned += 1
                    if scanned >= count:
                        return docs
                if cursor == 0:
                    break
            return docs
        except Exception as exc:
            logger.warning("Redis load failed: %s", exc)
            return [Document(text="", metadata={"source": source, "format": "redis",
                                                "error": str(exc)})]
