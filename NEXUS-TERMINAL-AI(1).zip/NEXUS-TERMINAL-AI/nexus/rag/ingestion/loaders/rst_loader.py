"""reStructuredText loader: strips directives and code blocks."""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)

_DIRECTIVE = re.compile(r"^\.\. [A-Za-z_]+::.*(?:\n {3,}.*)*", re.MULTILINE)
_UNDERLINE = re.compile(r"^[=\-`~\^\"]{3,}\s*$", re.MULTILINE)


class RSTLoader:
    """Naive RST loader; uses docutils when available."""

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        raw = path.read_text(encoding="utf-8")
        try:
            from docutils.core import publish_parts  # type: ignore
            parts = publish_parts(raw, writer_name="plaintext")
            text = parts.get("whole", raw)
        except Exception:
            text = _DIRECTIVE.sub("", raw)
            text = _UNDERLINE.sub("", text)
        return [Document(text=text.strip(),
                         metadata={"source": str(path), "format": "rst"})]
