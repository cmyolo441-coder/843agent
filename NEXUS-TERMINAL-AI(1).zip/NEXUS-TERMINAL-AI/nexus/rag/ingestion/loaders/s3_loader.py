"""Amazon S3 loader using boto3."""
from __future__ import annotations

import logging
from typing import Any
from urllib.parse import urlparse

from ...pipeline import Document

logger = logging.getLogger(__name__)


class S3Loader:
    """Loads an object or every object under a prefix from S3."""

    def __init__(self, region: str | None = None) -> None:
        self.region = region

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        parsed = urlparse(source)
        bucket = parsed.netloc
        key = parsed.path.lstrip("/")
        try:
            import boto3  # type: ignore
            client = boto3.client("s3", region_name=self.region)
        except Exception as exc:
            logger.warning("boto3 unavailable: %s", exc)
            return [Document(text="", metadata={"source": source, "format": "s3",
                                                "error": str(exc)})]
        docs: list[Document] = []
        if key.endswith("/") or not key:
            paginator = client.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=bucket, Prefix=key):
                for obj in page.get("Contents", []) or []:
                    docs.append(self._fetch_one(client, bucket, obj["Key"]))
        else:
            docs.append(self._fetch_one(client, bucket, key))
        return docs

    def _fetch_one(self, client: Any, bucket: str, key: str) -> Document:
        try:
            obj = client.get_object(Bucket=bucket, Key=key)
            body = obj["Body"].read()
            text = body.decode("utf-8", errors="ignore")
        except Exception as exc:
            text = ""
            logger.warning("S3 fetch failed s3://%s/%s: %s", bucket, key, exc)
        return Document(text=text, metadata={"source": f"s3://{bucket}/{key}",
                                             "format": "s3", "bucket": bucket, "key": key})
