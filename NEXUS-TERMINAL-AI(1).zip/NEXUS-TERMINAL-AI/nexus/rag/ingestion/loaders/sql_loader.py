"""SQL database loader: runs a query and yields rows as Documents."""
from __future__ import annotations

import logging
from typing import Any
from urllib.parse import urlparse

from ...pipeline import Document

logger = logging.getLogger(__name__)


class SQLLoader:
    """Loads rows from a SQL database via SQLAlchemy. Source = DSN like 'sql://...'.

    Pass `query` and optional `params` via kwargs to .load().
    """

    def __init__(self, batch_size: int = 1000) -> None:
        self.batch_size = batch_size

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        query: str = kwargs.get("query") or "SELECT 1"
        text_field: str = kwargs.get("text_field", "text")
        params: dict[str, Any] = kwargs.get("params", {})
        dsn = self._normalize_dsn(source)
        try:
            from sqlalchemy import create_engine, text as sa_text  # type: ignore
            engine = create_engine(dsn)
            with engine.connect() as conn:
                result = conn.execute(sa_text(query), params)
                rows = [dict(r._mapping) for r in result]
        except Exception as exc:
            logger.warning("SQL load failed: %s", exc)
            return [Document(text="", metadata={"source": dsn, "format": "sql",
                                                "error": str(exc)})]
        docs: list[Document] = []
        for i, row in enumerate(rows):
            txt = str(row.get(text_field, row))
            docs.append(Document(text=txt,
                                 metadata={"source": dsn, "format": "sql",
                                           "row": i, "columns": list(row.keys())}))
        return docs

    @staticmethod
    def _normalize_dsn(source: str) -> str:
        # Strip 'sql://' prefix → assume the rest is a real SQLAlchemy URL.
        parsed = urlparse(source)
        if parsed.scheme == "sql":
            return source[len("sql://"):]
        return source
