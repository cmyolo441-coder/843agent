"""Video loader: extracts keyframes (OCR) and audio track (transcription)."""
from __future__ import annotations

import logging
import tempfile
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class VideoLoader:
    """Extracts text from videos by combining frame OCR and audio transcription."""

    def __init__(self, frame_interval: int = 30, ocr_lang: str = "eng",
                 whisper_model: str = "base") -> None:
        self.frame_interval = frame_interval
        self.ocr_lang = ocr_lang
        self.whisper_model = whisper_model

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        docs: list[Document] = []
        ocr_text = self._frame_ocr(path)
        if ocr_text:
            docs.append(Document(text=ocr_text,
                                 metadata={"source": str(path), "format": "video",
                                           "track": "visual"}))
        speech = self._transcribe_audio(path)
        if speech:
            docs.append(Document(text=speech,
                                 metadata={"source": str(path), "format": "video",
                                           "track": "audio"}))
        if not docs:
            docs.append(Document(text="", metadata={"source": str(path), "format": "video",
                                                    "empty": True}))
        return docs

    def _frame_ocr(self, path: Path) -> str:
        try:
            import cv2  # type: ignore
            import pytesseract  # type: ignore
            cap = cv2.VideoCapture(str(path))
            i, parts = 0, []
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                if i % self.frame_interval == 0:
                    parts.append(pytesseract.image_to_string(frame, lang=self.ocr_lang))
                i += 1
            cap.release()
            return "\n".join(p.strip() for p in parts if p.strip())
        except Exception as exc:
            logger.warning("Video OCR unavailable for %s: %s", path, exc)
            return ""

    def _transcribe_audio(self, path: Path) -> str:
        try:
            from .audio_loader import AudioLoader
            return AudioLoader(self.whisper_model).load(path)[0].text
        except Exception as exc:
            logger.warning("Video transcription failed for %s: %s", path, exc)
            return ""
