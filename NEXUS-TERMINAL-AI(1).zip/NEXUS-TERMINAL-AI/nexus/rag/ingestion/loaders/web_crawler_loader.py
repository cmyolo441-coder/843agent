"""Web crawler loader: BFS traversal of same-origin pages."""
from __future__ import annotations

import logging
import re
import urllib.request
from collections import deque
from typing import Any
from urllib.parse import urldefrag, urljoin, urlparse

from ...pipeline import Document

logger = logging.getLogger(__name__)


class WebCrawlerLoader:
    """Fetches a start URL and follows same-host links up to a depth/page cap."""

    _HREF_RE = re.compile(r'href=["\']([^"\']+)["\']', re.IGNORECASE)
    _TAG_RE = re.compile(r"<[^>]+>")

    def __init__(self, max_pages: int = 25, max_depth: int = 2, timeout: float = 15.0) -> None:
        self.max_pages = max_pages
        self.max_depth = max_depth
        self.timeout = timeout

    def load(self, source: str, **kwargs: Any) -> list[Document]:
        start = source.replace("crawl://", "https://", 1) if source.startswith("crawl://") else source
        host = urlparse(start).netloc
        seen: set[str] = set()
        queue: deque[tuple[str, int]] = deque([(start, 0)])
        docs: list[Document] = []
        while queue and len(docs) < self.max_pages:
            url, depth = queue.popleft()
            url, _ = urldefrag(url)
            if url in seen:
                continue
            seen.add(url)
            try:
                with urllib.request.urlopen(url, timeout=self.timeout) as resp:
                    body = resp.read().decode("utf-8", errors="ignore")
            except Exception as exc:
                logger.warning("Crawl fetch failed %s: %s", url, exc)
                continue
            text = re.sub(r"\s+", " ", self._TAG_RE.sub(" ", body)).strip()
            docs.append(Document(text=text,
                                 metadata={"source": url, "format": "web",
                                           "depth": depth, "host": host}))
            if depth < self.max_depth:
                for m in self._HREF_RE.finditer(body):
                    nxt = urljoin(url, m.group(1))
                    if urlparse(nxt).netloc == host and nxt not in seen:
                        queue.append((nxt, depth + 1))
        return docs
