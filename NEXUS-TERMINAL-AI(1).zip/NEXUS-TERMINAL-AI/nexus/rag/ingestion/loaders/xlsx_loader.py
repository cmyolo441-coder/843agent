"""XLSX loader: extracts cell text per sheet using openpyxl."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class XlsxLoader:
    """Reads each sheet of an Excel workbook into a Document."""

    def __init__(self, include_formulas: bool = False) -> None:
        self.include_formulas = include_formulas

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        docs: list[Document] = []
        try:
            from openpyxl import load_workbook  # type: ignore
        except Exception:
            logger.warning("openpyxl not available for %s", path)
            return [Document(text="", metadata={"source": str(path), "format": "xlsx",
                                                "error": "openpyxl-missing"})]
        wb = load_workbook(str(path), data_only=not self.include_formulas, read_only=True)
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = []
            for row in ws.iter_rows(values_only=True):
                cells = ["" if c is None else str(c) for c in row]
                if any(cells):
                    rows.append(",".join(cells))
            text = "\n".join(rows)
            docs.append(Document(
                text=text,
                metadata={"source": str(path), "format": "xlsx",
                          "sheet": sheet_name, "rows": len(rows)},
            ))
        return docs
