"""XML loader using xml.etree from stdlib."""
from __future__ import annotations

import logging
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class XMLLoader:
    """Flatten XML into newline-separated tag=value strings."""

    def __init__(self, element_path: str | None = None) -> None:
        self.element_path = element_path

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        tree = ET.parse(str(path))
        root = tree.getroot()
        elements = root.iter() if self.element_path is None else root.iterfind(self.element_path)
        lines: list[str] = []
        for el in elements:
            text = (el.text or "").strip()
            if text:
                lines.append(f"{el.tag}: {text}")
            for attr, val in el.attrib.items():
                lines.append(f"{el.tag}@{attr}: {val}")
        return [Document(
            text="\n".join(lines),
            metadata={"source": str(path), "format": "xml",
                      "root": root.tag, "elements": len(lines)},
        )]
