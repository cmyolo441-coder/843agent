"""YAML loader using PyYAML when available, else a minimal fallback."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from ...pipeline import Document

logger = logging.getLogger(__name__)


class YAMLLoader:
    """Loads a YAML file; renders parsed object as pretty JSON for downstream chunking."""

    def load(self, source: str | Path, **kwargs: Any) -> list[Document]:
        path = Path(source)
        raw = path.read_text(encoding="utf-8")
        obj: Any
        try:
            import yaml  # type: ignore
            obj = yaml.safe_load(raw)
        except Exception:
            logger.warning("PyYAML unavailable; using raw text for %s", path)
            obj = raw
        text = json.dumps(obj, indent=2, ensure_ascii=False) if not isinstance(obj, str) else obj
        return [Document(text=text, metadata={"source": str(path), "format": "yaml"})]
