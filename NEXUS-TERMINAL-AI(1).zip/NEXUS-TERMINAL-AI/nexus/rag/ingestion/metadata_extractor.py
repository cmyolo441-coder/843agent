"""MetadataExtractor: heuristics for title, author, publish date."""
from __future__ import annotations

import logging
import re
from datetime import date
from typing import Any

from ..pipeline import Document

logger = logging.getLogger(__name__)


class MetadataExtractor:
    """Pulls common bibliographic-ish fields out of free text."""

    _TITLE_RE = re.compile(r"^\s*#\s+(.+)$|^title\s*[:=]\s*(.+)$",
                           re.IGNORECASE | re.MULTILINE)
    _AUTHOR_RE = re.compile(
        r"(?:by\s+|author\s*[:=]\s*)([A-Z][A-Za-z'\-]+(?:\s+[A-Z][A-Za-z'\-]+){0,3})",
        re.IGNORECASE,
    )
    _DATE_RE = re.compile(
        r"\b(\d{4})-(\d{2})-(\d{2})\b|"
        r"\b(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+(\d{4})\b",
        re.IGNORECASE,
    )

    def extract(self, doc: Document) -> Document:
        text = doc.text or ""
        meta: dict[str, Any] = dict(doc.metadata)
        if "title" not in meta:
            title = self._title(text) or self._first_line_title(text)
            if title:
                meta["title"] = title
        if "author" not in meta:
            author = self._author(text)
            if author:
                meta["author"] = author
        if "date" not in meta:
            d = self._date(text)
            if d:
                meta["date"] = d.isoformat()
        meta["word_count"] = len(text.split())
        return Document(text=text, metadata=meta, id=doc.id)

    def _title(self, text: str) -> str:
        match = self._TITLE_RE.search(text)
        if not match:
            return ""
        return (match.group(1) or match.group(2) or "").strip()

    @staticmethod
    def _first_line_title(text: str) -> str:
        for line in text.splitlines():
            line = line.strip()
            if 4 <= len(line) <= 120:
                return line
        return ""

    def _author(self, text: str) -> str:
        match = self._AUTHOR_RE.search(text)
        return match.group(1).strip() if match else ""

    def _date(self, text: str) -> date | None:
        match = self._DATE_RE.search(text)
        if not match:
            return None
        try:
            if match.group(1):
                return date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
            months = "jan feb mar apr may jun jul aug sep oct nov dec".split()
            month = months.index(match.group(5)[:3].lower()) + 1
            return date(int(match.group(6)), month, int(match.group(4)))
        except (ValueError, IndexError):
            return None
