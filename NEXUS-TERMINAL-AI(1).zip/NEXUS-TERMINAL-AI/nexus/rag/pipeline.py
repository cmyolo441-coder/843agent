"""End-to-end RAG pipeline: load -> chunk -> embed -> index -> retrieve -> rerank -> generate."""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence

logger = logging.getLogger(__name__)


@dataclass
class Document:
    """A unit of indexable content with text + metadata."""

    text: str
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: uuid.uuid4().hex)

    def __len__(self) -> int:
        return len(self.text)


@dataclass
class RAGResult:
    """Result of a RAG query: generated answer + supporting context."""

    answer: str
    contexts: list[Document]
    scores: list[float]
    latency_ms: float
    metadata: dict[str, Any] = field(default_factory=dict)


class RAGPipeline:
    """Orchestrates the full RAG flow across pluggable components."""

    def __init__(
        self,
        loader: Any,
        chunker: Any,
        embedder: Any,
        vectorstore: Any,
        retriever: Any,
        reranker: Optional[Any] = None,
        generator: Optional[Any] = None,
        top_k: int = 5,
        rerank_k: int = 20,
    ) -> None:
        self.loader = loader
        self.chunker = chunker
        self.embedder = embedder
        self.vectorstore = vectorstore
        self.retriever = retriever
        self.reranker = reranker
        self.generator = generator
        self.top_k = top_k
        self.rerank_k = rerank_k
        self._ingested: int = 0

    async def ingest(self, sources: Iterable[str | Path]) -> int:
        """Load each source, chunk, embed, and index."""
        total = 0
        for src in sources:
            docs = await self._maybe_await(self.loader.load(src))
            chunks = self.chunker.chunk(docs) if hasattr(self.chunker, "chunk") else docs
            vectors = await self._maybe_await(self.embedder.embed([c.text for c in chunks]))
            for chunk, vec in zip(chunks, vectors):
                self.vectorstore.add(chunk.id, vec, chunk.text, chunk.metadata)
                total += 1
        self._ingested += total
        logger.info("Ingested %d chunks (total=%d)", total, self._ingested)
        return total

    async def query(self, question: str, top_k: Optional[int] = None) -> RAGResult:
        """Run retrieval + (optional) rerank + generation for a question."""
        start = time.perf_counter()
        k = top_k or self.top_k
        candidates = await self._maybe_await(
            self.retriever.retrieve(question, k=self.rerank_k)
        )
        if self.reranker is not None:
            candidates = await self._maybe_await(
                self.reranker.rerank(question, candidates, top_k=k)
            )
        else:
            candidates = candidates[:k]
        docs = [c[0] if isinstance(c, tuple) else c for c in candidates]
        scores = [c[1] if isinstance(c, tuple) else 1.0 for c in candidates]
        answer = ""
        if self.generator is not None:
            answer = await self._maybe_await(self.generator.generate(question, docs))
        latency = (time.perf_counter() - start) * 1000.0
        return RAGResult(answer=answer, contexts=docs, scores=scores, latency_ms=latency)

    @staticmethod
    async def _maybe_await(value: Any) -> Any:
        if asyncio.iscoroutine(value) or asyncio.isfuture(value):
            return await value
        return value
