"""QueryEngine: query understanding, expansion, rewriting, and decomposition."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class ExpandedQuery:
    """Result of query expansion: original + variants + sub-questions."""

    original: str
    rewrites: list[str] = field(default_factory=list)
    sub_questions: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)

    def all_queries(self) -> list[str]:
        return [self.original, *self.rewrites, *self.sub_questions]


class QueryEngine:
    """Transforms a raw user query for richer retrieval."""

    _STOPWORDS = frozenset({
        "the", "a", "an", "of", "to", "in", "on", "for", "and", "or",
        "is", "are", "was", "were", "be", "this", "that", "with", "by",
    })

    def __init__(self, llm: Optional[Any] = None, max_rewrites: int = 3) -> None:
        self.llm = llm
        self.max_rewrites = max_rewrites

    def expand(self, query: str) -> ExpandedQuery:
        """Produce rewrites + sub-questions + keywords for *query*."""
        query = (query or "").strip()
        if not query:
            return ExpandedQuery(original="")
        rewrites = self._rule_based_rewrites(query)[: self.max_rewrites]
        subs = self._decompose(query)
        keywords = self._keywords(query)
        if self.llm is not None:
            try:
                llm_rewrites = self.llm.complete(
                    f"Generate {self.max_rewrites} paraphrases:\n{query}"
                )
                if isinstance(llm_rewrites, str):
                    rewrites.extend(s.strip("- \t") for s in llm_rewrites.splitlines() if s.strip())
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning("LLM expansion failed: %s", exc)
        return ExpandedQuery(original=query, rewrites=rewrites[: self.max_rewrites],
                             sub_questions=subs, keywords=keywords)

    def rewrite(self, query: str) -> str:
        """Single best rewrite (HyDE-style stub)."""
        return self._rule_based_rewrites(query)[0] if query else ""

    def _rule_based_rewrites(self, q: str) -> list[str]:
        base = q.rstrip("?").strip()
        return [
            f"{base}?",
            f"What is meant by {base}",
            f"Explain {base} in detail",
        ]

    def _decompose(self, q: str) -> list[str]:
        # Split on common conjunctions / question separators.
        parts = re.split(r"\band\b|\bor\b|;|\?", q, flags=re.IGNORECASE)
        return [p.strip() for p in parts if len(p.strip()) > 3 and p.strip().lower() != q.lower()]

    def _keywords(self, q: str) -> list[str]:
        tokens = re.findall(r"[A-Za-z][A-Za-z0-9_-]+", q.lower())
        return [t for t in tokens if t not in self._STOPWORDS]
