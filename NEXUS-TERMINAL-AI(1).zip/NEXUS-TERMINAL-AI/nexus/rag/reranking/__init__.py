"""Reranking subsystem: post-retrieval re-ordering of candidate documents."""
from __future__ import annotations

from .base_reranker import BaseReranker

__all__ = ["BaseReranker"]
