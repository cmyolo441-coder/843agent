"""BaseReranker: ABC for all rerankers."""
from __future__ import annotations

import abc
import logging
from typing import Sequence

from ..pipeline import Document

logger = logging.getLogger(__name__)

Candidate = tuple[Document, float]


class BaseReranker(abc.ABC):
    """All rerankers consume (query, candidates) and emit re-scored candidates."""

    name: str = "base"

    @abc.abstractmethod
    def _score(self, query: str, doc: Document) -> float:
        """Return a relevance score for *doc* given *query*."""

    def rerank(self, query: str, candidates: Sequence[Candidate],
               top_k: int | None = None) -> list[Candidate]:
        scored: list[Candidate] = []
        for item in candidates:
            doc = item[0] if isinstance(item, tuple) else item
            score = self._score(query, doc)
            scored.append((doc, score))
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[: top_k] if top_k else scored

    async def arerank(self, query: str, candidates: Sequence[Candidate],
                      top_k: int | None = None) -> list[Candidate]:
        return self.rerank(query, candidates, top_k)
