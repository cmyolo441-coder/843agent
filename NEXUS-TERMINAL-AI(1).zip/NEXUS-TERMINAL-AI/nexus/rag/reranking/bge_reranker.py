"""BGE reranker (BAAI/bge-reranker-large) via CrossEncoder."""
from __future__ import annotations

import logging

from .cross_encoder import CrossEncoderReranker

logger = logging.getLogger(__name__)


class BGEReranker(CrossEncoderReranker):
    """Convenience subclass pinning the BGE reranker model."""

    name = "bge_reranker"

    def __init__(self, model: str = "BAAI/bge-reranker-large", device: str = "cpu",
                 batch_size: int = 16) -> None:
        super().__init__(model=model, device=device, batch_size=batch_size)
