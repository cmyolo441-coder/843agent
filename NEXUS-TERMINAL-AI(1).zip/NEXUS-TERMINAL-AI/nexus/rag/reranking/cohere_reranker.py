"""Cohere rerank API wrapper."""
from __future__ import annotations

import logging
from typing import Any

from ..pipeline import Document
from .base_reranker import BaseReranker, Candidate

logger = logging.getLogger(__name__)


class CohereReranker(BaseReranker):
    """Wraps the Cohere rerank endpoint."""

    name = "cohere"

    def __init__(self, model: str = "rerank-english-v3.0", api_key: str | None = None) -> None:
        self.model = model
        self.api_key = api_key
        self._client: Any = None

    def _client_lazy(self) -> Any:
        if self._client is None:
            try:
                import cohere  # type: ignore
                self._client = cohere.Client(self.api_key) if self.api_key else cohere.Client()
            except Exception as exc:
                logger.warning("cohere SDK unavailable: %s", exc)
                self._client = False
        return self._client

    def _score(self, query: str, doc: Document) -> float:
        client = self._client_lazy()
        if not client:
            return 0.0
        try:
            res = client.rerank(query=query, documents=[doc.text],
                                model=self.model, top_n=1)
            return float(res.results[0].relevance_score)
        except Exception as exc:
            logger.warning("Cohere rerank single failed: %s", exc)
            return 0.0

    def rerank(self, query: str, candidates, top_k: int | None = None) -> list[Candidate]:
        client = self._client_lazy()
        if not client or not candidates:
            return super().rerank(query, candidates, top_k)
        docs = [(c[0] if isinstance(c, tuple) else c) for c in candidates]
        try:
            res = client.rerank(query=query, documents=[d.text for d in docs],
                                model=self.model, top_n=top_k or len(docs))
            out: list[Candidate] = []
            for r in res.results:
                out.append((docs[r.index], float(r.relevance_score)))
            return out
        except Exception as exc:
            logger.warning("Cohere batch rerank failed: %s", exc)
            return super().rerank(query, candidates, top_k)
