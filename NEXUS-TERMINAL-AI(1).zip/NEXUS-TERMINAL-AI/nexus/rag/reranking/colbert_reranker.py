"""ColBERT-style late-interaction reranker."""
from __future__ import annotations

import logging
import math
from typing import Sequence

from ..embedding.colbert_embedder import ColBERTEmbedder
from ..pipeline import Document
from .base_reranker import BaseReranker

logger = logging.getLogger(__name__)


class ColBERTReranker(BaseReranker):
    """MaxSim aggregation between query and document token vectors."""

    name = "colbert"

    def __init__(self, embedder: ColBERTEmbedder | None = None) -> None:
        self.embedder = embedder or ColBERTEmbedder()

    def _score(self, query: str, doc: Document) -> float:
        q_tokens = self.embedder.embed_tokens(query)
        d_tokens = self.embedder.embed_tokens(doc.text)
        if not q_tokens or not d_tokens:
            return 0.0
        total = 0.0
        for qv in q_tokens:
            best = max(self._cosine(qv, dv) for dv in d_tokens)
            total += best
        return total / len(q_tokens)

    @staticmethod
    def _cosine(a: Sequence[float], b: Sequence[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        return dot / (na * nb) if na and nb else 0.0
