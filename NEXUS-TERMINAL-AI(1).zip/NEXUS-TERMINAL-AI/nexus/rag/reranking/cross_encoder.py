"""Cross-encoder reranker using sentence-transformers CrossEncoder."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..pipeline import Document
from .base_reranker import BaseReranker, Candidate

logger = logging.getLogger(__name__)


class CrossEncoderReranker(BaseReranker):
    """Wraps a HuggingFace cross-encoder. Falls back to lexical Jaccard if unavailable."""

    name = "cross_encoder"

    def __init__(self, model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2",
                 device: str = "cpu", batch_size: int = 32) -> None:
        self.model_name = model
        self.device = device
        self.batch_size = batch_size
        self._model: Any = None

    def _load(self) -> bool:
        if self._model is not None:
            return True
        try:
            from sentence_transformers import CrossEncoder  # type: ignore
            self._model = CrossEncoder(self.model_name, device=self.device)
            return True
        except Exception as exc:
            logger.warning("CrossEncoder unavailable: %s", exc)
            return False

    def _score(self, query: str, doc: Document) -> float:
        if not self._load():
            return self._jaccard(query, doc.text)
        try:
            return float(self._model.predict([(query, doc.text)])[0])
        except Exception as exc:
            logger.warning("CrossEncoder predict failed: %s", exc)
            return self._jaccard(query, doc.text)

    def rerank(self, query: str, candidates, top_k: int | None = None) -> list[Candidate]:
        if not self._load() or not candidates:
            return super().rerank(query, candidates, top_k)
        pairs = [(query, (c[0] if isinstance(c, tuple) else c).text) for c in candidates]
        scores = self._model.predict(pairs, batch_size=self.batch_size).tolist()
        out = [((c[0] if isinstance(c, tuple) else c), float(s))
               for c, s in zip(candidates, scores)]
        out.sort(key=lambda x: x[1], reverse=True)
        return out[: top_k] if top_k else out

    @staticmethod
    def _jaccard(a: str, b: str) -> float:
        ta = {t for t in re.findall(r"[a-z0-9]+", a.lower()) if len(t) > 2}
        tb = {t for t in re.findall(r"[a-z0-9]+", b.lower()) if len(t) > 2}
        if not ta or not tb:
            return 0.0
        return len(ta & tb) / len(ta | tb)
