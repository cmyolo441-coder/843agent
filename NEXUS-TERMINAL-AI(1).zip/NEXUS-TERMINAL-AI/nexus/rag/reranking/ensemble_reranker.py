"""Ensemble reranker: averages or RRF-merges several reranker outputs."""
from __future__ import annotations

import logging
from typing import Sequence

from ..pipeline import Document
from ..retrieval.reciprocal_rank import reciprocal_rank_fusion
from .base_reranker import BaseReranker, Candidate

logger = logging.getLogger(__name__)


class EnsembleReranker(BaseReranker):
    """Combines multiple reranker scores."""

    name = "ensemble"

    def __init__(self, rerankers: Sequence[BaseReranker],
                 weights: Sequence[float] | None = None,
                 algorithm: str = "weighted_avg") -> None:
        if not rerankers:
            raise ValueError("EnsembleReranker requires at least one reranker")
        if algorithm not in ("weighted_avg", "rrf"):
            raise ValueError("algorithm must be 'weighted_avg' or 'rrf'")
        self.rerankers = list(rerankers)
        self.weights = list(weights or [1.0] * len(rerankers))
        if len(self.weights) != len(self.rerankers):
            raise ValueError("weights length must match rerankers length")
        self.algorithm = algorithm

    def _score(self, query: str, doc: Document) -> float:
        scores = [r._score(query, doc) for r in self.rerankers]
        weighted = sum(s * w for s, w in zip(scores, self.weights))
        return weighted / sum(self.weights)

    def rerank(self, query: str, candidates, top_k: int | None = None) -> list[Candidate]:
        if not candidates:
            return []
        if self.algorithm == "rrf":
            rankings = [r.rerank(query, candidates) for r in self.rerankers]
            return reciprocal_rank_fusion(rankings, self.weights)[: top_k or len(candidates)]
        return super().rerank(query, candidates, top_k)
