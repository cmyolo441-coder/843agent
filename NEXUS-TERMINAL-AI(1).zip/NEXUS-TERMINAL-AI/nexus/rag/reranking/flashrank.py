"""FlashRank: tiny on-device reranker (uses flashrank lib when available)."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..pipeline import Document
from .base_reranker import BaseReranker, Candidate

logger = logging.getLogger(__name__)


class FlashRankReranker(BaseReranker):
    """Wraps the flashrank Ranker; falls back to BM25-like lexical score."""

    name = "flashrank"

    def __init__(self, model: str = "ms-marco-MiniLM-L-12-v2") -> None:
        self.model_name = model
        self._ranker: Any = None

    def _load(self) -> bool:
        if self._ranker is not None:
            return True
        try:
            from flashrank import Ranker  # type: ignore
            self._ranker = Ranker(model_name=self.model_name)
            return True
        except Exception as exc:
            logger.warning("flashrank unavailable: %s", exc)
            return False

    def _score(self, query: str, doc: Document) -> float:
        # Fallback per-doc scorer.
        q = set(re.findall(r"[a-z0-9]+", query.lower()))
        d = set(re.findall(r"[a-z0-9]+", doc.text.lower()))
        return len(q & d) / max(len(q), 1)

    def rerank(self, query: str, candidates, top_k: int | None = None) -> list[Candidate]:
        if not self._load() or not candidates:
            return super().rerank(query, candidates, top_k)
        passages = [{"id": i, "text": (c[0] if isinstance(c, tuple) else c).text}
                    for i, c in enumerate(candidates)]
        from flashrank import RerankRequest  # type: ignore
        req = RerankRequest(query=query, passages=passages)
        results = self._ranker.rerank(req)
        out: list[Candidate] = []
        for r in results:
            i = int(r["id"])
            doc = candidates[i][0] if isinstance(candidates[i], tuple) else candidates[i]
            out.append((doc, float(r.get("score", 0.0))))
        return out[: top_k] if top_k else out
