"""Jina AI reranker (jina-reranker-v1)."""
from __future__ import annotations

import json
import logging
import urllib.request
from typing import Any

from ..pipeline import Document
from .base_reranker import BaseReranker, Candidate

logger = logging.getLogger(__name__)


class JinaReranker(BaseReranker):
    """Calls the public Jina rerank HTTPS endpoint."""

    name = "jina"
    _ENDPOINT = "https://api.jina.ai/v1/rerank"

    def __init__(self, model: str = "jina-reranker-v1-base-en",
                 api_key: str | None = None, timeout: float = 30.0) -> None:
        self.model = model
        self.api_key = api_key
        self.timeout = timeout

    def _score(self, query: str, doc: Document) -> float:
        results = self._call(query, [doc.text], top_n=1)
        if not results:
            return 0.0
        return float(results[0].get("relevance_score", 0.0))

    def rerank(self, query: str, candidates, top_k: int | None = None) -> list[Candidate]:
        docs = [(c[0] if isinstance(c, tuple) else c) for c in candidates]
        results = self._call(query, [d.text for d in docs], top_n=top_k or len(docs))
        if not results:
            return super().rerank(query, candidates, top_k)
        out: list[Candidate] = []
        for r in results:
            i = int(r.get("index", 0))
            out.append((docs[i], float(r.get("relevance_score", 0.0))))
        return out

    def _call(self, query: str, documents: list[str], top_n: int) -> list[dict[str, Any]]:
        if not self.api_key:
            logger.debug("JinaReranker: no API key, skipping HTTP call")
            return []
        body = json.dumps({"model": self.model, "query": query,
                           "documents": documents, "top_n": top_n}).encode("utf-8")
        headers = {"Content-Type": "application/json",
                   "Authorization": f"Bearer {self.api_key}"}
        try:
            req = urllib.request.Request(self._ENDPOINT, data=body, headers=headers)
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            return data.get("results", [])
        except Exception as exc:
            logger.warning("Jina rerank call failed: %s", exc)
            return []
