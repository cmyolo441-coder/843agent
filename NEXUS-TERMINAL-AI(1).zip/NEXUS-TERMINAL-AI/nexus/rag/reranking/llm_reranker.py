"""LLM-as-judge reranker."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..pipeline import Document
from .base_reranker import BaseReranker

logger = logging.getLogger(__name__)


class LLMReranker(BaseReranker):
    """Prompts an LLM to score doc relevance 0-10."""

    name = "llm"

    _NUM = re.compile(r"\d+(?:\.\d+)?")

    def __init__(self, llm: Any, max_chars: int = 1200) -> None:
        self.llm = llm
        self.max_chars = max_chars

    def _score(self, query: str, doc: Document) -> float:
        prompt = (
            "Rate how well the passage answers the question, 0 (no) to 10 (perfect). "
            "Return only the number.\n\n"
            f"QUESTION: {query}\n\nPASSAGE: {doc.text[: self.max_chars]}"
        )
        try:
            response = (self.llm.complete(prompt) if hasattr(self.llm, "complete")
                        else self.llm(prompt))
        except Exception as exc:
            logger.warning("LLM rerank failed: %s", exc)
            return 0.0
        match = self._NUM.search(str(response))
        if not match:
            return 0.0
        try:
            return min(10.0, max(0.0, float(match.group()))) / 10.0
        except ValueError:
            return 0.0
