"""Sentence-similarity reranker using a bi-encoder."""
from __future__ import annotations

import logging
import math
from typing import Any

from ..embedding.local_embedder import LocalEmbedder
from ..pipeline import Document
from .base_reranker import BaseReranker

logger = logging.getLogger(__name__)


class SentenceReranker(BaseReranker):
    """Re-scores candidates with cosine similarity against an embedder."""

    name = "sentence"

    def __init__(self, embedder: Any | None = None) -> None:
        self.embedder = embedder or LocalEmbedder()

    def _score(self, query: str, doc: Document) -> float:
        if hasattr(self.embedder, "embed_query"):
            qv = self.embedder.embed_query(query)
        else:
            qv = self.embedder.embed([query])[0]
        dv = self.embedder.embed([doc.text])[0]
        return self._cosine(qv, dv)

    @staticmethod
    def _cosine(a: list[float], b: list[float]) -> float:
        if not a or not b:
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        return dot / (na * nb) if na and nb else 0.0
