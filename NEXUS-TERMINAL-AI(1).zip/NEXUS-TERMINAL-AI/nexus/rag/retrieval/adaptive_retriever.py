"""Adaptive retriever: selects a strategy based on query characteristics."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..pipeline import Document

logger = logging.getLogger(__name__)


class AdaptiveRetriever:
    """Routes a query to dense, sparse, or hybrid retrievers using heuristics."""

    _CODE_RE = re.compile(r"[{}()\[\];=<>]|def |class |->|::")
    _ENTITY_RE = re.compile(r"\b[A-Z][a-zA-Z0-9_]{2,}\b")

    def __init__(self, dense: Any, sparse: Any, hybrid: Any | None = None,
                 short_query_chars: int = 30, k: int = 10) -> None:
        self.dense = dense
        self.sparse = sparse
        self.hybrid = hybrid
        self.short_query_chars = short_query_chars
        self.k = k

    def _route(self, query: str) -> tuple[str, Any]:
        if self._CODE_RE.search(query):
            return "sparse", self.sparse
        if len(query) <= self.short_query_chars and len(self._ENTITY_RE.findall(query)) >= 1:
            return "sparse", self.sparse
        if self.hybrid is not None and len(query.split()) >= 6:
            return "hybrid", self.hybrid
        return "dense", self.dense

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        route, retriever = self._route(query)
        logger.debug("AdaptiveRetriever routed query to %s", route)
        hits = retriever.retrieve(query, k=k or self.k)
        return [(Document(text=d.text, metadata={**d.metadata, "route": route}, id=d.id), s)
                for d, s in hits]
