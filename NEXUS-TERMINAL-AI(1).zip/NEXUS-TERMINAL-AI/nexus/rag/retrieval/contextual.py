"""Contextual compression retriever: trims hits to query-relevant spans."""
from __future__ import annotations

import logging
import re
from typing import Any

from ..pipeline import Document

logger = logging.getLogger(__name__)

_SENT_END = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")


class ContextualCompressionRetriever:
    """After retrieval, keep only sentences that overlap with query keywords."""

    def __init__(self, base_retriever: Any, min_overlap: int = 1,
                 max_sentences: int = 5, k: int = 10) -> None:
        self.base = base_retriever
        self.min_overlap = min_overlap
        self.max_sentences = max_sentences
        self.k = k

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return {t for t in re.findall(r"[a-z0-9]+", text.lower()) if len(t) > 2}

    def _compress(self, doc: Document, q_tokens: set[str]) -> Document:
        sentences = [s for s in _SENT_END.split(doc.text) if s.strip()]
        scored = sorted(
            ((len(self._tokens(s) & q_tokens), i, s) for i, s in enumerate(sentences)),
            key=lambda x: (-x[0], x[1]),
        )
        kept = [s for ov, _, s in scored[: self.max_sentences] if ov >= self.min_overlap]
        if not kept:
            kept = [s for _, _, s in scored[: max(1, self.max_sentences // 2)]]
        meta = {**doc.metadata, "compressed": True, "orig_len": len(doc.text)}
        return Document(text=" ".join(kept), metadata=meta, id=doc.id)

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        limit = k or self.k
        q_tokens = self._tokens(query)
        hits = self.base.retrieve(query, k=limit)
        return [(self._compress(d, q_tokens), s) for d, s in hits]
