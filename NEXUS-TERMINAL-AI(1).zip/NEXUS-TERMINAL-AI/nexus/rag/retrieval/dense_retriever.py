"""Dense retriever: embedding-based similarity search."""
from __future__ import annotations

import logging
from typing import Any

from ..pipeline import Document
from ..vectorstore.base_store import StoreRecord, VectorStore

logger = logging.getLogger(__name__)


class DenseRetriever:
    """Encodes the query with an embedder, then searches a vector store."""

    def __init__(self, embedder: Any, store: VectorStore, k: int = 10) -> None:
        self.embedder = embedder
        self.store = store
        self.k = k

    def retrieve(self, query: str, k: int | None = None,
                 filter: dict[str, Any] | None = None) -> list[tuple[Document, float]]:
        limit = k or self.k
        if hasattr(self.embedder, "embed_query"):
            vector = self.embedder.embed_query(query)
        else:
            vector = self.embedder.embed([query])[0]
        records = self.store.search(vector, k=limit, filter=filter)
        return [self._to_doc(r) for r in records]

    @staticmethod
    def _to_doc(rec: StoreRecord) -> tuple[Document, float]:
        return (Document(text=rec.text, metadata=rec.metadata, id=rec.id), rec.score)
