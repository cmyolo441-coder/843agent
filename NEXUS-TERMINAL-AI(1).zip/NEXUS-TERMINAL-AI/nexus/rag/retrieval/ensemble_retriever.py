"""Ensemble retriever: fuses arbitrary set of base retrievers."""
from __future__ import annotations

import logging
from typing import Any, Sequence

from ..pipeline import Document
from .reciprocal_rank import reciprocal_rank_fusion
from .relevance import weighted_sum

logger = logging.getLogger(__name__)


class EnsembleRetriever:
    """Aggregates several retrievers using a configurable fusion algorithm."""

    _ALGOS = ("rrf", "weighted_sum")

    def __init__(self, retrievers: Sequence[Any], weights: Sequence[float] | None = None,
                 algorithm: str = "rrf", k: int = 10) -> None:
        if not retrievers:
            raise ValueError("EnsembleRetriever requires at least one retriever")
        if algorithm not in self._ALGOS:
            raise ValueError(f"algorithm must be one of {self._ALGOS}")
        self.retrievers = list(retrievers)
        self.weights = list(weights or [1.0] * len(retrievers))
        if len(self.weights) != len(self.retrievers):
            raise ValueError("weights length must match retrievers")
        self.algorithm = algorithm
        self.k = k

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        limit = k or self.k
        rankings: list[list[tuple[Document, float]]] = []
        for r in self.retrievers:
            try:
                rankings.append(list(r.retrieve(query, k=limit * 2)))
            except Exception as exc:
                logger.warning("Sub-retriever %s failed: %s", type(r).__name__, exc)
        if self.algorithm == "rrf":
            return reciprocal_rank_fusion(rankings, self.weights)[:limit]
        return weighted_sum(rankings, self.weights)[:limit]
