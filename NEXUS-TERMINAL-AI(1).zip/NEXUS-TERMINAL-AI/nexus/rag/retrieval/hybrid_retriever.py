"""Hybrid retriever combining dense + sparse via reciprocal-rank fusion."""
from __future__ import annotations

import logging
from typing import Any

from ..pipeline import Document
from .reciprocal_rank import reciprocal_rank_fusion

logger = logging.getLogger(__name__)


class HybridRetriever:
    """Runs dense and sparse retrievers in parallel, fuses results with RRF."""

    def __init__(self, dense: Any, sparse: Any, k: int = 10,
                 rrf_k: int = 60, dense_weight: float = 1.0,
                 sparse_weight: float = 1.0) -> None:
        self.dense = dense
        self.sparse = sparse
        self.k = k
        self.rrf_k = rrf_k
        self.dense_weight = dense_weight
        self.sparse_weight = sparse_weight

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        limit = k or self.k
        dense_hits = self.dense.retrieve(query, k=limit * 2)
        sparse_hits = self.sparse.retrieve(query, k=limit * 2)
        fused = reciprocal_rank_fusion(
            [dense_hits, sparse_hits],
            weights=[self.dense_weight, self.sparse_weight],
            k=self.rrf_k,
        )
        return fused[:limit]
