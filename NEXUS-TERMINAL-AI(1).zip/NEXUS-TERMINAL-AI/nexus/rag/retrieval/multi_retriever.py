"""Multi-query retriever: dispatches several rewrites and merges results."""
from __future__ import annotations

import logging
from typing import Any

from ..pipeline import Document
from .reciprocal_rank import reciprocal_rank_fusion

logger = logging.getLogger(__name__)


class MultiQueryRetriever:
    """Runs the base retriever against multiple query variants from a QueryEngine."""

    def __init__(self, base_retriever: Any, query_engine: Any | None = None,
                 max_queries: int = 4, k: int = 10) -> None:
        self.base = base_retriever
        self.query_engine = query_engine
        self.max_queries = max_queries
        self.k = k

    def _queries(self, query: str) -> list[str]:
        if self.query_engine is None or not hasattr(self.query_engine, "expand"):
            return [query]
        expanded = self.query_engine.expand(query)
        return expanded.all_queries()[: self.max_queries]

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        limit = k or self.k
        all_hits: list[list[tuple[Document, float]]] = []
        for q in self._queries(query):
            try:
                hits = self.base.retrieve(q, k=limit * 2)
                all_hits.append(list(hits))
            except Exception as exc:
                logger.warning("Sub-query failed for %r: %s", q, exc)
        fused = reciprocal_rank_fusion(all_hits)
        return fused[:limit]
