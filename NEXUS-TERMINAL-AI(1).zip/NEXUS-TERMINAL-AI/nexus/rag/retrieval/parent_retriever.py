"""Parent-document retriever: returns the parent of any matched child chunk."""
from __future__ import annotations

import logging
from typing import Any

from ..pipeline import Document

logger = logging.getLogger(__name__)


class ParentDocumentRetriever:
    """Wraps a base retriever; promotes hits to their `parent_text` when present."""

    def __init__(self, base_retriever: Any, k: int = 10,
                 parent_meta_key: str = "parent_text") -> None:
        self.base = base_retriever
        self.k = k
        self.parent_meta_key = parent_meta_key

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        limit = k or self.k
        child_hits = self.base.retrieve(query, k=limit * 2)
        seen_parents: set[str] = set()
        out: list[tuple[Document, float]] = []
        for doc, score in child_hits:
            parent_id = doc.metadata.get("parent_id") or doc.id
            if parent_id in seen_parents:
                continue
            seen_parents.add(parent_id)
            parent_text = doc.metadata.get(self.parent_meta_key) or doc.text
            parent_doc = Document(
                text=parent_text,
                metadata={**doc.metadata, "child_id": doc.id, "promoted": True},
                id=parent_id,
            )
            out.append((parent_doc, score))
            if len(out) >= limit:
                break
        return out
