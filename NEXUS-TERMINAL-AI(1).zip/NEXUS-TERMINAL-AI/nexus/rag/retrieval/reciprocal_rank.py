"""Reciprocal Rank Fusion (RRF) used by hybrid / ensemble / multi-query retrievers."""
from __future__ import annotations

import logging
from typing import Sequence

from ..pipeline import Document

logger = logging.getLogger(__name__)


def reciprocal_rank_fusion(
    rankings: Sequence[Sequence[tuple[Document, float]]],
    weights: Sequence[float] | None = None,
    k: int = 60,
) -> list[tuple[Document, float]]:
    """RRF: score(d) = sum_i w_i / (k + rank_i(d)).

    `rank_i` is 1-based; documents missing from a list contribute 0.
    """
    if not rankings:
        return []
    weights = list(weights or [1.0] * len(rankings))
    if len(weights) != len(rankings):
        raise ValueError("weights length must match rankings length")
    scores: dict[str, float] = {}
    docs: dict[str, Document] = {}
    for ranking, w in zip(rankings, weights):
        for rank, (doc, _score) in enumerate(ranking, start=1):
            scores[doc.id] = scores.get(doc.id, 0.0) + w / (k + rank)
            docs.setdefault(doc.id, doc)
    fused = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    return [(docs[doc_id], score) for doc_id, score in fused]
