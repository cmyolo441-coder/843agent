"""Score-fusion utilities for combining ranked lists."""
from __future__ import annotations

import logging
import math
from typing import Sequence

from ..pipeline import Document

logger = logging.getLogger(__name__)


def normalize_scores(hits: Sequence[tuple[Document, float]]) -> list[tuple[Document, float]]:
    """Min-max normalize a single ranked list to [0, 1]."""
    if not hits:
        return []
    scores = [s for _, s in hits]
    lo, hi = min(scores), max(scores)
    span = hi - lo or 1.0
    return [(d, (s - lo) / span) for d, s in hits]


def weighted_sum(
    rankings: Sequence[Sequence[tuple[Document, float]]],
    weights: Sequence[float] | None = None,
) -> list[tuple[Document, float]]:
    """Linearly combine min-max normalized scores from multiple rankings."""
    if not rankings:
        return []
    weights = list(weights or [1.0] * len(rankings))
    if len(weights) != len(rankings):
        raise ValueError("weights length must match rankings length")
    combined: dict[str, tuple[Document, float]] = {}
    for ranking, w in zip(rankings, weights):
        for doc, score in normalize_scores(ranking):
            cur = combined.get(doc.id)
            new_score = (cur[1] if cur else 0.0) + w * score
            combined[doc.id] = (doc, new_score)
    fused = sorted(combined.values(), key=lambda x: x[1], reverse=True)
    return fused


def softmax_fusion(rankings: Sequence[Sequence[tuple[Document, float]]],
                   temperature: float = 1.0) -> list[tuple[Document, float]]:
    """Fuse by summing softmax-normalized per-list probabilities."""
    combined: dict[str, tuple[Document, float]] = {}
    for ranking in rankings:
        if not ranking:
            continue
        scores = [s / temperature for _, s in ranking]
        m = max(scores)
        exps = [math.exp(s - m) for s in scores]
        total = sum(exps) or 1.0
        for (doc, _), e in zip(ranking, exps):
            prob = e / total
            cur = combined.get(doc.id)
            combined[doc.id] = (doc, (cur[1] if cur else 0.0) + prob)
    return sorted(combined.values(), key=lambda x: x[1], reverse=True)
