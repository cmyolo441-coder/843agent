"""Self-query retriever: an LLM produces a metadata filter from the question."""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from ..pipeline import Document

logger = logging.getLogger(__name__)


class SelfQueryRetriever:
    """Extracts a metadata filter from the user's natural-language question
    and passes it through to the base retriever.
    """

    _NUM_FILTER = re.compile(r"(\w+)\s*(=|==|>=|<=|>|<)\s*(\d+)")
    _EQ_FILTER = re.compile(r"(\w+)\s*=\s*['\"]([^'\"]+)['\"]")

    def __init__(self, base_retriever: Any, llm: Any | None = None, k: int = 10) -> None:
        self.base = base_retriever
        self.llm = llm
        self.k = k

    def _parse_filter(self, query: str) -> tuple[str, dict[str, Any]]:
        filt: dict[str, Any] = {}
        for m in self._EQ_FILTER.finditer(query):
            filt[m.group(1)] = m.group(2)
        for m in self._NUM_FILTER.finditer(query):
            try:
                filt[m.group(1)] = int(m.group(3))
            except ValueError:
                pass
        if self.llm is not None and hasattr(self.llm, "complete"):
            try:
                spec = self.llm.complete(
                    f"Return JSON like {{\"filter\": {{...}}, \"query\": \"...\"}} "
                    f"extracting metadata filters from:\n{query}"
                )
                data = json.loads(str(spec))
                filt.update(data.get("filter") or {})
                return data.get("query") or query, filt
            except Exception as exc:
                logger.warning("self-query LLM parse failed: %s", exc)
        clean = self._EQ_FILTER.sub("", self._NUM_FILTER.sub("", query)).strip()
        return clean or query, filt

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        cleaned, flt = self._parse_filter(query)
        try:
            return self.base.retrieve(cleaned, k=k or self.k, filter=flt or None)
        except TypeError:
            return self.base.retrieve(cleaned, k=k or self.k)
