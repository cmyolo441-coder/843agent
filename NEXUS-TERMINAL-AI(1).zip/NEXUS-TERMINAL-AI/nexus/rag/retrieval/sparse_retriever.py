"""Sparse retriever using BM25 over a held corpus."""
from __future__ import annotations

import logging
import math
import re
from collections import Counter, defaultdict
from typing import Iterable

from ..pipeline import Document

logger = logging.getLogger(__name__)


class BM25Retriever:
    """In-memory BM25 retriever; index documents up-front via .index()."""

    _TOKEN_RE = re.compile(r"[A-Za-z0-9]+")

    def __init__(self, k1: float = 1.5, b: float = 0.75, k: int = 10) -> None:
        self.k1 = k1
        self.b = b
        self.k = k
        self._docs: list[Document] = []
        self._doc_lens: list[int] = []
        self._term_freqs: list[Counter[str]] = []
        self._doc_freq: dict[str, int] = defaultdict(int)
        self._avg_len: float = 0.0

    def _tokens(self, text: str) -> list[str]:
        return [t.lower() for t in self._TOKEN_RE.findall(text)]

    def index(self, docs: Iterable[Document]) -> None:
        for doc in docs:
            tokens = self._tokens(doc.text)
            tf = Counter(tokens)
            self._docs.append(doc)
            self._doc_lens.append(len(tokens))
            self._term_freqs.append(tf)
            for term in tf:
                self._doc_freq[term] += 1
        if self._doc_lens:
            self._avg_len = sum(self._doc_lens) / len(self._doc_lens)
        logger.info("BM25 indexed %d docs", len(self._docs))

    def _idf(self, term: str) -> float:
        n = len(self._docs)
        df = self._doc_freq.get(term, 0)
        if df == 0:
            return 0.0
        return math.log((n - df + 0.5) / (df + 0.5) + 1)

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        limit = k or self.k
        if not self._docs:
            return []
        q_terms = self._tokens(query)
        scores: list[tuple[Document, float]] = []
        for i, tf in enumerate(self._term_freqs):
            score = 0.0
            length = self._doc_lens[i] or 1
            for term in q_terms:
                f = tf.get(term, 0)
                if not f:
                    continue
                idf = self._idf(term)
                num = f * (self.k1 + 1)
                denom = f + self.k1 * (1 - self.b + self.b * length / max(self._avg_len, 1))
                score += idf * num / denom
            if score > 0:
                scores.append((self._docs[i], score))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:limit]
