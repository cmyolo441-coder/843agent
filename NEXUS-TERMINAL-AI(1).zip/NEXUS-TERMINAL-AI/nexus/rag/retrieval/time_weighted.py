"""Time-weighted retriever: decays scores by document age."""
from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any

from ..pipeline import Document

logger = logging.getLogger(__name__)


class TimeWeightedRetriever:
    """Multiplies base scores by an exponential decay over time-since-modification.

    score' = score * exp(-decay_rate * age_days)
    """

    def __init__(self, base_retriever: Any, decay_rate: float = 0.01,
                 timestamp_key: str = "date", k: int = 10) -> None:
        self.base = base_retriever
        self.decay_rate = decay_rate
        self.timestamp_key = timestamp_key
        self.k = k

    def _age_days(self, doc: Document) -> float:
        ts = doc.metadata.get(self.timestamp_key)
        if ts is None:
            return 0.0
        try:
            if isinstance(ts, (int, float)):
                dt = datetime.fromtimestamp(float(ts), tz=timezone.utc)
            else:
                dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
        except Exception:
            return 0.0
        now = datetime.now(tz=timezone.utc)
        return max(0.0, (now - dt).total_seconds() / 86400.0)

    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Document, float]]:
        limit = k or self.k
        hits = self.base.retrieve(query, k=limit * 2)
        weighted = []
        for doc, score in hits:
            age = self._age_days(doc)
            decayed = score * math.exp(-self.decay_rate * age)
            weighted.append((doc, decayed))
        weighted.sort(key=lambda x: x[1], reverse=True)
        return weighted[:limit]
