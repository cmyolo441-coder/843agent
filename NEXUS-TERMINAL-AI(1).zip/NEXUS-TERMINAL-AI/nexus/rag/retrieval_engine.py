"""RetrievalEngine: dispatches a query across strategies and fuses results."""
from __future__ import annotations

import logging
from enum import Enum
from typing import Any, Optional, Sequence

from .pipeline import Document

logger = logging.getLogger(__name__)


class RetrievalStrategy(str, Enum):
    DENSE = "dense"
    SPARSE = "sparse"
    HYBRID = "hybrid"
    MULTI = "multi"
    PARENT = "parent"
    SELF_QUERY = "self_query"
    CONTEXTUAL = "contextual"
    ADAPTIVE = "adaptive"


class RetrievalEngine:
    """Selects and runs a retrieval strategy from a registry."""

    def __init__(self, retrievers: dict[str, Any], default: str = RetrievalStrategy.HYBRID.value) -> None:
        if not retrievers:
            raise ValueError("RetrievalEngine requires at least one retriever")
        self._retrievers = retrievers
        self._default = default
        if default not in retrievers:
            self._default = next(iter(retrievers))

    def register(self, name: str, retriever: Any) -> None:
        self._retrievers[name] = retriever

    def available(self) -> list[str]:
        return sorted(self._retrievers)

    async def retrieve(
        self,
        query: str,
        strategy: Optional[str] = None,
        k: int = 10,
        **kwargs: Any,
    ) -> list[tuple[Document, float]]:
        name = (strategy or self._default).lower()
        retriever = self._retrievers.get(name)
        if retriever is None:
            logger.warning("Unknown strategy '%s'; falling back to '%s'", name, self._default)
            retriever = self._retrievers[self._default]
        results = retriever.retrieve(query, k=k, **kwargs)
        if hasattr(results, "__await__"):
            results = await results  # type: ignore[assignment]
        return list(results)

    async def retrieve_many(
        self,
        queries: Sequence[str],
        strategy: Optional[str] = None,
        k: int = 10,
    ) -> list[list[tuple[Document, float]]]:
        return [await self.retrieve(q, strategy=strategy, k=k) for q in queries]
