"""Synthesis subsystem: generation, citation, fact-checking, structured output."""
from __future__ import annotations

from .generator import Generator
from .citation import Citation, CitationFormatter
from .fact_checker import FactChecker
from .hallucination import HallucinationDetector
from .confidence import ConfidenceEstimator
from .source_synthesis import SourceSynthesizer
from .structured_output import StructuredOutputParser

__all__ = [
    "Generator", "Citation", "CitationFormatter", "FactChecker",
    "HallucinationDetector", "ConfidenceEstimator", "SourceSynthesizer",
    "StructuredOutputParser",
]
