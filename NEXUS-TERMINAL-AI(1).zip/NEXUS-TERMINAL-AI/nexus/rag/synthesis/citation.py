"""Citation formatting: numeric, footnote, and bracketed source styles."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Iterable, Sequence

from ..pipeline import Document

logger = logging.getLogger(__name__)


@dataclass
class Citation:
    """A single citation marker resolved back to a Document."""

    index: int
    label: str
    source: str
    snippet: str = ""

    def as_footnote(self) -> str:
        return f"[{self.index}] {self.source}: {self.snippet[:160]}"


class CitationFormatter:
    """Appends source references in numeric / footnote / inline style."""

    _STYLES = ("numeric", "footnote", "inline")

    def __init__(self, style: str = "numeric") -> None:
        if style not in self._STYLES:
            raise ValueError(f"style must be one of {self._STYLES}")
        self.style = style

    def attach(self, answer: str, contexts: Sequence[Document]) -> tuple[str, list[str]]:
        citations = self._build(contexts)
        if self.style == "numeric":
            marker = " " + " ".join(f"[{c.index}]" for c in citations)
            return answer.rstrip() + marker, [c.as_footnote() for c in citations]
        if self.style == "footnote":
            footnotes = "\n".join(c.as_footnote() for c in citations)
            return f"{answer.rstrip()}\n\nReferences:\n{footnotes}", [c.as_footnote() for c in citations]
        # inline
        inline = []
        for c in citations:
            inline.append(f"({c.source})")
        return answer.rstrip() + " " + " ".join(inline), [c.source for c in citations]

    @staticmethod
    def _build(contexts: Iterable[Document]) -> list[Citation]:
        out: list[Citation] = []
        for i, doc in enumerate(contexts, 1):
            source = (doc.metadata.get("source")
                      or doc.metadata.get("title")
                      or doc.id)
            snippet = (doc.text or "").strip().replace("\n", " ")[:200]
            out.append(Citation(index=i, label=str(source), source=str(source),
                                snippet=snippet))
        return out
