"""ConfidenceEstimator: aggregates retrieval and grounding signals into [0,1]."""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Sequence

from ..pipeline import Document
from .fact_checker import FactChecker
from .hallucination import HallucinationDetector

logger = logging.getLogger(__name__)


@dataclass
class ConfidenceReport:
    """Final confidence score with component breakdown."""

    score: float
    components: dict[str, float]

    @property
    def label(self) -> str:
        if self.score >= 0.75:
            return "high"
        if self.score >= 0.5:
            return "medium"
        if self.score >= 0.25:
            return "low"
        return "very_low"


class ConfidenceEstimator:
    """Blends retrieval scores, grounding coverage and hallucination signal."""

    def __init__(self, fact_checker: FactChecker | None = None,
                 hallucination: HallucinationDetector | None = None) -> None:
        self.fc = fact_checker or FactChecker()
        self.hd = hallucination or HallucinationDetector(self.fc)

    def estimate(self, answer: str, contexts: Sequence[Document],
                 scores: Sequence[float] | None = None) -> ConfidenceReport:
        retrieval = self._retrieval_signal(scores or [])
        coverage = self.fc.check(answer, contexts).coverage
        halluc = self.hd.detect(answer, contexts).score
        score = max(0.0, min(1.0,
                             0.4 * retrieval + 0.4 * coverage + 0.2 * (1.0 - halluc)))
        return ConfidenceReport(
            score=score,
            components={"retrieval": retrieval, "coverage": coverage,
                        "hallucination": halluc},
        )

    @staticmethod
    def _retrieval_signal(scores: Sequence[float]) -> float:
        if not scores:
            return 0.0
        top = max(scores)
        # Sigmoid squash to discourage tiny scores from dominating.
        return 1.0 / (1.0 + math.exp(-4.0 * (top - 0.5)))
