"""FactChecker: verifies each answer sentence is supported by retrieved contexts."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Sequence

from ..pipeline import Document

logger = logging.getLogger(__name__)

_SENT_END = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")


@dataclass
class FactCheckReport:
    """Per-sentence support analysis."""

    sentences: list[str] = field(default_factory=list)
    supported: list[bool] = field(default_factory=list)
    coverage: float = 0.0
    unsupported: list[str] = field(default_factory=list)

    def is_grounded(self, threshold: float = 0.8) -> bool:
        return self.coverage >= threshold


class FactChecker:
    """Checks lexical overlap between answer sentences and context tokens."""

    def __init__(self, min_overlap: int = 3, min_ratio: float = 0.4) -> None:
        self.min_overlap = min_overlap
        self.min_ratio = min_ratio

    def check(self, answer: str, contexts: Sequence[Document]) -> FactCheckReport:
        if not answer.strip():
            return FactCheckReport()
        ctx_tokens = self._tokens(" ".join(d.text for d in contexts))
        sentences = [s for s in _SENT_END.split(answer) if s.strip()]
        supported: list[bool] = []
        unsupported: list[str] = []
        for s in sentences:
            s_tokens = self._tokens(s)
            if not s_tokens:
                supported.append(True)
                continue
            overlap = len(s_tokens & ctx_tokens)
            ok = overlap >= self.min_overlap and overlap / len(s_tokens) >= self.min_ratio
            supported.append(ok)
            if not ok:
                unsupported.append(s.strip())
        coverage = sum(supported) / len(supported) if supported else 0.0
        return FactCheckReport(sentences=sentences, supported=supported,
                               coverage=coverage, unsupported=unsupported)

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return {t for t in re.findall(r"[a-z0-9]+", text.lower()) if len(t) > 2}
