"""Generator: high-level synthesis around the GenerationEngine + citations."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Sequence

from ..generation_engine import GenerationConfig, GenerationEngine
from ..pipeline import Document
from .citation import CitationFormatter

logger = logging.getLogger(__name__)


@dataclass
class GenerationResponse:
    """A generated answer plus structured citations + raw context."""

    answer: str
    citations: list[str] = field(default_factory=list)
    contexts: list[Document] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class Generator:
    """Wraps a GenerationEngine and emits a fully formatted, cited response."""

    def __init__(self, llm: Any, citation_style: str = "numeric",
                 config: GenerationConfig | None = None) -> None:
        self.engine = GenerationEngine(llm=llm, config=config or GenerationConfig())
        self.formatter = CitationFormatter(style=citation_style)

    async def generate(self, question: str,
                       contexts: Sequence[Document]) -> GenerationResponse:
        answer = await self.engine.generate(question, contexts)
        formatted, citations = self.formatter.attach(answer, contexts)
        return GenerationResponse(answer=formatted, citations=citations,
                                  contexts=list(contexts),
                                  metadata={"n_contexts": len(contexts)})
