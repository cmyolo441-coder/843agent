"""Hallucination detector combining several lightweight heuristics."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Sequence

from ..pipeline import Document
from .fact_checker import FactChecker

logger = logging.getLogger(__name__)


@dataclass
class HallucinationReport:
    """Aggregated hallucination signal."""

    score: float
    flagged_claims: list[str] = field(default_factory=list)
    metrics: dict[str, float] = field(default_factory=dict)

    @property
    def is_hallucination(self) -> bool:
        return self.score >= 0.5


class HallucinationDetector:
    """Combines fact-checker coverage with numeric / named-entity novelty checks."""

    _NUM_RE = re.compile(r"\b\d+(?:\.\d+)?\b")
    _PROPER_RE = re.compile(r"\b[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]+)*\b")

    def __init__(self, fact_checker: FactChecker | None = None,
                 weights: tuple[float, float, float] = (0.5, 0.3, 0.2)) -> None:
        self.fact_checker = fact_checker or FactChecker()
        self.weights = weights

    def detect(self, answer: str, contexts: Sequence[Document]) -> HallucinationReport:
        fc = self.fact_checker.check(answer, contexts)
        ctx_text = " ".join(d.text for d in contexts)
        num_score = self._novel_ratio(self._NUM_RE.findall(answer),
                                      self._NUM_RE.findall(ctx_text))
        ent_score = self._novel_ratio(self._PROPER_RE.findall(answer),
                                      self._PROPER_RE.findall(ctx_text))
        unsup = 1.0 - fc.coverage
        w_unsup, w_num, w_ent = self.weights
        score = (w_unsup * unsup) + (w_num * num_score) + (w_ent * ent_score)
        return HallucinationReport(
            score=min(1.0, max(0.0, score)),
            flagged_claims=fc.unsupported,
            metrics={"coverage": fc.coverage, "novel_numbers": num_score,
                     "novel_entities": ent_score},
        )

    @staticmethod
    def _novel_ratio(answer_items: list[str], ctx_items: list[str]) -> float:
        if not answer_items:
            return 0.0
        ctx_set = {x.lower() for x in ctx_items}
        novel = sum(1 for x in answer_items if x.lower() not in ctx_set)
        return novel / len(answer_items)
