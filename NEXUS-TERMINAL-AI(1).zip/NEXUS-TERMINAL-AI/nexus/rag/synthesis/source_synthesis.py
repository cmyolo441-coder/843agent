"""SourceSynthesizer: builds a per-source summary block (map-reduce style)."""
from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Sequence

from ..pipeline import Document

logger = logging.getLogger(__name__)


@dataclass
class SourceSynthesis:
    """One synthesized summary per unique source."""

    source: str
    summary: str
    chunks: list[Document] = field(default_factory=list)


class SourceSynthesizer:
    """Groups contexts by source and asks the LLM to summarize each group."""

    def __init__(self, llm: Any | None = None, max_chars_per_source: int = 4000) -> None:
        self.llm = llm
        self.max_chars_per_source = max_chars_per_source

    def synthesize(self, question: str, contexts: Sequence[Document]) -> list[SourceSynthesis]:
        groups: dict[str, list[Document]] = defaultdict(list)
        for doc in contexts:
            src = str(doc.metadata.get("source") or doc.id)
            groups[src].append(doc)
        out: list[SourceSynthesis] = []
        for src, docs in groups.items():
            joined = "\n\n".join(d.text for d in docs)[: self.max_chars_per_source]
            summary = self._summarize(question, joined, src)
            out.append(SourceSynthesis(source=src, summary=summary, chunks=docs))
        return out

    def _summarize(self, question: str, text: str, source: str) -> str:
        if self.llm is None:
            sentences = [s.strip() for s in text.split(".") if s.strip()]
            return ". ".join(sentences[:3]) + ("." if sentences else "")
        prompt = (
            f"Summarize the following passage with respect to the question.\n"
            f"QUESTION: {question}\nSOURCE: {source}\n\nPASSAGE:\n{text}\n\nSUMMARY:"
        )
        try:
            return (self.llm.complete(prompt) if hasattr(self.llm, "complete")
                    else str(self.llm(prompt)))
        except Exception as exc:
            logger.warning("Source summarization failed: %s", exc)
            return text[:300]
