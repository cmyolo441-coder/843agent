"""StructuredOutputParser: validates LLM output against a Pydantic-style schema."""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Any, Type

logger = logging.getLogger(__name__)


@dataclass
class ParsedOutput:
    """Wrapper around a parsed object plus errors encountered."""

    data: Any
    errors: list[str]
    raw: str

    @property
    def ok(self) -> bool:
        return not self.errors


class StructuredOutputParser:
    """Parses JSON out of LLM text and (optionally) validates with a Pydantic model."""

    _JSON_BLOCK = re.compile(r"\{[\s\S]*\}|\[[\s\S]*\]")

    def __init__(self, schema: Type[Any] | dict[str, type] | None = None) -> None:
        self.schema = schema

    def parse(self, text: str) -> ParsedOutput:
        errors: list[str] = []
        snippet = self._extract_json(text)
        if snippet is None:
            return ParsedOutput(data=None, errors=["no JSON found"], raw=text)
        try:
            data = json.loads(snippet)
        except json.JSONDecodeError as exc:
            return ParsedOutput(data=None, errors=[f"json: {exc}"], raw=text)
        data = self._validate(data, errors)
        return ParsedOutput(data=data, errors=errors, raw=text)

    def _extract_json(self, text: str) -> str | None:
        match = self._JSON_BLOCK.search(text)
        return match.group(0) if match else None

    def _validate(self, data: Any, errors: list[str]) -> Any:
        if self.schema is None:
            return data
        # Pydantic-style model with model_validate.
        if hasattr(self.schema, "model_validate"):
            try:
                return self.schema.model_validate(data)
            except Exception as exc:
                errors.append(f"schema: {exc}")
                return data
        # dict typespec like {"name": str, "age": int}.
        if isinstance(self.schema, dict) and isinstance(data, dict):
            for key, typ in self.schema.items():
                if key not in data:
                    errors.append(f"missing key: {key}")
                elif not isinstance(data[key], typ):
                    errors.append(f"key {key}: expected {typ.__name__}, "
                                  f"got {type(data[key]).__name__}")
        return data
