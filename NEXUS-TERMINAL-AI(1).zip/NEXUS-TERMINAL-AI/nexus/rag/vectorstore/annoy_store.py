"""Annoy-backed (Spotify) approximate nearest neighbor vector store."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class AnnoyStore(VectorStore):
    """Lightweight ANN store. Build is one-shot; mutations rebuild lazily."""

    name = "annoy"

    def __init__(self, dim: int = 768, n_trees: int = 10, metric: str = "angular") -> None:
        self.dim = dim
        self.n_trees = n_trees
        self.metric = metric
        self._index: Any = None
        self._records: dict[int, StoreRecord] = {}
        self._id_to_idx: dict[str, int] = {}
        self._dirty = True
        self._fallback = _InMemoryStore()

    def _ensure(self) -> bool:
        if self._index is not None and not self._dirty:
            return True
        try:
            from annoy import AnnoyIndex  # type: ignore
            idx = AnnoyIndex(self.dim, self.metric)
            for i, rec in self._records.items():
                idx.add_item(i, rec.vector)
            if self._records:
                idx.build(self.n_trees)
            self._index = idx
            self._dirty = False
            return True
        except Exception as exc:
            logger.warning("annoy unavailable: %s", exc)
            self._index = None
            return False

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        idx = self._id_to_idx.get(id)
        if idx is None:
            idx = len(self._id_to_idx)
            self._id_to_idx[id] = idx
        self._records[idx] = StoreRecord(id=id, vector=list(vector), text=text,
                                         metadata=dict(metadata or {}))
        self._dirty = True
        self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if not self._ensure():
            return self._fallback.search(query, k, filter)
        try:
            idxs, dists = self._index.get_nns_by_vector(query, k, include_distances=True)
            out: list[StoreRecord] = []
            for i, d in zip(idxs, dists):
                rec = self._records[i]
                if filter and not all(rec.metadata.get(kk) == v for kk, v in filter.items()):
                    continue
                out.append(StoreRecord(id=rec.id, vector=rec.vector, text=rec.text,
                                       metadata=rec.metadata, score=1.0 - float(d)))
            return out
        except Exception as exc:
            logger.warning("annoy query failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        idx = self._id_to_idx.pop(id, None)
        if idx is None:
            return False
        self._records.pop(idx, None)
        self._dirty = True
        return True

    def count(self) -> int:
        return len(self._records)
