"""VectorStore ABC: defines the contract for all vector backends."""
from __future__ import annotations

import abc
import logging
import math
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

logger = logging.getLogger(__name__)

Vector = list[float]


@dataclass
class StoreRecord:
    """A single (id, vector, text, metadata) tuple stored in a backend."""

    id: str
    vector: Vector
    text: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    score: float = 0.0


class VectorStore(abc.ABC):
    """Abstract base class for all NEXUS vector stores."""

    name: str = "base"

    @abc.abstractmethod
    def add(self, id: str, vector: Vector, text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        """Insert (or upsert) a single record."""

    def add_many(self, records: Iterable[StoreRecord]) -> int:
        n = 0
        for r in records:
            self.add(r.id, r.vector, r.text, r.metadata)
            n += 1
        return n

    @abc.abstractmethod
    def search(self, query: Vector, k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        """Return top-k records by similarity to *query*."""

    @abc.abstractmethod
    def delete(self, id: str) -> bool:
        """Remove a record by id. Returns True if found and removed."""

    @abc.abstractmethod
    def count(self) -> int:
        """Number of records currently stored."""

    @staticmethod
    def cosine(a: Sequence[float], b: Sequence[float]) -> float:
        if not a or not b or len(a) != len(b):
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        return dot / (na * nb) if na and nb else 0.0

    def __len__(self) -> int:
        return self.count()


class _InMemoryStore(VectorStore):
    """Reference implementation used by most concrete backends as a fallback."""

    name = "memory"

    def __init__(self) -> None:
        self._records: dict[str, StoreRecord] = {}

    def add(self, id: str, vector: Vector, text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        self._records[id] = StoreRecord(id=id, vector=list(vector), text=text,
                                        metadata=dict(metadata or {}))

    def search(self, query: Vector, k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        scored = []
        for rec in self._records.values():
            if filter and not all(rec.metadata.get(k) == v for k, v in filter.items()):
                continue
            score = self.cosine(query, rec.vector)
            scored.append(StoreRecord(id=rec.id, vector=rec.vector, text=rec.text,
                                      metadata=rec.metadata, score=score))
        scored.sort(key=lambda r: r.score, reverse=True)
        return scored[:k]

    def delete(self, id: str) -> bool:
        return self._records.pop(id, None) is not None

    def count(self) -> int:
        return len(self._records)
