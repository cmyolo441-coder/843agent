"""ChromaDB-backed vector store."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class ChromaStore(VectorStore):
    """Persists vectors in a Chroma collection; falls back to in-memory store."""

    name = "chroma"

    def __init__(self, collection: str = "nexus", persist_dir: str | None = None) -> None:
        self.collection_name = collection
        self.persist_dir = persist_dir
        self._collection: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            import chromadb  # type: ignore
            client = (chromadb.PersistentClient(path=self.persist_dir)
                      if self.persist_dir else chromadb.Client())
            self._collection = client.get_or_create_collection(self.collection_name)
        except Exception as exc:
            logger.warning("Chroma unavailable, using in-memory fallback: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        meta = metadata or {}
        if self._collection is None:
            self._fallback.add(id, vector, text, meta)
            return
        try:
            self._collection.upsert(ids=[id], embeddings=[vector],
                                    documents=[text], metadatas=[meta or {"_": 1}])
        except Exception as exc:
            logger.warning("Chroma upsert failed: %s", exc)
            self._fallback.add(id, vector, text, meta)

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._collection is None:
            return self._fallback.search(query, k, filter)
        try:
            res = self._collection.query(query_embeddings=[query], n_results=k,
                                         where=filter)
            ids = res.get("ids", [[]])[0]
            docs = res.get("documents", [[]])[0]
            metas = res.get("metadatas", [[]])[0]
            dists = res.get("distances", [[1.0] * len(ids)])[0]
            return [StoreRecord(id=i, vector=[], text=d or "", metadata=m or {},
                                score=1.0 - float(dist))
                    for i, d, m, dist in zip(ids, docs, metas, dists)]
        except Exception as exc:
            logger.warning("Chroma query failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._collection is None:
            return self._fallback.delete(id)
        try:
            self._collection.delete(ids=[id])
            return True
        except Exception:
            return False

    def count(self) -> int:
        if self._collection is None:
            return self._fallback.count()
        try:
            return int(self._collection.count())
        except Exception:
            return self._fallback.count()
