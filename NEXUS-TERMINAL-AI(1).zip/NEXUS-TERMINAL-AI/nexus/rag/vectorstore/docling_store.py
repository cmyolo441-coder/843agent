"""Docling-style document-aware vector store wrapping LanceDB."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class DoclingStore(VectorStore):
    """Specialised store that preserves Docling parsed-document metadata
    (page numbers, bounding boxes, block types) alongside vectors.
    """

    name = "docling"

    def __init__(self, base: VectorStore | None = None) -> None:
        self._base = base or _InMemoryStore()
        self._extra: dict[str, dict[str, Any]] = {}

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        md = dict(metadata or {})
        # Extract docling-style fields for indexed lookup.
        self._extra[id] = {
            "page": md.get("page"),
            "bbox": md.get("bbox"),
            "block_type": md.get("block_type"),
        }
        self._base.add(id, vector, text, md)

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        results = self._base.search(query, k=k, filter=filter)
        for r in results:
            extra = self._extra.get(r.id)
            if extra:
                r.metadata = {**r.metadata, **{k: v for k, v in extra.items()
                                               if v is not None}}
        return results

    def delete(self, id: str) -> bool:
        self._extra.pop(id, None)
        return self._base.delete(id)

    def count(self) -> int:
        return self._base.count()

    def by_page(self, page: int) -> list[str]:
        return [i for i, e in self._extra.items() if e.get("page") == page]
