"""Elasticsearch dense-vector store using kNN search."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class ElasticStore(VectorStore):
    """Stores documents with a dense_vector field for kNN."""

    name = "elastic"

    def __init__(self, hosts: list[str] | None = None, index: str = "nexus",
                 dim: int = 768, api_key: str | None = None) -> None:
        self.hosts = hosts or ["http://localhost:9200"]
        self.index = index
        self.dim = dim
        self.api_key = api_key
        self._client: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            from elasticsearch import Elasticsearch  # type: ignore
            self._client = Elasticsearch(self.hosts, api_key=self.api_key)
            if not self._client.indices.exists(index=self.index):
                self._client.indices.create(
                    index=self.index,
                    mappings={"properties": {
                        "embedding": {"type": "dense_vector", "dims": self.dim,
                                      "index": True, "similarity": "cosine"},
                        "text": {"type": "text"},
                        "metadata": {"type": "object"},
                    }},
                )
        except Exception as exc:
            logger.warning("elasticsearch unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        if self._client is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            self._client.index(index=self.index, id=id, document={
                "embedding": vector, "text": text, "metadata": metadata or {},
            })
        except Exception as exc:
            logger.warning("elastic index failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._client is None:
            return self._fallback.search(query, k, filter)
        try:
            res = self._client.search(index=self.index, knn={
                "field": "embedding", "query_vector": query, "k": k,
                "num_candidates": max(k * 4, 50),
            })
            out: list[StoreRecord] = []
            for hit in res["hits"]["hits"]:
                src = hit.get("_source", {})
                out.append(StoreRecord(id=hit["_id"], vector=[],
                                       text=src.get("text", ""),
                                       metadata=src.get("metadata", {}),
                                       score=float(hit.get("_score", 0.0))))
            return out
        except Exception as exc:
            logger.warning("elastic search failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._client is None:
            return self._fallback.delete(id)
        try:
            self._client.delete(index=self.index, id=id)
            return True
        except Exception:
            return False

    def count(self) -> int:
        if self._client is None:
            return self._fallback.count()
        try:
            return int(self._client.count(index=self.index)["count"])
        except Exception:
            return self._fallback.count()
