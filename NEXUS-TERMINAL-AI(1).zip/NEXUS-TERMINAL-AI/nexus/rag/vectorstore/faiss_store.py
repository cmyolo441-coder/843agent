"""FAISS-backed vector store (in-process)."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class FAISSStore(VectorStore):
    """Flat inner-product FAISS index with parallel metadata dict."""

    name = "faiss"

    def __init__(self, dim: int = 768) -> None:
        self.dim = dim
        self._index: Any = None
        self._ids: list[str] = []
        self._meta: dict[str, StoreRecord] = {}
        self._fallback = _InMemoryStore()
        self._init_index()

    def _init_index(self) -> None:
        try:
            import faiss  # type: ignore
            self._index = faiss.IndexFlatIP(self.dim)
        except Exception as exc:
            logger.warning("faiss unavailable: %s", exc)
            self._index = None

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        rec = StoreRecord(id=id, vector=list(vector), text=text,
                          metadata=dict(metadata or {}))
        if self._index is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            import numpy as np  # type: ignore
            arr = np.asarray([vector], dtype="float32")
            self._index.add(arr)
            self._ids.append(id)
            self._meta[id] = rec
        except Exception as exc:
            logger.warning("faiss add failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._index is None or not self._ids:
            return self._fallback.search(query, k, filter)
        try:
            import numpy as np  # type: ignore
            q = np.asarray([query], dtype="float32")
            distances, indices = self._index.search(q, min(k, len(self._ids)))
            out: list[StoreRecord] = []
            for idx, dist in zip(indices[0], distances[0]):
                if idx < 0 or idx >= len(self._ids):
                    continue
                rec = self._meta[self._ids[idx]]
                if filter and not all(rec.metadata.get(kk) == v for kk, v in filter.items()):
                    continue
                out.append(StoreRecord(id=rec.id, vector=rec.vector, text=rec.text,
                                       metadata=rec.metadata, score=float(dist)))
            return out
        except Exception as exc:
            logger.warning("faiss search failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        # FAISS Flat index does not support targeted deletion cheaply.
        return self._meta.pop(id, None) is not None

    def count(self) -> int:
        return len(self._meta) if self._index is not None else self._fallback.count()
