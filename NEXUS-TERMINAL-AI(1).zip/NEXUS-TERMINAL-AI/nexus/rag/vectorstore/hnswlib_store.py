"""hnswlib-backed vector store (HNSW graph index)."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class HNSWLibStore(VectorStore):
    """Wraps hnswlib.Index with parallel metadata."""

    name = "hnswlib"

    def __init__(self, dim: int = 768, max_elements: int = 100_000,
                 ef_construction: int = 200, M: int = 16, space: str = "cosine") -> None:
        self.dim = dim
        self.max_elements = max_elements
        self.ef_construction = ef_construction
        self.M = M
        self.space = space
        self._index: Any = None
        self._next_label = 0
        self._label_to_id: dict[int, str] = {}
        self._records: dict[str, StoreRecord] = {}
        self._fallback = _InMemoryStore()
        self._init()

    def _init(self) -> None:
        try:
            import hnswlib  # type: ignore
            self._index = hnswlib.Index(space=self.space, dim=self.dim)
            self._index.init_index(max_elements=self.max_elements,
                                   ef_construction=self.ef_construction, M=self.M)
            self._index.set_ef(50)
        except Exception as exc:
            logger.warning("hnswlib unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        rec = StoreRecord(id=id, vector=list(vector), text=text,
                          metadata=dict(metadata or {}))
        self._records[id] = rec
        if self._index is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            label = self._next_label
            self._next_label += 1
            self._label_to_id[label] = id
            self._index.add_items([vector], [label])
        except Exception as exc:
            logger.warning("hnswlib add failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._index is None or self._next_label == 0:
            return self._fallback.search(query, k, filter)
        try:
            labels, distances = self._index.knn_query([query], k=min(k, self._next_label))
            out: list[StoreRecord] = []
            for lab, dist in zip(labels[0], distances[0]):
                rid = self._label_to_id.get(int(lab))
                if rid is None:
                    continue
                rec = self._records[rid]
                if filter and not all(rec.metadata.get(kk) == v for kk, v in filter.items()):
                    continue
                out.append(StoreRecord(id=rec.id, vector=rec.vector, text=rec.text,
                                       metadata=rec.metadata, score=1.0 - float(dist)))
            return out
        except Exception as exc:
            logger.warning("hnswlib query failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        rec = self._records.pop(id, None)
        if rec is None:
            return False
        for lab, rid in list(self._label_to_id.items()):
            if rid == id and self._index is not None:
                try:
                    self._index.mark_deleted(lab)
                except Exception:
                    pass
                self._label_to_id.pop(lab, None)
                return True
        return True

    def count(self) -> int:
        return len(self._records)
