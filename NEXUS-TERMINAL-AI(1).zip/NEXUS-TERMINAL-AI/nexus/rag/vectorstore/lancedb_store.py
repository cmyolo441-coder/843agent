"""LanceDB-backed vector store."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class LanceDBStore(VectorStore):
    """Persists vectors in a LanceDB table on disk."""

    name = "lancedb"

    def __init__(self, uri: str = "./lancedb", table: str = "nexus",
                 dim: int = 768) -> None:
        self.uri = uri
        self.table_name = table
        self.dim = dim
        self._table: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            import lancedb  # type: ignore
            db = lancedb.connect(self.uri)
            if self.table_name in db.table_names():
                self._table = db.open_table(self.table_name)
            else:
                self._table = db.create_table(
                    self.table_name,
                    data=[{"id": "_seed", "vector": [0.0] * self.dim,
                           "text": "", "metadata": "{}"}],
                )
                self._table.delete("id = '_seed'")
        except Exception as exc:
            logger.warning("lancedb unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        import json
        if self._table is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            self._table.add([{"id": id, "vector": vector, "text": text,
                              "metadata": json.dumps(metadata or {})}])
        except Exception as exc:
            logger.warning("lancedb add failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        import json
        if self._table is None:
            return self._fallback.search(query, k, filter)
        try:
            df = self._table.search(query).limit(k).to_list()
            out: list[StoreRecord] = []
            for r in df:
                out.append(StoreRecord(
                    id=r.get("id", ""), vector=[], text=r.get("text", ""),
                    metadata=json.loads(r.get("metadata", "{}")),
                    score=1.0 - float(r.get("_distance", 0.0)),
                ))
            return out
        except Exception as exc:
            logger.warning("lancedb query failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._table is None:
            return self._fallback.delete(id)
        try:
            self._table.delete(f"id = '{id}'")
            return True
        except Exception:
            return False

    def count(self) -> int:
        if self._table is None:
            return self._fallback.count()
        try:
            return int(self._table.count_rows())
        except Exception:
            return self._fallback.count()
