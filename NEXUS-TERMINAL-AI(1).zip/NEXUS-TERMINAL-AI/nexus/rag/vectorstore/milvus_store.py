"""Milvus-backed vector store."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class MilvusStore(VectorStore):
    """Wraps a Milvus collection. Falls back to in-memory store on failure."""

    name = "milvus"

    def __init__(self, collection: str = "nexus", host: str = "localhost",
                 port: int = 19530, dim: int = 768) -> None:
        self.collection_name = collection
        self.host = host
        self.port = port
        self.dim = dim
        self._collection: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            from pymilvus import (  # type: ignore
                connections, Collection, CollectionSchema, FieldSchema,
                DataType, utility,
            )
            connections.connect(alias="default", host=self.host, port=self.port)
            if not utility.has_collection(self.collection_name):
                fields = [
                    FieldSchema("id", DataType.VARCHAR, is_primary=True, max_length=64),
                    FieldSchema("vector", DataType.FLOAT_VECTOR, dim=self.dim),
                    FieldSchema("text", DataType.VARCHAR, max_length=65535),
                ]
                schema = CollectionSchema(fields)
                Collection(self.collection_name, schema=schema)
            self._collection = Collection(self.collection_name)
        except Exception as exc:
            logger.warning("Milvus unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        if self._collection is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            self._collection.insert([[id], [vector], [text]])
        except Exception as exc:
            logger.warning("Milvus insert failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._collection is None:
            return self._fallback.search(query, k, filter)
        try:
            self._collection.load()
            params = {"metric_type": "COSINE", "params": {"nprobe": 16}}
            results = self._collection.search([query], "vector", params, limit=k,
                                              output_fields=["text"])
            out: list[StoreRecord] = []
            for hits in results:
                for h in hits:
                    out.append(StoreRecord(id=str(h.id), vector=[],
                                           text=h.entity.get("text", ""),
                                           metadata={}, score=float(h.score)))
            return out
        except Exception as exc:
            logger.warning("Milvus search failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._collection is None:
            return self._fallback.delete(id)
        try:
            self._collection.delete(f'id == "{id}"')
            return True
        except Exception:
            return False

    def count(self) -> int:
        if self._collection is None:
            return self._fallback.count()
        try:
            return int(self._collection.num_entities)
        except Exception:
            return self._fallback.count()
