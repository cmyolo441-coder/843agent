"""MultiStore: federation that fans out add/search across multiple backends."""
from __future__ import annotations

import logging
from typing import Any, Iterable

from .base_store import StoreRecord, VectorStore

logger = logging.getLogger(__name__)


class MultiStore(VectorStore):
    """Round-robin writes (sharded) and broadcast reads with score fusion."""

    name = "multi"

    def __init__(self, stores: list[VectorStore], strategy: str = "broadcast",
                 fusion: str = "max") -> None:
        if not stores:
            raise ValueError("MultiStore requires at least one backing store")
        if strategy not in ("broadcast", "round_robin", "shard"):
            raise ValueError(f"unknown write strategy {strategy!r}")
        if fusion not in ("max", "sum", "avg"):
            raise ValueError(f"unknown fusion strategy {fusion!r}")
        self._stores = stores
        self.strategy = strategy
        self.fusion = fusion
        self._cursor = 0

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        if self.strategy == "broadcast":
            for s in self._stores:
                s.add(id, vector, text, metadata)
        else:
            shard = hash(id) % len(self._stores) if self.strategy == "shard" else self._cursor
            self._cursor = (self._cursor + 1) % len(self._stores)
            self._stores[shard].add(id, vector, text, metadata)

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        merged: dict[str, list[StoreRecord]] = {}
        for s in self._stores:
            for r in s.search(query, k=k, filter=filter):
                merged.setdefault(r.id, []).append(r)
        fused: list[StoreRecord] = []
        for rid, recs in merged.items():
            scores = [r.score for r in recs]
            score = (max(scores) if self.fusion == "max"
                     else sum(scores) if self.fusion == "sum"
                     else sum(scores) / len(scores))
            best = max(recs, key=lambda r: r.score)
            fused.append(StoreRecord(id=rid, vector=best.vector, text=best.text,
                                     metadata=best.metadata, score=score))
        fused.sort(key=lambda r: r.score, reverse=True)
        return fused[:k]

    def delete(self, id: str) -> bool:
        return any(s.delete(id) for s in self._stores)

    def count(self) -> int:
        return sum(s.count() for s in self._stores)
