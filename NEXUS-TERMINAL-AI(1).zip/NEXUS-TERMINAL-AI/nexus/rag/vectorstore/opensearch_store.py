"""OpenSearch dense-vector store (similar to ElasticStore)."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class OpenSearchStore(VectorStore):
    """kNN-based store on OpenSearch (knn_vector field type)."""

    name = "opensearch"

    def __init__(self, hosts: list[dict] | None = None, index: str = "nexus",
                 dim: int = 768, auth: tuple[str, str] | None = None) -> None:
        self.hosts = hosts or [{"host": "localhost", "port": 9200}]
        self.index = index
        self.dim = dim
        self.auth = auth
        self._client: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            from opensearchpy import OpenSearch  # type: ignore
            self._client = OpenSearch(hosts=self.hosts, http_auth=self.auth)
            if not self._client.indices.exists(index=self.index):
                self._client.indices.create(index=self.index, body={
                    "settings": {"index": {"knn": True}},
                    "mappings": {"properties": {
                        "embedding": {"type": "knn_vector", "dimension": self.dim},
                        "text": {"type": "text"},
                        "metadata": {"type": "object"},
                    }},
                })
        except Exception as exc:
            logger.warning("opensearch unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        if self._client is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            self._client.index(index=self.index, id=id, body={
                "embedding": vector, "text": text, "metadata": metadata or {},
            })
        except Exception as exc:
            logger.warning("opensearch index failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._client is None:
            return self._fallback.search(query, k, filter)
        try:
            res = self._client.search(index=self.index, body={
                "size": k,
                "query": {"knn": {"embedding": {"vector": query, "k": k}}},
            })
            out: list[StoreRecord] = []
            for hit in res["hits"]["hits"]:
                src = hit.get("_source", {})
                out.append(StoreRecord(id=hit["_id"], vector=[],
                                       text=src.get("text", ""),
                                       metadata=src.get("metadata", {}),
                                       score=float(hit.get("_score", 0.0))))
            return out
        except Exception as exc:
            logger.warning("opensearch search failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._client is None:
            return self._fallback.delete(id)
        try:
            self._client.delete(index=self.index, id=id)
            return True
        except Exception:
            return False

    def count(self) -> int:
        if self._client is None:
            return self._fallback.count()
        try:
            return int(self._client.count(index=self.index)["count"])
        except Exception:
            return self._fallback.count()
