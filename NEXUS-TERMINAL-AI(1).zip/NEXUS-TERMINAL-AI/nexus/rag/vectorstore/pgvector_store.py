"""pgvector-backed (PostgreSQL) vector store."""
from __future__ import annotations

import json
import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class PGVectorStore(VectorStore):
    """Stores vectors in a Postgres table with the pgvector extension."""

    name = "pgvector"

    def __init__(self, dsn: str = "postgresql://localhost/nexus",
                 table: str = "nexus_vectors", dim: int = 768) -> None:
        self.dsn = dsn
        self.table = table
        self.dim = dim
        self._conn: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            import psycopg  # type: ignore
            self._conn = psycopg.connect(self.dsn, autocommit=True)
            with self._conn.cursor() as cur:
                cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
                cur.execute(
                    f"CREATE TABLE IF NOT EXISTS {self.table} ("
                    "id TEXT PRIMARY KEY, "
                    f"embedding vector({self.dim}), "
                    "text TEXT, metadata JSONB)"
                )
        except Exception as exc:
            logger.warning("pgvector unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        if self._conn is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            with self._conn.cursor() as cur:
                cur.execute(
                    f"INSERT INTO {self.table} (id, embedding, text, metadata) "
                    "VALUES (%s, %s, %s, %s) ON CONFLICT (id) DO UPDATE "
                    "SET embedding=EXCLUDED.embedding, text=EXCLUDED.text, "
                    "metadata=EXCLUDED.metadata",
                    (id, str(vector), text, json.dumps(metadata or {})),
                )
        except Exception as exc:
            logger.warning("pgvector insert failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._conn is None:
            return self._fallback.search(query, k, filter)
        try:
            with self._conn.cursor() as cur:
                cur.execute(
                    f"SELECT id, text, metadata, 1 - (embedding <=> %s::vector) "
                    f"FROM {self.table} ORDER BY embedding <=> %s::vector LIMIT %s",
                    (str(query), str(query), k),
                )
                rows = cur.fetchall()
            return [StoreRecord(id=r[0], vector=[], text=r[1] or "",
                                metadata=r[2] or {}, score=float(r[3]))
                    for r in rows]
        except Exception as exc:
            logger.warning("pgvector query failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._conn is None:
            return self._fallback.delete(id)
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"DELETE FROM {self.table} WHERE id=%s", (id,))
            return True
        except Exception:
            return False

    def count(self) -> int:
        if self._conn is None:
            return self._fallback.count()
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) FROM {self.table}")
                return int(cur.fetchone()[0])
        except Exception:
            return self._fallback.count()
