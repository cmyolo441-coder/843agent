"""Pinecone-backed vector store."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class PineconeStore(VectorStore):
    """Wraps a Pinecone index with optional in-memory fallback."""

    name = "pinecone"

    def __init__(self, index: str = "nexus", api_key: str | None = None,
                 environment: str | None = None, namespace: str = "") -> None:
        self.index_name = index
        self.api_key = api_key
        self.environment = environment
        self.namespace = namespace
        self._index: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            from pinecone import Pinecone  # type: ignore
            client = Pinecone(api_key=self.api_key)
            self._index = client.Index(self.index_name)
        except Exception as exc:
            logger.warning("Pinecone unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        meta = {"text": text, **(metadata or {})}
        if self._index is None:
            self._fallback.add(id, vector, text, meta)
            return
        try:
            self._index.upsert(vectors=[(id, vector, meta)], namespace=self.namespace)
        except Exception as exc:
            logger.warning("Pinecone upsert failed: %s", exc)
            self._fallback.add(id, vector, text, meta)

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._index is None:
            return self._fallback.search(query, k, filter)
        try:
            res = self._index.query(vector=query, top_k=k, include_metadata=True,
                                    namespace=self.namespace, filter=filter)
            out: list[StoreRecord] = []
            for m in res.get("matches", []):
                meta = m.get("metadata") or {}
                out.append(StoreRecord(id=m["id"], vector=[], text=meta.get("text", ""),
                                       metadata=meta, score=float(m.get("score", 0.0))))
            return out
        except Exception as exc:
            logger.warning("Pinecone query failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._index is None:
            return self._fallback.delete(id)
        try:
            self._index.delete(ids=[id], namespace=self.namespace)
            return True
        except Exception:
            return False

    def count(self) -> int:
        if self._index is None:
            return self._fallback.count()
        try:
            stats = self._index.describe_index_stats()
            return int(stats.get("total_vector_count", 0))
        except Exception:
            return self._fallback.count()
