"""Qdrant-backed vector store."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class QdrantStore(VectorStore):
    """Wraps a Qdrant collection (cosine distance) with in-memory fallback."""

    name = "qdrant"

    def __init__(self, collection: str = "nexus", url: str = "http://localhost:6333",
                 api_key: str | None = None, dim: int = 768) -> None:
        self.collection = collection
        self.url = url
        self.api_key = api_key
        self.dim = dim
        self._client: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            from qdrant_client import QdrantClient  # type: ignore
            from qdrant_client.http.models import Distance, VectorParams  # type: ignore
            self._client = QdrantClient(url=self.url, api_key=self.api_key)
            collections = {c.name for c in self._client.get_collections().collections}
            if self.collection not in collections:
                self._client.create_collection(
                    collection_name=self.collection,
                    vectors_config=VectorParams(size=self.dim, distance=Distance.COSINE),
                )
        except Exception as exc:
            logger.warning("Qdrant unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        if self._client is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            from qdrant_client.http.models import PointStruct  # type: ignore
            payload = {"text": text, **(metadata or {})}
            self._client.upsert(collection_name=self.collection,
                                points=[PointStruct(id=id, vector=vector, payload=payload)])
        except Exception as exc:
            logger.warning("Qdrant upsert failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._client is None:
            return self._fallback.search(query, k, filter)
        try:
            hits = self._client.search(collection_name=self.collection,
                                       query_vector=query, limit=k)
            out: list[StoreRecord] = []
            for h in hits:
                payload = h.payload or {}
                out.append(StoreRecord(id=str(h.id), vector=[],
                                       text=payload.get("text", ""),
                                       metadata=payload, score=float(h.score)))
            return out
        except Exception as exc:
            logger.warning("Qdrant query failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._client is None:
            return self._fallback.delete(id)
        try:
            self._client.delete(collection_name=self.collection, points_selector=[id])
            return True
        except Exception:
            return False

    def count(self) -> int:
        if self._client is None:
            return self._fallback.count()
        try:
            info = self._client.get_collection(self.collection)
            return int(getattr(info, "points_count", 0) or 0)
        except Exception:
            return self._fallback.count()
