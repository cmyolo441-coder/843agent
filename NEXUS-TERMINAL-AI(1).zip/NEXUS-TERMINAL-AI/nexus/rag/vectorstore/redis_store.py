"""Redis-backed vector store using RedisSearch + HNSW."""
from __future__ import annotations

import json
import logging
import struct
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class RedisStore(VectorStore):
    """Stores hashes with a binary vector field; queries via FT.SEARCH KNN."""

    name = "redis"

    def __init__(self, url: str = "redis://localhost:6379", index: str = "nexus_idx",
                 prefix: str = "nexus:", dim: int = 768) -> None:
        self.url = url
        self.index_name = index
        self.prefix = prefix
        self.dim = dim
        self._client: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            import redis  # type: ignore
            self._client = redis.Redis.from_url(self.url, decode_responses=False)
            try:
                self._client.execute_command(
                    "FT.CREATE", self.index_name, "ON", "HASH",
                    "PREFIX", "1", self.prefix, "SCHEMA",
                    "embedding", "VECTOR", "HNSW", "6", "TYPE", "FLOAT32",
                    "DIM", str(self.dim), "DISTANCE_METRIC", "COSINE",
                    "text", "TEXT", "metadata", "TEXT",
                )
            except Exception:
                pass  # index may already exist
        except Exception as exc:
            logger.warning("redis unavailable: %s", exc)

    def _pack(self, vector: list[float]) -> bytes:
        return struct.pack(f"{len(vector)}f", *vector)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        if self._client is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            self._client.hset(f"{self.prefix}{id}", mapping={
                "embedding": self._pack(vector),
                "text": text.encode("utf-8"),
                "metadata": json.dumps(metadata or {}).encode("utf-8"),
            })
        except Exception as exc:
            logger.warning("redis HSET failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._client is None:
            return self._fallback.search(query, k, filter)
        try:
            q = f"*=>[KNN {k} @embedding $V AS score]"
            res = self._client.execute_command(
                "FT.SEARCH", self.index_name, q,
                "PARAMS", "2", "V", self._pack(query),
                "SORTBY", "score", "DIALECT", "2",
            )
            out: list[StoreRecord] = []
            for i in range(1, len(res), 2):
                doc_id = res[i].decode() if isinstance(res[i], bytes) else str(res[i])
                fields = res[i + 1]
                f = {fields[j].decode(): fields[j + 1] for j in range(0, len(fields), 2)}
                score = float(f.get("score", b"0"))
                out.append(StoreRecord(
                    id=doc_id.removeprefix(self.prefix), vector=[],
                    text=f.get("text", b"").decode("utf-8", errors="ignore"),
                    metadata=json.loads(f.get("metadata", b"{}") or b"{}"),
                    score=1.0 - score,
                ))
            return out
        except Exception as exc:
            logger.warning("redis search failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._client is None:
            return self._fallback.delete(id)
        try:
            return bool(self._client.delete(f"{self.prefix}{id}"))
        except Exception:
            return False

    def count(self) -> int:
        if self._client is None:
            return self._fallback.count()
        try:
            return len(self._client.keys(f"{self.prefix}*"))
        except Exception:
            return self._fallback.count()
