"""SQLite (vss/sqlite-vec) backed vector store."""
from __future__ import annotations

import json
import logging
import sqlite3
import struct
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class SQLiteVecStore(VectorStore):
    """Persists vectors in a sqlite3 file; cosine search done in Python."""

    name = "sqlite_vec"

    def __init__(self, path: str = ":memory:", table: str = "nexus_vec") -> None:
        self.path = path
        self.table = table
        self._conn = sqlite3.connect(path)
        self._fallback = _InMemoryStore()
        self._init()

    def _init(self) -> None:
        with self._conn:
            self._conn.execute(
                f"CREATE TABLE IF NOT EXISTS {self.table} ("
                "id TEXT PRIMARY KEY, vector BLOB, text TEXT, metadata TEXT)"
            )

    @staticmethod
    def _pack(v: list[float]) -> bytes:
        return struct.pack(f"{len(v)}f", *v)

    @staticmethod
    def _unpack(b: bytes) -> list[float]:
        n = len(b) // 4
        return list(struct.unpack(f"{n}f", b))

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        with self._conn:
            self._conn.execute(
                f"INSERT OR REPLACE INTO {self.table} VALUES (?, ?, ?, ?)",
                (id, self._pack(vector), text, json.dumps(metadata or {})),
            )

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        cur = self._conn.execute(f"SELECT id, vector, text, metadata FROM {self.table}")
        records: list[StoreRecord] = []
        for rid, blob, text, meta_json in cur:
            meta = json.loads(meta_json or "{}")
            if filter and not all(meta.get(kk) == v for kk, v in filter.items()):
                continue
            score = self.cosine(query, self._unpack(blob))
            records.append(StoreRecord(id=rid, vector=[], text=text or "",
                                       metadata=meta, score=score))
        records.sort(key=lambda r: r.score, reverse=True)
        return records[:k]

    def delete(self, id: str) -> bool:
        with self._conn:
            cur = self._conn.execute(f"DELETE FROM {self.table} WHERE id=?", (id,))
            return cur.rowcount > 0

    def count(self) -> int:
        cur = self._conn.execute(f"SELECT COUNT(*) FROM {self.table}")
        return int(cur.fetchone()[0])

    def close(self) -> None:
        self._conn.close()
