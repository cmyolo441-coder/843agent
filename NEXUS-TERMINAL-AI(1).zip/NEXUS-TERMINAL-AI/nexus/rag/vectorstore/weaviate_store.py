"""Weaviate-backed vector store."""
from __future__ import annotations

import logging
from typing import Any

from .base_store import StoreRecord, VectorStore, _InMemoryStore

logger = logging.getLogger(__name__)


class WeaviateStore(VectorStore):
    """Stores objects in a Weaviate class with vectorizer=none."""

    name = "weaviate"

    def __init__(self, url: str = "http://localhost:8080", class_name: str = "NexusDoc",
                 api_key: str | None = None) -> None:
        self.url = url
        self.class_name = class_name
        self.api_key = api_key
        self._client: Any = None
        self._fallback = _InMemoryStore()
        self._connect()

    def _connect(self) -> None:
        try:
            import weaviate  # type: ignore
            auth = None
            if self.api_key:
                auth = weaviate.AuthApiKey(api_key=self.api_key)
            self._client = weaviate.Client(self.url, auth_client_secret=auth)
        except Exception as exc:
            logger.warning("Weaviate unavailable: %s", exc)

    def add(self, id: str, vector: list[float], text: str = "",
            metadata: dict[str, Any] | None = None) -> None:
        if self._client is None:
            self._fallback.add(id, vector, text, metadata or {})
            return
        try:
            self._client.data_object.create(
                data_object={"text": text, **(metadata or {})},
                class_name=self.class_name, uuid=id, vector=vector,
            )
        except Exception as exc:
            logger.warning("Weaviate insert failed: %s", exc)
            self._fallback.add(id, vector, text, metadata or {})

    def search(self, query: list[float], k: int = 10,
               filter: dict[str, Any] | None = None) -> list[StoreRecord]:
        if self._client is None:
            return self._fallback.search(query, k, filter)
        try:
            q = (self._client.query
                 .get(self.class_name, ["text"])
                 .with_near_vector({"vector": query})
                 .with_limit(k)
                 .with_additional(["id", "distance"]))
            res = q.do()
            objs = res.get("data", {}).get("Get", {}).get(self.class_name, []) or []
            out: list[StoreRecord] = []
            for o in objs:
                extra = o.get("_additional", {})
                out.append(StoreRecord(id=extra.get("id", ""), vector=[],
                                       text=o.get("text", ""),
                                       metadata={k: v for k, v in o.items()
                                                 if k != "_additional"},
                                       score=1.0 - float(extra.get("distance", 1.0))))
            return out
        except Exception as exc:
            logger.warning("Weaviate query failed: %s", exc)
            return self._fallback.search(query, k, filter)

    def delete(self, id: str) -> bool:
        if self._client is None:
            return self._fallback.delete(id)
        try:
            self._client.data_object.delete(uuid=id, class_name=self.class_name)
            return True
        except Exception:
            return False

    def count(self) -> int:
        return self._fallback.count()
