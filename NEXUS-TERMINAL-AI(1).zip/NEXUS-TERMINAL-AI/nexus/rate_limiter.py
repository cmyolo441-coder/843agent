"""Token-bucket rate limiter, async-safe."""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass


@dataclass
class TokenBucket:
    """Async token bucket.

    `rate` tokens per second, with capacity `capacity`. Calls to `acquire(n)`
    block until n tokens are available.
    """

    rate: float
    capacity: float
    _tokens: float = 0.0
    _last: float = 0.0
    _lock: asyncio.Lock | None = None

    def __post_init__(self) -> None:
        self._tokens = self.capacity
        self._last = time.monotonic()
        self._lock = asyncio.Lock()

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last
        self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)
        self._last = now

    async def acquire(self, n: float = 1.0) -> None:
        """Wait until `n` tokens are available, then consume them."""
        if n > self.capacity:
            raise ValueError(f"requested {n} tokens > capacity {self.capacity}")
        assert self._lock is not None
        while True:
            async with self._lock:
                self._refill()
                if self._tokens >= n:
                    self._tokens -= n
                    return
                missing = n - self._tokens
            await asyncio.sleep(missing / self.rate)

    def try_acquire(self, n: float = 1.0) -> bool:
        """Non-blocking acquire."""
        self._refill()
        if self._tokens >= n:
            self._tokens -= n
            return True
        return False

    @property
    def available(self) -> float:
        self._refill()
        return self._tokens
