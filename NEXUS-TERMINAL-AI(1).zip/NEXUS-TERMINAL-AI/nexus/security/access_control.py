"""RBAC / ABAC access control engine."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class Policy:
    """A single access control policy rule."""
    name: str
    effect: str  # "allow" | "deny"
    roles: list[str] = field(default_factory=list)
    actions: list[str] = field(default_factory=list)
    resources: list[str] = field(default_factory=list)
    conditions: dict[str, Any] = field(default_factory=dict)


class AccessControlEngine:
    """Role-based and attribute-based access control engine."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.policies: list[Policy] = []
        self.role_hierarchy: dict[str, list[str]] = {}

    async def load_policies(self) -> None:
        """Load predefined policies from config."""
        for raw in self.config.get("policies", []):
            self.policies.append(Policy(**raw))
        self.role_hierarchy = self.config.get("roles", {})
        _log.info("Loaded %d policies", len(self.policies))

    def add_policy(self, policy: Policy) -> None:
        self.policies.append(policy)

    def _resolve_roles(self, roles: list[str]) -> set[str]:
        resolved: set[str] = set(roles)
        for role in roles:
            for parent, children in self.role_hierarchy.items():
                if role in children:
                    resolved.add(parent)
        return resolved

    def _match_policy(self, policy: Policy, identity: dict[str, Any], action: str, resource: str) -> bool | None:
        """Check if a policy applies. Returns True (allow), False (deny), or None (no match)."""
        identity_roles = identity.get("roles", [])
        resolved = self._resolve_roles(identity_roles)
        if policy.roles and not resolved.intersection(policy.roles):
            return None
        if policy.actions and action not in policy.actions:
            return None
        if policy.resources:
            matched = False
            for pr in policy.resources:
                if resource == pr or (pr.endswith("*") and resource.startswith(pr[:-1])):
                    matched = True
                    break
            if not matched:
                return None
        for attr, expected in policy.conditions.items():
            actual = identity.get("attributes", {}).get(attr)
            if actual != expected:
                return None
        return policy.effect == "allow"

    async def check(self, identity: dict[str, Any], action: str, resource: str) -> bool:
        """Evaluate all policies against the request."""
        for policy in self.policies:
            result = self._match_policy(policy, identity, action, resource)
            if result is False:
                _log.warning("Denied %s %s on %s by policy %s", identity.get("sub"), action, resource, policy.name)
                return False
            if result is True:
                return True
        _log.warning("No matching policy — denying %s %s on %s", identity.get("sub"), action, resource)
        return False

    async def get_user_permissions(self, identity: dict[str, Any]) -> list[str]:
        """Return all permitted action:resource pairs for a user."""
        permitted: list[str] = []
        for action in self.config.get("actions", []):
            for resource in self.config.get("resources", []):
                if await self.check(identity, action, resource):
                    permitted.append(f"{action}:{resource}")
        return permitted
