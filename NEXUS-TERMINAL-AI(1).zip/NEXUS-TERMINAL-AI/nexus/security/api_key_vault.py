"""Encrypted API key vault — generate, store, validate API keys."""
from __future__ import annotations

import hashlib
import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import Any

from nexus.exceptions import SecurityError
from nexus.security.encryption import EncryptionEngine

_log = logging.getLogger(__name__)


@dataclass
class StoredKey:
    """Internal representation of a stored API key."""
    key_hash: str
    owner: str
    roles: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    expires_at: float | None = None
    enabled: bool = True


class APIKeyVault:
    """Encrypted vault for managing API keys."""

    PREFIX = "nexus_"

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._keys: dict[str, StoredKey] = {}
        self._encryption = EncryptionEngine(self.config.get("encryption", {}))

    async def load_keys(self) -> None:
        """Load persisted keys from encrypted storage."""
        raw = self.config.get("keys", [])
        for entry in raw:
            decrypted = await self._encryption.decrypt(entry["ciphertext"])
            sk = StoredKey(**decrypted)
            self._keys[sk.key_hash] = sk
        _log.info("Loaded %d API keys", len(self._keys))

    async def generate_key(self, owner: str, roles: list[str] | None = None, ttl_days: int | None = None) -> str:
        """Generate a new API key and store its hash."""
        raw_key = self.PREFIX + secrets.token_hex(32)
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        sk = StoredKey(
            key_hash=key_hash,
            owner=owner,
            roles=roles or [],
            expires_at=time.time() + ttl_days * 86400 if ttl_days else None,
        )
        self._keys[key_hash] = sk
        to_store = {"ciphertext": await self._encryption.encrypt(sk.__dict__)}
        self.config.setdefault("keys", []).append(to_store)
        _log.info("Generated key for owner=%s", owner)
        return raw_key

    async def validate_key(self, raw_key: str) -> dict[str, Any] | None:
        """Validate a raw API key and return its metadata."""
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        sk = self._keys.get(key_hash)
        if sk is None:
            return None
        if not sk.enabled:
            return None
        if sk.expires_at and time.time() > sk.expires_at:
            return None
        return {"owner": sk.owner, "roles": sk.roles}

    async def revoke_key(self, raw_key: str) -> None:
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        sk = self._keys.get(key_hash)
        if sk:
            sk.enabled = False
            _log.info("Revoked key for owner=%s", sk.owner)

    async def list_keys(self) -> list[dict[str, Any]]:
        return [
            {"owner": sk.owner, "roles": sk.roles, "created_at": sk.created_at, "enabled": sk.enabled}
            for sk in self._keys.values()
        ]
