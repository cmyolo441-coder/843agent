"""Audit logging — tamper-evident event logging."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class AuditEvent:
    """A single audit log entry."""
    action: str
    subject: str
    resource: str = ""
    target: str = ""
    success: bool = True
    details: dict[str, Any] = field(default_factory=dict)
    source_ip: str | None = None
    timestamp: float = field(default_factory=time.time)
    hash_chain: str = ""


class AuditLogger:
    """Tamper-evident audit logger with hash chaining."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._queue: asyncio.Queue[AuditEvent] = asyncio.Queue()
        self._worker_task: asyncio.Task[None] | None = None
        self._last_hash = "0" * 64
        self._events: list[AuditEvent] = []

    async def start(self) -> None:
        self._worker_task = asyncio.create_task(self._worker())
        _log.info("AuditLogger started")

    async def stop(self) -> None:
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        _log.info("AuditLogger stopped")

    async def log(self, action: str, subject: str, **kwargs: Any) -> None:
        event = AuditEvent(action=action, subject=subject, **kwargs)
        event.hash_chain = self._compute_hash(event)
        self._last_hash = event.hash_chain
        await self._queue.put(event)

    def _compute_hash(self, event: AuditEvent) -> str:
        raw = json.dumps({
            "action": event.action,
            "subject": event.subject,
            "resource": event.resource,
            "timestamp": event.timestamp,
            "success": event.success,
            "prev_hash": self._last_hash,
        }, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode()).hexdigest()

    async def _worker(self) -> None:
        while True:
            try:
                event = await self._queue.get()
                self._events.append(event)
                _log.info("AUDIT: %s by %s on %s — %s", event.action, event.subject, event.resource, "OK" if event.success else "FAIL")
            except asyncio.CancelledError:
                break
            except Exception as exc:
                _log.exception("Audit worker error: %s", exc)

    async def query(self, action: str | None = None, subject: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        results = []
        for ev in reversed(self._events):
            if action and ev.action != action:
                continue
            if subject and ev.subject != subject:
                continue
            results.append({
                "action": ev.action,
                "subject": ev.subject,
                "resource": ev.resource,
                "success": ev.success,
                "timestamp": datetime.fromtimestamp(ev.timestamp, tz=timezone.utc).isoformat(),
                "source_ip": ev.source_ip,
                "hash_chain": ev.hash_chain,
            })
            if len(results) >= limit:
                break
        return results

    async def verify_chain(self) -> bool:
        """Verify the integrity of the hash chain."""
        prev_hash = "0" * 64
        for ev in self._events:
            expected = self._compute_hash(AuditEvent(
                action=ev.action, subject=ev.subject, resource=ev.resource,
                success=ev.success, timestamp=ev.timestamp,
            ))
            if ev.hash_chain != expected:
                return False
            prev_hash = ev.hash_chain
        return True
