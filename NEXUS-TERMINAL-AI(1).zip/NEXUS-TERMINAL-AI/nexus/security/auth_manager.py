"""Authentication manager — JWT + API key authentication."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from nexus.exceptions import SecurityError
from nexus.security.api_key_vault import APIKeyVault
from nexus.security.token_manager import TokenManager

_log = logging.getLogger(__name__)


@dataclass
class AuthProvider:
    """Configured identity provider."""
    name: str
    issuer: str
    jwks_url: str | None = None
    type: str = "jwt"


class AuthManager:
    """Multi-provider authentication dispatcher."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.providers: dict[str, AuthProvider] = {}
        self.token_manager = TokenManager(self.config.get("token", {}))
        self.api_key_vault = APIKeyVault(self.config.get("vault", {}))

    async def load_providers(self) -> None:
        for raw in self.config.get("providers", []):
            p = AuthProvider(**raw)
            self.providers[p.name] = p
        await self.api_key_vault.load_keys()
        _log.info("Loaded %d auth providers", len(self.providers))

    async def authenticate(self, token: str) -> dict[str, Any]:
        """Authenticate a JWT or API key. Returns claims dict."""
        if token.startswith("nexus_"):
            return await self._authenticate_api_key(token)
        return await self._authenticate_jwt(token)

    async def _authenticate_jwt(self, token: str) -> dict[str, Any]:
        claims = await self.token_manager.decode(token)
        if not claims:
            raise SecurityError("Invalid JWT token")
        _log.debug("JWT auth succeeded for %s", claims.get("sub"))
        return claims

    async def _authenticate_api_key(self, api_key: str) -> dict[str, Any]:
        key_data = await self.api_key_vault.validate_key(api_key)
        if not key_data:
            raise SecurityError("Invalid API key")
        _log.debug("API key auth succeeded for %s", key_data.get("owner"))
        return {"sub": key_data.get("owner", "api-user"), "roles": key_data.get("roles", []), "auth_type": "api_key"}

    async def create_token(self, identity: dict[str, Any]) -> str:
        """Issue a signed JWT for the given identity."""
        return await self.token_manager.encode(identity)

    async def revoke_token(self, token: str) -> None:
        await self.token_manager.revoke(token)

    async def create_api_key(self, owner: str, roles: list[str] | None = None) -> str:
        return await self.api_key_vault.generate_key(owner, roles)
