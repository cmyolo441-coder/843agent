"""Compliance engine — GDPR / HIPAA / SOC2 rule checking."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class ComplianceRule:
    """A compliance rule with metadata."""
    framework: str
    rule_id: str
    description: str
    severity: str = "medium"
    category: str = "privacy"


@dataclass
class Violation:
    """A compliance violation result."""
    rule_id: str
    framework: str
    description: str
    severity: str
    details: str = ""


class ComplianceEngine:
    """Evaluates data and configurations against regulatory frameworks."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.rules: list[ComplianceRule] = []
        self._pii_patterns = [
            re.compile(r"\b[A-Z][a-z]+ [A-Z][a-z]+\b"),  # Full name
            re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),         # SSN
            re.compile(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"),  # IP
            re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"),  # Email
        ]

    async def check(self, data: dict[str, Any], context: str) -> list[str]:
        """Run data against applicable rules. Returns violation strings."""
        violations: list[str] = []
        if context == "gdpr":
            violations.extend(await self._check_gdpr(data))
        if context == "hipaa":
            violations.extend(await self._check_hipaa(data))
        if context == "soc2":
            violations.extend(await self._check_soc2(data))
        return violations

    async def _check_gdpr(self, data: dict[str, Any]) -> list[str]:
        result: list[str] = []
        if "user_email" in data and not data.get("consent_given"):
            result.append("GDPR: Personal data without consent")
        if "ip_address" in data and not data.get("anonymized"):
            result.append("GDPR: IP address not anonymized")
        for key, value in data.items():
            if isinstance(value, str) and any(p.search(value) for p in self._pii_patterns):
                result.append(f"GDPR: Potential PII in field '{key}'")
        return result

    async def _check_hipaa(self, data: dict[str, Any]) -> list[str]:
        result: list[str] = []
        phi_fields = {"patient_name", "ssn", "medical_record", "diagnosis", "treatment", "provider"}
        found_phi = [f for f in phi_fields if f in data]
        if found_phi and not data.get("encrypted"):
            result.append(f"HIPAA: PHI fields {found_phi} not encrypted")
        if "phi_access_log" not in data:
            result.append("HIPAA: Missing PHI access audit trail")
        return result

    async def _check_soc2(self, data: dict[str, Any]) -> list[str]:
        result: list[str] = []
        if "access_log" not in data:
            result.append("SOC2: System access not logged")
        if "encryption_at_rest" in data and not data["encryption_at_rest"]:
            result.append("SOC2: Encryption at rest not enabled")
        if "encryption_in_transit" in data and not data["encryption_in_transit"]:
            result.append("SOC2: Encryption in transit not enabled")
        return result

    async def load_rules(self, framework: str | None = None) -> None:
        rules_config = self.config.get("rules", [])
        for raw in rules_config:
            if framework is None or raw.get("framework") == framework:
                self.rules.append(ComplianceRule(**raw))
        _log.info("Loaded %d compliance rules", len(self.rules))

    async def get_frameworks(self) -> list[str]:
        return ["gdpr", "hipaa", "soc2"]
