"""Content policy enforcement — prevent unsafe or policy-violating content."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class ContentRule:
    """A content policy rule."""
    name: str
    action: str  # "block" | "warn" | "flag"
    patterns: list[str] = field(default_factory=list)
    categories: list[str] = field(default_factory=list)


class ContentPolicy:
    """Enforces content policies — blocks or flags policy-violating content."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.rules: list[ContentRule] = []
        self._compiled: dict[str, list[re.Pattern]] = {}

    async def load_policies(self) -> None:
        raw_rules = self.config.get("rules", [
            {"name": "hate_speech", "action": "block", "categories": ["hate", "discrimination"]},
            {"name": "violence", "action": "block", "categories": ["violence", "gore"]},
            {"name": "personal_info", "action": "flag", "categories": ["pii"]},
            {"name": "nsfw", "action": "block", "categories": ["adult", "nsfw"]},
            {"name": "harmful_code", "action": "warn", "patterns": [r"rm\s+-rf\s*/", r"DROP\s+DATABASE", r"format\s+C:"]},
        ])
        for raw in raw_rules:
            rule = ContentRule(**raw)
            self.rules.append(rule)
            self._compiled[rule.name] = [re.compile(p, re.I) for p in rule.patterns]
        _log.info("Loaded %d content policy rules", len(self.rules))

    async def check(self, content: str, context: str = "default") -> dict[str, Any]:
        """Evaluate content against all rules. Returns verdict."""
        results: dict[str, Any] = {"allowed": True, "flags": [], "blocks": [], "warnings": []}
        for rule in self.rules:
            compiled_patterns = self._compiled.get(rule.name, [])
            matched = any(p.search(content) for p in compiled_patterns)
            if matched or rule.categories:
                for cat in rule.categories:
                    if self._category_match(content, cat):
                        matched = True
                        break
            if matched:
                if rule.action == "block":
                    results["allowed"] = False
                    results["blocks"].append(rule.name)
                elif rule.action == "warn":
                    results["warnings"].append(rule.name)
                elif rule.action == "flag":
                    results["flags"].append(rule.name)
        return results

    def _category_match(self, content: str, category: str) -> bool:
        """Simple keyword-based category matching."""
        keywords = {
            "hate": ["hate", "racist", "bigot", "discriminat"],
            "violence": ["kill", "murder", "bomb", "attack", "weapon"],
            "pii": ["ssn", "social security", "credit card", "passport"],
            "adult": ["nsfw", "explicit", "porn", "xxx"],
            "discrimination": ["sexist", "racist", "homophobic", "xenophobic"],
            "nsfw": ["nsfw", "18+", "adult content"],
        }
        cats = keywords.get(category, [category])
        return any(kw in content.lower() for kw in cats)

    async def sanitize(self, content: str) -> str:
        """Remove or replace policy-violating content."""
        result = content
        for rule in self.rules:
            if rule.action == "block":
                for p in self._compiled.get(rule.name, []):
                    result = p.sub(f"[{rule.name.upper()}_REMOVED]", result)
        return result
