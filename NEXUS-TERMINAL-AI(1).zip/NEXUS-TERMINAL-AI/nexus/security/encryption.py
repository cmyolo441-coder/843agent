"""AES / RSA encryption engine."""
from __future__ import annotations

import base64
import hashlib
import logging
import os
from typing import Any

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

_log = logging.getLogger(__name__)


class EncryptionEngine:
    """Symmetric (AES-GCM / Fernet) and asymmetric (RSA-OAEP) encryption."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._fernet_key: bytes | None = None
        self._fernet: Fernet | None = None
        self._private_key: rsa.RSAPrivateKey | None = None
        self._public_key: rsa.RSAPublicKey | None = None

    async def load_keys(self) -> None:
        fernet_b64 = self.config.get("fernet_key") or base64.urlsafe_b64encode(os.urandom(32)).decode()
        self._fernet_key = base64.urlsafe_b64decode(fernet_b64)
        self._fernet = Fernet(base64.urlsafe_b64encode(self._fernet_key))
        if "rsa_private" in self.config:
            self._private_key = serialization.load_pem_private_key(
                self.config["rsa_private"].encode(), password=None
            )
        if "rsa_public" in self.config:
            self._public_key = serialization.load_pem_public_key(
                self.config["rsa_public"].encode()
            )
        _log.info("Encryption keys loaded")

    async def encrypt(self, data: dict[str, Any] | str) -> str:
        """Encrypt data with Fernet (symmetric)."""
        if self._fernet is None:
            raise RuntimeError("EncryptionEngine not initialised — call load_keys()")
        payload = data if isinstance(data, bytes) else str(data).encode()
        return self._fernet.encrypt(payload).decode()

    async def decrypt(self, ciphertext: str) -> dict[str, Any]:
        """Decrypt Fernet ciphertext."""
        if self._fernet is None:
            raise RuntimeError("EncryptionEngine not initialised — call load_keys()")
        plain = self._fernet.decrypt(ciphertext.encode())
        return eval(plain.decode()) if b"{" in plain else {"value": plain.decode()}

    async def rsa_encrypt(self, plaintext: str) -> str:
        if self._public_key is None:
            raise RuntimeError("RSA public key not loaded")
        ct = self._public_key.encrypt(plaintext.encode(), padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
        return base64.b64encode(ct).decode()

    async def rsa_decrypt(self, ciphertext: str) -> str:
        if self._private_key is None:
            raise RuntimeError("RSA private key not loaded")
        ct = base64.b64decode(ciphertext)
        pt = self._private_key.decrypt(ct, padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
        return pt.decode()

    async def aes_gcm_encrypt(self, plaintext: str, key: bytes | None = None) -> tuple[bytes, bytes, bytes]:
        k = key or os.urandom(32)
        iv = os.urandom(12)
        cipher = Cipher(algorithms.AES(k), modes.GCM(iv))
        encryptor = cipher.encryptor()
        ct = encryptor.update(plaintext.encode()) + encryptor.finalize()
        return ct, iv, encryptor.tag

    async def aes_gcm_decrypt(self, ciphertext: bytes, iv: bytes, tag: bytes, key: bytes) -> str:
        cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag))
        decryptor = cipher.decryptor()
        pt = decryptor.update(ciphertext) + decryptor.finalize()
        return pt.decode()

    async def hash_password(self, password: str) -> str:
        salt = os.urandom(16)
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100_000)
        return base64.b64encode(salt + dk).decode()

    async def verify_password(self, password: str, hashed: str) -> bool:
        raw = base64.b64decode(hashed)
        salt, dk = raw[:16], raw[16:]
        new_dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100_000)
        return dk == new_dk
