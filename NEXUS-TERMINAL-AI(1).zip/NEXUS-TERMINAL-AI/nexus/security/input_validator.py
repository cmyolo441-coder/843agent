"""Input validation and sanitization — prevent injection and malformed data."""
from __future__ import annotations

import html
import logging
import re
from typing import Any

_log = logging.getLogger(__name__)


class InputValidator:
    """Validates and sanitizes user-supplied input across multiple contexts."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._max_length = self.config.get("max_length", 100_000)
        self._blocked_patterns = {
            "sql_injection": re.compile(r"(\b(select|insert|update|delete|drop|alter|exec|union)\b.*\b(from|into|set|where|table)\b)", re.I),
            "xss": re.compile(r"<script[^>]*>.*?</script>", re.I | re.S),
            "command_injection": re.compile(r"[;&|`$(){}\[\]<>!#~]"),
            "path_traversal": re.compile(r"\.\./|\.\.\\"),
            "template_injection": re.compile(r"\{\{.*\}\}|{%\s*.*\s*%}"),
        }
        self._allowlist: dict[str, re.Pattern] = {
            "alphanumeric": re.compile(r"^[a-zA-Z0-9_\-.@+ ]+$"),
            "email": re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$"),
            "url": re.compile(r"^https?://[^\s/$.?#].[^\s]*$"),
            "uuid": re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I),
        }

    async def validate(self, data: str, context: str = "default") -> tuple[bool, str]:
        """Validate raw input. Returns (is_valid, reason)."""
        if not data or not isinstance(data, str):
            return False, "Input must be a non-empty string"
        if len(data) > self._max_length:
            return False, f"Input exceeds max length of {self._max_length}"
        for name, pattern in self._blocked_patterns.items():
            if pattern.search(data):
                _log.warning("Blocked %s in input (context=%s)", name, context)
                return False, f"Blocked pattern: {name}"
        return True, ""

    async def sanitize(self, data: str, context: str = "default") -> str:
        """Sanitize input by escaping dangerous characters."""
        result = html.escape(data, quote=True)
        result = re.sub(r"[;&|`$(){}\[\]<>!#~]", "", result)
        return result

    async def validate_email(self, email: str) -> bool:
        return bool(self._allowlist["email"].match(email))

    async def validate_url(self, url: str) -> bool:
        return bool(self._allowlist["url"].match(url))

    async def validate_uuid(self, uuid: str) -> bool:
        return bool(self._allowlist["uuid"].match(uuid))

    async def deep_validate(self, data: Any, schema: dict[str, Any] | None = None) -> tuple[bool, str]:
        """Recursively validate nested structures against a type schema."""
        if schema is None:
            return True, ""
        if isinstance(schema, dict) and "type" in schema:
            expected = schema["type"]
            if expected == "string":
                if not isinstance(data, str):
                    return False, f"Expected string, got {type(data).__name__}"
                min_len = schema.get("minLength", 0)
                max_len = schema.get("maxLength", self._max_length)
                if len(data) < min_len:
                    return False, f"String too short ({len(data)} < {min_len})"
                if len(data) > max_len:
                    return False, f"String too long ({len(data)} > {max_len})"
                pattern = schema.get("pattern")
                if pattern and not re.match(pattern, data):
                    return False, "String does not match pattern"
            elif expected == "number":
                if not isinstance(data, (int, float)):
                    return False, f"Expected number, got {type(data).__name__}"
                if "minimum" in schema and data < schema["minimum"]:
                    return False, f"Number below minimum ({data} < {schema['minimum']})"
                if "maximum" in schema and data > schema["maximum"]:
                    return False, f"Number above maximum ({data} > {schema['maximum']})"
            elif expected == "array":
                if not isinstance(data, list):
                    return False, f"Expected array, got {type(data).__name__}"
                if "minItems" in schema and len(data) < schema["minItems"]:
                    return False, f"Array too short ({len(data)} < {schema['minItems']})"
        return True, ""
