"""Output filtering — strip PII and sensitive data from outbound content."""
from __future__ import annotations

import logging
import re
from typing import Any

_log = logging.getLogger(__name__)


class OutputFilter:
    """Filters sensitive patterns (PII, keys, tokens) from output content."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._patterns: list[tuple[str, str, re.Pattern]] = []
        self._load_patterns()

    def _load_patterns(self) -> None:
        raw = [
            ("email", "[EMAIL]", r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"),
            ("phone", "[PHONE]", r"\+?1?\d{1,4}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}"),
            ("ssn", "[SSN]", r"\b\d{3}-\d{2}-\d{4}\b"),
            ("credit_card", "[CREDIT_CARD]", r"\b(?:\d[ -]*?){13,16}\b"),
            ("ipv4", "[IP_ADDR]", r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
            ("aws_key", "[AWS_KEY]", r"(?:AKIA|ASIA)[0-9A-Z]{16}"),
            ("github_token", "[GITHUB_TOKEN]", r"gh[pousr]_[A-Za-z0-9_]{36,}"),
            ("jwt_token", "[JWT]", r"eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+"),
            ("nexus_api_key", "[API_KEY]", r"nexus_[a-f0-9]{64}"),
            ("bearer_token", "[BEARER]", r"Bearer\s+[A-Za-z0-9\-._~+/]+=*"),
        ]
        for name, placeholder, pattern_str in raw:
            try:
                self._patterns.append((name, placeholder, re.compile(pattern_str)))
            except re.error as exc:
                _log.warning("Invalid regex for %s: %s", name, exc)

    async def filter(self, data: str, level: str = "strict") -> str:
        """Apply filters to redact sensitive data."""
        if not data:
            return data
        result = data
        for name, placeholder, pattern in self._patterns:
            if level == "strict" or (level == "moderate" and name in ("email", "phone", "ssn", "credit_card")):
                result = pattern.sub(placeholder, result)
        _log.debug("Output filter applied (level=%s, %d replacements)", level, len(self._patterns))
        return result

    async def has_sensitive_data(self, data: str) -> list[str]:
        """Check if data contains any sensitive patterns without redacting."""
        found: list[str] = []
        for name, _placeholder, pattern in self._patterns:
            if pattern.search(data):
                found.append(name)
        return found

    async def add_custom_pattern(self, name: str, placeholder: str, regex: str) -> None:
        compiled = re.compile(regex)
        self._patterns.append((name, placeholder, compiled))
        _log.info("Added custom output filter: %s", name)
