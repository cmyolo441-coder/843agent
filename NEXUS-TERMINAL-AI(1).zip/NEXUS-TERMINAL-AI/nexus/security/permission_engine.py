"""Permission engine — fine-grained resource-level permissions."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class Permission:
    """A permission entry binding an action to a resource."""
    action: str
    resource: str
    conditions: dict[str, Any] = field(default_factory=dict)


@dataclass
class Role:
    """A role with a set of permissions."""
    name: str
    permissions: list[Permission] = field(default_factory=list)
    parents: list[str] = field(default_factory=list)


class PermissionEngine:
    """Resolves role inheritance and evaluates granular permissions."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.roles: dict[str, Role] = {}

    async def load_roles(self) -> None:
        raw = self.config.get("roles", {
            "admin": {
                "permissions": [{"action": "*", "resource": "*"}],
                "parents": [],
            },
            "user": {
                "permissions": [
                    {"action": "read", "resource": "namespace:user:${user_id}:*"},
                    {"action": "write", "resource": "namespace:user:${user_id}:*"},
                ],
                "parents": [],
            },
            "viewer": {
                "permissions": [{"action": "read", "resource": "*"}],
                "parents": [],
            },
        })
        for name, data in raw.items():
            perms = [Permission(**p) for p in data.get("permissions", [])]
            self.roles[name] = Role(name=name, permissions=perms, parents=data.get("parents", []))
        _log.info("Loaded %d roles", len(self.roles))

    def _resolve_role(self, role_name: str, visited: set[str] | None = None) -> list[Permission]:
        if visited is None:
            visited = set()
        if role_name in visited:
            return []
        visited.add(role_name)
        role = self.roles.get(role_name)
        if not role:
            return []
        result = list(role.permissions)
        for parent_name in role.parents:
            result.extend(self._resolve_role(parent_name, visited))
        return result

    async def has_permission(self, identity: dict[str, Any], action: str, resource: str) -> bool:
        """Check if identity has the given permission."""
        user_roles = identity.get("roles", ["user"])
        user_id = identity.get("sub", "")
        for role_name in user_roles:
            perms = self._resolve_role(role_name)
            for perm in perms:
                if perm.action != "*" and perm.action != action:
                    continue
                res_pattern = perm.resource.replace("${user_id}", user_id)
                if res_pattern == "*" or resource == res_pattern or (res_pattern.endswith("*") and resource.startswith(res_pattern[:-1])):
                    if perm.conditions:
                        for attr, expected in perm.conditions.items():
                            if identity.get("attributes", {}).get(attr) != expected:
                                break
                        else:
                            return True
                    else:
                        return True
        return False

    async def get_effective_permissions(self, identity: dict[str, Any]) -> list[str]:
        """Return all permissions a user has."""
        result: list[str] = []
        for action in ("read", "write", "delete", "admin"):
            for resource in self.config.get("resource_patterns", ["*"]):
                if await self.has_permission(identity, action, resource):
                    result.append(f"{action}:{resource}")
        return result
