"""Data masking — dynamically mask sensitive data fields."""
from __future__ import annotations

import logging
import re
from typing import Any

_log = logging.getLogger(__name__)


class DataMasker:
    """Masks sensitive data fields with configurable strategies."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._strategies: dict[str, str] = self.config.get("strategies", {
            "email": "partial",
            "phone": "partial",
            "ssn": "full",
            "credit_card": "partial",
            "password": "full",
            "api_key": "full",
        })

    async def mask(self, field_name: str, value: str) -> str:
        """Mask a single value based on its field name and configured strategy."""
        strategy = self._strategies.get(field_name, "none")
        if strategy == "full":
            return self._full_mask(value)
        elif strategy == "partial":
            return self._partial_mask(value, field_name)
        elif strategy == "email_mask":
            return self._email_mask(value)
        else:
            return value

    async def mask_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        """Recursively mask sensitive fields in a dictionary."""
        result: dict[str, Any] = {}
        for key, value in data.items():
            if isinstance(value, str):
                result[key] = await self.mask(key, value)
            elif isinstance(value, dict):
                result[key] = await self.mask_dict(value)
            elif isinstance(value, list):
                result[key] = [
                    await self.mask_dict(item) if isinstance(item, dict)
                    else await self.mask(key, str(item)) if isinstance(item, str)
                    else item
                    for item in value
                ]
            else:
                result[key] = value
        return result

    def _full_mask(self, value: str) -> str:
        return "*" * len(value)

    def _partial_mask(self, value: str, field_name: str) -> str:
        if field_name == "email":
            return self._email_mask(value)
        elif field_name == "phone":
            return value[:3] + "***" + value[-4:] if len(value) > 7 else self._full_mask(value)
        elif field_name == "credit_card":
            return "****-****-****-" + value[-4:] if len(value) > 4 else self._full_mask(value)
        elif field_name == "ssn":
            return "***-**-" + value[-4:] if len(value) == 11 else self._full_mask(value)
        else:
            return value[:2] + "..." + value[-2:] if len(value) > 4 else self._full_mask(value)

    def _email_mask(self, value: str) -> str:
        parts = value.split("@")
        if len(parts) == 2:
            local = parts[0]
            masked_local = local[:2] + "***" if len(local) > 2 else local[0] + "***"
            return f"{masked_local}@{parts[1]}"
        return value

    async def mask_by_regex(self, value: str, pattern: str, replacement: str = "***") -> str:
        """Mask substrings matching a regex pattern."""
        return re.sub(pattern, replacement, value)
