"""Differential privacy — ε-differential privacy with Laplace mechanism."""
from __future__ import annotations

import logging
import random
from typing import Any

_log = logging.getLogger(__name__)


class DifferentialPrivacy:
    """Applies differential privacy using the Laplace mechanism."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._epsilon = self.config.get("epsilon", 1.0)
        self._sensitivity = self.config.get("sensitivity", 1.0)

    def _laplace_noise(self, scale: float) -> float:
        """Generate Laplace noise."""
        u = random.random() - 0.5
        return -scale * (1 if u >= 0 else -1) * (1 - 2 * abs(u)).__log__() if abs(u) > 1e-15 else 0.0

    async def add_noise(self, value: float, epsilon: float | None = None) -> float:
        """Add Laplace noise to a numeric value."""
        eps = epsilon or self._epsilon
        scale = self._sensitivity / eps if eps > 0 else 0
        noise = self._laplace_noise(scale)
        return value + noise

    async def add_noise_batch(self, values: list[float], epsilon: float | None = None) -> list[float]:
        return [await self.add_noise(v, epsilon) for v in values]

    async def query_count(self, true_count: int, epsilon: float | None = None) -> int:
        """Return a differentially private count."""
        noisy = await self.add_noise(float(true_count), epsilon)
        return max(0, int(round(noisy)))

    async def query_sum(self, true_sum: float, epsilon: float | None = None) -> float:
        """Return a differentially private sum."""
        return await self.add_noise(true_sum, epsilon)

    async def query_mean(self, true_sum: float, true_count: int, epsilon: float | None = None) -> float:
        """Return a differentially private mean using the Laplace mechanism."""
        eps = epsilon or self._epsilon
        scale = self._sensitivity / (eps * true_count) if eps > 0 and true_count > 0 else 0
        noise = self._laplace_noise(scale)
        return (true_sum / true_count) + noise if true_count > 0 else 0.0

    @property
    def epsilon(self) -> float:
        return self._epsilon
