"""k-anonymity — anonymize datasets to satisfy k-anonymity property."""
from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class AnonymizationReport:
    """Report of anonymization results."""
    original_rows: int
    suppressed_rows: int
    generalized_columns: list[str] = field(default_factory=list)
    k_value: int = 1


class KAnonymity:
    """Enforces k-anonymity on tabular data via suppression and generalization."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._k = self.config.get("k", 5)

    async def check(self, data: list[dict[str, Any]], quasi_identifiers: list[str]) -> bool:
        """Check if a dataset satisfies k-anonymity."""
        if not data:
            return True
        groups = Counter()
        for row in data:
            key = tuple(row.get(qi, "") for qi in quasi_identifiers)
            groups[key] += 1
        min_count = min(groups.values())
        return min_count >= self._k

    async def anonymize(self, data: list[dict[str, Any]], quasi_identifiers: list[str], k: int | None = None) -> list[dict[str, Any]]:
        """Anonymize data to satisfy k-anonymity via row suppression."""
        k_val = k or self._k
        groups: dict[tuple, list[int]] = {}
        for i, row in enumerate(data):
            key = tuple(row.get(qi, "") for qi in quasi_identifiers)
            groups.setdefault(key, []).append(i)

        suppressed_indices: set[int] = set()
        for key, indices in groups.items():
            if len(indices) < k_val:
                suppressed_indices.update(indices)

        result = [row for i, row in enumerate(data) if i not in suppressed_indices]
        _log.info("k-anonymity: suppressed %d/%d rows to achieve k=%d", len(suppressed_indices), len(data), k_val)
        return result

    async def report(self, data: list[dict[str, Any]], quasi_identifiers: list[str], k: int | None = None) -> AnonymizationReport:
        """Generate an anonymization report."""
        k_val = k or self._k
        original = len(data)
        anonymized = await self.anonymize(data, quasi_identifiers, k_val)
        return AnonymizationReport(
            original_rows=original,
            suppressed_rows=original - len(anonymized),
            generalized_columns=quasi_identifiers,
            k_value=k_val,
        )
