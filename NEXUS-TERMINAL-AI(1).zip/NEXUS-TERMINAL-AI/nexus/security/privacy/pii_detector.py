"""PII detector — identify personally identifiable information in text/data."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class PIISighting:
    """A detected PII occurrence."""
    type: str
    value: str
    start: int
    end: int
    confidence: float = 1.0


class PIIDetector:
    """Detects PII in text using regex patterns and heuristic checks."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._patterns: list[tuple[str, re.Pattern, float]] = []
        self._load_patterns()

    def _load_patterns(self) -> None:
        raw = [
            ("email", r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", 0.95),
            ("phone", r"\+?1?\d{1,4}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}", 0.85),
            ("ssn", r"\b\d{3}-\d{2}-\d{4}\b", 0.99),
            ("credit_card", r"\b(?:\d[ -]*?){13,16}\b", 0.9),
            ("ip_address", r"\b(?:\d{1,3}\.){3}\d{1,3}\b", 0.7),
            ("passport", r"\b[A-Z]{1,2}\d{6,9}\b", 0.8),
            ("driver_license", r"\b[A-Z]\d{3,8}\b", 0.6),
            ("zip_code", r"\b\d{5}(?:-\d{4})?\b", 0.5),
            ("date_of_birth", r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", 0.75),
            ("address", r"\d+\s+[A-Za-z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Court|Ct)", 0.6),
        ]
        for name, pattern_str, confidence in raw:
            try:
                self._patterns.append((name, re.compile(pattern_str), confidence))
            except re.error as exc:
                _log.warning("Invalid PII pattern %s: %s", name, exc)

    async def detect(self, text: str) -> list[PIISighting]:
        """Scan text for PII and return all sightings."""
        sightings: list[PIISighting] = []
        for name, pattern, confidence in self._patterns:
            for match in pattern.finditer(text):
                sightings.append(PIISighting(
                    type=name,
                    value=match.group(),
                    start=match.start(),
                    end=match.end(),
                    confidence=confidence,
                ))
        return sightings

    async def classify(self, text: str) -> dict[str, list[str]]:
        """Classify text by PII types found."""
        sightings = await self.detect(text)
        classified: dict[str, list[str]] = {}
        for s in sightings:
            classified.setdefault(s.type, []).append(s.value)
        return classified

    async def has_pii(self, text: str) -> bool:
        """Quick check if text contains any PII."""
        for _, pattern, _ in self._patterns:
            if pattern.search(text):
                return True
        return False

    async def redact(self, text: str) -> str:
        """Redact all detected PII from text."""
        result = text
        for name, pattern, _ in self._patterns:
            result = pattern.sub(f"[{name.upper()}]", result)
        return result
