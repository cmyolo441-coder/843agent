"""Rate limiting — token bucket and sliding window rate limiter."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class Bucket:
    """Token bucket instance for a key."""
    rate: float
    capacity: float
    tokens: float = 0.0
    last_refill: float = field(default_factory=time.monotonic)


class RateLimiter:
    """Multi-key rate limiter using token bucket algorithm."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._default_rate = self.config.get("default_rate", 10.0)
        self._default_capacity = self.config.get("default_capacity", 20)
        self._buckets: dict[str, Bucket] = {}
        self._lock = asyncio.Lock()
        self._worker_task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        self._worker_task = asyncio.create_task(self._maintenance_worker())
        _log.info("RateLimiter started")

    async def stop(self) -> None:
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass

    async def _maintenance_worker(self) -> None:
        while True:
            try:
                await asyncio.sleep(60)
                now = time.monotonic()
                async with self._lock:
                    stale = [k for k, b in self._buckets.items() if now - b.last_refill > 3600]
                    for k in stale:
                        del self._buckets[k]
            except asyncio.CancelledError:
                break
            except Exception as exc:
                _log.exception("Maintenance error: %s", exc)

    def _get_or_create(self, key: str) -> Bucket:
        if key not in self._buckets:
            limits = self.config.get("limits", {}).get(key.split(":")[0], {})
            self._buckets[key] = Bucket(
                rate=limits.get("rate", self._default_rate),
                capacity=limits.get("capacity", self._default_capacity),
            )
        return self._buckets[key]

    def _refill(self, bucket: Bucket) -> None:
        now = time.monotonic()
        elapsed = now - bucket.last_refill
        bucket.tokens = min(bucket.capacity, bucket.tokens + elapsed * bucket.rate)
        bucket.last_refill = now

    async def check(self, key: str, cost: int = 1) -> bool:
        """Check and consume tokens. Returns True if allowed."""
        async with self._lock:
            bucket = self._get_or_create(key)
            self._refill(bucket)
            if bucket.tokens >= cost:
                bucket.tokens -= cost
                return True
            _log.debug("Rate limit exceeded for %s", key)
            return False

    async def remaining(self, key: str) -> float:
        async with self._lock:
            bucket = self._get_or_create(key)
            self._refill(bucket)
            return bucket.tokens

    async def reset(self, key: str) -> None:
        async with self._lock:
            self._buckets.pop(key, None)

    def create_limit(self, name: str, rate: float, capacity: int) -> None:
        self.config.setdefault("limits", {})[name] = {"rate": rate, "capacity": capacity}
