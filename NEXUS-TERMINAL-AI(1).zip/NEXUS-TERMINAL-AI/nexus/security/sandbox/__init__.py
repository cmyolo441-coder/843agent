"""Sandbox subsystem — isolated execution environments.

Provides container, nsjail, firecracker, gvisor, wasm, chroot, seccomp sandbox
implementations with resource limiting, filesystem/network isolation, process
isolation, and timeout enforcement.
"""
from __future__ import annotations

from .sandbox_manager import SandboxManager
from .container_sandbox import ContainerSandbox
from .nsjail_sandbox import NSJailSandbox
from .firecracker_sandbox import FirecrackerSandbox
from .gvisor_sandbox import GVisorSandbox
from .wasm_sandbox import WasmSandbox
from .chroot_sandbox import ChrootSandbox
from .seccomp_sandbox import SeccompSandbox
from .resource_limiter import ResourceLimiter
from .filesystem_isolation import FilesystemIsolation
from .network_isolation import NetworkIsolation
from .process_isolation import ProcessIsolation
from .timeout_enforcer import TimeoutEnforcer

__all__ = [
    "SandboxManager",
    "ContainerSandbox",
    "NSJailSandbox",
    "FirecrackerSandbox",
    "GVisorSandbox",
    "WasmSandbox",
    "ChrootSandbox",
    "SeccompSandbox",
    "ResourceLimiter",
    "FilesystemIsolation",
    "NetworkIsolation",
    "ProcessIsolation",
    "TimeoutEnforcer",
]
