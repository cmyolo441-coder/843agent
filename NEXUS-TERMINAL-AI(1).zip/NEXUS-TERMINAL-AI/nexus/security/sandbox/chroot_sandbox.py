"""Chroot sandbox implementation — filesystem-level isolation."""
from __future__ import annotations

import asyncio
import logging
import os
import tempfile
from pathlib import Path
from typing import Any

from nexus.exceptions import SandboxError
from nexus.security.sandbox.sandbox_manager import SandboxBase, SandboxResult

_log = logging.getLogger(__name__)


class ChrootSandbox(SandboxBase):
    """Executes commands inside a chroot jail with minimal filesystem."""

    name = "chroot"

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._chroot_dir = Path(self.config.get("chroot_dir", "/var/empty"))
        self._copy_bins = self.config.get("copy_bins", ["/bin/sh", "/bin/ls", "/bin/cat", "/bin/echo"])

    async def execute(self, command: str, timeout_s: float = 30.0, env: dict[str, str] | None = None) -> SandboxResult:
        if not self._chroot_dir.exists():
            raise SandboxError(f"Chroot directory '{self._chroot_dir}' does not exist")
        env_vars = env or {}
        env_str = " ".join(f"{k}={v}" for k, v in env_vars.items())
        full_cmd = f"chroot {self._chroot_dir} /bin/sh -c '{env_str} {command}'"
        try:
            proc = await asyncio.create_subprocess_exec(
                "chroot", str(self._chroot_dir), "/bin/sh", "-c", f"{env_str} {command}",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
            return SandboxResult(
                success=proc.returncode == 0,
                output=stdout.decode().strip(),
                error=stderr.decode().strip(),
                exit_code=proc.returncode or 0,
            )
        except asyncio.TimeoutError:
            raise SandboxError(f"Chroot sandbox timed out after {timeout_s}s")

    def prepare_chroot(self) -> None:
        """Set up a minimal chroot directory tree."""
        self._chroot_dir.mkdir(parents=True, exist_ok=True)
        for d in ["bin", "lib", "lib64", "usr", "etc", "tmp", "dev"]:
            (self._chroot_dir / d).mkdir(exist_ok=True)
        for binary in self._copy_bins:
            target = Path(binary)
            if target.exists():
                dest = self._chroot_dir / target.relative_to("/")
                dest.parent.mkdir(parents=True, exist_ok=True)
                os.system(f"cp {target} {dest}")
                ldd_output = os.popen(f"ldd {target} 2>/dev/null | grep '=> /' | awk '{{print $3}}'").read()
                for lib in ldd_output.strip().split("\n"):
                    lib_path = Path(lib.strip())
                    if lib_path.exists():
                        lib_dest = self._chroot_dir / lib_path.relative_to("/")
                        lib_dest.parent.mkdir(parents=True, exist_ok=True)
                        os.system(f"cp {lib_path} {lib_dest}")

    async def check_health(self) -> bool:
        return self._chroot_dir.exists() and (self._chroot_dir / "bin").exists()
