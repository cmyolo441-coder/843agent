"""Docker/Podman container sandbox implementation."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from nexus.exceptions import SandboxError
from nexus.security.sandbox.sandbox_manager import SandboxBase, SandboxResult

_log = logging.getLogger(__name__)


class ContainerSandbox(SandboxBase):
    """Executes commands inside a container using Docker or Podman."""

    name = "container"

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._image = self.config.get("image", "alpine:latest")
        self._runtime = self.config.get("runtime", "docker")
        self._memory_limit = self.config.get("memory_limit", "256m")
        self._cpu_limit = self.config.get("cpu_limit", "0.5")
        self._network_disabled = self.config.get("network_disabled", True)
        self._container_name_prefix = self.config.get("container_prefix", "nexus-sandbox")

    async def execute(self, command: str, timeout_s: float = 30.0, env: dict[str, str] | None = None) -> SandboxResult:
        env_args = []
        if env:
            for k, v in env.items():
                env_args.extend(["-e", f"{k}={v}"])
        net = "--network=none" if self._network_disabled else ""
        container_name = f"{self._container_name_prefix}-{asyncio.get_running_loop().time():.0f}"
        cmd = [
            self._runtime, "run", "--rm", "--name", container_name,
            "-m", self._memory_limit, "--cpus", self._cpu_limit,
            net, *env_args, self._image, "sh", "-c", command,
        ]
        _log.debug("Container command: %s", " ".join(cmd))
        try:
            proc = await asyncio.create_subprocess_exec(
                *[c for c in cmd if c],
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
            return SandboxResult(
                success=proc.returncode == 0,
                output=stdout.decode().strip(),
                error=stderr.decode().strip(),
                exit_code=proc.returncode or 0,
            )
        except asyncio.TimeoutError:
            raise SandboxError(f"Container sandbox timed out after {timeout_s}s")
        except FileNotFoundError:
            raise SandboxError(f"Container runtime '{self._runtime}' not found")

    async def check_health(self) -> bool:
        try:
            proc = await asyncio.create_subprocess_exec(self._runtime, "info", stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            rc = await proc.wait()
            return rc == 0
        except FileNotFoundError:
            return False
