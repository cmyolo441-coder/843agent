"""Filesystem isolation — restricted views of the filesystem."""
from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)


class FilesystemIsolation:
    """Creates and manages restricted filesystem views for sandboxed processes."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._root = Path(self.config.get("root_dir", tempfile.mkdtemp(prefix="nexus-fs-")))
        self._read_only = self.config.get("read_only", True)
        self._allowed_paths = [Path(p) for p in self.config.get("allowed_paths", ["/tmp", "/dev/null"])]

    async def setup(self) -> Path:
        """Prepare the isolated filesystem."""
        self._root.mkdir(parents=True, exist_ok=True)
        for subdir in ["bin", "lib", "lib64", "usr", "tmp", "dev", "etc"]:
            (self._root / subdir).mkdir(exist_ok=True)
        if self._read_only:
            os.chmod(str(self._root), 0o555)
        _log.debug("Filesystem isolation root at %s", self._root)
        return self._root

    async def teardown(self) -> None:
        """Clean up the isolated filesystem."""
        import shutil
        if self._root.exists():
            shutil.rmtree(str(self._root), ignore_errors=True)
            _log.debug("Tore down filesystem isolation at %s", self._root)

    async def mount_path(self, source: Path, target: str | None = None) -> Path:
        """Bind-mount a path into the sandbox."""
        target_path = self._root / (target or source.relative_to("/") if source.is_absolute() else source.name)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.system(f"mount --bind {source} {target_path}")
            if self._read_only:
                os.system(f"mount -o remount,ro {target_path}")
            _log.debug("Mounted %s -> %s", source, target_path)
        except OSError as exc:
            _log.warning("Mount failed: %s", exc)
        return target_path

    def resolve_path(self, path: str) -> Path:
        """Resolve a sandbox-relative path, blocking escapes."""
        clean = Path(path).resolve()
        try:
            clean.relative_to(self._root)
        except ValueError:
            clean = self._root / clean.name
        return clean

    async def check_permission(self, path: str, mode: str = "r") -> bool:
        """Check if a path is accessible in the sandbox."""
        resolved = Path(path).resolve()
        if mode == "w" and self._read_only:
            return False
        ap = str(resolved)
        for allowed in self._allowed_paths:
            if ap.startswith(str(allowed)):
                return True
        return ap.startswith(str(self._root))
