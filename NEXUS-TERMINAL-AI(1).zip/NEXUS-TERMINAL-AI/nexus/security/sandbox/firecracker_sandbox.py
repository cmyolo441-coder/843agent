"""Firecracker microVM sandbox implementation."""
from __future__ import annotations

import asyncio
import json
import logging
import tempfile
from pathlib import Path
from typing import Any

from nexus.exceptions import SandboxError
from nexus.security.sandbox.sandbox_manager import SandboxBase, SandboxResult

_log = logging.getLogger(__name__)


class FirecrackerSandbox(SandboxBase):
    """Executes code inside a Firecracker microVM."""

    name = "firecracker"

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._fc_binary = self.config.get("fc_binary", "firecracker")
        self._kernel = self.config.get("kernel", "")
        self._rootfs = self.config.get("rootfs", "")
        self._vcpu_count = self.config.get("vcpu_count", 1)
        self._mem_size_mib = self.config.get("mem_size_mib", 256)

    async def execute(self, command: str, timeout_s: float = 30.0, env: dict[str, str] | None = None) -> SandboxResult:
        with tempfile.TemporaryDirectory() as tmpdir:
            config = {
                "boot-source": {"kernel_image_path": self._kernel, "boot_args": "console=ttyS0 reboot=k panic=1 pci=off"},
                "drives": [{"drive_id": "rootfs", "path_on_host": self._rootfs, "is_root_device": True, "is_read_only": False}],
                "machine-config": {"vcpu_count": self._vcpu_count, "mem_size_mib": self._mem_size_mib},
            }
            config_path = Path(tmpdir) / "vmconfig.json"
            config_path.write_text(json.dumps(config))

            proc = await asyncio.create_subprocess_exec(
                self._fc_binary, "--config-file", str(config_path),
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            try:
                _, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
                return SandboxResult(
                    success=proc.returncode == 0,
                    output="",
                    error=stderr.decode().strip(),
                    exit_code=proc.returncode or 0,
                )
            except asyncio.TimeoutError:
                proc.kill()
                raise SandboxError(f"Firecracker sandbox timed out after {timeout_s}s")

    async def check_health(self) -> bool:
        try:
            proc = await asyncio.create_subprocess_exec(self._fc_binary, "--help", stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            rc = await proc.wait()
            return rc == 0
        except FileNotFoundError:
            return False
