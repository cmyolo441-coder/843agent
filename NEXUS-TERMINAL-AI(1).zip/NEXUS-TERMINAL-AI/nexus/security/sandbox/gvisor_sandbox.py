"""gVisor sandbox implementation (runsc)."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from nexus.exceptions import SandboxError
from nexus.security.sandbox.sandbox_manager import SandboxBase, SandboxResult

_log = logging.getLogger(__name__)


class GVisorSandbox(SandboxBase):
    """Executes commands using gVisor's runsc runtime."""

    name = "gvisor"

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._runsc = self.config.get("runsc_binary", "runsc")
        self._root_dir = self.config.get("root_dir", "/tmp/runsc-root")

    async def execute(self, command: str, timeout_s: float = 30.0, env: dict[str, str] | None = None) -> SandboxResult:
        sandbox_name = f"nexus-{asyncio.get_running_loop().time():.0f}"

        create_cmd = [self._runsc, "--root", self._root_dir, "create", sandbox_name, "--", "/bin/sh"]
        _log.debug("gVisor create: %s", " ".join(create_cmd))
        try:
            proc = await asyncio.create_subprocess_exec(*create_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
        except FileNotFoundError:
            raise SandboxError(f"runsc binary '{self._runsc}' not found")

        exec_cmd = [self._runsc, "--root", self._root_dir, "exec", sandbox_name, "--", "/bin/sh", "-c", command]
        exec_proc = await asyncio.create_subprocess_exec(*exec_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            stdout, stderr = await asyncio.wait_for(exec_proc.communicate(), timeout=timeout_s)
        except asyncio.TimeoutError:
            delete_cmd = [self._runsc, "--root", self._root_dir, "delete", sandbox_name]
            await asyncio.create_subprocess_exec(*delete_cmd)
            raise SandboxError(f"gVisor sandbox timed out after {timeout_s}s")

        delete_cmd = [self._runsc, "--root", self._root_dir, "delete", sandbox_name]
        await asyncio.create_subprocess_exec(*delete_cmd)

        return SandboxResult(
            success=exec_proc.returncode == 0,
            output=stdout.decode().strip(),
            error=stderr.decode().strip(),
            exit_code=exec_proc.returncode or 0,
        )

    async def check_health(self) -> bool:
        try:
            proc = await asyncio.create_subprocess_exec(self._runsc, "--version", stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            rc = await proc.wait()
            return rc == 0
        except FileNotFoundError:
            return False
