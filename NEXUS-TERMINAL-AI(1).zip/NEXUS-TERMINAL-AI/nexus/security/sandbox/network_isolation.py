"""Network isolation — restrict or disable network access."""
from __future__ import annotations

import logging
import os
from typing import Any

_log = logging.getLogger(__name__)


class NetworkIsolation:
    """Restricts network access for sandboxed processes using iptables / nftables."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._enabled = self.config.get("enabled", True)
        self._allowed_hosts = self.config.get("allowed_hosts", [])
        self._allowed_ports = self.config.get("allowed_ports", [])
        self._interface = self.config.get("interface", "lo")
        self._chain_name = self.config.get("chain_name", "NEXUS_SANDBOX")
        self._isolated: set[int] = set()

    async def isolate(self, pid: int) -> None:
        """Isolate a process by PID using network namespaces."""
        if not self._enabled:
            return
        try:
            if os.name == "posix":
                ns_name = f"netns-{pid}"
                os.system(f"ip netns add {ns_name}")
                os.system(f"ip link set {self._interface} netns {ns_name}")
                self._isolated.add(pid)
                _log.debug("Isolated PID %d in netns %s", pid, ns_name)
        except OSError as exc:
            _log.warning("Network isolation failed for PID %d: %s", pid, exc)

    async def apply_rule(self, host: str, port: int, action: str = "DROP") -> None:
        """Apply iptables rule for allowed/denied hosts."""
        if not self._enabled:
            return
        target = "ACCEPT" if host in self._allowed_hosts else action
        cmd = f"iptables -A {self._chain_name} -d {host} -p tcp --dport {port} -j {target}"
        os.system(cmd)
        _log.debug("Applied network rule: %s", cmd)

    async def remove_all_rules(self) -> None:
        """Clear all sandbox network rules."""
        if not self._enabled:
            return
        try:
            os.system(f"iptables -F {self._chain_name}")
            os.system(f"iptables -X {self._chain_name}")
            _log.debug("Cleared network isolation rules")
        except OSError:
            pass

    async def allow_only(self, hosts: list[str], ports: list[int]) -> None:
        """Restrict network to specific host:port pairs only."""
        self._allowed_hosts = hosts
        self._allowed_ports = ports
        os.system(f"iptables -N {self._chain_name}")
        for port in ports:
            os.system(f"iptables -A {self._chain_name} -p tcp --dport {port} -j ACCEPT")
        os.system(f"iptables -A {self._chain_name} -j DROP")
        _log.debug("Set allow-only policy for %d hosts, %d ports", len(hosts), len(ports))
