"""NSJail sandbox implementation — Google's sandboxing tool."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from nexus.exceptions import SandboxError
from nexus.security.sandbox.sandbox_manager import SandboxBase, SandboxResult

_log = logging.getLogger(__name__)


class NSJailSandbox(SandboxBase):
    """Executes commands via NSJail for process-level sandboxing."""

    name = "nsjail"

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._binary = self.config.get("binary", "nsjail")
        self._chroot_dir = self.config.get("chroot_dir", "")
        self._max_cpus = self.config.get("max_cpus", 1)
        self._max_mem_mb = self.config.get("max_mem_mb", 128)
        self._time_limit_ms = self.config.get("time_limit_ms", 30000)
        self._disable_proc = self.config.get("disable_proc", True)

    async def execute(self, command: str, timeout_s: float = 30.0, env: dict[str, str] | None = None) -> SandboxResult:
        cmd = [self._binary, "--silent"]
        if self._chroot_dir:
            cmd.extend(["--chroot", self._chroot_dir])
        cmd.extend(["--max_cpus", str(self._max_cpus)])
        cmd.extend(["--max_mem_mb", str(self._max_mem_mb)])
        cmd.extend(["--time_limit", str(int(timeout_s * 1000))])
        if self._disable_proc:
            cmd.append("--disable_proc")
        if env:
            for k, v in env.items():
                cmd.extend(["--env", f"{k}={v}"])
        cmd.extend(["--", "/bin/sh", "-c", command])

        _log.debug("NSJail command: %s", " ".join(cmd))
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s + 5)
            return SandboxResult(
                success=proc.returncode == 0,
                output=stdout.decode().strip(),
                error=stderr.decode().strip(),
                exit_code=proc.returncode or 0,
            )
        except asyncio.TimeoutError:
            raise SandboxError(f"NSJail sandbox timed out after {timeout_s}s")
        except FileNotFoundError:
            raise SandboxError(f"NSJail binary '{self._binary}' not found")
