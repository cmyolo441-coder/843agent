"""Process isolation — PID namespace and cgroup management."""
from __future__ import annotations

import asyncio
import logging
import os
import signal
from typing import Any

_log = logging.getLogger(__name__)


class ProcessIsolation:
    """Manages process isolation via PID namespaces and cgroups."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._cgroup_base = self.config.get("cgroup_base", "/sys/fs/cgroup/nexus")
        self._tracked_pids: list[int] = []

    async def create_cgroup(self, name: str) -> str:
        """Create a cgroup v2 subtree for tracking processes."""
        cg_path = f"{self._cgroup_base}/{name}"
        try:
            os.makedirs(cg_path, exist_ok=True)
            _log.debug("Created cgroup: %s", cg_path)
        except PermissionError:
            _log.warning("Cannot create cgroup (not root): %s", cg_path)
        return cg_path

    async def add_process(self, pid: int, cgroup: str = "default") -> None:
        """Add a process to a cgroup for tracking."""
        cg_path = f"{self._cgroup_base}/{cgroup}"
        try:
            with open(f"{cg_path}/cgroup.procs", "a") as f:
                f.write(str(pid))
            self._tracked_pids.append(pid)
            _log.debug("Added PID %d to cgroup %s", pid, cgroup)
        except (PermissionError, FileNotFoundError) as exc:
            _log.warning("Could not add PID %d to cgroup: %s", pid, exc)

    async def kill_all(self, cgroup: str | None = None) -> int:
        """Kill all processes in a cgroup or all tracked processes."""
        killed = 0
        pids = list(self._tracked_pids)
        for pid in pids:
            try:
                os.kill(pid, signal.SIGKILL)
                killed += 1
            except ProcessLookupError:
                pass
        self._tracked_pids = [p for p in self._tracked_pids if p not in pids]
        _log.info("Killed %d processes in isolation", killed)
        return killed

    async def list_processes(self, cgroup: str = "default") -> list[int]:
        """List PIDs in a cgroup."""
        cg_path = f"{self._cgroup_base}/{cgroup}"
        try:
            with open(f"{cg_path}/cgroup.procs") as f:
                return [int(line.strip()) for line in f if line.strip()]
        except (PermissionError, FileNotFoundError):
            return [p for p in self._tracked_pids if os.path.exists(f"/proc/{p}")]

    async def get_stats(self, cgroup: str = "default") -> dict[str, Any]:
        """Get resource stats for a cgroup."""
        stats: dict[str, Any] = {}
        cg_path = f"{self._cgroup_base}/{cgroup}"
        try:
            with open(f"{cg_path}/cpu.stat") as f:
                for line in f:
                    k, v = line.strip().split(maxsplit=1)
                    stats[k] = int(v)
            with open(f"{cg_path}/memory.current") as f:
                stats["memory_current"] = int(f.read().strip())
        except (PermissionError, FileNotFoundError):
            pass
        return stats
