"""Resource limiter — CPU, memory, and disk limits for sandboxed execution."""
from __future__ import annotations

import asyncio
import logging
import os
import signal
from typing import Any

_log = logging.getLogger(__name__)


class ResourceLimiter:
    """Applies and enforces resource limits on subprocesses."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._max_cpu_time_s = self.config.get("max_cpu_time_s", 10)
        self._max_memory_mb = self.config.get("max_memory_mb", 256)
        self._max_processes = self.config.get("max_processes", 50)
        self._max_fds = self.config.get("max_fds", 128)
        self._max_disk_mb = self.config.get("max_disk_mb", 100)

    def apply(self, pid: int) -> None:
        """Apply resource limits to a running process."""
        try:
            if os.name == "posix":
                import resource
                resource.prlimit(pid, resource.RLIMIT_CPU, (self._max_cpu_time_s, self._max_cpu_time_s))
                mem_bytes = self._max_memory_mb * 1024 * 1024
                resource.prlimit(pid, resource.RLIMIT_AS, (mem_bytes, mem_bytes))
                resource.prlimit(pid, resource.RLIMIT_NPROC, (self._max_processes, self._max_processes))
                resource.prlimit(pid, resource.RLIMIT_NOFILE, (self._max_fds, self._max_fds))
                _log.debug("Applied resource limits to PID %d", pid)
        except (ImportError, OSError, ValueError) as exc:
            _log.warning("Could not apply resource limits to PID %d: %s", pid, exc)

    async def monitor(self, pid: int, timeout_s: float) -> bool:
        """Monitor a process and kill if it exceeds limits. Returns True if killed."""
        try:
            await asyncio.sleep(timeout_s)
            os.kill(pid, signal.SIGKILL)
            _log.warning("Killed PID %d for exceeding timeout", pid)
            return True
        except ProcessLookupError:
            return False

    def get_usage(self, pid: int) -> dict[str, float]:
        """Get current resource usage for a process."""
        usage: dict[str, float] = {}
        try:
            with open(f"/proc/{pid}/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        usage["memory_mb"] = int(line.split()[1]) / 1024
                    elif line.startswith("Threads:"):
                        usage["threads"] = int(line.split()[1])
            with open(f"/proc/{pid}/stat") as f:
                parts = f.read().split()
                if len(parts) > 13:
                    utime = float(parts[13]) / 100
                    stime = float(parts[14]) / 100
                    usage["cpu_time_s"] = utime + stime
        except (FileNotFoundError, IndexError, ValueError):
            pass
        return usage
