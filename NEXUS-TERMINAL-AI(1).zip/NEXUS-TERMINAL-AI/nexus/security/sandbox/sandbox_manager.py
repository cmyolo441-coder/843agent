"""Sandbox orchestrator — manages multiple sandbox implementations."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from nexus.exceptions import SandboxError

_log = logging.getLogger(__name__)


@dataclass
class SandboxResult:
    """Result of a sandbox execution."""
    success: bool
    output: str = ""
    error: str = ""
    exit_code: int = 0
    duration_ms: float = 0.0
    resource_usage: dict[str, Any] = field(default_factory=dict)


class SandboxBase:
    """Abstract base for all sandbox implementations."""
    name: str = "base"

    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    async def execute(self, command: str, timeout_s: float = 30.0, env: dict[str, str] | None = None) -> SandboxResult:
        raise NotImplementedError

    async def check_health(self) -> bool:
        return True


class SandboxManager:
    """Orchestrator that routes execution to the appropriate sandbox."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._sandboxes: dict[str, SandboxBase] = {}
        self._default = self.config.get("default_sandbox", "seccomp")

    def register(self, name: str, sandbox: SandboxBase) -> None:
        self._sandboxes[name] = sandbox
        _log.info("Registered sandbox: %s", name)

    async def execute(self, command: str, sandbox: str | None = None, **kwargs: Any) -> SandboxResult:
        sb_name = sandbox or self._default
        sb = self._sandboxes.get(sb_name)
        if sb is None:
            raise SandboxError(f"Sandbox '{sb_name}' not registered")
        _log.info("Executing via sandbox=%s: %.80s", sb_name, command)
        return await sb.execute(command, **kwargs)

    async def start_all(self) -> None:
        for name, sb in self._sandboxes.items():
            await sb.start()
            _log.info("Started sandbox: %s", name)

    async def stop_all(self) -> None:
        for name, sb in self._sandboxes.items():
            await sb.stop()
            _log.info("Stopped sandbox: %s", name)

    async def health_check(self) -> dict[str, bool]:
        return {name: await sb.check_health() for name, sb in self._sandboxes.items()}
