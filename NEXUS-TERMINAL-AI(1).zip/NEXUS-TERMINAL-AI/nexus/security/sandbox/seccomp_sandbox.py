"""Seccomp sandbox implementation — system call filtering."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from nexus.exceptions import SandboxError
from nexus.security.sandbox.sandbox_manager import SandboxBase, SandboxResult

_log = logging.getLogger(__name__)


class SeccompSandbox(SandboxBase):
    """Executes commands with seccomp syscall filtering (via minijail or pysandbox)."""

    name = "seccomp"

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._mode = self.config.get("mode", "minijail")
        self._policy = self.config.get("policy", "default")

    async def execute(self, command: str, timeout_s: float = 30.0, env: dict[str, str] | None = None) -> SandboxResult:
        cmd = self._build_command(command, env)
        _log.debug("Seccomp command: %s", " ".join(cmd))
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
            return SandboxResult(
                success=proc.returncode == 0,
                output=stdout.decode().strip(),
                error=stderr.decode().strip(),
                exit_code=proc.returncode or 0,
            )
        except asyncio.TimeoutError:
            raise SandboxError(f"Seccomp sandbox timed out after {timeout_s}s")
        except FileNotFoundError:
            raise SandboxError("Seccomp tool not found")

    def _build_command(self, command: str, env: dict[str, str] | None = None) -> list[str]:
        if self._mode == "minijail":
            cmd = ["minijail0", "-n", "-S", f"/etc/minijail/{self._policy}.policy", "--", "/bin/sh", "-c", command]
        elif self._mode == "bubblewrap":
            cmd = ["bwrap", "--ro-bind", "/", "/", "--proc", "/proc", "--dev", "/dev", "--unshare-all", "--", "/bin/sh", "-c", command]
        elif self._mode == "firejail":
            cmd = ["firejail", f"--seccomp={self._policy}", "--", "/bin/sh", "-c", command]
        else:
            cmd = ["minijail0", "-n", "--", "/bin/sh", "-c", command]
        if env:
            for k, v in env.items():
                cmd.insert(-1, "--env")
                cmd.insert(-1, f"{k}={v}")
        return cmd

    async def check_health(self) -> bool:
        tools = {"minijail": "minijail0", "bubblewrap": "bwrap", "firejail": "firejail"}
        tool = tools.get(self._mode, "minijail0")
        try:
            proc = await asyncio.create_subprocess_exec(tool, "--help", stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            rc = await proc.wait()
            return rc == 0
        except FileNotFoundError:
            return False
