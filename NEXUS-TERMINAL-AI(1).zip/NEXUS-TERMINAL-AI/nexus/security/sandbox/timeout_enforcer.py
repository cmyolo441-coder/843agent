"""Timeout enforcer — enforces wall-clock execution limits."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

_log = logging.getLogger(__name__)


class TimeoutEnforcer:
    """Enforces execution timeouts for sandboxed processes."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._default_timeout_s = self.config.get("default_timeout_s", 30)
        self._max_timeout_s = self.config.get("max_timeout_s", 300)
        self._running: dict[int, asyncio.Task[None]] = {}

    async def run_with_timeout(self, coro, timeout_s: float | None = None) -> Any:
        """Run an async callable with a timeout."""
        effective_timeout = min(timeout_s or self._default_timeout_s, self._max_timeout_s)
        try:
            result = await asyncio.wait_for(coro, timeout=effective_timeout)
            return result
        except asyncio.TimeoutError:
            _log.warning("Operation timed out after %.1fs", effective_timeout)
            raise

    def track(self, task_id: int, task: asyncio.Task[None]) -> None:
        self._running[task_id] = task

    async def cancel(self, task_id: int) -> bool:
        """Cancel a tracked task by ID."""
        task = self._running.get(task_id)
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            del self._running[task_id]
            return True
        return False

    async def cancel_all(self) -> int:
        count = 0
        for task_id in list(self._running.keys()):
            if await self.cancel(task_id):
                count += 1
        return count

    @property
    def active_count(self) -> int:
        return len(self._running)
