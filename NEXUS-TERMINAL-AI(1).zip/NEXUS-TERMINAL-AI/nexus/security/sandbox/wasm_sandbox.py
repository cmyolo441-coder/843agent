"""WebAssembly sandbox implementation."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from nexus.exceptions import SandboxError
from nexus.security.sandbox.sandbox_manager import SandboxBase, SandboxResult

_log = logging.getLogger(__name__)


class WasmSandbox(SandboxBase):
    """Executes WebAssembly modules using wasmtime/wasmer runtime."""

    name = "wasm"

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._runtime = self.config.get("runtime", "wasmtime")
        self._max_memory = self.config.get("max_memory", "1m")
        self._max_fuel = self.config.get("max_fuel", 100_000)

    async def execute(self, command: str, timeout_s: float = 30.0, env: dict[str, str] | None = None) -> SandboxResult:
        cmd = [self._runtime]
        if self._runtime == "wasmtime":
            cmd.extend(["--dir", ".", f"--max-memory={self._max_memory}", f"--fuel={self._max_fuel}", "run"])
        elif self._runtime == "wasmer":
            cmd.extend(["run"])
        cmd.extend(command.split())

        _log.debug("Wasm command: %s", " ".join(cmd))
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
            return SandboxResult(
                success=proc.returncode == 0,
                output=stdout.decode().strip(),
                error=stderr.decode().strip(),
                exit_code=proc.returncode or 0,
            )
        except asyncio.TimeoutError:
            raise SandboxError(f"Wasm sandbox timed out after {timeout_s}s")
        except FileNotFoundError:
            raise SandboxError(f"Wasm runtime '{self._runtime}' not found")

    async def check_health(self) -> bool:
        try:
            proc = await asyncio.create_subprocess_exec(self._runtime, "--version", stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            rc = await proc.wait()
            return rc == 0
        except FileNotFoundError:
            return False
