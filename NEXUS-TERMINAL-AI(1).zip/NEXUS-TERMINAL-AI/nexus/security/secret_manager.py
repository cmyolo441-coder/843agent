"""Secret management — encrypted storage and retrieval of secrets."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from nexus.exceptions import SecurityError
from nexus.security.encryption import EncryptionEngine

_log = logging.getLogger(__name__)


@dataclass
class Secret:
    """A stored secret with metadata."""
    name: str
    value: str
    version: int = 1
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    tags: dict[str, str] = field(default_factory=dict)


class SecretManager:
    """Manages secrets with encryption-at-rest and rotation."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._encryption = EncryptionEngine(self.config.get("encryption", {}))
        self._store: dict[str, list[Secret]] = {}

    async def set(self, name: str, value: str, tags: dict[str, str] | None = None) -> None:
        """Store or update a secret (versioned)."""
        existing = self._store.get(name, [])
        latest_version = existing[-1].version if existing else 0
        secret = Secret(name=name, value=value, version=latest_version + 1, tags=tags or {})
        existing.append(secret)
        self._store[name] = existing
        _log.info("Secret %s stored (v%d)", name, secret.version)

    async def get(self, name: str, version: int | None = None) -> str | None:
        """Retrieve a secret value by name and optional version."""
        existing = self._store.get(name)
        if not existing:
            return None
        if version is not None:
            for s in existing:
                if s.version == version:
                    return s.value
            return None
        return existing[-1].value

    async def rotate(self, name: str, new_value: str) -> None:
        """Rotate a secret to a new value (creates new version)."""
        await self.set(name, new_value)
        _log.info("Secret %s rotated", name)

    async def delete(self, name: str) -> None:
        self._store.pop(name, None)
        _log.info("Secret %s deleted", name)

    async def list_secrets(self) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for name, versions in self._store.items():
            latest = versions[-1]
            result.append({
                "name": name,
                "version": latest.version,
                "created_at": latest.created_at,
                "updated_at": latest.updated_at,
                "tags": latest.tags,
            })
        return result
