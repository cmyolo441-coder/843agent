"""Central security orchestrator — coordinates all security subsystems."""
from __future__ import annotations

import logging
from typing import Any

from nexus.exceptions import SecurityError
from nexus.security.access_control import AccessControlEngine
from nexus.security.auth_manager import AuthManager
from nexus.security.encryption import EncryptionEngine
from nexus.security.audit_logger import AuditLogger
from nexus.security.threat_detector import ThreatDetector
from nexus.security.input_validator import InputValidator
from nexus.security.output_filter import OutputFilter
from nexus.security.rate_limiter import RateLimiter
from nexus.security.session_manager import SessionManager
from nexus.security.permission_engine import PermissionEngine
from nexus.security.compliance_engine import ComplianceEngine
from nexus.security.zero_trust import ZeroTrustEngine
from nexus.singleton import SingletonMeta

_log = logging.getLogger(__name__)


class SecurityManager(metaclass=SingletonMeta):
    """Top-level orchestrator that wires up all security subsystems."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.auth = AuthManager(self.config.get("auth", {}))
        self.encryption = EncryptionEngine(self.config.get("encryption", {}))
        self.access_control = AccessControlEngine(self.config.get("access_control", {}))
        self.audit = AuditLogger(self.config.get("audit", {}))
        self.threat = ThreatDetector(self.config.get("threat_detector", {}))
        self.validator = InputValidator(self.config.get("input_validator", {}))
        self.filter = OutputFilter(self.config.get("output_filter", {}))
        self.rate_limiter = RateLimiter(self.config.get("rate_limiter", {}))
        self.sessions = SessionManager(self.config.get("sessions", {}))
        self.permissions = PermissionEngine(self.config.get("permissions", {}))
        self.compliance = ComplianceEngine(self.config.get("compliance", {}))
        self.zero_trust = ZeroTrustEngine(self.config.get("zero_trust", {}))
        _log.info("SecurityManager initialised")

    async def initialize(self) -> None:
        """Start all security subsystems."""
        await self.encryption.load_keys()
        await self.auth.load_providers()
        await self.access_control.load_policies()
        await self.rate_limiter.start()
        await self.sessions.start()
        await self.threat.start()
        await self.audit.start()
        _log.info("SecurityManager initialised all subsystems")

    async def shutdown(self) -> None:
        """Gracefully shut down all security subsystems."""
        await self.rate_limiter.stop()
        await self.sessions.stop()
        await self.threat.stop()
        await self.audit.stop()
        _log.info("SecurityManager shut down")

    async def authenticate(self, token: str, source_ip: str | None = None) -> dict[str, Any]:
        """Authenticate a token and return resolved identity."""
        identity = await self.auth.authenticate(token)
        await self.audit.log("authentication", identity.get("sub", "unknown"), source_ip=source_ip, success=True)
        return identity

    async def authorize(self, identity: dict[str, Any], action: str, resource: str) -> bool:
        """Check if identity is permitted to perform action on resource."""
        allowed = await self.access_control.check(identity, action, resource)
        await self.audit.log("authorization", identity.get("sub", "unknown"), action=action, resource=resource, allowed=allowed)
        return allowed

    async def validate_input(self, data: str, context: str = "default") -> str:
        """Validate and sanitize user input."""
        return await self.validator.sanitize(data, context)

    async def filter_output(self, data: str, level: str = "strict") -> str:
        """Strip sensitive data from outbound content."""
        return await self.filter.filter(data, level)

    async def check_rate_limit(self, key: str, cost: int = 1) -> bool:
        """Check if key has exceeded allowed rate."""
        return await self.rate_limiter.check(key, cost)

    async def check_compliance(self, data: dict[str, Any], context: str) -> list[str]:
        """Run data against compliance rules; return violations."""
        return await self.compliance.check(data, context)

    async def evaluate_trust(self, identity: dict[str, Any], context: dict[str, Any]) -> float:
        """Evaluate zero-trust score for a request context."""
        return await self.zero_trust.evaluate(identity, context)
