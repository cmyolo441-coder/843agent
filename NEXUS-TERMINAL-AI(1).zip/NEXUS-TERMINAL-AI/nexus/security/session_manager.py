"""Session management — create, validate, and expire user sessions."""
from __future__ import annotations

import asyncio
import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class Session:
    """A user session."""
    session_id: str
    user_id: str
    claims: dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)
    expires_at: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


class SessionManager:
    """Creates, validates, and expires sessions with async expiry sweep."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._sessions: dict[str, Session] = {}
        self._ttl_s = self.config.get("ttl_s", 3600)
        self._lock = asyncio.Lock()
        self._worker_task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        self._worker_task = asyncio.create_task(self._expiry_worker())
        _log.info("SessionManager started (TTL=%ds)", self._ttl_s)

    async def stop(self) -> None:
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass

    async def _expiry_worker(self) -> None:
        while True:
            try:
                await asyncio.sleep(30)
                now = time.time()
                async with self._lock:
                    expired = [sid for sid, s in self._sessions.items() if s.expires_at <= now]
                    for sid in expired:
                        del self._sessions[sid]
                    if expired:
                        _log.debug("Expired %d sessions", len(expired))
            except asyncio.CancelledError:
                break
            except Exception as exc:
                _log.exception("Expiry worker error: %s", exc)

    async def create(self, user_id: str, claims: dict[str, Any] | None = None, ttl_s: int | None = None) -> Session:
        sess = Session(
            session_id=secrets.token_hex(32),
            user_id=user_id,
            claims=claims or {},
            expires_at=time.time() + (ttl_s or self._ttl_s),
        )
        async with self._lock:
            self._sessions[sess.session_id] = sess
        _log.info("Session created for user=%s", user_id)
        return sess

    async def get(self, session_id: str) -> Session | None:
        async with self._lock:
            sess = self._sessions.get(session_id)
            if sess is None:
                return None
            if sess.expires_at <= time.time():
                del self._sessions[session_id]
                return None
            sess.last_active = time.time()
            return sess

    async def refresh(self, session_id: str, ttl_s: int | None = None) -> Session | None:
        async with self._lock:
            sess = self._sessions.get(session_id)
            if sess is None or sess.expires_at <= time.time():
                return None
            sess.expires_at = time.time() + (ttl_s or self._ttl_s)
            sess.last_active = time.time()
            return sess

    async def delete(self, session_id: str) -> None:
        async with self._lock:
            self._sessions.pop(session_id, None)

    async def get_user_sessions(self, user_id: str) -> list[Session]:
        async with self._lock:
            return [s for s in self._sessions.values() if s.user_id == user_id]

    async def invalidate_user(self, user_id: str) -> int:
        count = 0
        async with self._lock:
            to_remove = [sid for sid, s in self._sessions.items() if s.user_id == user_id]
            for sid in to_remove:
                del self._sessions[sid]
                count += 1
        return count
