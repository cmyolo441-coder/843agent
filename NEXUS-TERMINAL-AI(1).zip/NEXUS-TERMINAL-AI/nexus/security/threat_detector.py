"""Anomaly detection — identify suspicious request patterns."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class AnomalyEvent:
    """A detected anomaly."""
    rule: str
    subject: str
    score: float
    details: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class ThreatDetector:
    """Detects anomalous patterns using sliding window counters and scoring."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._threshold = self.config.get("threshold", 0.8)
        self._window_s = self.config.get("window_s", 60)
        self._counts: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
        self._anomalies: list[AnomalyEvent] = []
        self._rules: dict[str, dict[str, Any]] = {}
        self._worker_task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        self._rules = {
            "rapid_fire": {"field": "action", "max_per_window": 100, "weight": 0.6},
            "ip_spread": {"field": "source_ip", "max_actions_per_ip": 20, "weight": 0.4},
            "unusual_hours": {"field": "hour", "allowed_range": (6, 23), "weight": 0.3},
        }
        self._worker_task = asyncio.create_task(self._prune_worker())
        _log.info("ThreatDetector started")

    async def stop(self) -> None:
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass

    async def _prune_worker(self) -> None:
        while True:
            try:
                await asyncio.sleep(self._window_s)
                now = time.time()
                for dim in self._counts:
                    for key in list(self._counts[dim]):
                        self._counts[dim][key] = [t for t in self._counts[dim][key] if now - t < self._window_s]
                        if not self._counts[dim][key]:
                            del self._counts[dim][key]
            except asyncio.CancelledError:
                break
            except Exception as exc:
                _log.exception("Prune worker error: %s", exc)

    async def record(self, dimension: str, key: str) -> None:
        self._counts[dimension][key].append(time.time())

    async def evaluate(self, subject: str, attributes: dict[str, Any]) -> float:
        """Score a request. Returns 0.0 (safe) to 1.0 (suspicious)."""
        total_score = 0.0
        hits: list[str] = []

        action = attributes.get("action", "")
        ip = attributes.get("source_ip", "")
        hour = attributes.get("hour", 0)

        recent_actions = self._counts.get("action", {}).get(action, [])
        if len(recent_actions) > self._rules.get("rapid_fire", {}).get("max_per_window", 100):
            total_score += self._rules["rapid_fire"]["weight"]
            hits.append("rapid_fire")

        recent_ips = self._counts.get("source_ip", {}).get(ip, [])
        if len(recent_ips) > self._rules.get("ip_spread", {}).get("max_actions_per_ip", 20):
            total_score += self._rules["ip_spread"]["weight"]
            hits.append("ip_spread")

        allowed = self._rules.get("unusual_hours", {}).get("allowed_range", (6, 23))
        if not (allowed[0] <= hour <= allowed[1]):
            total_score += self._rules["unusual_hours"]["weight"]
            hits.append("unusual_hours")

        if total_score >= self._threshold:
            ev = AnomalyEvent(rule=",".join(hits), subject=subject, score=total_score, details=attributes)
            self._anomalies.append(ev)
            _log.warning("Anomaly detected: subject=%s score=%.2f rules=%s", subject, total_score, hits)

        return min(total_score, 1.0)

    async def get_recent_anomalies(self, limit: int = 20) -> list[AnomalyEvent]:
        return list(reversed(self._anomalies[-limit:]))
