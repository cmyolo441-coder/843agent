"""JWT token management — create, decode, revoke tokens."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any

from nexus.exceptions import SecurityError

try:
    import jwt as pyjwt
except ImportError:
    pyjwt = None  # type: ignore[assignment]

_log = logging.getLogger(__name__)


@dataclass
class TokenConfig:
    """Token configuration."""
    secret: str = "change-me"
    algorithm: str = "HS256"
    access_ttl_s: int = 3600
    refresh_ttl_s: int = 86400
    issuer: str = "nexus"


class TokenManager:
    """Issue, decode, and revoke JWT tokens."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._cfg = TokenConfig(**{k: v for k, v in self.config.items() if k in TokenConfig.__dataclass_fields__})  # type: ignore[attr-defined]
        self._revoked: set[str] = set()

    async def encode(self, payload: dict[str, Any], ttl_s: int | None = None) -> str:
        """Create a signed JWT from a claims dict."""
        if pyjwt is None:
            raise RuntimeError("PyJWT not installed — run `pip install pyjwt`")
        now = int(time.time())
        claims = {
            **payload,
            "iss": self._cfg.issuer,
            "iat": now,
            "exp": now + (ttl_s or self._cfg.access_ttl_s),
            "jti": f"nexus-{now}-{hash(str(payload)) & 0xFFFF}",
        }
        token = pyjwt.encode(claims, self._cfg.secret, algorithm=self._cfg.algorithm)
        _log.debug("Issued token for %s", payload.get("sub"))
        return token

    async def decode(self, token: str) -> dict[str, Any] | None:
        """Decode and verify a JWT. Returns claims or None."""
        if pyjwt is None:
            raise RuntimeError("PyJWT not installed")
        try:
            if token in self._revoked:
                _log.warning("Revoked token used")
                return None
            claims = pyjwt.decode(token, self._cfg.secret, algorithms=[self._cfg.algorithm], options={"require": ["exp", "iss"]})
            return claims  # type: ignore[return-value]
        except pyjwt.ExpiredSignatureError:
            _log.debug("Token expired")
            return None
        except pyjwt.InvalidTokenError as exc:
            _log.debug("Invalid token: %s", exc)
            return None

    async def revoke(self, token: str) -> None:
        claims = await self.decode(token)
        if claims:
            self._revoked.add(token)
            _log.info("Revoked token %s", claims.get("jti"))

    async def refresh(self, refresh_token: str) -> tuple[str, str] | None:
        """Exchange a refresh token for a new access + refresh pair."""
        claims = await self.decode(refresh_token)
        if not claims or claims.get("type") != "refresh":
            return None
        new_access = await self.encode({k: v for k, v in claims.items() if k in ("sub", "roles")})
        new_refresh = await self.encode(
            {**claims, "type": "refresh"},
            ttl_s=self._cfg.refresh_ttl_s,
        )
        return new_access, new_refresh
