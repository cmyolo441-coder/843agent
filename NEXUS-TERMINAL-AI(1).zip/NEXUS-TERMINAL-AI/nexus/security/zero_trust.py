"""Zero Trust Architecture — never trust, always verify."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger(__name__)


@dataclass
class TrustFactor:
    """A trust scoring factor with weight."""
    name: str
    weight: float
    score: float = 0.0


@dataclass
class TrustEvaluation:
    """Result of a trust evaluation."""
    identity: str
    score: float
    factors: list[TrustFactor] = field(default_factory=list)
    decision: str = "deny"
    timestamp: float = field(default_factory=time.time)


class ZeroTrustEngine:
    """Evaluates trust continuously for every request (never trust, always verify)."""

    MIN_TRUST_SCORE = 0.6

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._min_score = self.config.get("min_trust_score", self.MIN_TRUST_SCORE)

    async def evaluate(self, identity: dict[str, Any], context: dict[str, Any]) -> float:
        """Calculate a trust score for a request context. Returns 0.0–1.0."""
        factors = await self._score_factors(identity, context)
        total = sum(f.score * f.weight for f in factors)
        weight_sum = sum(f.weight for f in factors)
        score = total / weight_sum if weight_sum > 0 else 0.0
        score = max(0.0, min(1.0, score))
        _log.debug("Trust score for %s: %.2f", identity.get("sub", "unknown"), score)
        return score

    async def _score_factors(self, identity: dict[str, Any], context: dict[str, Any]) -> list[TrustFactor]:
        factors: list[TrustFactor] = []

        auth_strength = context.get("auth_type", "none")
        auth_scores = {"mfa": 1.0, "jwt": 0.8, "api_key": 0.6, "none": 0.1}
        factors.append(TrustFactor(name="auth_strength", weight=0.3, score=auth_scores.get(auth_strength, 0.1)))

        device_trusted = context.get("device_trusted", False)
        factors.append(TrustFactor(name="device_trust", weight=0.15, score=1.0 if device_trusted else 0.3))

        geo_allowed = context.get("geo_allowed", True)
        factors.append(TrustFactor(name="geo_location", weight=0.1, score=1.0 if geo_allowed else 0.2))

        recent_auth = context.get("last_authenticated", 0)
        if recent_auth and time.time() - recent_auth < 300:
            factors.append(TrustFactor(name="recent_auth", weight=0.15, score=1.0))
        else:
            factors.append(TrustFactor(name="recent_auth", weight=0.15, score=0.4))

        anomaly_score = context.get("anomaly_score", 0.0)
        factors.append(TrustFactor(name="anomaly", weight=0.2, score=1.0 - anomaly_score))

        ip_reputation = context.get("ip_reputation", 0.5)
        factors.append(TrustFactor(name="ip_reputation", weight=0.1, score=ip_reputation))

        return factors

    async def verify(self, identity: dict[str, Any], context: dict[str, Any]) -> TrustEvaluation:
        """Evaluate trust and return a decision."""
        score = await self.evaluate(identity, context)
        decision = "allow" if score >= self._min_score else "deny"
        if decision == "deny":
            _log.warning("Zero-trust denied for %s (score=%.2f)", identity.get("sub"), score)
        return TrustEvaluation(
            identity=identity.get("sub", "unknown"),
            score=score,
            decision=decision,
        )
