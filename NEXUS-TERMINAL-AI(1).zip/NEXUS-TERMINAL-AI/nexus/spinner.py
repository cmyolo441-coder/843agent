"""Terminal spinner with configurable frame sets."""
from __future__ import annotations

import asyncio
import sys
from typing import Sequence

DOTS: Sequence[str] = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")
LINE: Sequence[str] = ("|", "/", "-", "\\")
ARROW: Sequence[str] = ("←", "↖", "↑", "↗", "→", "↘", "↓", "↙")


class Spinner:
    """Async terminal spinner usable as an `async with` context manager."""

    def __init__(self, message: str = "working", frames: Sequence[str] = DOTS, interval: float = 0.08) -> None:
        self.message = message
        self.frames = frames
        self.interval = interval
        self._task: asyncio.Task[None] | None = None
        self._stop = asyncio.Event()

    async def __aenter__(self) -> "Spinner":
        self.start()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.stop()

    def start(self) -> None:
        self._stop.clear()
        self._task = asyncio.create_task(self._spin())

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            await self._task
        sys.stdout.write("\r\x1b[2K")
        sys.stdout.flush()

    async def _spin(self) -> None:
        i = 0
        while not self._stop.is_set():
            frame = self.frames[i % len(self.frames)]
            sys.stdout.write(f"\r{frame} {self.message}")
            sys.stdout.flush()
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=self.interval)
            except asyncio.TimeoutError:
                pass
            i += 1

    def set_message(self, msg: str) -> None:
        self.message = msg
