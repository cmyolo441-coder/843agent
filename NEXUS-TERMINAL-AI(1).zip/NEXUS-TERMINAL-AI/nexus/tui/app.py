"""Main TUI application class — event loop, lifecycle, and top-level orchestration."""
from __future__ import annotations

import asyncio
import logging
import signal
from typing import Any

from nexus.exceptions import NexusError, ShutdownError, StartupError
from nexus.registry import SERVICES
from nexus.tui.input_handler import InputHandler
from nexus.tui.layout import Layout
from nexus.tui.screen import ScreenManager
from nexus.tui.theme import ThemeManager

_log = logging.getLogger(__name__)


class AppError(NexusError):
    """Raised when the application encounters a fatal runtime error."""


class App:
    """Asyncio-based terminal application.

    Owns the screen manager, layout engine, theme manager, and input
    handler.  Call :meth:`run` to start the event loop.
    """

    def __init__(self, *, title: str = "NEXUS Terminal AI") -> None:
        self.title = title
        self.running = False
        self._loop: asyncio.AbstractEventLoop | None = None

        self.screens = ScreenManager(self)
        self.layout = Layout(self)
        self.themes = ThemeManager(self)
        self.input = InputHandler(self)

    async def startup(self) -> None:
        """Acquire resources, load theme, register core services."""
        _log.info("Starting %s", self.title)
        try:
            await self.themes.load_default()
            await self.screens.push("welcome")
            SERVICES.register("app", self, replace=True)
            _log.debug("Services registered, welcome screen active")
        except Exception as exc:
            raise StartupError(f"Failed to start {self.title}") from exc

    async def shutdown(self) -> None:
        """Release resources and stop all subsystems."""
        _log.info("Shutting down %s", self.title)
        self.running = False
        try:
            await self.screens.pop_all()
            SERVICES.unregister("app")
        except Exception as exc:
            raise ShutdownError("Error during shutdown") from exc

    async def run(self) -> None:
        """Main entry point — set up signal handlers, start event loop."""
        self.running = True
        self._loop = asyncio.get_running_loop()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                self._loop.add_signal_handler(sig, lambda: asyncio.ensure_future(self._handle_signal(sig)))
            except (NotImplementedError, ValueError):
                _log.warning("Signal handling not supported on this platform")

        try:
            await self.startup()
            while self.running:
                await self._tick()
        except asyncio.CancelledError:
            _log.debug("App run cancelled")
        except Exception as exc:
            _log.exception("Unhandled exception in main loop")
            raise AppError(str(exc)) from exc
        finally:
            await self.shutdown()

    async def _tick(self) -> None:
        """Process one iteration of the main loop."""
        await asyncio.sleep(0.05)
        screen = self.screens.current
        if screen is not None:
            await screen.refresh()

    async def _handle_signal(self, sig: signal.Signals) -> None:
        _log.info("Received signal %s, shutting down", sig.name)
        self.running = False

    async def refresh(self) -> None:
        """Request a full redraw from the active screen."""
        if self.screens.current is not None:
            await self.screens.current.refresh()

    async def notify(self, message: str, *, level: str = "info") -> None:
        """Dispatch a notification to the current screen."""
        if self.screens.current is not None:
            await self.screens.current.show_notification(message, level=level)

    def __repr__(self) -> str:
        return f"App({self.title!r}, running={self.running})"
