"""Command palette — fuzzy-searchable list of available commands."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


@dataclass
class Command:
    """A single command shown in the palette."""
    label: str
    shortcut: str = ""
    description: str = ""
    handler: Callable[[], Any] | None = None
    category: str = "General"


class CommandPalette:
    """Overlay that shows a filterable list of commands."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._commands: list[Command] = []
        self._filtered: list[Command] = field(default_factory=list)
        self.visible = False
        self._query = ""
        self._selected = 0

    def register(self, cmd: Command) -> None:
        self._commands.append(cmd)
        _log.debug("Registered command %r", cmd.label)

    async def toggle(self) -> None:
        self.visible = not self.visible
        if self.visible:
            self._query = ""
            self._filtered = list(self._commands)
            self._selected = 0
        _log.debug("Palette visibility: %s", self.visible)

    async def search(self, query: str) -> list[Command]:
        self._query = query
        q = query.lower()
        self._filtered = [c for c in self._commands if q in c.label.lower()]
        self._selected = 0
        return self._filtered

    async def select_next(self) -> None:
        if self._filtered:
            self._selected = (self._selected + 1) % len(self._filtered)

    async def select_prev(self) -> None:
        if self._filtered:
            self._selected = (self._selected - 1) % len(self._filtered)

    async def execute(self) -> bool:
        if not self._filtered:
            return False
        cmd = self._filtered[self._selected]
        if cmd.handler is not None:
            result = cmd.handler()
            if hasattr(result, "__await__"):
                await result
            self.visible = False
            return True
        return False

    async def render(self) -> str:
        if not self.visible:
            return ""
        lines = [f" Command Palette ({len(self._filtered)}/{len(self._commands)}) "]
        for i, cmd in enumerate(self._filtered[:20]):
            marker = "▸" if i == self._selected else " "
            lines.append(f" {marker} {cmd.label:<30} {cmd.shortcut}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"CommandPalette(visible={self.visible}, commands={len(self._commands)})"
