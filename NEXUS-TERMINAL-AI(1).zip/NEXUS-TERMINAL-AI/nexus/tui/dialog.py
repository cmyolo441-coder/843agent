"""Modal dialog system — confirm, prompt, alert with async user response."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class DialogResult(Enum):
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    CLOSED = "closed"


@dataclass
class Dialog:
    """A modal dialog with title, body, and buttons."""
    title: str = ""
    body: str = ""
    buttons: list[str] = field(default_factory=lambda: ["OK"])
    selected: int = 0
    result: DialogResult = DialogResult.CLOSED
    active: bool = False
    future: Any = None


class DialogManager:
    """Manages modal dialog lifecycle."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._dialog = Dialog()

    @property
    def active(self) -> bool:
        return self._dialog.active

    async def confirm(self, title: str, body: str) -> bool:
        """Show a confirm/cancel dialog. Returns True if confirmed."""
        self._dialog = Dialog(
            title=title, body=body, buttons=["Confirm", "Cancel"],
            selected=0, active=True,
        )
        _log.debug("Dialog confirm: %s", title)
        while self._dialog.active:
            await self.app._tick()
        return self._dialog.result == DialogResult.CONFIRMED

    async def alert(self, title: str, body: str) -> None:
        """Show an informational alert."""
        self._dialog = Dialog(
            title=title, body=body, buttons=["OK"],
            selected=0, active=True,
        )
        while self._dialog.active:
            await self.app._tick()

    async def prompt(self, title: str, body: str) -> str:
        """Show a prompt dialog. Returns the input string."""
        self._dialog = Dialog(
            title=title, body=body, buttons=["OK", "Cancel"],
            selected=0, active=True,
        )
        _log.debug("Dialog prompt: %s", title)
        while self._dialog.active:
            await self.app._tick()
        return self._dialog.body if self._dialog.result == DialogResult.CONFIRMED else ""

    async def select_next(self) -> None:
        if self._dialog.buttons:
            self._dialog.selected = (self._dialog.selected + 1) % len(self._dialog.buttons)

    async def select_prev(self) -> None:
        if self._dialog.buttons:
            self._dialog.selected = (self._dialog.selected - 1) % len(self._dialog.buttons)

    async def confirm_selected(self) -> None:
        if self._dialog.selected == 0:
            self._dialog.result = DialogResult.CONFIRMED
        else:
            self._dialog.result = DialogResult.CANCELLED
        self._dialog.active = False

    async def cancel(self) -> None:
        self._dialog.result = DialogResult.CANCELLED
        self._dialog.active = False

    async def render(self, width: int, height: int) -> str:
        if not self._dialog.active:
            return ""
        lines = [f"┌─ {self._dialog.title} {'─' * (width - len(self._dialog.title) - 5)}┐"]
        for line in self._dialog.body.split("\n"):
            lines.append(f"│ {line:<{width - 4}} │")
        lines.append(f"├{'─' * (width - 2)}┤")
        btn_line = "   ".join(
            f"[{b}]" if i == self._dialog.selected else f" {b} "
            for i, b in enumerate(self._dialog.buttons)
        )
        lines.append(f"│ {btn_line:<{width - 4}} │")
        lines.append(f"└{'─' * (width - 2)}┘")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"DialogManager(active={self._dialog.active})"
