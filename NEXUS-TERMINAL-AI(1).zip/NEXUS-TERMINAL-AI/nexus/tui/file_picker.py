"""File picker — interactive directory/file browser with filtering."""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


@dataclass
class FileEntry:
    """A single file or directory entry."""
    path: Path
    is_dir: bool = False
    selected: bool = False


class FilePicker:
    """Interactive file and directory selection widget."""

    def __init__(self, app: App, *, root: str | Path = ".", pattern: str = "*") -> None:
        self.app = app
        self._root = Path(root).resolve()
        self._pattern = pattern
        self._entries: list[FileEntry] = []
        self._selected = 0
        self._current_path: Path = self._root
        self.active = False
        self.result: Path | None = None

    async def open(self, path: str | Path | None = None) -> Path | None:
        """Open the picker and return the selected path."""
        self.active = True
        self.result = None
        self._selected = 0
        if path is not None:
            self._current_path = Path(path).resolve()
        await self._load_entries()
        _log.debug("File picker opened at %s", self._current_path)
        while self.active:
            await self.app._tick()
        return self.result

    async def _load_entries(self) -> None:
        self._entries = []
        try:
            if self._current_path != self._root:
                self._entries.append(FileEntry(path=self._current_path.parent, is_dir=True))
            for p in sorted(self._current_path.iterdir()):
                if p.name.startswith("."):
                    continue
                if p.is_dir():
                    self._entries.append(FileEntry(path=p, is_dir=True))
                elif p.match(self._pattern):
                    self._entries.append(FileEntry(path=p, is_dir=False))
        except PermissionError:
            _log.warning("Permission denied listing %s", self._current_path)

    async def navigate_down(self) -> None:
        if self._selected < len(self._entries) - 1:
            self._selected += 1

    async def navigate_up(self) -> None:
        if self._selected > 0:
            self._selected -= 1

    async def enter(self) -> None:
        if not self._entries:
            return
        entry = self._entries[self._selected]
        if entry.is_dir:
            self._current_path = entry.path
            self._selected = 0
            await self._load_entries()
        else:
            self.result = entry.path
            self.active = False

    async def go_up(self) -> None:
        if self._current_path.parent != self._current_path:
            self._current_path = self._current_path.parent
            self._selected = 0
            await self._load_entries()

    async def cancel(self) -> None:
        self.result = None
        self.active = False

    async def render(self, width: int, height: int) -> str:
        lines = [f" File: {self._current_path} "]
        lines.append("─" * width)
        for i, entry in enumerate(self._entries[:height - 3]):
            marker = "▸" if i == self._selected else " "
            icon = "📁" if entry.is_dir else "📄"
            name = entry.path.name
            if len(name) > width - 6:
                name = name[: width - 9] + "…"
            lines.append(f" {marker} {icon} {name}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"FilePicker(path={self._current_path}, active={self.active})"
