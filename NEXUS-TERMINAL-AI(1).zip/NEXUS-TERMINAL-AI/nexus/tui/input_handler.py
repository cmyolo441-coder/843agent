"""Keyboard and mouse input handler — key mapping, dispatch, and event capture."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable, Coroutine

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)

KeyHandler = Callable[[str], Coroutine[Any, Any, bool]]


class InputHandler:
    """Processes raw terminal input and dispatches to the active screen."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._bindings: dict[str, KeyHandler] = {}
        self._captured: list[str] = []

    async def process(self, key: str) -> bool:
        """Process a single key event. Returns True if consumed."""
        if self._captured and self._captured[-1] == key:
            self._captured.pop()
            handled = await self._dispatch(key)
            if not handled and self.app.screens.current is not None:
                handled = await self.app.screens.current.handle_input(key)
            return handled
        if self.app.screens.current is not None:
            handled = await self.app.screens.current.handle_input(key)
            if not handled:
                handled = await self._dispatch(key)
            return handled
        return await self._dispatch(key)

    async def _dispatch(self, key: str) -> bool:
        handler = self._bindings.get(key)
        if handler is not None:
            return await handler(key)
        return False

    def bind(self, key: str, handler: KeyHandler) -> None:
        """Bind a key sequence to an async handler."""
        self._bindings[key] = handler
        _log.debug("Bound key %r", key)

    def unbind(self, key: str) -> None:
        self._bindings.pop(key, None)

    async def capture(self, keys: list[str]) -> str:
        """Capture the next keypress matching one of *keys*."""
        self._captured = keys
        _log.debug("Capturing input from %r", keys)
        while self._captured:
            await self.app._tick()
        return ""

    async def handle_sequence(self, seq: str) -> bool:
        """Handle an escape sequence or multi-key sequence."""
        _log.debug("Handling sequence: %r", seq)
        return await self.process(seq)

    def __repr__(self) -> str:
        return f"InputHandler(bindings={len(self._bindings)})"
