"""Layout engine — region-based layout with horizontal/vertical splits."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from nexus.exceptions import NexusError

if TYPE_CHECKING:
    from nexus.tui.app import App
    from nexus.tui.screen import Screen

_log = logging.getLogger(__name__)


class LayoutError(NexusError):
    """Raised on invalid layout operations."""


@dataclass
class Region:
    """A rectangular region of the terminal."""
    x: int = 0
    y: int = 0
    width: int = 0
    height: int = 0
    children: list[Region] = field(default_factory=list)

    @property
    def area(self) -> int:
        return self.width * self.height


class Layout:
    """Engine that partitions terminal space into regions for each widget."""

    def __init__(self, app: App) -> None:
        self.app = app
        self.root: Region = Region()
        self._dirty = True

    async def set_root(self, width: int, height: int) -> None:
        """Set the full terminal dimensions and mark layout as dirty."""
        self.root = Region(x=0, y=0, width=width, height=height)
        self._dirty = True
        _log.debug("Layout root set to %dx%d", width, height)

    def split_horizontal(self, parent: Region, *ratios: float) -> list[Region]:
        """Split *parent* into horizontal slices by *ratios* (must sum to 1)."""
        if not ratios:
            raise LayoutError("At least one ratio required")
        total = sum(ratios)
        regions: list[Region] = []
        y = parent.y
        for r in ratios:
            h = max(1, int(parent.height * (r / total)))
            regions.append(Region(x=parent.x, y=y, width=parent.width, height=h))
            y += h
        parent.children = regions
        return regions

    def split_vertical(self, parent: Region, *ratios: float) -> list[Region]:
        """Split *parent* into vertical slices by *ratios*."""
        if not ratios:
            raise LayoutError("At least one ratio required")
        total = sum(ratios)
        regions: list[Region] = []
        x = parent.x
        for r in ratios:
            w = max(1, int(parent.width * (r / total)))
            regions.append(Region(x=x, y=parent.y, width=w, height=parent.height))
            x += w
        parent.children = regions
        return regions

    def region_for(self, screen: Screen, name: str) -> Region | None:
        """Retrieve a named region for a screen."""
        _log.debug("Region lookup for %s on %s", name, screen.name)
        return None

    async def calculate(self, screen: Screen) -> Region:
        """Compute the layout tree for the given screen."""
        if self._dirty:
            _log.debug("Calculating layout for %s", screen.name)
            self._dirty = False
        return self.root

    def mark_dirty(self) -> None:
        self._dirty = True

    def __repr__(self) -> str:
        return f"Layout(root={self.root!r})"
