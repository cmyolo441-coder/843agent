"""Notification system — transient toast messages with levels."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class NotificationLevel(Enum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    ERROR = "error"


@dataclass
class Notification:
    """A single notification message."""
    message: str
    level: NotificationLevel = NotificationLevel.INFO
    duration: float = 3.0
    _elapsed: float = 0.0


class NotificationManager:
    """Manages a queue of transient notifications."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._queue: list[Notification] = field(default_factory=list)
        self._active: Notification | None = None

    async def notify(self, message: str, *, level: str = "info", duration: float = 3.0) -> None:
        """Queue a new notification."""
        try:
            lvl = NotificationLevel(level)
        except ValueError:
            lvl = NotificationLevel.INFO
        notification = Notification(message=message, level=lvl, duration=duration)
        self._queue.append(notification)
        _log.debug("Notification queued: [%s] %s", level, message)

    async def tick(self, dt: float) -> None:
        """Advance notification lifecycle by *dt* seconds."""
        if self._active is not None:
            self._active._elapsed += dt
            if self._active._elapsed >= self._active.duration:
                self._active = None
        if self._active is None and self._queue:
            self._active = self._queue.pop(0)
            self._active._elapsed = 0.0

    async def render(self, width: int) -> str:
        """Render the active notification as a single line."""
        if self._active is None:
            return ""
        msg = f" {self._active.level.value.upper()} {self._active.message} "
        return msg[:width]

    def __repr__(self) -> str:
        return f"NotificationManager(active={self._active is not None}, queued={len(self._queue)})"
