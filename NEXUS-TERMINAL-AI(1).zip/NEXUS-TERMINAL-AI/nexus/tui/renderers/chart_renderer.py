"""Chart renderer — generates ASCII bar and line charts from numeric data."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.theme import Theme

_log = logging.getLogger(__name__)


class ChartRenderer:
    """Renders numeric data series as terminal-based bar or line charts."""

    def __init__(self, theme: Theme) -> None:
        self.theme = theme

    async def render_bar(
        self,
        labels: list[str],
        values: list[float],
        width: int = 80,
        height: int = 12,
    ) -> str:
        if not values:
            return "  (no data)"
        lines: list[str] = []
        max_val = max(values) or 1
        plot_h = height - 2
        for row in range(plot_h, 0, -1):
            threshold = max_val * row / plot_h
            bar = ""
            for v in values:
                bar += "█" if v >= threshold else " "
            y_label = f"{max_val * row / plot_h:>4.0f}"
            lines.append(f" {y_label} ┤{bar}")
        lines.append("       " + "─" * len(values))
        return "\n".join(lines)

    async def render_line(
        self,
        data: list[float],
        width: int = 80,
        height: int = 12,
    ) -> str:
        if not data:
            return "  (no data)"
        lines: list[str] = []
        min_val = min(data)
        max_val = max(data)
        range_val = max_val - min_val or 1
        plot_h = height - 2
        for row in range(plot_h, 0, -1):
            threshold = min_val + range_val * (row - 1) / plot_h
            line = ""
            for v in data:
                line += "•" if v >= threshold else " "
            y_label = f"{min_val + range_val * (row - 1) / plot_h:>4.0f}"
            lines.append(f" {y_label} ┤{line}")
        lines.append("       " + "─" * len(data))
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"ChartRenderer(theme={self.theme.name!r})"
