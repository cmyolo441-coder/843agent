"""Code renderer — syntax-highlighted code output with line numbers."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.theme import Theme

_log = logging.getLogger(__name__)

_KEYWORDS = frozenset({
    "def", "class", "if", "else", "elif", "for", "while", "return",
    "import", "from", "as", "try", "except", "finally", "with",
    "async", "await", "yield", "lambda", "pass", "break", "continue",
    "and", "or", "not", "in", "is", "None", "True", "False", "raise",
})


class CodeRenderer:
    """Transforms source code into terminal output with syntax highlighting."""

    def __init__(self, theme: Theme) -> None:
        self.theme = theme
        self._show_line_numbers = True

    async def render(self, source: str, language: str = "", width: int = 80) -> str:
        lines: list[str] = []
        pad = len(str(len(source.split("\n"))))
        for i, raw_line in enumerate(source.split("\n"), start=1):
            line = raw_line[: width - pad - 3]
            highlighted = self._highlight(line)
            if self._show_line_numbers:
                lines.append(f" {i:>{pad}} │ {highlighted}")
            else:
                lines.append(f"   {highlighted}")
        return "\n".join(lines)

    def _highlight(self, line: str) -> str:
        tokens: list[str] = []
        for word in re_split_words(line):
            tokens.append(word)
        return "".join(tokens)

    def __repr__(self) -> str:
        return f"CodeRenderer(theme={self.theme.name!r})"


import re


def re_split_words(text: str) -> list[str]:
    """Split text into words and non-word tokens for highlighting."""
    return re.findall(r"\w+|[^\w]+", text)
