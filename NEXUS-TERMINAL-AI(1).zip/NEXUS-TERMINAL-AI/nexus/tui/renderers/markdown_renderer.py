"""Markdown renderer — converts markdown AST to styled terminal output."""
from __future__ import annotations

import logging
import re
from typing import Any

from nexus.tui.theme import Style, Theme

_log = logging.getLogger(__name__)


class MarkdownRenderer:
    """Transforms markdown source into terminal-formatted text using a theme."""

    def __init__(self, theme: Theme) -> None:
        self.theme = theme

    async def render(self, source: str, width: int) -> str:
        """Render markdown *source* to a string of at most *width* columns."""
        lines: list[str] = []
        in_code = False
        in_list = False
        for raw in source.split("\n"):
            line = raw[:width]
            if line.startswith("```"):
                in_code = not in_code
                lines.append(f" {'─' * (width - 2)}")
                continue
            if in_code:
                lines.append(self._render_code_line(line))
                continue
            if line.startswith("# "):
                lines.append(self._render_heading(line[2:], 1))
            elif line.startswith("## "):
                lines.append(self._render_heading(line[3:], 2))
            elif line.startswith("### "):
                lines.append(self._render_heading(line[4:], 3))
            elif line.startswith("- ") or line.startswith("* "):
                lines.append(self._render_list_item(line[2:]))
                in_list = True
            elif line.strip() == "":
                if in_list:
                    in_list = False
                lines.append("")
            else:
                lines.append(self._render_paragraph(line))
        return "\n".join(lines)

    def _render_heading(self, text: str, level: int) -> str:
        prefix = "━" * level
        return f" [{prefix}] {text} "

    def _render_code_line(self, line: str) -> str:
        return f" │ {line}"

    def _render_list_item(self, text: str) -> str:
        return f" • {text}"

    def _render_paragraph(self, text: str) -> str:
        return f"  {text}"

    def __repr__(self) -> str:
        return f"MarkdownRenderer(theme={self.theme.name!r})"
