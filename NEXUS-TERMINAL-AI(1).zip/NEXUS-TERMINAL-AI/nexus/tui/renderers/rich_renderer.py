"""Rich renderer — composite rendering with panels, rules, and spacing."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.theme import Theme

_log = logging.getLogger(__name__)


class RichRenderer:
    """Rich text renderer — panels, horizontal rules, indentation, and layout boxes."""

    def __init__(self, theme: Theme) -> None:
        self.theme = theme

    async def panel(self, content: str, title: str = "", width: int = 80) -> str:
        """Wrap *content* in a bordered panel with optional *title*."""
        lines: list[str] = []
        inner = width - 4
        title_str = f" {title} " if title else ""
        lines.append(f"┌─{title_str}{'─' * (inner - len(title_str) - 1)}┐")
        for line in content.split("\n"):
            lines.append(f"│ {line[:inner]:<{inner}} │")
        lines.append(f"└{'─' * (width - 2)}┘")
        return "\n".join(lines)

    async def rule(self, char: str = "─", width: int = 80, title: str = "") -> str:
        """Render a horizontal rule, optionally with a centered *title*."""
        if title:
            side = (width - len(title) - 2) // 2
            return f"{char * side} {title} {char * side}"
        return char * width

    async def indent(self, text: str, level: int = 1, width: int = 80) -> str:
        """Indent every line of *text* by *level* spaces."""
        prefix = "  " * level
        return "\n".join(f"{prefix}{line[:width - len(prefix)]}" for line in text.split("\n"))

    async def tree(self, items: list[tuple[str, list[str]]], width: int = 80) -> str:
        """Render a simple indented tree structure."""
        lines: list[str] = []
        for label, children in items:
            lines.append(f" ▶ {label[:width - 4]}")
            for child in children:
                lines.append(f"   • {child[:width - 6]}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"RichRenderer(theme={self.theme.name!r})"
