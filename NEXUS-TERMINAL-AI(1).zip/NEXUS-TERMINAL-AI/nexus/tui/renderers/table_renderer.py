"""Table renderer — converts structured row/column data to a formatted table."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.theme import Theme

_log = logging.getLogger(__name__)


class TableRenderer:
    """Renders structured data as a bordered, column-aligned table."""

    def __init__(self, theme: Theme) -> None:
        self.theme = theme
        self._border_style: str = "rounded"

    async def render(
        self,
        headers: list[str],
        rows: list[list[str]],
        width: int = 80,
    ) -> str:
        if not headers:
            return ""
        col_count = len(headers)
        col_width = max(8, (width - col_count - 1) // col_count)
        lines: list[str] = []
        hdr = "│".join(f" {h:<{col_width}} " for h in headers)
        lines.append(f"┌{'─' * (col_width + 2)}" + f"┬{'─' * (col_width + 2)}" * (col_count - 1) + "┐")
        lines.append(f"│{hdr}│")
        lines.append(f"├{'─' * (col_width + 2)}" + f"┼{'─' * (col_width + 2)}" * (col_count - 1) + "┤")
        for row in rows[:max(1, (width - 4) // max(1, col_width))]:
            cells = "│".join(f" {c[:col_width]:<{col_width}} " for c in row[:col_count])
            lines.append(f"│{cells}│")
        lines.append(f"└{'─' * (col_width + 2)}" + f"┴{'─' * (col_width + 2)}" * (col_count - 1) + "┘")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"TableRenderer(theme={self.theme.name!r})"
