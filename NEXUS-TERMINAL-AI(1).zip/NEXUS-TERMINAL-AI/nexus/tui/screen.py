"""Screen manager — push/pop lifecycle with async rendering."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from nexus.exceptions import NexusError

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class ScreenError(NexusError):
    """Raised on invalid screen operations."""


class Screen:
    """Base class for every screen in the application.

    Subclasses override :meth:`render`, :meth:`handle_input`, and
    lifecycle hooks.
    """

    def __init__(self, app: App, name: str = "") -> None:
        self.app = app
        self.name = name or type(self).__name__
        self.active = False

    async def on_enter(self) -> None:
        """Called when the screen becomes active."""
        self.active = True
        _log.debug("Screen %s entered", self.name)

    async def on_exit(self) -> None:
        """Called when the screen is popped or replaced."""
        self.active = False
        _log.debug("Screen %s exited", self.name)

    async def render(self) -> str:
        """Return the rendered string representation of this screen."""
        return ""

    async def refresh(self) -> None:
        """Trigger a full re-render."""
        _log.debug("Refreshing screen %s", self.name)

    async def handle_input(self, key: str) -> bool:
        """Process a key event. Return True if handled."""
        return False

    async def show_notification(self, message: str, *, level: str = "info") -> None:
        """Display a transient notification on this screen."""
        _log.debug("Notification on %s: [%s] %s", self.name, level, message)

    async def handle_resize(self, width: int, height: int) -> None:
        """React to terminal resize events."""


class ScreenManager:
    """Stack-based screen manager — push, pop, and replace screens."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._stack: list[Screen] = []

    @property
    def current(self) -> Screen | None:
        return self._stack[-1] if self._stack else None

    async def push(self, screen: str | Screen, **kwargs: Any) -> Screen:
        """Push a screen onto the stack and activate it."""
        if isinstance(screen, str):
            screen = self._resolve(screen, **kwargs)
        if self._stack:
            await self._stack[-1].on_exit()
        self._stack.append(screen)
        await screen.on_enter()
        return screen

    async def pop(self) -> Screen | None:
        """Pop the top screen and resume the previous one."""
        if not self._stack:
            return None
        top = self._stack.pop()
        await top.on_exit()
        if self._stack:
            await self._stack[-1].on_enter()
        return top

    async def pop_all(self) -> None:
        """Pop every screen."""
        while self._stack:
            await self.pop()

    async def replace(self, screen: str | Screen, **kwargs: Any) -> Screen:
        """Replace the top screen without changing stack depth."""
        if isinstance(screen, str):
            screen = self._resolve(screen, **kwargs)
        if self._stack:
            await self._stack[-1].on_exit()
            self._stack[-1] = screen
        else:
            self._stack.append(screen)
        await screen.on_enter()
        return screen

    def _resolve(self, name: str, **kwargs: Any) -> Screen:
        _log.debug("Resolving screen %r with kwargs %s", name, kwargs)
        raise ScreenError(f"Unknown screen: {name!r}")

    def __len__(self) -> int:
        return len(self._stack)

    def __repr__(self) -> str:
        return f"ScreenManager(stack={[s.name for s in self._stack]})"
