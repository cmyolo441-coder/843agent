"""TUI screen implementations — each screen maps to a distinct application view."""
from __future__ import annotations

from nexus.tui.screens.chat_screen import ChatScreen
from nexus.tui.screens.agent_screen import AgentScreen
from nexus.tui.screens.tool_screen import ToolScreen
from nexus.tui.screens.memory_screen import MemoryScreen
from nexus.tui.screens.config_screen import ConfigScreen
from nexus.tui.screens.plugin_screen import PluginScreen
from nexus.tui.screens.workflow_screen import WorkflowScreen
from nexus.tui.screens.monitor_screen import MonitorScreen
from nexus.tui.screens.knowledge_screen import KnowledgeScreen
from nexus.tui.screens.history_screen import HistoryScreen
from nexus.tui.screens.log_screen import LogScreen
from nexus.tui.screens.welcome_screen import WelcomeScreen

__all__ = [
    "ChatScreen",
    "AgentScreen",
    "ToolScreen",
    "MemoryScreen",
    "ConfigScreen",
    "PluginScreen",
    "WorkflowScreen",
    "MonitorScreen",
    "KnowledgeScreen",
    "HistoryScreen",
    "LogScreen",
    "WelcomeScreen",
]
