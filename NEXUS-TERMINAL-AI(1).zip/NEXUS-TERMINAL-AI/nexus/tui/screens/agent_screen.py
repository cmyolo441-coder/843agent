"""Agent screen — view, create, and manage AI agents."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class AgentScreen(Screen):
    """Screen for browsing and configuring agents."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="agent")
        self._agents: list[dict[str, str]] = []
        self._selected = 0

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Agents", "BROWSE")
        self._agents = [
            {"name": "Coordinator", "status": "idle", "model": "claude-opus-4"},
            {"name": "Planner", "status": "idle", "model": "claude-sonnet-4"},
            {"name": "Executor", "status": "running", "model": "claude-haiku-3"},
        ]
        _log.info("Agent screen activated (%d agents)", len(self._agents))

    async def render(self) -> str:
        lines = [f" {'─' * 40} Agents {'─' * 40}", ""]
        for i, agent in enumerate(self._agents):
            marker = "▸" if i == self._selected else " "
            lines.append(
                f" {marker} {agent['name']:<20} {agent['status']:<10} {agent['model']}"
            )
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "up":
            self._selected = max(0, self._selected - 1)
            return True
        if key == "down":
            self._selected = min(len(self._agents) - 1, self._selected + 1)
            return True
        if key == "enter" and self._agents:
            _log.info("Selected agent %r", self._agents[self._selected]["name"])
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
