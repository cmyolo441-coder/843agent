"""Chat screen — interactive conversation with agents."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class ChatScreen(Screen):
    """Screen for interactive chat with LLM agents."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="chat")
        self._messages: list[dict[str, str]] = []
        self._input_buffer = ""
        self._cursor_pos = 0

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Chat", "NORMAL")
        _log.info("Chat screen activated")

    async def render(self) -> str:
        lines = [f" {'─' * 40} Chat {'─' * 40}", ""]
        for msg in self._messages[-20:]:
            role = msg.get("role", "?").upper()
            content = msg.get("content", "")
            for line in content.split("\n"):
                lines.append(f" [{role}] {line}")
        lines.append("")
        lines.append(f" > {self._input_buffer}")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "enter":
            if self._input_buffer.strip():
                self._messages.append({"role": "user", "content": self._input_buffer})
                _log.debug("User message queued (%d chars)", len(self._input_buffer))
                self._input_buffer = ""
                self._cursor_pos = 0
            return True
        if key == "backspace":
            if self._cursor_pos > 0:
                self._input_buffer = (
                    self._input_buffer[: self._cursor_pos - 1]
                    + self._input_buffer[self._cursor_pos :]
                )
                self._cursor_pos -= 1
            return True
        if len(key) == 1:
            self._input_buffer = (
                self._input_buffer[: self._cursor_pos]
                + key
                + self._input_buffer[self._cursor_pos :]
            )
            self._cursor_pos += 1
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
