"""Config screen — view and modify application settings."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class ConfigScreen(Screen):
    """Screen for editing application configuration."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="config")
        self._settings: list[dict[str, str]] = []
        self._selected = 0
        self._editing = False

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Config", "BROWSE")
        self._settings = [
            {"key": "default_model", "value": "claude-opus-4-8", "type": "str"},
            {"key": "temperature", "value": "0.7", "type": "float"},
            {"key": "max_tokens", "value": "4096", "type": "int"},
            {"key": "theme", "value": "dark", "type": "str"},
            {"key": "log_level", "value": "INFO", "type": "str"},
        ]
        _log.info("Config screen activated (%d settings)", len(self._settings))

    async def render(self) -> str:
        lines = [f" {'─' * 40} Configuration {'─' * 40}", ""]
        for i, setting in enumerate(self._settings):
            marker = "▸" if i == self._selected else " "
            lines.append(f" {marker} {setting['key']:<25} = {setting['value']}")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "up":
            self._selected = max(0, self._selected - 1)
            return True
        if key == "down":
            self._selected = min(len(self._settings) - 1, self._selected + 1)
            return True
        if key == "enter" and self._settings:
            self._editing = True
            _log.info("Editing setting %r", self._settings[self._selected]["key"])
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
