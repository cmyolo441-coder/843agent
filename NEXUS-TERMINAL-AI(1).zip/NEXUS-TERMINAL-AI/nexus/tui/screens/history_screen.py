"""History screen — recent session history and command log."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class HistoryScreen(Screen):
    """Screen for reviewing session history and past commands."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="history")
        self._entries: list[str] = []
        self._offset = 0

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("History", "VIEW")
        self._entries = [
            "[10:30:01] User: list files in current directory",
            "[10:30:05] Agent: running ls -la ...",
            "[10:30:08] Tool: python_executor completed",
            "[10:31:15] User: search for plugin docs",
            "[10:31:20] Agent: found 3 relevant documents",
        ]
        _log.info("History screen activated (%d entries)", len(self._entries))

    async def render(self) -> str:
        lines = [f" {'─' * 40} History {'─' * 40}", ""]
        for entry in self._entries[self._offset : self._offset + 15]:
            lines.append(f"  {entry}")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "up":
            self._offset = max(0, self._offset - 1)
            return True
        if key == "down":
            self._offset = min(len(self._entries) - 1, self._offset + 1)
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
