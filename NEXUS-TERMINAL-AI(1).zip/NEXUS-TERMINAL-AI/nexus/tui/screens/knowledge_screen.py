"""Knowledge screen — browse, search, and manage the knowledge base."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class KnowledgeScreen(Screen):
    """Screen for exploring the knowledge base and RAG collections."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="knowledge")
        self._documents: list[dict[str, str]] = []
        self._selected = 0

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Knowledge", "BROWSE")
        self._documents = [
            {"title": "NEXUS Architecture", "source": "docs", "chunks": "12"},
            {"title": "Agent Protocol", "source": "spec", "chunks": "8"},
            {"title": "Plugin Development", "source": "guide", "chunks": "15"},
        ]
        _log.info("Knowledge screen activated (%d docs)", len(self._documents))

    async def render(self) -> str:
        lines = [f" {'─' * 40} Knowledge Base {'─' * 40}", ""]
        for i, doc in enumerate(self._documents):
            marker = "▸" if i == self._selected else " "
            lines.append(f" {marker} {doc['title']:<30} {doc['source']:<8} {doc['chunks']} chunks")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "up":
            self._selected = max(0, self._selected - 1)
            return True
        if key == "down":
            self._selected = min(len(self._documents) - 1, self._selected + 1)
            return True
        if key == "enter" and self._documents:
            _log.info("Selected document %r", self._documents[self._selected]["title"])
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
