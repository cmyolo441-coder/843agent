"""Log screen — real-time application log viewer with filtering."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class LogScreen(Screen):
    """Screen for viewing and filtering application logs."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="log")
        self._logs: list[str] = []
        self._filter = ""
        self._follow = True

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Logs", "LIVE", f"filter={self._filter or '*'}")
        self._logs = [
            "INFO  app             Starting NEXUS Terminal AI",
            "DEBUG layout          Layout root set to 120x40",
            "INFO  screen          Welcome screen activated",
            "WARNING rate_limiter  Approaching rate limit (85/100)",
            "INFO  memory          Loaded 3 episodic memories",
        ]
        _log.info("Log screen activated")

    async def render(self) -> str:
        lines = [f" {'─' * 40} Application Logs {'─' * 40}", ""]
        filtered = [l for l in self._logs if self._filter.lower() in l.lower()] if self._filter else self._logs
        for entry in filtered[-20:]:
            lines.append(f"  {entry}")
        lines.append("")
        lines.append(f"  [F]ilter: {self._filter or '*'}  {'FOLLOW' if self._follow else 'PAUSED'}")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "f":
            self._follow = not self._follow
            self.app.status_bar.set_left("Logs", "LIVE" if self._follow else "PAUSED")
            return True
        if key == "/":
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
