"""Memory screen — browse and search agent memory stores."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class MemoryScreen(Screen):
    """Screen for inspecting and searching memory backends."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="memory")
        self._entries: list[dict[str, str]] = []
        self._selected = 0
        self._search_query = ""

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Memory", "BROWSE")
        self._entries = [
            {"key": "session_001", "kind": "episodic", "summary": "Previous conversation"},
            {"key": "user_prefs", "kind": "semantic", "summary": "User preferences"},
            {"key": "tool_patterns", "kind": "procedural", "summary": "Common tool usage"},
        ]
        _log.info("Memory screen activated (%d entries)", len(self._entries))

    async def render(self) -> str:
        lines = [f" {'─' * 40} Memory {'─' * 40}", ""]
        if self._search_query:
            lines.append(f" Search: {self._search_query}")
            lines.append("")
        for i, entry in enumerate(self._entries):
            marker = "▸" if i == self._selected else " "
            lines.append(f" {marker} {entry['key']:<20} {entry['kind']:<12} {entry['summary']}")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "up":
            self._selected = max(0, self._selected - 1)
            return True
        if key == "down":
            self._selected = min(len(self._entries) - 1, self._selected + 1)
            return True
        if key == "enter" and self._entries:
            _log.info("Selected memory %r", self._entries[self._selected]["key"])
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
