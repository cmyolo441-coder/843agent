"""Monitor screen — real-time system metrics dashboard."""
from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class MonitorScreen(Screen):
    """Screen for monitoring system resources and performance metrics."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="monitor")
        self._metrics: dict[str, float] = {}
        self._start_time = time.monotonic()

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Monitor", "LIVE")
        _log.info("Monitor screen activated")

    async def render(self) -> str:
        uptime = time.monotonic() - self._start_time
        lines = [f" {'─' * 40} System Monitor {'─' * 40}", ""]
        lines.append(f"  Uptime:       {uptime:.1f}s")
        lines.append(f"  CPU:          {self._metrics.get('cpu', 0):.1f}%")
        lines.append(f"  Memory:       {self._metrics.get('memory', 0):.1f}%")
        lines.append(f"  Active Tasks: {self._metrics.get('tasks', 0):.0f}")
        lines.append(f"  Queue Depth:  {self._metrics.get('queue', 0):.0f}")
        lines.append(f"  Rate:         {self._metrics.get('rate', 0):.1f} req/s")
        return "\n".join(lines)

    async def update_metrics(self, metrics: dict[str, float]) -> None:
        self._metrics.update(metrics)

    async def handle_input(self, key: str) -> bool:
        if key == "r":
            self._start_time = time.monotonic()
            self._metrics.clear()
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
