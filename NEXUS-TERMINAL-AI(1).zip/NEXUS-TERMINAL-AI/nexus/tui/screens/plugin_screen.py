"""Plugin screen — manage installed and available plugins."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class PluginScreen(Screen):
    """Screen for browsing, installing, and removing plugins."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="plugin")
        self._plugins: list[dict[str, str]] = []
        self._selected = 0

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Plugins", "BROWSE")
        self._plugins = [
            {"name": "web_scraper", "version": "1.2.0", "status": "active"},
            {"name": "code_formatter", "version": "0.9.1", "status": "active"},
            {"name": "data_visualizer", "version": "0.5.0", "status": "inactive"},
        ]
        _log.info("Plugin screen activated (%d plugins)", len(self._plugins))

    async def render(self) -> str:
        lines = [f" {'─' * 40} Plugins {'─' * 40}", ""]
        for i, plugin in enumerate(self._plugins):
            marker = "▸" if i == self._selected else " "
            lines.append(f" {marker} {plugin['name']:<25} v{plugin['version']:<8} {plugin['status']}")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "up":
            self._selected = max(0, self._selected - 1)
            return True
        if key == "down":
            self._selected = min(len(self._plugins) - 1, self._selected + 1)
            return True
        if key == "enter" and self._plugins:
            _log.info("Selected plugin %r", self._plugins[self._selected]["name"])
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
