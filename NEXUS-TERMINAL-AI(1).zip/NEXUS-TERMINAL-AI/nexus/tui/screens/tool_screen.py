"""Tool screen — browse, execute, and monitor available tools."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class ToolScreen(Screen):
    """Screen for tool execution and monitoring."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="tool")
        self._tools: list[dict[str, str]] = []
        self._selected = 0

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Tools", "BROWSE")
        self._tools = [
            {"name": "python_executor", "category": "code", "status": "ready"},
            {"name": "web_search", "category": "web", "status": "ready"},
            {"name": "file_read", "category": "file", "status": "ready"},
            {"name": "file_write", "category": "file", "status": "ready"},
            {"name": "git_tool", "category": "system", "status": "ready"},
        ]
        _log.info("Tool screen activated (%d tools)", len(self._tools))

    async def render(self) -> str:
        lines = [f" {'─' * 40} Tools {'─' * 40}", ""]
        for i, tool in enumerate(self._tools):
            marker = "▸" if i == self._selected else " "
            lines.append(f" {marker} {tool['name']:<25} {tool['category']:<10} {tool['status']}")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "up":
            self._selected = max(0, self._selected - 1)
            return True
        if key == "down":
            self._selected = min(len(self._tools) - 1, self._selected + 1)
            return True
        if key == "enter" and self._tools:
            _log.info("Selected tool %r", self._tools[self._selected]["name"])
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
