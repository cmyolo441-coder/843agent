"""Welcome screen — landing screen with quick actions and system status."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class WelcomeScreen(Screen):
    """Landing screen shown on application startup."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="welcome")
        self._version = "0.1.0"
        self._status: dict[str, str] = {}

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Welcome", "NORMAL")
        self._status = {
            "System": "✓ Online",
            "Agents": "3 available",
            "Memory": "✓ Initialized",
            "Plugins": "5 loaded",
        }
        _log.info("Welcome screen activated — system status: %s", self._status)

    async def render(self) -> str:
        lines = [
            "",
            f"  ╔═══╗ ╔═╗ ╔═╗ ╔═══╗ ╔═══╗ ╔═══╗",
            f"  ╚═╗ ║ ║ ║ ║ ║ ╚═╗ ║ ║ ╔═╝ ║ ╔═╝",
            f"    ║ ║ ║ ║ ║ ║   ║ ║ ║ ╚═╗ ║ ╚═╗",
            f"    ║ ║ ║ ║ ║ ║   ║ ║ ╚═╗ ║ ╚═╗ ║",
            f"    ║ ║ ║ ╚═╝ ║   ║ ║ ╔═╝ ║ ╔═╝ ║",
            f"    ╚═╝ ╚═══╝ ╚═╝ ╚═══╝ ╚═══╝",
            f"         Terminal AI  v{self._version}",
            "",
            f"  {'─' * 44}",
            "",
        ]
        for label, value in self._status.items():
            lines.append(f"    {label:<12} {value}")
        lines += [
            "",
            f"  {'─' * 44}",
            "",
            "  Press any key to continue, or ? for help",
            "",
        ]
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "?":
            return True
        _log.debug("Welcome screen dismissed via key %r", key)
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
