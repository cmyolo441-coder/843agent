"""Workflow screen — design, edit, and run multi-step workflows."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus.tui.screen import Screen

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class WorkflowScreen(Screen):
    """Screen for creating and managing automated workflows."""

    def __init__(self, app: App) -> None:
        super().__init__(app, name="workflow")
        self._workflows: list[dict[str, str]] = []
        self._selected = 0

    async def on_enter(self) -> None:
        await super().on_enter()
        self.app.status_bar.set_left("Workflows", "BROWSE")
        self._workflows = [
            {"name": "Daily Report", "steps": "5", "status": "ready"},
            {"name": "Code Review", "steps": "3", "status": "running"},
            {"name": "Data Pipeline", "steps": "8", "status": "draft"},
        ]
        _log.info("Workflow screen activated (%d workflows)", len(self._workflows))

    async def render(self) -> str:
        lines = [f" {'─' * 40} Workflows {'─' * 40}", ""]
        for i, wf in enumerate(self._workflows):
            marker = "▸" if i == self._selected else " "
            lines.append(f" {marker} {wf['name']:<25} {wf['steps']} steps  {wf['status']}")
        return "\n".join(lines)

    async def handle_input(self, key: str) -> bool:
        if key == "up":
            self._selected = max(0, self._selected - 1)
            return True
        if key == "down":
            self._selected = min(len(self._workflows) - 1, self._selected + 1)
            return True
        if key == "enter" and self._workflows:
            _log.info("Selected workflow %r", self._workflows[self._selected]["name"])
            return True
        return False

    async def handle_resize(self, width: int, height: int) -> None:
        await self.app.layout.set_root(width, height)
