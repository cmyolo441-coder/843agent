"""Sidebar navigation — screen list, quick switching, and status indicators."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


@staticmethod
def _noop() -> None:
    return None


class Sidebar:
    """Collapsible sidebar with screen navigation entries."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._entries: list[dict[str, Any]] = []
        self._selected = 0
        self.collapsed = False
        self._build_default_entries()

    def _build_default_entries(self) -> None:
        default_screens = [
            ("chat", "💬 Chat", "Chat with agents"),
            ("agent", "🤖 Agents", "Manage agents"),
            ("tool", "🔧 Tools", "Tool execution"),
            ("memory", "🧠 Memory", "Memory browser"),
            ("config", "⚙ Config", "Settings"),
            ("plugin", "🔌 Plugins", "Plugin manager"),
            ("workflow", "📋 Workflows", "Workflow editor"),
            ("monitor", "📊 Monitor", "System monitor"),
            ("knowledge", "📚 Knowledge", "Knowledge base"),
            ("history", "📜 History", "Session history"),
            ("log", "📝 Logs", "Application logs"),
        ]
        self._entries = [
            {"id": sid, "label": label, "description": desc, "handler": _noop}
            for sid, label, desc in default_screens
        ]

    async def navigate_to(self, name: str) -> None:
        _log.debug("Navigating to screen %r", name)
        for i, entry in enumerate(self._entries):
            if entry["id"] == name:
                self._selected = i
                break

    async def select_next(self) -> None:
        self._selected = (self._selected + 1) % len(self._entries)

    async def select_prev(self) -> None:
        self._selected = (self._selected - 1) % len(self._entries)

    async def activate(self) -> str | None:
        entry = self._entries[self._selected]
        _log.info("Activating sidebar entry %r", entry["id"])
        return entry["id"]

    async def render(self, width: int) -> str:
        if self.collapsed:
            return "  ☰"
        lines = [f"{'─' * width}", ""]
        for i, entry in enumerate(self._entries):
            marker = "▸" if i == self._selected else " "
            label = entry["label"]
            if len(label) > width - 4:
                label = label[: width - 7] + "…"
            lines.append(f" {marker} {label}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"Sidebar(collapsed={self.collapsed}, entries={len(self._entries)})"
