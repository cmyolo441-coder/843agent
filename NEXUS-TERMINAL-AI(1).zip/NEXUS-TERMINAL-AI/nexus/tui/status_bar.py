"""Status bar — bottom bar showing context, mode, and key hints."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class StatusBar:
    """Fixed bottom bar with app status, mode indicator, and key bindings."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._left: list[str] = []
        self._right: list[str] = []
        self.mode: str = "NORMAL"

    def set_left(self, *items: str) -> None:
        self._left = list(items)

    def set_right(self, *items: str) -> None:
        self._right = list(items)

    async def update_mode(self, mode: str) -> None:
        self.mode = mode
        _log.debug("Status bar mode set to %r", mode)

    async def render(self, width: int) -> str:
        """Render the status bar as a single line of *width* characters."""
        left = f" {self.mode} "
        for item in self._left:
            left += f" | {item}"
        right = " | ".join(self._right)
        padding = width - len(left) - len(right) - 2
        if padding < 1:
            left = left[: width - len(right) - 3] + "…"
            padding = 1
        return f"{left}{' ' * padding} {right} "

    def __repr__(self) -> str:
        return f"StatusBar(mode={self.mode!r})"
