"""Theme engine — colour scheme, style tokens, and theme management."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


@dataclass
class Style:
    """A named set of style attributes."""
    fg: str = "default"
    bg: str = "default"
    bold: bool = False
    italic: bool = False
    underline: bool = False
    blink: bool = False


@dataclass
class Theme:
    """Complete theme definition — palette of named styles."""
    name: str = "default"
    styles: dict[str, Style] = field(default_factory=dict)
    foreground: str = "#ffffff"
    background: str = "#000000"
    accent: str = "#00aaff"
    error: str = "#ff3333"
    success: str = "#33ff33"
    warning: str = "#ffaa00"

    def style(self, name: str) -> Style:
        return self.styles.get(name, Style())

    def merge(self, other: Theme) -> Theme:
        merged = Theme(name=f"{self.name}+{other.name}", styles={**self.styles})
        for k, v in other.styles.items():
            merged.styles[k] = v
        return merged


class ThemeManager:
    """Manages the active theme and available theme registry."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._themes: dict[str, Theme] = {}
        self._active: Theme = Theme()

    @property
    def active(self) -> Theme:
        return self._active

    async def load_default(self) -> None:
        """Load the built-in dark theme as the default."""
        _log.info("Loading default theme")
        self._active = Theme(name="dark")

    async def load(self, name: str) -> Theme:
        """Load a theme by name and activate it."""
        theme = self._themes.get(name)
        if theme is None:
            _log.warning("Unknown theme %r, keeping current", name)
            return self._active
        self._active = theme
        _log.info("Activated theme %r", name)
        return theme

    def register(self, name: str, theme: Theme) -> None:
        self._themes[name] = theme
        _log.debug("Registered theme %r", name)

    def available(self) -> list[str]:
        return list(self._themes)

    def style(self, name: str) -> Style:
        return self._active.style(name)
