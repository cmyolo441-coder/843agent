"""Built-in theme definitions — each file defines a colour palette."""
from __future__ import annotations

from nexus.tui.themes.dark_theme import DarkTheme
from nexus.tui.themes.light_theme import LightTheme
from nexus.tui.themes.monokai_theme import MonokaiTheme
from nexus.tui.themes.dracula_theme import DraculaTheme
from nexus.tui.themes.nord_theme import NordTheme
from nexus.tui.themes.solarized_theme import SolarizedTheme
from nexus.tui.themes.cyberpunk_theme import CyberpunkTheme

__all__ = [
    "DarkTheme",
    "LightTheme",
    "MonokaiTheme",
    "DraculaTheme",
    "NordTheme",
    "SolarizedTheme",
    "CyberpunkTheme",
]
