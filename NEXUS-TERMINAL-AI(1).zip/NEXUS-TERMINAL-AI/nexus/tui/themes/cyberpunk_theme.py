"""Cyberpunk theme — neon colours on a dark, futuristic background."""
from __future__ import annotations

from nexus.tui.theme import Style, Theme


def CyberpunkTheme() -> Theme:
    """Build and return the Cyberpunk theme.

    A high-energy theme with neon pink, cyan, and yellow on a
    very dark background, inspired by cyberpunk aesthetics.
    """
    t = Theme(
        name="cyberpunk",
        foreground="#00ff41",
        background="#0d0208",
        accent="#00ff41",
        error="#ff0040",
        success="#00ff41",
        warning="#ffb000",
        styles={
            "default": Style(fg="#00ff41", bg="#0d0208"),
            "keyword": Style(fg="#ff00ff"),
            "string": Style(fg="#ffb000"),
            "number": Style(fg="#00ffff"),
            "comment": Style(fg="#008f11"),
            "heading": Style(fg="#ff00ff", bold=True),
            "status": Style(fg="#00ff41", bg="#003b00"),
            "error": Style(fg="#ff0040"),
            "success": Style(fg="#00ff41"),
            "warning": Style(fg="#ffb000"),
            "info": Style(fg="#00ffff"),
            "selected": Style(fg="#0d0208", bg="#00ff41"),
            "border": Style(fg="#008f11"),
        },
    )
    return t
