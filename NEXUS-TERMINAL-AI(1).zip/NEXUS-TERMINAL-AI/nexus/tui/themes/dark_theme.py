"""Dark theme — default dark background colour scheme."""
from __future__ import annotations

from nexus.tui.theme import Style, Theme


def DarkTheme() -> Theme:
    """Build and return the default dark theme.

    Uses a near-black background with soft blue accents and a
    high-contrast foreground for readability.
    """
    t = Theme(
        name="dark",
        foreground="#d4d4d4",
        background="#1e1e1e",
        accent="#569cd6",
        error="#f44747",
        success="#4ec9b0",
        warning="#dcdcaa",
        styles={
            "default": Style(fg="#d4d4d4", bg="#1e1e1e"),
            "keyword": Style(fg="#569cd6"),
            "string": Style(fg="#ce9178"),
            "number": Style(fg="#b5cea8"),
            "comment": Style(fg="#6a9955"),
            "heading": Style(fg="#569cd6", bold=True),
            "status": Style(fg="#d4d4d4", bg="#333333"),
            "error": Style(fg="#f44747"),
            "success": Style(fg="#4ec9b0"),
            "warning": Style(fg="#dcdcaa"),
            "info": Style(fg="#569cd6"),
            "selected": Style(fg="#1e1e1e", bg="#569cd6"),
            "border": Style(fg="#444444"),
        },
    )
    return t
