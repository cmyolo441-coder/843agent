"""Dracula theme — dark theme with purple-pink accents."""
from __future__ import annotations

from nexus.tui.theme import Style, Theme


def DraculaTheme() -> Theme:
    """Build and return the Dracula colour scheme.

    A popular dark theme featuring a purple-ish background with
    pink, green, and cyan accents.
    """
    t = Theme(
        name="dracula",
        foreground="#f8f8f2",
        background="#282a36",
        accent="#bd93f9",
        error="#ff5555",
        success="#50fa7b",
        warning="#f1fa8c",
        styles={
            "default": Style(fg="#f8f8f2", bg="#282a36"),
            "keyword": Style(fg="#ff79c6"),
            "string": Style(fg="#f1fa8c"),
            "number": Style(fg="#bd93f9"),
            "comment": Style(fg="#6272a4"),
            "heading": Style(fg="#ff79c6", bold=True),
            "status": Style(fg="#f8f8f2", bg="#44475a"),
            "error": Style(fg="#ff5555"),
            "success": Style(fg="#50fa7b"),
            "warning": Style(fg="#f1fa8c"),
            "info": Style(fg="#8be9fd"),
            "selected": Style(fg="#282a36", bg="#bd93f9"),
            "border": Style(fg="#6272a4"),
        },
    )
    return t
