"""Light theme — bright background with dark text for daytime use."""
from __future__ import annotations

from nexus.tui.theme import Style, Theme


def LightTheme() -> Theme:
    """Build and return the light theme.

    Uses a white/cream background with dark charcoal text and
    muted accent colours.
    """
    t = Theme(
        name="light",
        foreground="#1e1e1e",
        background="#f5f5f5",
        accent="#2b5797",
        error="#d32f2f",
        success="#388e3c",
        warning="#f57c00",
        styles={
            "default": Style(fg="#1e1e1e", bg="#f5f5f5"),
            "keyword": Style(fg="#2b5797"),
            "string": Style(fg="#a31515"),
            "number": Style(fg="#098658"),
            "comment": Style(fg="#008000"),
            "heading": Style(fg="#2b5797", bold=True),
            "status": Style(fg="#1e1e1e", bg="#e0e0e0"),
            "error": Style(fg="#d32f2f"),
            "success": Style(fg="#388e3c"),
            "warning": Style(fg="#f57c00"),
            "info": Style(fg="#2b5797"),
            "selected": Style(fg="#ffffff", bg="#2b5797"),
            "border": Style(fg="#cccccc"),
        },
    )
    return t
