"""Monokai theme — vibrant colour scheme inspired by Sublime Text."""
from __future__ import annotations

from nexus.tui.theme import Style, Theme


def MonokaiTheme() -> Theme:
    """Build and return the Monokai-inspired theme.

    Deep charcoal background with bright, saturated accent colours
    originally made popular by the Sublime Text editor.
    """
    t = Theme(
        name="monokai",
        foreground="#f8f8f2",
        background="#272822",
        accent="#a6e22e",
        error="#f92672",
        success="#a6e22e",
        warning="#e6db74",
        styles={
            "default": Style(fg="#f8f8f2", bg="#272822"),
            "keyword": Style(fg="#f92672"),
            "string": Style(fg="#e6db74"),
            "number": Style(fg="#ae81ff"),
            "comment": Style(fg="#75715e"),
            "heading": Style(fg="#a6e22e", bold=True),
            "status": Style(fg="#f8f8f2", bg="#3e3d32"),
            "error": Style(fg="#f92672"),
            "success": Style(fg="#a6e22e"),
            "warning": Style(fg="#e6db74"),
            "info": Style(fg="#66d9ef"),
            "selected": Style(fg="#272822", bg="#a6e22e"),
            "border": Style(fg="#75715e"),
        },
    )
    return t
