"""Nord theme — arctic, bluish colour scheme inspired by north."""
from __future__ import annotations

from nexus.tui.theme import Style, Theme


def NordTheme() -> Theme:
    """Build and return the Nord theme.

    A clean, arctic-inspired colour palette with cool blue-grey
    tones and restrained accent colours.
    """
    t = Theme(
        name="nord",
        foreground="#d8dee9",
        background="#2e3440",
        accent="#88c0d0",
        error="#bf616a",
        success="#a3be8c",
        warning="#ebcb8b",
        styles={
            "default": Style(fg="#d8dee9", bg="#2e3440"),
            "keyword": Style(fg="#81a1c1"),
            "string": Style(fg="#a3be8c"),
            "number": Style(fg="#b48ead"),
            "comment": Style(fg="#616e88"),
            "heading": Style(fg="#88c0d0", bold=True),
            "status": Style(fg="#d8dee9", bg="#3b4252"),
            "error": Style(fg="#bf616a"),
            "success": Style(fg="#a3be8c"),
            "warning": Style(fg="#ebcb8b"),
            "info": Style(fg="#81a1c1"),
            "selected": Style(fg="#2e3440", bg="#88c0d0"),
            "border": Style(fg="#4c566a"),
        },
    )
    return t
