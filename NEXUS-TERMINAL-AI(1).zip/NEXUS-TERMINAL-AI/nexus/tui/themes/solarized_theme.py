"""Solarized theme — carefully designed 16-colour palette (dark variant)."""
from __future__ import annotations

from nexus.tui.theme import Style, Theme


def SolarizedTheme() -> Theme:
    """Build and return the Solarized dark theme.

    Uses the precise Solarized colour palette with both base and
    accent colours configured for low eye strain.
    """
    t = Theme(
        name="solarized",
        foreground="#839496",
        background="#002b36",
        accent="#268bd2",
        error="#dc322f",
        success="#859900",
        warning="#b58900",
        styles={
            "default": Style(fg="#839496", bg="#002b36"),
            "keyword": Style(fg="#268bd2"),
            "string": Style(fg="#2aa198"),
            "number": Style(fg="#d33682"),
            "comment": Style(fg="#586e75"),
            "heading": Style(fg="#268bd2", bold=True),
            "status": Style(fg="#839496", bg="#073642"),
            "error": Style(fg="#dc322f"),
            "success": Style(fg="#859900"),
            "warning": Style(fg="#b58900"),
            "info": Style(fg="#268bd2"),
            "selected": Style(fg="#002b36", bg="#268bd2"),
            "border": Style(fg="#586e75"),
        },
    )
    return t
