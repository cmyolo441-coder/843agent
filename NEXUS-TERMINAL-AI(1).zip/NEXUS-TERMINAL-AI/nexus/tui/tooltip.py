"""Tooltip component — hover help text for UI elements."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


@dataclass
class Tooltip:
    """A positioned tooltip with text content."""
    text: str = ""
    x: int = 0
    y: int = 0
    visible: bool = False


class TooltipManager:
    """Manages tooltip display and lifecycle."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._tooltip = Tooltip()
        self._delay: float = 0.5
        self._timer: float = 0.0

    async def show(self, text: str, x: int, y: int) -> None:
        """Show a tooltip at the given position."""
        self._tooltip = Tooltip(text=text, x=x, y=y, visible=True)
        self._timer = 0.0
        _log.debug("Tooltip shown at (%d, %d): %r", x, y, text[:40])

    async def hide(self) -> None:
        self._tooltip.visible = False
        self._timer = 0.0

    async def tick(self, dt: float) -> None:
        if not self._tooltip.visible:
            return
        self._timer += dt
        if self._timer >= self._delay:
            self._tooltip.visible = True

    async def render(self, width: int) -> str:
        if not self._tooltip.visible or not self._tooltip.text:
            return ""
        text = self._tooltip.text[:width]
        return f" {text} "

    def __repr__(self) -> str:
        return f"TooltipManager(visible={self._tooltip.visible})"
