"""TUI widget collection — reusable terminal UI components."""
from __future__ import annotations

from nexus.tui.widgets.chat_widget import ChatWidget
from nexus.tui.widgets.code_widget import CodeWidget
from nexus.tui.widgets.markdown_widget import MarkdownWidget
from nexus.tui.widgets.table_widget import TableWidget
from nexus.tui.widgets.tree_widget import TreeWidget
from nexus.tui.widgets.graph_widget import GraphWidget
from nexus.tui.widgets.gauge_widget import GaugeWidget
from nexus.tui.widgets.sparkline_widget import SparklineWidget
from nexus.tui.widgets.diff_widget import DiffWidget
from nexus.tui.widgets.syntax_widget import SyntaxWidget
from nexus.tui.widgets.image_widget import ImageWidget
from nexus.tui.widgets.audio_widget import AudioWidget

__all__ = [
    "ChatWidget",
    "CodeWidget",
    "MarkdownWidget",
    "TableWidget",
    "TreeWidget",
    "GraphWidget",
    "GaugeWidget",
    "SparklineWidget",
    "DiffWidget",
    "SyntaxWidget",
    "ImageWidget",
    "AudioWidget",
]
