"""Audio widget — waveform visualization and playback status display."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)

WAVEFORM_CHARS = "⡀⡄⡆⡇⣇⣧⣷⣿"


class AudioWidget:
    """Renders a simple ASCII waveform view for audio data."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._samples: list[float] = []
        self._path: str = ""
        self._duration: float = 0.0
        self._position: float = 0.0
        self._playing: bool = False

    def set_samples(self, samples: list[float], *, duration: float = 0.0) -> None:
        self._samples = samples
        self._duration = duration
        _log.debug("Audio samples set (%d points, %.1fs)", len(samples), duration)

    async def set_path(self, path: str) -> None:
        self._path = path

    async def play(self) -> None:
        self._playing = True
        _log.debug("Audio playback started")

    async def stop(self) -> None:
        self._playing = False

    async def render(self, width: int, height: int) -> str:
        if not self._samples:
            if self._path:
                return f"  [Audio: {self._path}]"
            return "  (no audio)"
        lines: list[str] = []
        status = "▶" if self._playing else "⏸"
        pos_str = f"{self._position:.1f}s / {self._duration:.1f}s" if self._duration else ""
        lines.append(f"  {status} {pos_str}")
        n = min(width - 4, len(self._samples))
        window = self._samples[-n:] if len(self._samples) > n else self._samples
        for row in range(min(height - 1, 3), 0, -1):
            threshold = row / 3.0
            wave = ""
            for s in window:
                wave += WAVEFORM_CHARS[min(len(WAVEFORM_CHARS) - 1, int(abs(s) * len(WAVEFORM_CHARS)))]
                wave += " "
            lines.append(f"  {wave}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"AudioWidget(samples={len(self._samples)}, playing={self._playing})"
