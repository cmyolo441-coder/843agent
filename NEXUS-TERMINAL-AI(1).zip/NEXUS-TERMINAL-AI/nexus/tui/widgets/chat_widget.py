"""Chat widget — scrollable conversation view with formatted messages."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class ChatWidget:
    """Displays a scrollable list of chat messages with role formatting."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._messages: list[dict[str, Any]] = []
        self._scroll_offset = 0
        self._max_visible = 20

    def add_message(self, role: str, content: str) -> None:
        self._messages.append({"role": role, "content": content})
        self._scroll_offset = max(0, len(self._messages) - self._max_visible)
        _log.debug("Chat message added from %r (%d chars)", role, len(content))

    async def render(self, width: int, height: int) -> str:
        lines: list[str] = []
        visible = self._messages[self._scroll_offset : self._scroll_offset + height]
        for msg in visible:
            role_tag = msg["role"].upper()
            for line in msg["content"].split("\n"):
                lines.append(f" [{role_tag}] {line}")
        return "\n".join(lines)

    async def scroll_up(self) -> None:
        if self._scroll_offset > 0:
            self._scroll_offset -= 1

    async def scroll_down(self) -> None:
        max_offset = max(0, len(self._messages) - self._max_visible)
        if self._scroll_offset < max_offset:
            self._scroll_offset += 1

    async def clear(self) -> None:
        self._messages.clear()
        self._scroll_offset = 0

    def __len__(self) -> int:
        return len(self._messages)

    def __repr__(self) -> str:
        return f"ChatWidget(messages={len(self._messages)})"
