"""Code widget — syntax-highlighted code block renderer."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class CodeWidget:
    """Renders a block of source code with line numbers and optional highlighting."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._code: str = ""
        self._language: str = ""
        self._highlight_line: int = -1
        self._start_line: int = 1

    def set_code(self, code: str, language: str = "") -> None:
        self._code = code
        self._language = language
        self._start_line = 1
        _log.debug("Code set for %s (%d lines)", language or "text", code.count("\n") + 1)

    async def render(self, width: int, height: int) -> str:
        lines: list[str] = []
        code_lines = self._code.split("\n")
        for i, line in enumerate(code_lines[:height]):
            lineno = self._start_line + i
            gutter = f"{lineno:>4}"
            marker = "▸" if lineno == self._highlight_line else " "
            display = line[: width - 8]
            lines.append(f" {marker}{gutter} │ {display}")
        return "\n".join(lines)

    async def highlight(self, line: int) -> None:
        self._highlight_line = line

    def __repr__(self) -> str:
        return f"CodeWidget(lines={self._code.count(chr(10)) + 1}, lang={self._language!r})"
