"""Diff widget — side-by-side or unified diff display."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class DiffWidget:
    """Renders a unified or side-by-side diff of two texts."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._old_text: str = ""
        self._new_text: str = ""
        self._mode: str = "unified"

    def set_diff(self, old_text: str, new_text: str, *, mode: str = "unified") -> None:
        self._old_text = old_text
        self._new_text = new_text
        self._mode = mode
        _log.debug("Diff set (mode=%s, old=%d chars, new=%d chars)", mode, len(old_text), len(new_text))

    async def render(self, width: int, height: int) -> str:
        if self._mode == "side-by-side":
            return await self._render_side_by_side(width, height)
        return await self._render_unified(width, height)

    async def _render_unified(self, width: int, height: int) -> str:
        old_lines = self._old_text.split("\n")
        new_lines = self._new_text.split("\n")
        lines: list[str] = []
        max_lines = max(len(old_lines), len(new_lines))
        for i in range(min(max_lines, height)):
            old = old_lines[i] if i < len(old_lines) else ""
            new = new_lines[i] if i < len(new_lines) else ""
            if old != new:
                if old:
                    lines.append(f" -{old[:width - 2]}")
                if new:
                    lines.append(f" +{new[:width - 2]}")
            else:
                lines.append(f"  {old[:width - 2]}")
        return "\n".join(lines)

    async def _render_side_by_side(self, width: int, height: int) -> str:
        old_lines = self._old_text.split("\n")
        new_lines = self._new_text.split("\n")
        half = width // 2 - 2
        lines: list[str] = []
        max_lines = max(len(old_lines), len(new_lines))
        for i in range(min(max_lines, height)):
            old = old_lines[i] if i < len(old_lines) else ""
            new = new_lines[i] if i < len(new_lines) else ""
            lines.append(f" {old[:half]:<{half}} │ {new[:half]:<{half}}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"DiffWidget(mode={self._mode!r})"
