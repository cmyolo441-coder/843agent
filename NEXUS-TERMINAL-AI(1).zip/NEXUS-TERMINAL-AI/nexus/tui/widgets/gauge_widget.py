"""Gauge widget — horizontal progress bar with label and percentage."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class GaugeWidget:
    """Renders a horizontal progress bar with label and percentage."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._value: float = 0.0
        self._maximum: float = 100.0
        self._label: str = ""
        self._width: int = 40

    def set_value(self, value: float, maximum: float | None = None) -> None:
        self._value = value
        if maximum is not None:
            self._maximum = maximum
        _log.debug("Gauge set to %.1f/%.1f", self._value, self._maximum)

    def set_label(self, label: str) -> None:
        self._label = label

    async def render(self, width: int, height: int) -> str:
        pct = min(100.0, (self._value / max(self._maximum, 1)) * 100)
        bar_width = width - len(self._label) - 8
        if bar_width < 5:
            bar_width = 5
        filled = int(bar_width * pct / 100)
        bar = "█" * filled + "░" * (bar_width - filled)
        label = f"{self._label}: " if self._label else ""
        return f" {label}[{bar}] {pct:>3.0f}%"

    def __repr__(self) -> str:
        return f"GaugeWidget({self._value:.1f}/{self._maximum:.1f})"
