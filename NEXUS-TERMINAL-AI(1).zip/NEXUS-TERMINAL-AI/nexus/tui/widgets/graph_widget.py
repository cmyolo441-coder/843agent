"""Graph widget — ascii-based graph visualization for data series."""
from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class GraphWidget:
    """Renders a simple ASCII line or bar graph from a data series."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._data: list[float] = []
        self._title: str = ""
        self._kind: str = "line"

    def set_data(self, data: list[float], *, title: str = "", kind: str = "line") -> None:
        self._data = data
        self._title = title
        self._kind = kind
        _log.debug("Graph data set (%d points, kind=%s)", len(data), kind)

    async def render(self, width: int, height: int) -> str:
        if not self._data:
            return "  (no data)"
        lines: list[str] = []
        if self._title:
            lines.append(f" {self._title}")
        min_val = min(self._data)
        max_val = max(self._data)
        range_val = max_val - min_val or 1
        plot_height = height - 2 if self._title else height - 1
        plot_height = max(3, plot_height)
        for row in range(plot_height, 0, -1):
            threshold = min_val + (range_val * (row - 1) / plot_height)
            bar = ""
            for val in self._data:
                if val >= threshold:
                    bar += "█" if self._kind == "bar" else "•"
                else:
                    bar += " "
            y_label = f"{min_val + range_val * (row - 1) / plot_height:>4.0f}"
            lines.append(f" {y_label} │{bar}")
        x_axis = "       " + "─" * max(0, len(self._data))
        lines.append(x_axis)
        if len(self._data) <= 10:
            ticks = "".join(str(i % 10) for i in range(len(self._data)))
            lines.append(f"       {ticks}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"GraphWidget(points={len(self._data)}, kind={self._kind!r})"
