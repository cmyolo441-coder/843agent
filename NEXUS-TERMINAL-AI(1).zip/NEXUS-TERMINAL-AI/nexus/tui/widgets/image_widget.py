"""Image widget — ASCII-art and half-block image preview in terminal."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class ImageWidget:
    """Renders a simple ASCII art or half-block representation of an image."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._pixels: list[list[str]] = []
        self._path: str = ""

    def load_ascii(self, art: list[str]) -> None:
        self._pixels = [list(line) for line in art]
        _log.debug("ASCII art loaded (%d rows)", len(art))

    async def set_path(self, path: str) -> None:
        self._path = path
        _log.debug("Image path set to %s", path)

    async def render(self, width: int, height: int) -> str:
        if not self._pixels:
            if self._path:
                return f"  [Image: {self._path}]"
            return "  (no image)"
        lines: list[str] = []
        for row in self._pixels[:height]:
            line = "".join(row[:width])
            lines.append(f" {line}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"ImageWidget(rows={len(self._pixels)}, path={self._path!r})"
