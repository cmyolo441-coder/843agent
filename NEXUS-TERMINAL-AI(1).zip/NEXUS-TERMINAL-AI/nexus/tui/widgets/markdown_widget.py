"""Markdown widget — renders markdown content with basic formatting."""
from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class MarkdownWidget:
    """Renders markdown-formatted text into styled terminal output."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._content: str = ""

    def set_content(self, content: str) -> None:
        self._content = content
        _log.debug("Markdown content set (%d chars)", len(content))

    async def render(self, width: int, height: int) -> str:
        lines: list[str] = []
        in_code_block = False
        for raw_line in self._content.split("\n")[:height]:
            line = raw_line[:width]
            if line.startswith("```"):
                in_code_block = not in_code_block
                lines.append(f" {'─' * (width - 2)}")
            elif in_code_block:
                lines.append(f" │ {line}")
            elif line.startswith("# "):
                lines.append(f" ┏━ {line[2:]} ")
            elif line.startswith("## "):
                lines.append(f" ┣━ {line[3:]} ")
            elif line.startswith("- ") or line.startswith("* "):
                lines.append(f" • {line[2:]}")
            elif re.match(r"^\d+\. ", line):
                lines.append(f" {line}")
            elif line.strip() == "":
                lines.append("")
            else:
                lines.append(f"  {line}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"MarkdownWidget(chars={len(self._content)})"
