"""Sparkline widget — compact inline trend visualization."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)

SPARK_CHARS = "▁▂▃▄▅▆▇█"


class SparklineWidget:
    """Renders a compact single-line sparkline chart from a data series."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._data: list[float] = []

    def set_data(self, data: list[float]) -> None:
        self._data = data[-100:]
        _log.debug("Sparkline data set (%d points)", len(self._data))

    def push(self, value: float) -> None:
        self._data.append(value)
        if len(self._data) > 100:
            self._data = self._data[-100:]

    async def render(self, width: int, height: int) -> str:
        if not self._data:
            return ""
        n = min(width, len(self._data))
        window = self._data[-n:]
        min_val = min(window)
        max_val = max(window)
        range_val = max_val - min_val or 1
        result = ""
        for val in window:
            idx = int((val - min_val) / range_val * (len(SPARK_CHARS) - 1))
            idx = max(0, min(idx, len(SPARK_CHARS) - 1))
            result += SPARK_CHARS[idx]
        return f" {result}  min={min_val:.1f} max={max_val:.1f}"

    def __repr__(self) -> str:
        return f"SparklineWidget(points={len(self._data)})"
