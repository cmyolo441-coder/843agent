"""Syntax widget — token-based syntax highlighting for source code."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)

TOKEN_COLORS: dict[str, str] = {
    "keyword": "cyan",
    "string": "green",
    "number": "yellow",
    "comment": "dim",
    "builtin": "magenta",
    "decorator": "blue",
    "function": "yellow",
    "class": "cyan",
}


class SyntaxWidget:
    """Renders source code with token-based syntax highlighting."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._code: str = ""
        self._language: str = ""
        self._tokens: list[tuple[str, str]] = []

    def set_code(self, code: str, language: str = "") -> None:
        self._code = code
        self._language = language
        self._tokenize()
        _log.debug("Syntax code set (%s, %d tokens)", language or "text", len(self._tokens))

    def _tokenize(self) -> None:
        self._tokens = []
        keywords = {"def", "class", "if", "else", "elif", "for", "while", "return",
                     "import", "from", "as", "try", "except", "finally", "with",
                     "async", "await", "yield", "lambda", "pass", "break", "continue"}
        for line in self._code.split("\n"):
            line_tokens: list[tuple[str, str]] = []
            words = line.split(" ")
            for word in words:
                if word in keywords:
                    line_tokens.append(("keyword", word))
                elif word.startswith('"') or word.startswith("'"):
                    line_tokens.append(("string", word))
                elif word.startswith("#"):
                    line_tokens.append(("comment", word))
                    break
                elif word.isdigit():
                    line_tokens.append(("number", word))
                else:
                    line_tokens.append(("text", word))
            self._tokens.append(("text", " "))
            self._tokens.extend(line_tokens)

    async def render(self, width: int, height: int) -> str:
        lines: list[str] = []
        current_line = ""
        for tok_type, tok_text in self._tokens:
            if tok_type == "text" and tok_text == " ":
                lines.append(current_line[:width])
                current_line = ""
                if len(lines) >= height:
                    break
                continue
            current_line += tok_text
        if current_line and len(lines) < height:
            lines.append(current_line[:width])
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"SyntaxWidget(lang={self._language!r})"
