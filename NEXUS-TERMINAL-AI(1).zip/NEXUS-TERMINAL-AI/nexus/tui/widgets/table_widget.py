"""Table widget — sortable, scrollable data table with column headers."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class TableWidget:
    """Displays structured data in a columnar table with sort support."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._headers: list[str] = []
        self._rows: list[list[str]] = []
        self._selected = 0
        self._sort_col = -1
        self._sort_asc = True

    def set_headers(self, *headers: str) -> None:
        self._headers = list(headers)

    def add_row(self, *cells: str) -> None:
        self._rows.append(list(cells))

    async def sort_by(self, col: int) -> None:
        if col == self._sort_col:
            self._sort_asc = not self._sort_asc
        else:
            self._sort_col = col
            self._sort_asc = True
        self._rows.sort(key=lambda r: r[col] if col < len(r) else "", reverse=not self._sort_asc)
        _log.debug("Table sorted by col %d (asc=%s)", col, self._sort_asc)

    async def render(self, width: int, height: int) -> str:
        lines: list[str] = []
        col_count = max(len(self._headers), 1)
        col_width = max(10, (width - col_count - 1) // col_count)
        sep = "─" * (col_width + 2)
        header_cells = []
        for h in self._headers:
            h_display = h[:col_width]
            header_cells.append(f" {h_display:<{col_width}} ")
        lines.append("│" + "│".join(header_cells) + "│")
        lines.append("├" + "┼".join([sep] * col_count) + "┤")
        for i, row in enumerate(self._rows[:height - 2]):
            cells = []
            for j in range(col_count):
                val = row[j] if j < len(row) else ""
                cells.append(f" {val:<{col_width}} "[:col_width + 2])
            marker = "▸" if i == self._selected else " "
            lines.append(f"{marker}{'│'.join(cells)}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"TableWidget(rows={len(self._rows)}, cols={len(self._headers)})"
