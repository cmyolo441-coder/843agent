"""Tree widget — expandable hierarchical tree view for structured data."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nexus.tui.app import App

_log = logging.getLogger(__name__)


class TreeNode:
    """A single node in a tree hierarchy."""
    def __init__(self, label: str, *, data: Any = None) -> None:
        self.label = label
        self.data = data
        self.children: list[TreeNode] = []
        self.expanded = False


class TreeWidget:
    """Renders an expandable, selectable tree structure."""

    def __init__(self, app: App) -> None:
        self.app = app
        self._roots: list[TreeNode] = []
        self._selected_path: list[int] = [0]

    def add_root(self, label: str, *, data: Any = None) -> TreeNode:
        node = TreeNode(label, data=data)
        self._roots.append(node)
        return node

    async def toggle(self) -> None:
        node = self._resolve_path(self._selected_path)
        if node is not None:
            node.expanded = not node.expanded
            _log.debug("Toggled node %r (expanded=%s)", node.label, node.expanded)

    def _resolve_path(self, path: list[int]) -> TreeNode | None:
        current: TreeNode | None = None
        for i, idx in enumerate(path):
            if i == 0:
                if idx < len(self._roots):
                    current = self._roots[idx]
                else:
                    return None
            elif current is not None and idx < len(current.children):
                current = current.children[idx]
            else:
                return None
        return current

    async def render(self, width: int, height: int) -> str:
        lines: list[str] = []
        def walk(node: TreeNode, depth: int, path: list[int]) -> None:
            if len(lines) >= height:
                return
            prefix = "  " * depth
            is_selected = path == self._selected_path[:len(path)]
            marker = "▸" if is_selected else " "
            icon = "▼" if node.expanded else "▶"
            lines.append(f" {marker}{prefix}{icon} {node.label}"[:width])
            if node.expanded:
                for i, child in enumerate(node.children):
                    walk(child, depth + 1, path + [i])
        for i, root in enumerate(self._roots):
            walk(root, 0, [i])
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"TreeWidget(roots={len(self._roots)})"
