"""Shared type aliases and structural Protocols used across NEXUS.

Centralizing these prevents circular imports between agents/tools/memory/llm.
"""
from __future__ import annotations

from typing import Any, AsyncIterator, Awaitable, Callable, Mapping, Protocol, TypeAlias, runtime_checkable

JSON: TypeAlias = dict[str, Any]
JSONList: TypeAlias = list[JSON]
Embedding: TypeAlias = list[float]
ToolResult: TypeAlias = dict[str, Any]
Handler: TypeAlias = Callable[..., Awaitable[Any]]


@runtime_checkable
class AgentLike(Protocol):
    """An agent that can be invoked with a task and returns a result."""

    name: str
    role: str

    async def run(self, task: str, /, **kwargs: Any) -> Any: ...
    async def stop(self) -> None: ...


@runtime_checkable
class ToolLike(Protocol):
    """A callable tool with a JSON schema."""

    name: str
    schema: Mapping[str, Any]

    async def call(self, **kwargs: Any) -> ToolResult: ...


@runtime_checkable
class MemoryLike(Protocol):
    """Memory backend Protocol — write/read/search."""

    async def write(self, key: str, value: Any) -> None: ...
    async def read(self, key: str) -> Any: ...
    async def search(self, query: str, k: int = 5) -> list[Any]: ...


@runtime_checkable
class LLMLike(Protocol):
    """LLM adapter contract."""

    model: str

    async def complete(self, prompt: str, **kwargs: Any) -> str: ...
    async def stream(self, prompt: str, **kwargs: Any) -> AsyncIterator[str]: ...
