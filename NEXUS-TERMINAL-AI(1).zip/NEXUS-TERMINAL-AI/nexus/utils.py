"""Utility grab-bag: hashing, deep merge, path sanitization, formatting, chunking."""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
from collections.abc import Iterable, Iterator
from pathlib import Path
from typing import Any, TypeVar

T = TypeVar("T")


def hash_obj(obj: Any, *, algo: str = "sha256") -> str:
    """Return a hex digest for any JSON-serializable object."""
    payload = json.dumps(obj, sort_keys=True, default=str, separators=(",", ":")).encode()
    return hashlib.new(algo, payload).hexdigest()


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge `override` into a deep copy of `base`."""
    out = {k: (v.copy() if isinstance(v, dict) else v) for k, v in base.items()}
    for k, v in override.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def sanitize_path(p: str | os.PathLike[str], *, root: Path | None = None) -> Path:
    """Resolve `p`, raising if it escapes `root`."""
    target = Path(p).expanduser().resolve()
    if root is not None:
        root = root.expanduser().resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise PermissionError(f"path {target} escapes root {root}") from exc
    return target


def format_bytes(n: float) -> str:
    """Human-readable byte count."""
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if abs(n) < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}EB"


def time_human(seconds: float) -> str:
    """Human-readable duration."""
    s = int(seconds)
    if s < 60:
        return f"{seconds:.1f}s"
    if s < 3600:
        return f"{s // 60}m{s % 60}s"
    if s < 86400:
        return f"{s // 3600}h{(s % 3600) // 60}m"
    return f"{s // 86400}d{(s % 86400) // 3600}h"


def chunked(seq: Iterable[T], size: int) -> Iterator[list[T]]:
    """Yield consecutive chunks of `size` from `seq`."""
    if size <= 0:
        raise ValueError("chunk size must be positive")
    batch: list[T] = []
    for item in seq:
        batch.append(item)
        if len(batch) == size:
            yield batch
            batch = []
    if batch:
        yield batch


def run_sync(coro: Any) -> Any:
    """Run a coroutine from sync code, even if a loop is already running."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    return loop.run_until_complete(coro)
