"""Nox automation entrypoints for tests, lint, type-check, and docs."""
from __future__ import annotations

import nox

nox.options.sessions = ["tests", "lint", "type"]
PYTHON_VERSIONS = ["3.12"]


@nox.session(python=PYTHON_VERSIONS)
def tests(session: nox.Session) -> None:
    session.install("-r", "requirements-dev.txt")
    session.install("-e", ".")
    session.run("pytest", "-xvs", "--cov=nexus", *session.posargs)


@nox.session(python=PYTHON_VERSIONS)
def lint(session: nox.Session) -> None:
    session.install("black", "ruff")
    session.run("black", "--check", "nexus", "tests")
    session.run("ruff", "check", "nexus", "tests")


@nox.session(python=PYTHON_VERSIONS)
def type(session: nox.Session) -> None:
    session.install("mypy", "-r", "requirements.txt")
    session.run("mypy", "nexus")


@nox.session(python=PYTHON_VERSIONS)
def docs(session: nox.Session) -> None:
    session.install("mkdocs", "mkdocs-material")
    session.run("mkdocs", "build", "-f", "docs/mkdocs.yml")
