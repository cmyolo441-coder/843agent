#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="${PYTHONPATH:-}:$PWD"
echo "Starting NEXUS in development mode..."
python3 -m nexus.main --mode repl --verbose
