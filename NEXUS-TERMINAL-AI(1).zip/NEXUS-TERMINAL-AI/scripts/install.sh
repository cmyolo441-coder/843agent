#!/usr/bin/env bash
set -euo pipefail
echo "Installing NEXUS Terminal AI..."
python3 -m pip install --upgrade pip
python3 -m pip install -e /content/NEXUS-TERMINAL-AI
echo "Done. Run 'nexus --help' to get started."
