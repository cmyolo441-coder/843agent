"""Test OpenCode models through NEXUS LLM infrastructure."""
from __future__ import annotations

import asyncio
import sys

API_KEY = "sk-uM0oXXKJGFhyn3bk9kwvjF0RfZ2MSOfKMW5kyDrYXEGZnO1ZJT8BptOX6i6ry7Ue"
BASE_URL = "https://opencode.ai/zen/v1"
MODELS = ["deepseek-v4-flash-free", "mimo-v2.5-free"]
MAX_TOKENS = 128000


async def main() -> int:
    from nexus.llm.base import LLMRequest, LLMMessage, Role
    from nexus.llm.providers.openai_provider import OpenAIProvider

    print("=" * 60)
    print("🚀 NEXUS LLM — OpenCode API Test")
    print("=" * 60)

    provider = OpenAIProvider(api_key=API_KEY, base_url=BASE_URL)

    successes = 0
    for model in MODELS:
        print(f"\n🔍 Testing model: {model}")
        try:
            req = LLMRequest(
                model=model,
                messages=[
                    LLMMessage(role=Role.SYSTEM, content="Reply in 1 sentence."),
                    LLMMessage(role=Role.USER, content="What model are you?"),
                ],
                temperature=0.7,
                max_tokens=MAX_TOKENS,
            )
            resp = await provider.agenerate(req)
            print(f"  ✅ Response: {resp.content[:100]}")
            print(f"  📊 Tokens: prompt={resp.prompt_tokens}, completion={resp.completion_tokens}")
            successes += 1
        except Exception as e:
            print(f"  ❌ Error: {e}")

    print(f"\n✅ {successes}/{len(MODELS)} models OK")
    return 0 if successes > 0 else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
