"""Test OpenCode API with deepseek-v4-flash-free model."""
from __future__ import annotations

import asyncio
import json
import sys

import httpx

API_KEY = "sk-uM0oXXKJGFhyn3bk9kwvjF0RfZ2MSOfKMW5kyDrYXEGZnO1ZJT8BptOX6i6ry7Ue"
BASE_URL = "https://opencode.ai/zen/v1"
MODELS = ["deepseek-v4-flash-free", "mimo-v2.5-free"]


async def test_model(model: str) -> dict:
    print(f"\n🔍 Testing model: {model}")
    async with httpx.AsyncClient(timeout=60.0) as client:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "You are a helpful assistant. Reply in 1 sentence."},
                {"role": "user", "content": "Say hello and tell me your name."}
            ],
            "temperature": 0.7,
            "max_tokens": 100,
        }
        try:
            resp = await client.post(
                f"{BASE_URL}/chat/completions",
                json=payload,
                headers={
                    "Authorization": f"Bearer {API_KEY}",
                    "Content-Type": "application/json",
                },
            )
            result = resp.json()
            if resp.status_code == 200:
                content = result["choices"][0]["message"]["content"]
                usage = result.get("usage", {})
                print(f"  ✅ Response: {content}")
                print(f"  📊 Usage: {json.dumps(usage)}")
                return {"model": model, "status": "ok", "response": content}
            else:
                print(f"  ❌ Error {resp.status_code}: {result}")
                return {"model": model, "status": "error", "detail": str(result)}
        except Exception as e:
            print(f"  ❌ Exception: {e}")
            return {"model": model, "status": "error", "detail": str(e)}


async def main() -> None:
    print("=" * 60)
    print("🚀 OpenCode API Test")
    print("=" * 60)
    results = await asyncio.gather(*[test_model(m) for m in MODELS])
    print("\n" + "=" * 60)
    print("📋 Summary:")
    for r in results:
        status_icon = "✅" if r["status"] == "ok" else "❌"
        print(f"  {status_icon} {r['model']}: {r['status']}")
    successes = sum(1 for r in results if r["status"] == "ok")
    print(f"\n{successes}/{len(results)} models responding correctly")
    return 0 if successes > 0 else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
