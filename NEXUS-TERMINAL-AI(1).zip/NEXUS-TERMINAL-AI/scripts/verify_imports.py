"""Verify every single Python file in the nexus package can be imported."""
from __future__ import annotations

import importlib
import pkgutil
import sys
import time
from pathlib import Path


def collect_modules() -> list[str]:
    nexus_path = Path(__file__).resolve().parent.parent / "nexus"
    sys.path.insert(0, str(nexus_path.parent))
    modules: list[str] = []
    for info in pkgutil.walk_packages([str(nexus_path)], prefix="nexus."):
        if not info.ispkg:
            modules.append(info.name)
    return modules


def main() -> int:
    modules = collect_modules()
    total = len(modules)
    print(f"Found {total} modules to verify\n")

    failed: list[tuple[str, str]] = []
    start = time.perf_counter()
    for i, mod in enumerate(modules, 1):
        try:
            importlib.import_module(mod)
            print(f"  ✅  {i:4d}/{total:4d}  {mod}")
        except Exception as e:
            failed.append((mod, str(e)))
            print(f"  ❌  {i:4d}/{total:4d}  {mod}  ->  {e}")

    elapsed = time.perf_counter() - start
    print(f"\n{'='*60}")
    print(f"Total: {total} modules  |  Passed: {total - len(failed)}  |  Failed: {len(failed)}")
    print(f"Time: {elapsed:.2f}s")

    if failed:
        print(f"\nFailed modules:")
        for mod, err in failed:
            print(f"  ❌  {mod}: {err}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
