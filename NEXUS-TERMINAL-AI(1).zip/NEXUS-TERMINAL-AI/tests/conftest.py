"""pytest fixtures for NEXUS tests."""
from __future__ import annotations

import pytest


@pytest.fixture
def event_loop():
    import asyncio
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()
