"""Minimal engine smoke test."""
from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_engine_start_stop() -> None:
    from nexus.core.engine import NexusEngine
    engine = NexusEngine(name="test")
    await engine.start(config={"test": True})
    assert engine.is_running
    await engine.stop()
    assert not engine.is_running
