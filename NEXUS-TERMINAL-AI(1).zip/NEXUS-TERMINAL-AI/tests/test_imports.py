"""Verify every public subpackage can be imported without errors."""
from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path

import nexus


def _walk_package(pkg_name: str, path: Path) -> list[str]:
    modules: list[str] = []
    for info in pkgutil.walk_packages([str(path)], prefix=f"{pkg_name}."):
        if not info.ispkg:
            modules.append(info.name)
    return modules


def test_all_modules_import() -> None:
    nexus_path = Path(nexus.__file__).parent
    modules = _walk_package("nexus", nexus_path)
    failed: list[str] = []
    for mod in modules:
        try:
            importlib.import_module(mod)
        except Exception as exc:
            failed.append(f"{mod}: {exc}")
    assert not failed, f"Import failures:\n" + "\n".join(failed)
